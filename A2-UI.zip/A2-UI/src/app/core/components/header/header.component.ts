import { Component, OnInit, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/authentication/user.service';
import { IUser } from '../../model/user.model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit, AfterViewChecked {
  username: string = '';
  // LogguserDetails: IUser = this.userService.userDetails;
  isLoggedIn: boolean = false;
  siteCheck: boolean = false;
  selectedItem: string = 'Select a Site';

  constructor(
    private userService: UserService,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private router: Router
  ) {}

  ngAfterViewChecked(): void {
    // if (this.userService.isLoggedIn == true) {
    //   //this.isLoggedIn = this.userService.isLoggedIn;
    //   this.siteCheck = true;
    //   // this.username = this.userService.userDetails.name;
    // }

    // this.username = this.userService.userDetails.name;
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    // this.isLoggedIn = this.userService.isLoggedIn;
    // this.username = this.userService.userDetails.name;
  }

  logout() {
    // this.userService.logout();
  }

  siteClick(event: any) {
    console.log(event.target.value);
    this.selectedItem = event.target.value;
    if (this.selectedItem == 'Action') {
    }
  }
  Report() {
    this.router.navigate(['home/reports']);
  }
  Reconcile() {
    this.router.navigate(['home/reconcile']);
  }
  LoginPage(){
    this.router.navigate(['home']);
  }
}

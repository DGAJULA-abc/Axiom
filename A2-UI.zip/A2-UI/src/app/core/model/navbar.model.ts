export interface ViewSites {
    userName: string
    serviceLocks: ServiceLocks
    runsheetLocks: RunsheetLocks
    sites: Site[]
    externalUser: boolean
    setupReferenceMetadata: SetupReferenceMetadaum[]
    referenceMetadata: ReferenceMetadaum[]
    permissions: Permissions
    uiPreferences: any
    userThemes: UserTheme[]
    applicationOptions: ApplicationOption[]
    routingUnit: string
    siteTimeZoneId: string
    selectedSite: SelectedSite
    superUser: boolean
    ref: Ref
  }
  
  export interface ServiceLocks {}
  
  export interface RunsheetLocks {}
  
  export interface Site {
    id: number
    description: string
    address1?: string
    address2: any
    suburb: any
    city?: string
    state?: string
    postcode?: string
    businessManager: any
    operationsManager: any
    ohsSupervisor: any
    businessManagerName: any
    operationsManagerName: any
    ohsSupervisorName: any
  }
  
  export interface SetupReferenceMetadaum {
    name: string
    readonly: boolean
    endpoint: string
    displayName: string
    uniqueKeys: any
    internalOnly: boolean
    creatable: boolean
    deletable: boolean
    updatable: boolean
    exportable: boolean
    referenceDisplayFormat?: string
    fields: Field[]
    uniqueConditions: any[]
  }
  
  export interface Field {
    name: string
    required: boolean
    creatable: boolean
    updatable: boolean
    hidden: boolean
    columnHidden: boolean
    highlight: boolean
    defaultValue?: string
    displayName?: string
    precision?: number
    maxLength?: number
    minLength: number
    reference?: string
    order: number
    groupName?: string
    type: string
    id: boolean
    originalId: boolean
    filters: Filter[]
    custom: boolean
    maxValue?: number
    minValue: number
    atLeastOneRequiredGrouping: any
    conditionallyRequiredFieldNames: any
    useForDisplay: boolean
    rangeTypeStart?: string
    rangeTypeEnd?: string
    showDependingOnFields: any[]
    validationRules: ValidationRule[]
    forceCsv: boolean
  }
  
  export interface Filter {
    field: string
    value: boolean
  }
  
  export interface ValidationRule {
    ruleName: string
    ruleValue: string
  }
  
  export interface ReferenceMetadaum {
    name: string
    readonly: boolean
    endpoint?: string
    displayName?: string
    uniqueKeys: any
    internalOnly: boolean
    creatable: boolean
    deletable: boolean
    updatable: boolean
    exportable: boolean
    referenceDisplayFormat?: string
    fields: Field2[]
    uniqueConditions: any[]
  }
  
  export interface Field2 {
    name: string
    required: boolean
    creatable: boolean
    updatable: boolean
    hidden: boolean
    columnHidden: boolean
    highlight: boolean
    defaultValue?: string
    displayName?: string
    precision?: number
    maxLength?: number
    minLength: number
    reference?: string
    order: number
    groupName?: string
    type: string
    id: boolean
    originalId: boolean
    filters: Filter2[]
    custom: boolean
    maxValue?: number
    minValue: number
    atLeastOneRequiredGrouping?: string[]
    conditionallyRequiredFieldNames?: string[]
    useForDisplay: boolean
    rangeTypeStart?: string
    rangeTypeEnd?: string
    showDependingOnFields: any[]
    validationRules: ValidationRule2[]
    forceCsv: boolean
  }
  
  export interface Filter2 {
    field: string
    value: boolean
  }
  
  export interface ValidationRule2 {
    ruleName: string
    ruleValue: string
  }
  
  export interface Permissions {
    userId: string
    userName: string
    sitePermissions: SitePermission[]
  }
  
  export interface SitePermission {
    siteId: number
    permissions: Permission[]
  }
  
  export interface Permission {
    groupId: number
    id: string
    read: boolean
    write: boolean
  }
  
  export interface UserTheme {
    label: string
    defaultSetting: boolean
    contextRoot: string
  }
  
  export interface ApplicationOption {
    applicationOptionId: number
    siteId: number
    userId?: string
    optionName: string
    optionValue: string
  }
  
  export interface SelectedSite {
    id: number
    description: string
    address1: any
    address2: any
    suburb: any
    city: any
    state: any
    postcode: any
    businessManager: any
    operationsManager: any
    ohsSupervisor: any
    businessManagerName: any
    operationsManagerName: any
    ohsSupervisorName: any
    permissions: Permissions2
  }
  
  export interface Permissions2 {
    siteId: number
    permissions: Permission2[]
  }
  
  export interface Permission2 {
    groupId: number
    id: string
    read: boolean
    write: boolean
  }
  
  export interface Ref {
    activityTypes: ActivityType[]
    adjustmentTypes: AdjustmentType[]
    breakTypes: BreakType[]
    companys: Company[]
    companyTypes: CompanyType[]
    companyMasters: CompanyMaster[]
    containers: Container[]
    containerTypes: ContainerType[]
    containerStatuses: ContainerStatuse[]
    customerGroups: CustomerGroup[]
    customers: Customer[]
    docks: Dock[]
    drivers: Driver[]
    eventTypes: EventType[]
    loadTypes: LoadType[]
    locations: Location[]
    locationTypes: LocationType[]
    permissionGroups: PermissionGroup[]
    multiLegSites: MultiLegSite[]
    allMultiLegSites: AllMultiLegSite[]
    payBases: PayBase[]
    pointKMs: PointKm[]
    reasons: Reason[]
    refPermissionSites: any
    sites: Site2[]
    regions: Region[]
    routes: Route[]
    runsheetTypes: RunsheetType[]
    serviceTypes: ServiceType[]
    siteOptions: SiteOption[]
    trailers: Trailer[]
    trailerTypes: TrailerType[]
    trucks: Truck[]
    truckSizes: TruckSize[]
    truckTypes: TruckType[]
    units: Unit[]
    vessels: Vessel[]
    zoneCharges: ZoneCharge[]
    zonePays: ZonePay[]
    rates: Rate[]
    windows: Window[]
    periodicPeriods: string[]
    systemOptions: SystemOption[]
    userOptions: UserOption[]
    userDatas: UserData[]
    mapSources: MapSource[]
    homeLocations: HomeLocation[]
    activityCategories: ActivityCategory[]
    workGroups: WorkGroup[]
    loadPriorities: LoadPriority[]
    creditNoteReportFormats: CreditNoteReportFormat[]
    driverSummaryReportFormats: DriverSummaryReportFormat[]
    invoiceReportFormats: InvoiceReportFormat[]
    payAdviceReportFormats: PayAdviceReportFormat[]
    runsheetReportFormats: RunsheetReportFormat[]
    trackingPreferenceOptions: TrackingPreferenceOption[]
    runsheetCalculationTypes: RunsheetCalculationType[]
    invoiceRemarksModes: InvoiceRemarksMode[]
    curfewWindows: CurfewWindow[]
    rateCategories: RateCategory[]
    rateMethods: RateMethod[]
    rateMethodFieldMapgs: RateMethodFieldMapg[]
    states: State[]
    multiLegUnitCompare: MultiLegUnitCompare[]
    multiLegDriverTypes: MultiLegDriverType[]
    multiLegServiceDates: MultiLegServiceDate[]
    ansConnectionTypes: AnsConnectionType[]
    ansActions: AnsAction[]
  }
  
  export interface ActivityType {
    id: number
    name: string
    code: string
  }
  
  export interface AdjustmentType {
    adjustmentTypeId: string
    siteId: number
    adjustmentTypeDesc?: string
    adjustInvoice: boolean
    adjustPayAdvise: boolean
    negateValue: boolean
    showReCharge: boolean
    requiredServiceId: boolean
    defaultAmt?: number
    active: boolean
  }
  
  export interface BreakType {
    typeId: string
    siteId: number
    description?: string
    breakPaid: boolean
    minutes?: number
    minLength?: number
    maxLength?: number
    active: boolean
  }
  
  export interface Company {
    companyId: string
    companyName: string
    siteId: number
    companyType: string
    personId?: number
    personName?: string
    customerId: any
    active: boolean
    paFormat: any
    activeHistory: ActiveHistory[]
    masterActive: boolean
  }
  
  export interface ActiveHistory {
    id: number
    companyId: string
    siteId: number
    statusFrom: number
    active: boolean
  }
  
  export interface CompanyType {
    companyTypeId: string
    description?: string
    paFormat?: number
    active: boolean
  }
  
  export interface CompanyMaster {
    vendorId: string
    vendorName?: string
    active: boolean
  }
  
  export interface Container {
    containerId: string
    siteId: number
    containerType?: string
    containerStatusId?: string
    statusUdpdated?: number
    companyId?: string
    containerDesc?: string
    weightTonnes?: number
    permanent: boolean
    onHire: boolean
    locationId?: string
    dropDate?: number
    pickupDate?: number
  }
  
  export interface ContainerType {
    containerTypeId: string
    siteId: number
    capacity?: number
    description?: string
    active: boolean
  }
  
  export interface ContainerStatuse {
    id: string
  }
  
  export interface CustomerGroup {
    groupId: string
    siteId: number
    groupName?: string
    invFormat?: number
    cnFormat?: number
    active: boolean
  }
  
  export interface Customer {
    customerId: string
    siteId: number
    customerName?: string
    personIdContact?: number
    personContactName?: string
    personIdBilling?: number
    personBillingName?: string
    groupId?: string
    groupName?: string
    invFormat?: number
    invFormatName?: string
    applyGST: boolean
    internalCustomer: boolean
    allowContPickupDrop: boolean
    fuelLevyChargeRate?: number
    fuelLevyPayRate: any
    scheduleEntryForm?: string
    scheduledImportFunction?: string
    uniqueLoadNo: boolean
    numericLoadNo: boolean
    loadNoMinLen: any
    loadNoMaxLen: any
    glCodeBranch: string
    abn?: string
    debtorCode?: string
    active: boolean
    cnFormat?: number
    cnFormatName?: string
    invUnit1?: string
    invUnit2: any
    invUnit3: any
    invUnit4: any
    invUnit5: any
    invUnit6: any
    invUnit7: any
    invUnit8: any
    customBillingName1?: string
    customBillingName2?: string
    customBillingName3?: string
    customBillingValue1?: string
    customBillingValue2?: string
    customBillingValue3?: string
    invoiceRemarksMode: number
    invoiceRemarksModeName?: string
  }
  
  export interface Dock {
    id: number
    siteId: number
    dockName: string
    locationId?: string
    homeLocationId?: string
    active: boolean
  }
  
  export interface Driver {
    id: number
    siteId: number
    personId: number
    firstName?: string
    surname?: string
    employeeName?: string
    mdtCode?: string
    groupDriver: boolean
    companyId: string
    vendorName: string
    truckId?: string
    trailerId?: string
    payBasisId?: string
    homeLocationId?: string
    active: boolean
    mobile?: string
    invalidationDate?: number
    entityDriver: boolean
  }
  
  export interface EventType {
    id: number
    siteId: number
    eventDesc: string
    todExportable: boolean
  }
  
  export interface LoadType {
    loadTypeId: string
    siteId: number
    loadTypeDescription?: string
    serviceTypeId: any
    customerId?: string
    active: boolean
  }
  
  export interface Location {
    locationId: string
    siteId: number
    locationTypeId?: string
    locationDesc?: string
    zonePayId?: string
    zoneChargeId?: string
    suburb?: string
    active: boolean
    loadTimeMins?: number
    address1?: string
    address2?: string
    state?: string
    postCode?: string
    window1From?: number
    window1To?: number
    window2From?: number
    window2To?: number
    window3From: any
    window3To: any
    personIdContact?: number
    personIdContactName?: string
    customerId?: string
    locationCode?: string
    latitude?: number
    longitude?: number
    geofence?: number
    mapSourceId: any
    mapReference?: string
    remarks: any
    truckSizeLimit: any
    defaultTripSeq: any
    routeId?: string
    permanent: boolean
    loadTimeMinsPerUnit: any
    loadTimeUnit: any
    waitTimeMins?: number
    waitTimeMinsPerUnit: any
    waitTimeUnit: any
    accShortCut?: string
    locationIdGroup?: string
    siteTravelTime?: number
    disableWPUpdated: boolean
    externalLookUp?: string
    internalLookUp: any
    segManaged: boolean
    segExported: boolean
    routeCapacity: any
  }
  
  export interface LocationType {
    locationTypeId: string
    siteId: number
    locationTypeDesc?: string
    active: boolean
  }
  
  export interface PermissionGroup {
    permissionGroupId: number
    permissionGroupDesc: string
    allowNewUsers: boolean
  }
  
  export interface MultiLegSite {
    id: number
    description: string
    address1: any
    address2: any
    suburb: any
    city: any
    state: any
    postcode: any
    businessManager: any
    operationsManager: any
    ohsSupervisor: any
    businessManagerName: any
    operationsManagerName: any
    ohsSupervisorName: any
  }
  
  export interface AllMultiLegSite {
    id: number
    description: string
    address1: any
    address2: any
    suburb: any
    city: any
    state: any
    postcode: any
    businessManager: any
    operationsManager: any
    ohsSupervisor: any
    businessManagerName: any
    operationsManagerName: any
    ohsSupervisorName: any
  }
  
  export interface PayBase {
    id: string
    siteId: number
    desc?: string
    active: boolean
  }
  
  export interface PointKm {
    id: number
    siteId: number
    locationFrom: string
    locationTo: string
    km: number
    mins?: number
    practicalKm?: number
    practicalMins?: number
    calculatedMins: any
    lastModified?: number
    numberOfExaminedJourneys: any
    routeRequestMins?: number
    source?: string
  }
  
  export interface Reason {
    reasonId: string
    siteId: number
    reasonDescription: string
    driver: boolean
    active: boolean
  }
  
  export interface Site2 {
    id: number
    description: string
    address1?: string
    address2: any
    suburb: any
    city?: string
    state?: string
    postcode?: string
    businessManager: any
    operationsManager: any
    ohsSupervisor: any
    businessManagerName: any
    operationsManagerName: any
    ohsSupervisorName: any
  }
  
  export interface Region {
    regionId: string
    siteId: number
    regionDescription?: string
    active: boolean
  }
  
  export interface Route {
    routeId: string
    siteId: number
    regionId: string
    routeDescription?: string
    active: boolean
    routeIdUpperCase: string
  }
  
  export interface RunsheetType {
    runsheetTypeId: string
    runsheetTypeDesc: string
    siteId: number
    allowNoLines: boolean
    active: boolean
  }
  
  export interface ServiceType {
    serviceTypeId: string
    serviceTypeDescription?: string
    customerId?: string
    categoryId?: number
    sortOrder?: number
    printOrder: any
    active: boolean
    unit1?: string
    reqUnit1: boolean
    maxQty1?: number
    runsheetCalcId1?: string
    defaultQty1?: number
    unit2?: string
    reqUnit2: boolean
    maxQty2?: number
    runsheetCalcId2?: string
    defaultQty2?: number
    unit3?: string
    reqUnit3: boolean
    maxQty3?: number
    runsheetCalcId3?: string
    defaultQty3: any
    unit4?: string
    reqUnit4: boolean
    maxQty4?: number
    runsheetCalcId4: any
    defaultQty4: any
    unit5?: string
    reqUnit5: boolean
    maxQty5?: number
    runsheetCalcId5: any
    defaultQty5: any
    unit6?: string
    reqUnit6: boolean
    maxQty6?: number
    runsheetCalcId6: any
    defaultQty6: any
    unit7?: string
    reqUnit7: boolean
    maxQty7?: number
    runsheetCalcId7: any
    defaultQty7: any
    unit8?: string
    reqUnit8: boolean
    maxQty8?: number
    runsheetCalcId8: any
    defaultQty8: any
    createInvoiceLine: boolean
    hireContainer: boolean
    hireTrailer: boolean
    onRunsheets: boolean
    allowZeroChargeAmt: boolean
    applyFuelLevy: boolean
    applyRoute: boolean
    allowNoRunsheet: boolean
    singleTripRunsheets: boolean
    loadTypeIdPref?: string
    disableTripRating: boolean
    allowBonusPay: boolean
    applyDiscount?: boolean
    mdAllowReject: boolean
    mdAllowCancel: boolean
    mdAllowLoadNoEdit: boolean
    mdTimeMapArrPickup?: number
    mdTimeMapRdyPickup: any
    mdTimeMapDptPickup?: number
    mdTimeMapArrDrop?: number
    mdTimeMapDockDrop?: number
    mdTimeMapRdyDrop?: number
    mdTimeMapDptDrop?: number
    mdTimeMapDockPickup: any
    mdAllowRequest: boolean
    mdtException: boolean
    showTruck: boolean
    showTrailer: boolean
    showContainer: boolean
    showTrailerTag: boolean
    showLoad: boolean
    showDocket: boolean
    showOffSiderUsed: boolean
    labelContPickup: any
    showContainerDrop: boolean
    showContainerPickup: boolean
    showLoadLocation: boolean
    showOwnTrailer: boolean
    hireTruck: boolean
    reqTrailer: boolean
    reqTruck: boolean
    reqContainer: boolean
    reqDocket: boolean
    labelContDrop: any
    labelLoadLocation: any
    tempDecimalPlaces: any
    showPickupLocation: boolean
    showPickupArrTemp: boolean
    showPickupArrTime: boolean
    showPickupDptTemp: boolean
    showPickupDptTime: boolean
    showPickupRdyTemp: boolean
    showPickupRdyTime: boolean
    showPickupDocTemp: boolean
    showPickupDocTime: boolean
    reqPickupArrTime: boolean
    reqPickupDptTime: boolean
    reqPickupLocation: boolean
    labelPickup?: string
    labelPickupDocTime: any
    labelPickupArrTime: any
    labelPickupDptTime: any
    reqPickupRdyTime: boolean
    reqPickupDocTime: boolean
    labelPickupRdyTime: any
    reqPickupArrTemp: boolean
    reqPickupDocTemp: boolean
    reqPickupRdyTemp: boolean
    reqPickupDptTemp: boolean
    showDropLocation: boolean
    showDropArrTemp: boolean
    showDropArrTime: boolean
    showDropDptTemp: boolean
    showDropDptTime: boolean
    showDropRdyTemp: boolean
    showDropRdyTime: boolean
    showDropDocTemp: boolean
    showDropDocTime: boolean
    reqDropArrTime: boolean
    reqDropRdyTime: boolean
    reqDropDptTime: boolean
    reqDropDocTemp: boolean
    reqDropLocation: boolean
    reqDropRdyTemp: boolean
    reqDropDocTime: boolean
    reqDropDptTemp: boolean
    reqDropArrTemp: boolean
    labelDropArrTime?: string
    labelDrop?: string
    siteId: number
    labelDropRdyTime?: string
    labelDropDptTime: any
    labelDropDocTime?: string
  }
  
  export interface SiteOption {
    siteId: number
    optionName: string
    optionValue?: string
  }
  
  export interface Trailer {
    trailerId: string
    siteId: number
    trailerTypeId?: string
    tare?: number
    routeCapacity?: number
    companyId?: string
    fleetNumber?: string
    customerId?: string
    trailerIdTag: any
    trackableObjectId?: number
    costPerKm?: number
    costPerDay: any
    regoExpiry: any
    trailerDesc?: string
    homeLocationId?: string
    onHire: boolean
    locationId?: string
    dropDate: any
    pickupDate: any
    hireRateDaily?: number
    active: boolean
    trailerTypeDesc: any
    odometerKms: any
    transmittedTs: any
  }
  
  export interface TrailerType {
    trailerTypeId: string
    siteId: number
    trailerTypeDesc?: string
    capacity?: number
    loadTypeId?: string
    allowLead: boolean
    allowTag: boolean
    volumeConversion?: number
    active: boolean
  }
  
  export interface Truck {
    truckId: string
    siteId: number
    truckTypeId?: string
    truckDesc?: string
    trailerId?: string
    routeCapacity?: number
    fleetNumber?: string
    active: boolean
    trailerIdTag?: string
    companyId?: string
    costPerKm?: number
    hireRateHourly: any
    tare?: number
    regoExpiry: any
    truckSizeId?: number
    truckSize?: number
    costPerDay?: number
    phoneNumber: any
    onHire: boolean
    homeLocationId: any
    makeId: any
    equipmentGroupId: any
    year: any
    trackableObjectId?: number
    externalLookup?: string
    truckTypeDesc: any
    rigid: boolean
    odometerKms: any
    transmittedTs: any
  }
  
  export interface TruckSize {
    id: number
    siteId: number
    truckSize: number
    truckSizeDesc: string
    active: boolean
  }
  
  export interface TruckType {
    truckTypeId: string
    siteId: number
    truckTypeDesc?: string
    truckSizeId?: number
    volumeConversion?: number
    dockable: boolean
    allowTrailer: boolean
    active: boolean
  }
  
  export interface Unit {
    unitId: string
    siteId: number
    decimalPlaces?: number
    allowNegative: boolean
  }
  
  export interface Vessel {
    id: number
    siteId: number
    vessel: string
  }
  
  export interface ZoneCharge {
    id: string
    siteId: number
    desc?: string
    active: boolean
  }
  
  export interface ZonePay {
    id: string
    siteId: number
    desc?: string
    active: boolean
  }
  
  export interface Rate {
    rateId: string
    siteId: number
    ratedesc?: string
    rateType: number
    methodId: string
    methodDesc: any
    zeroAllowed: boolean
    perStop?: number
    threshold?: number
    unit01?: string
    unit02?: string
    unit03: any
    unit04: any
    rate01?: number
    rate02?: number
    rate03?: number
    rate04?: number
    rate05?: number
    rate06?: number
    rate07?: number
    rate08?: number
    rate09?: number
    rate10?: number
    rate11?: number
    rate12?: number
    rate13?: number
    rate14?: number
    rate15?: number
    rate16?: number
    rate17?: number
    rate18: any
    rate19?: number
    rate20: any
    rate21?: number
    rate22?: number
    rate23?: number
    rate24?: number
    rate25?: number
    rate26?: number
    rate27?: number
    rate28: any
    rate29?: number
    rate30?: number
    showPayByRunsheet: boolean
    showPayByLine: boolean
    showCharge: boolean
    showPayByTrip: boolean
  }
  
  export interface Window {
    id: number
    siteId: number
    locationId?: string
    serviceTypeId?: string
    loadTypeId: any
    customerId?: string
    locationIdPickup?: string
    windowDay?: number
    effectiveDateFrom: any
    effectiveDateTo: any
    window1from?: number
    window1to?: number
    window2from: any
    window2to: any
    window3from: any
    window3to: any
  }
  
  export interface SystemOption {
    optionName: string
    optionValue: string
  }
  
  export interface UserOption {
    siteId: number
    optionName: string
    optionUser: string
    optionValue?: string
  }
  
  export interface UserData {
    userId: string
    siteId: number
    userName: string
    permissionGroupId?: number
    sessionUpdate: any
    altPermGroupStart: any
    altPermGroupEnd: any
    altPermGroupId: any
    workGroupId?: string
    entityUser: boolean
  }
  
  export interface MapSource {
    id: string
  }
  
  export interface HomeLocation {
    homeLocationId: string
    siteId: number
    homeLocationDesc?: string
    active: boolean
  }
  
  export interface ActivityCategory {
    id: number
    category: string
    productive: boolean
  }
  
  export interface WorkGroup {
    workGroupId: string
    siteId: number
    workGroupDesc: string
    active: boolean
  }
  
  export interface LoadPriority {
    id: number
    name: string
  }
  
  export interface CreditNoteReportFormat {
    id: number
    name: string
  }
  
  export interface DriverSummaryReportFormat {
    id: number
    name: string
  }
  
  export interface InvoiceReportFormat {
    id: number
    name: string
  }
  
  export interface PayAdviceReportFormat {
    id: number
    name: string
  }
  
  export interface RunsheetReportFormat {
    id: number
    name: string
  }
  
  export interface TrackingPreferenceOption {
    name: string
  }
  
  export interface RunsheetCalculationType {
    name: string
    description: string
  }
  
  export interface InvoiceRemarksMode {
    id: number
    name: string
  }
  
  export interface CurfewWindow {
    id: number
    siteId: number
    windowDay: number
    startTime?: number
    endDay?: number
    endTime: any
    locationId?: string
  }
  
  export interface RateCategory {
    id: number
    description: string
    active: boolean
  }
  
  export interface RateMethod {
    id: number
    methodId: string
    description: string
    methodLabel: string
    rateCategoryTypeId: number
    displayOrder: number
    active: boolean
  }
  
  export interface RateMethodFieldMapg {
    id: number
    methodId: string
    fieldType: string
    fieldName: string
    fieldLabel?: string
    fieldValue?: string
    fieldGroup: string
    fieldOrder: number
    active: boolean
  }
  
  export interface State {
    label: string
  }
  
  export interface MultiLegUnitCompare {
    id: string
    displayValue: string
  }
  
  export interface MultiLegDriverType {
    id: number
    displayValue: string
  }
  
  export interface MultiLegServiceDate {
    id: number
    displayValue: string
  }
  
  export interface AnsConnectionType {
    id: string
    displayValue: string
  }
  
  export interface AnsAction {
    id: number
    groupId: number
    actionName: string
    description?: string
  }
  
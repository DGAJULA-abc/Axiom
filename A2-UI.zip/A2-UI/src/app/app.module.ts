import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from './core/core.module';
import { AuthenticationModule } from './features/authentication/authentication.module';
import { SharedModule } from './shared/shared.module';
import { ApiInterceptor } from './core/components/interceptors/api.interceptor';
import { BasicAuthInterceptor, ErrorInterceptor, fakeBackendProvider } from './shared/_helper';
import { PlanModule } from './features/plan/plan.module';
import { ReconcileModule } from './features/reconcile/reconcile.module';
import { SetupModule } from './features/setup/setup.module';
import { ReportsModule } from './features/reports/reports.module';
import { ReportViewModule } from './features/reportview/report-view.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    PlanModule,
    ReconcileModule,
    CoreModule,
    SharedModule,
    AuthenticationModule,
    SetupModule,
    ReportsModule,
    ReportViewModule,
    ConfirmDialogModule
    //material
    // ToastrModule.forRoot({
    //   positionClass: 'toast-top-right',
    // }),
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: BasicAuthInterceptor, multi: true },
  { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
   ConfirmationService

    // provider used to create fake backend
    // fakeBackendProvider
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

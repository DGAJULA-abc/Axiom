import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFoldersComponent } from './edit-folders.component';

describe('EditFoldersComponent', () => {
  let component: EditFoldersComponent;
  let fixture: ComponentFixture<EditFoldersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditFoldersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditFoldersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

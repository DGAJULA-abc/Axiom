import { Component, ViewChild, Inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, IRowNode, GetRowIdParams, GridApi, GridReadyEvent } from 'ag-grid-community';
import { DeleteFolderComponent } from '../delete-folder/delete-folder.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { IDandName } from '../model/report.model';
import { ReportService } from '../services/report.service';
import { MatSelect } from '@angular/material/select';
import { DeletepopupComponent } from '../../setup/deletepopup/deletepopup.component';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
import { UnsavedChangesDialogComponent } from '../../setup/unsaved-changes-dialog/unsaved-changes-dialog.component';


@Component({
  selector: 'app-edit-folders',
  templateUrl: './edit-folders.component.html',
  styleUrls: ['./edit-folders.component.scss'],
})
export class EditFoldersComponent {
  @ViewChild('closebutton') closebutton: { nativeElement: { click: () => void; }; };
  @ViewChild('mySelect') mySelect: MatSelect;

  // properties
  isEdit: boolean = false;
  isDisabled: boolean = true;
  rowData: IDandName[] = [];    
  gridApi: GridApi<IDandName>;
  selectedOptions: any[];
  colDefs: ColDef[] = [
    { headerName: 'Name',field: 'name', resizable: true, filter: true, floatingFilter: true },
  ];
  columnDefs: ColDef[] = this.colDefs;
  selectedRowNode: null | IRowNode<IDandName>;
  createQlrFolderTemplate = { id: null, name: "" };
  

  constructor(public dialogRef: MatDialogRef<EditFoldersComponent>, public dialog: MatDialog, @Inject(MAT_DIALOG_DATA) public data: IDandName[], private reportService: ReportService,public permission: PermissionsService) {
    this.rowData = data;
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  canWrite: boolean = true
  async permissionMethod() {
    try {
      const permission1 = await this.permission.isSuperUser();
      console.log(permission1)
      this.canWrite = permission1;
    } catch (error) {
      console.error("Error:", error);
    }
  }

  getRowDataId = (params: GetRowIdParams) => {
    return params.data.id;
  }

  getSelectedRowNodeName() {
    return (this.selectedRowNode?.data ? this.selectedRowNode.data.name : null);
  }  

  openDeleteDialog() {
    const dialogRef = this.dialog.open(DeletepopupComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result == true && this.selectedRowNode?.data?.id != null) {
        // call delete QLR Report API
        this.reportService.deleteQlrFolder(this.selectedRowNode.data.id).subscribe(
          (result: any) => {
            if (this.selectedRowNode?.data?.id) {              
              // remove folder from grid
              this.gridApi.applyTransaction({ remove: [this.selectedRowNode?.data] });
              this.selectedRowNode = null;

              // close edit section.
              this.isEdit = false;  
            }        
          }
        );        
      }
    });
  }

  onCloseClick() {
    let rowDataTemp: any[] = [];
    this.gridApi.forEachNode(function (node) {
      rowDataTemp.push(node.data);
    });    
    this.dialogRef.close(rowDataTemp);    
  }

  onNewButtonClick() {
    // unselect the selected row.
    if (this.selectedRowNode) {
      this.selectedRowNode.setSelected(false);
    }
    this.selectedRowNode = null;
    this.isEdit = true;
    this.isDisabled = true;

  }

  onRowSelected(event: any) {   
    if (event.node.isSelected()) {
      this.selectedRowNode = event.node;      
      this.isEdit = true;   
      this.isDisabled = true; // disable Save button as nothing is edited yet.
    } 
  }

  onSaveClick() {
    if (this.selectedRowNode?.data?.id) {
      // id has a value so this is an update.
      
      this.selectedRowNode.data.name = this.createQlrFolderTemplate.name; // get updated name from template object.
      
      this.reportService.saveQlrFolder(this.selectedRowNode.data).subscribe(
        (result: IDandName[]) => {
          this.selectedRowNode?.setData(result[0]);          
        }
      );
    } else {
      // nothing is selected so this is a create.
      if (this.selectedRowNode == null) {
        this.reportService.createQlrFolder(this.createQlrFolderTemplate).subscribe(
          (result: IDandName[]) => {
            // add to grid since it's a new record.
            this.gridApi.applyTransaction({ add: result });
            // close edit section.
            this.isEdit = false;
          }
        );
      }
    }
  }

  onGridReady(params: GridReadyEvent<IDandName>) {
    this.gridApi = params.api;   
  }

  onInput(event: any){
    
    // Get the input's value
    let text = event.target.value;

    this.createQlrFolderTemplate.name = text;

    // Keep the button disabled if input is empty
    if(text==''){
      this.isDisabled = true;
    } else {
      this.isDisabled = false;
    }
  }
  
  public  onNoClick() {
    this.closebutton.nativeElement.click();
  }
  ngOnInit(): void {
    this.selectedOptions = this.colDefs.map((coulmn) => coulmn.field);
  }
  onSelectionChange(event: any) {
    console.log(event.value);
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach(element => {
      this.gridApi.destroyFilter(element.field!);
    });

  }
  isEditing: boolean = false;
  closeDialog() {
    if(this.selectedRowNode?.data ? this.selectedRowNode.data.name: null){
      if(this.isEditing){
        if (this.isEdit ) {
          const dialogRef = this.dialog.open(UnsavedChangesDialogComponent);
          dialogRef.afterClosed().subscribe(result => {
              if (result === 'discard') {
                  // Discard changes and close the dialog
                
                  this.isEdit = false;
               
              } else {
                
              }
          });
      }
      }
    }
    else {
        // No changes to discard, simply close the dialog
        this.isEdit = false;
        this.isEditing = true;
    }
  }
}

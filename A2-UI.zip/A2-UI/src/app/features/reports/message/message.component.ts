import { Component } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss'],
})
export class MessageComponent {
  queryNumber: string = 'TLQ0475';
  layoutNumber: string = 'TLQ0475A';
  show: boolean = true;
}

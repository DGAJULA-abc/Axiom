import { Site } from "src/app/shared/model/context-vew.model";
import { ActionGroupList } from "src/app/shared/model/shared.model";

export interface ViewReport {
    actionGroupList: ActionGroupList
    permissionGroups: {
        allowNewUsers: boolean
        permissionGroupDesc: string
        permissionGroupId: number
    }[]
    qlrFolders: IDandName[]
    qlrLayouts: {
        name: string
        owner: string
        titleText: string
    }[]
    qlrQueries: {
        description: string
        name: string
        owner: string
    }[]
    qlrReports: QlrReports[],
    qlrServers: IDandName[],
    refSites: Site[],
    selectedSite: number
    superUser: boolean
    userGroupId: number
}

export interface QlrReports {
  allGroups: boolean;
  allSites: boolean;
  description: null | string;
  enabled: boolean;
  folderId: null | number;
  groupIds: number[];
  id: null | number;
  layout: null | string;
  name: string;
  query: string;
  serverId: number;
  siteIds: number[];
  siteParam: boolean;
}

export interface IDandName {
    id: null | number,
    name: string
}
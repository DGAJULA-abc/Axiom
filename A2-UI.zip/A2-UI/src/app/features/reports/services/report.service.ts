import { Injectable } from '@angular/core';
import { QlrReports, ViewReport, IDandName } from '../model/report.model';
import { HttpClient } from '@angular/common/http';
import { Site } from 'src/app/shared/model/navbar.model';
import { apiEndpoint, localEndpoint } from '../../../config/config.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  public viewReport: ViewReport;
  constructor(
    private http: HttpClient
  ) { }

  deleteQlrFolder (id: number) {
    let options: any = {
      body: [id]
    };    
    
    return this.http.delete<any>(apiEndpoint.report.qlrFolder, options);
  }

  deleteQlrReport (id: number) {
    let options: any = {
      body: [id]
    };    
    
    return this.http.delete<any>(apiEndpoint.report.qlr, options);
  }

  saveQlrFolder(qlrFolder: IDandName) {  
  
    let options: IDandName[] = [];
    options.push(qlrFolder); 
    
    // test data
    //options =[{"name":"test", id: null}];
    
    return this.http.post<any>(apiEndpoint.report.qlrFolder, options);
  }

  saveQlrNewFolder(data: any) {
    let options: QlrReports[] =[];
    options.push(data);
    return this.http.post<any>(apiEndpoint.report.qlrNewFolder, options);
  }

  createQlrFolder(qlrFolder: IDandName) {  
  
    let options: IDandName[] = [];
    options.push(qlrFolder); 
    
    // test data
    //options =[{"name":"test", id: null}];
    
    return this.http.put<any>(apiEndpoint.report.qlrFolder, options);
  }

  createQlrReport(qlrReport: QlrReports) {
  
    let options: QlrReports[] = [];
    options.push(qlrReport); 
    
    // test data
  //   options = [
  //     {
  //         "id": null,
  //         "query": "test",
  //         "layout": null,
  //         "name": "test",
  //         "description": null,
  //         "folderId": null,
  //         "allSites": false,
  //         "allGroups": false,
  //         "enabled": false,
  //         "siteParam": false,
  //         "serverId": 1,
  //         "groupIds": [],
  //         "siteIds": []
  //     }
  // ];
    
    return this.http.put<any>(apiEndpoint.report.qlr, options);
  }

  saveQlrReport(qlrReport: QlrReports) {

    let options: QlrReports[] = [];
    options.push(qlrReport); 
    
    // test data
    //options = [{"id":7,"query":"TLQ0308","layout":"TLQ0308A","name":"Invoice Backing Sheet","description":"test123","folderId":0,"allSites":false,"allGroups":true,"enabled":true,"siteParam":false,"serverId":1,"siteIds":[890,102,802,806,835,832,352,852,452,252],"groupIds":[]}];   
    
    return this.http.post<any>(apiEndpoint.report.qlr, options);
  }

  getReportViewDetails() {

    // get Report screen context
    let options :any = [];    
    
    // mock data call
    //return this.http.get<ViewReport>('assets/APIs/report-view.json', options);
    
    return this.http.get<ViewReport>(apiEndpoint.report.contextView, options);
  }
 
  getSiteDetails() : Observable<Site[]> {
      return this.http.get<Site[]>('assets/APIs/context-view.json');
    }
}

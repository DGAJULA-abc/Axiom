import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QlrMenuComponent } from './qlr-menu/qlr-menu.component';

import { ReportsComponent } from './reports.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { EditFoldersComponent } from './edit-folders/edit-folders.component';

const routes: Routes = [
  { path: '', component: ReportsComponent,
  children: [
    {
      path: '',
      component: LandingPageComponent
    },
    {
      path:'edit_folder',
      component: EditFoldersComponent
    },
    {
      path:'Report.QLRMenu',
      component: QlrMenuComponent
    }
  ]
 }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReportsRoutingModule {}

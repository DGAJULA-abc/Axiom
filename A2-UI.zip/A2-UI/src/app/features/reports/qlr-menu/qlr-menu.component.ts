import { Component, EventEmitter, OnInit, AfterViewInit, Output, ViewChild } from '@angular/core';
import { EditFoldersComponent } from '../edit-folders/edit-folders.component';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GridApi, GridReadyEvent, IRowNode } from 'ag-grid-community';
import { HttpClient } from '@angular/common/http';
import { IDandName, QlrReports, ViewReport } from '../model/report.model';
import { Site } from "src/app/shared/model/context-vew.model";
import { ReportService } from '../services/report.service';
import { DeleteFolderComponent } from '../delete-folder/delete-folder.component';
import { MatSelect } from '@angular/material/select';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { Subscription } from 'rxjs';
import { DeletepopupComponent } from '../../setup/deletepopup/deletepopup.component';
import { PlanService } from '../../plan/services/plan.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
@Component({
  selector: 'app-qlr-menu',
  templateUrl: './qlr-menu.component.html',
  styleUrls: ['./qlr-menu.component.scss'],
})

export class QlrMenuComponent implements OnInit {
  @ViewChild('closebutton') closebutton: { nativeElement: { click: () => void; }; };
  @ViewChild('mySelect') mySelect: MatSelect;

  //properties
  pageTitle: string = 'QLR Menu';
  canSaveNewReport: boolean = false;
  canProcessReport: boolean = false;
  isEdit: boolean = false;
  isNew: boolean = false;
  isRowSelected: boolean = false;
  gridAPI!: GridApi<QlrReports>;
  viewDetails: ViewReport;
  selectedServerId: null | IDandName;
  selectedFolderId: number;
  selectedSiteId: Site | undefined;
  selectedPermissionGroupId: number;
  selectedRowNode: null | IRowNode<QlrReports>;
  templateQlrReport: QlrReports; // scratch object to be used for updating.
  rowData: QlrReports[];
  filteredServer: any[];
  filteredFolder: any[];
  filteredSite: any[];
  filteredPermissiongroup: any[];
  formSelectedFolder: null | IDandName;
  formSelectedQuery: null | any;
  formSelectedLayout: null | any;
  gridUserVisibleColumns: any[];
  applicationOptions: any;
  applicationId: any;
  gridSelectedVisibleColumns: any[];
  selectedOptions: any[];
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  layoutSubscription: Subscription;
  columnApi: any;
  columnState: any;
  userName: any;
  selectedSite: any;
  gridOptions: any;
  constructor(  public planService: PlanService,public dialog: MatDialog, private http: HttpClient, private reportService: ReportService,  public dialogService: DialogService,public navbarService: NavbarService,public permission: PermissionsService) {
    this.gridOptions = {
      context: { Component: this }
    }  
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
      if (shouldSubscribe) {
        let data = this.saveLayout();
        console.log("create:", data)
        this.dialogService.savaLayout(data);
      }
    })
    //this.getView();
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  canWrite: boolean = true
  async permissionMethod() {
    try {
      const permission1 = await this.permission.canWrite('QLRMenuLaunch');
      const permission2 = await this.permission.isSuperUser();
      const canWriteBoth = permission1 || permission2;
      console.log("Can write both permissions:", canWriteBoth);
      this.canWrite = canWriteBoth;
    } catch (error) {
      console.error("Error:", error);
    }
  }
  
  // saveLayout(): any {
  //   if (this.columnApi) {
  //     this.columnState = this.columnApi.getColumnState();
  //     let columns = [];
  //     for (let column of this.columnState) {
  //       const customColumn = {
  //         name: column.colId,
  //         visible: !column.hide,
  //         width: column.width,
  //         sort: column.sort,
  //         filter: column.filter
  //       }
  //       columns.push(customColumn)

  //     }
  //     let columnValueObj: any = { columns };
  //     columnValueObj = JSON.stringify(columnValueObj);
  //     this.navbarService.usernameSubject.subscribe((username) => {
  //       this.userName = username;
  //     });
  //     this.selectedSite = this.navbarService.selectedSiteId;
  //     console.log("site:", this.selectedSite);
  //     return {
  //       "applicationOptionId" : 9704,
  //       "optionName": "a2v3.report.qlr.grid.layout",
  //       "optionValue": columnValueObj,
  //       "siteId": this.selectedSite,
  //       "userId": this.userName
  //     }
  //   }
  // }

  // getLayout() {
  //   this.navbarService.applicationOptions.subscribe(
  //     (applicationOptions: any) => {
  //       let appOptions = applicationOptions;
  //       let a = appOptions.filter((item: any) => {
  //         if (item["optionName"] === "a2v3.report.qlr.grid.layout")
  //           this.columnState = JSON.parse(item["optionValue"]);
  //         if (this.columnState) {

  //           if (this.columnState.columns) {
  //             this.columnState.columns.forEach((column: any) => {
  //               if ("name" in column) {
  //                 column.colId = column.name;
  //                 delete column.name
  //               }
  //             });
  //             this.columnState = this.columnState.columns;
  //             this.applyLayout();
  //           }
  //         }
  //       })
  //     });
  // }

  // applyLayout() {
  //   console.log("new:", this.columnState)
  //   const applyColumnStateParams = {
  //     state: this.columnState,
  //     applyOrder: true
  //   }
  //   this.columnApi.applyColumnState(applyColumnStateParams);
  //   this.columnState.forEach(({ colId, width }: { colId: any, width: any }) => {
  //     const column = this.columnApi.getColumn(colId);
  //     if (column) {
  //       this.columnApi.setColumnWidth(column, width);
  //     }
  //   })

  // }
 
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.report.qlr.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.report.qlr.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.report.qlr.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }

  openEditFoldersDialog() {
    const dialogRef = this.dialog.open(EditFoldersComponent, { data: this.viewDetails.qlrFolders });  
    
    dialogRef.afterClosed().subscribe(result => {
      // received new list of QLRFolders
      this.viewDetails.qlrFolders = result;
    });
  }

  colDefs: ColDef[] = [
    { headerName: 'Name', field: 'name', resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Query', field: 'query', resizable: true, filter: true, floatingFilter: true },
    { headerName: 'Layout', field: 'layout', resizable: true, filter: true, floatingFilter: true }    ,
    { field: 'serverId', hide: true, filter: true },
    { field: 'folderId', hide: true, filter: true },
    //{ field: 'description', resizable: true, filter: true, floatingFilter: true },
    //{ field: 'siteIds', hide: false, valueFormatter: this.siteIdsValueFormatter,  filter: 'agTextColumnFilter' },
    { field: 'siteIds', hide: true, filter: true },
    { field: 'groupIds', hide: true, filter: true },
    { field: 'allSites', hide: true, filter: true },
    { field: 'allGroups', hide: true, filter: true },   
  ];

  public defaultColDef: ColDef = {
    cellStyle: {'border-right': '1px solid #d4d4d4'},
    //flex: 1,
     width: 200,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,

  };
  public  onNoClick() {
    this.closebutton.nativeElement.click();
  } 
  
  ngOnInit() {    
    this.notify.emit(this.pageTitle);
    
    this.viewDetails = this.reportService.viewReport;
    this.rowData = this.reportService.viewReport.qlrReports;      

    // initialize grid hamburger tool for column selection.
    this.gridUserVisibleColumns = [];
    this.gridSelectedVisibleColumns = [];
    this.colDefs.forEach(element => {
      if (!element.hide) {
        this.gridUserVisibleColumns.push(element.headerName);
        this.gridSelectedVisibleColumns.push(element.headerName);
      }
    });
    this.selectedOptions = this.colDefs.map((coulmn) => coulmn.field);
  }

  applyQlrServerFilter(serverId: number) {
    var serverIdFilterComponent = this.gridAPI.getFilterInstance('serverId')!;
    serverIdFilterComponent.setModel({
      type: 'equals',
      filter: serverId
    });
    this.gridAPI.onFilterChanged();
  }

  applyQlrFolderFilter(folderId: number) {
    var folderIdFilterComponent = this.gridAPI.getFilterInstance('folderId')!;
    folderIdFilterComponent.setModel({
      type: 'equals',
      filter: folderId
    });
    this.gridAPI.onFilterChanged();
  }

  applySitesFilter(siteId: number) {
    var siteIdsFilterComponent = this.gridAPI.getFilterInstance('siteIds')!;
    siteIdsFilterComponent.setModel({      
      type: 'contains',
      filter: siteId
    });
    this.gridAPI.onFilterChanged();
  }

  applyPermissionGroupsFilter(permissionGroupId: number) {
    var siteIdsFilterComponent = this.gridAPI.getFilterInstance('groupIds')!;
    siteIdsFilterComponent.setModel({      
      type: 'contains',
      filter: permissionGroupId
    });
    this.gridAPI.onFilterChanged();
  }

  onQlrFolderChange(event: any) {
    this.applyQlrFolderFilter(event.id);
  }

  onQlrServerChange(event: any) {
    this.applyQlrServerFilter(event.id);
  }

 onSitesChange(event: any) {       
    this.applySitesFilter(event.id);
  }

  onPermissionGroupChange(event: any) {    
    this.applyPermissionGroupsFilter(event.permissionGroupId);
  }

  onGridReady(params: GridReadyEvent<QlrReports>) {
    this.gridAPI = params.api;  
    this.selectedSiteId = this.viewDetails.refSites.find((site: Site) => site.id == this.viewDetails.selectedSite);
    
    if (this.selectedSiteId?.id) {
      this.applySitesFilter(this.selectedSiteId?.id);  
    }
  }
  onGridReady1(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  onGridColumnSelectionChange(event: any) {
    // event will contain only the selected columns. 
    this.clearFilters();
    this.colDefs.forEach(element => {
      // columns that have Header names are the ones that need to be displayed so that's what we check for.      
      if (element.headerName && event.value.includes(element.headerName)) {
        element.hide = false;
      } else {
        element.hide = true;
      }
    });
    this.gridAPI.setColumnDefs(this.colDefs);
  }
  clearFilters() {
    this.colDefs.forEach(element => {
      this.gridAPI.destroyFilter(element.field!);
    });

  }
  ok:boolean  =false;
  sum : number = 0;
  
  closeDialog(){
    
    this.unselectSelectedRow();
    this.isNew = false;
    this.ok = false;    
    this.sum = 0;
  }

  // looks for matching qlrFolder in context and returns it.
  getQlrFolderFromId(id: null | number) {
    if (id) {
      for (let i = 0; i < this.viewDetails.qlrFolders.length; i++) {    
        let item = this.viewDetails.qlrFolders[i];
        if (item.id === id) {
          return item;
        }
      }
    }
    return null;
  }

  // looks for matching qlrQuery in context and returns it.
  getQlrQueryFromName(name: null | string) {
    if (name) {
      for (let i = 0; i < this.viewDetails.qlrQueries.length; i++) {    
        let item = this.viewDetails.qlrQueries[i];
        if (item.name === name) {
          return item;
        }
      }
    }
    return null;
  }

  // looks for matching qlrLayout in context and returns it.
  getQlrLayoutFromName(name: null | string) {
    if (name) {
      for (let i = 0; i < this.viewDetails.qlrLayouts.length; i++) {    
        let item = this.viewDetails.qlrLayouts[i];
        if (item.name === name) {
          return item;
        }
      }
    }
    return null;
  }

  onRowSelected(event: any) {   
    if (event.node.isSelected()) {
      this.isNew = false;
      this.isRowSelected = true;
      this.selectedRowNode = event.node; // this is a pass by reference to the original object.
      if (this.selectedRowNode?.data) {
        // create a copy of the object so we don't affect the original object while user edits the fields. 
        // we only overwrite the original object when Save is clicked.
        this.templateQlrReport = JSON.parse(JSON.stringify(this.selectedRowNode.data));

        // initialize form autocomplete models.        
        this.formSelectedFolder = this.getQlrFolderFromId(this.templateQlrReport.folderId);     
        this.formSelectedQuery = this.getQlrQueryFromName(this.templateQlrReport.query);    
        this.formSelectedLayout =  this.getQlrLayoutFromName(this.templateQlrReport.layout);    
      }      
    } 
  }
  onNameInputChanged(event: any) {    
    let text = event.target.value;
    this.templateQlrReport.name = text;
    this.validateNewReportForm();
  } 

  onDescriptionInputChanged(event: any) {
    let text = event.target.value;
    this.templateQlrReport.description = text;
  }

  onQueryInputChanged(event: any) {    
    this.templateQlrReport.query = event.name;
    this.validateNewReportForm();
  }

  onLayoutInputChanged(event: any) {
    this.templateQlrReport.layout = event.name;
  }

  onAllSitesChanged(event: any) {
    let checked = event.target.checked;
    this.templateQlrReport.allSites = checked;
  }

  onAllGroupsChanged(event: any) {
    let checked = event.target.checked;
    this.templateQlrReport.allGroups = checked;
  }

  onEnabledChanged(event: any) {
    let checked = event.target.checked;
    this.templateQlrReport.enabled = checked;
  }

  onEditFolderChange(event: any) {    
    this.templateQlrReport.folderId = event.id;
  }

  onEditReportsClick() {
    this.isEdit = true;    
  }

  onStopEditReportsClick() {
    this.isEdit = false;    
    this.isNew = false;
  }

  onUpdateQlrReportClick() {    
    // call API to save templateQlrReport 
    this.reportService.saveQlrReport(this.templateQlrReport).subscribe(
      (result: any) => {
        // update selectedRowNode with templateQlrReport        
        this.selectedRowNode?.setData(this.templateQlrReport);

        // update reference data ??
        let obj = this.viewDetails.qlrReports.find((o, i) => {
          if (o.id === this.templateQlrReport.id) {
            this.viewDetails.qlrReports[i] = this.templateQlrReport;
            return true; // stop searching
          }
          return false;          
        });        
      }
    );
  }

  onNewSaveClick() {
    // call API to save templateQlrReport 
    this.reportService.createQlrReport(this.templateQlrReport).subscribe(
      (result: any) => {
        // update grid with new QLR Report 
        // add to grid since it's a new record.
        this.gridAPI.applyTransaction({ add: result.qlrReports });
        // close edit section.
        this.isNew = false;

        // update reference data
        this.viewDetails.qlrReports.push(result);
      }
    );
  }

  onProcessClick() {
    // get selected report Id.
    let reportId = this.selectedRowNode?.data?.id;

    // open report view window
    window.open('/reportview?qlrReportPreview=' + reportId, '_blank');    
  }


  validateNewReportForm() {    
    // only allow saving if report name and query are filled.
    if (this.templateQlrReport.name && this.templateQlrReport.query) {
      this.canSaveNewReport = true;
    } else {
      this.canSaveNewReport = false;
    }
    this.validateProcessButton();
  }

  validateProcessButton() {
    // only allow process of report if it has an ID.
    if (this.templateQlrReport.id) {
      this.canProcessReport = true;
    } else {
      this.canProcessReport = false;
    }
  }

  doesExternalFilterPass(node: IRowNode<QlrReports>): boolean {
    var folderIdFilterComponent = this.gridAPI.getFilterInstance('folderId')!;
    var siteIdFilterComponent = this.gridAPI.getFilterInstance('siteId')!;
    // return true;
    // if (node.data) {
    //   switch (ageType) {
    //     case 'below25':
    //       return node.data.age < 25;
    //     case 'between25and50':
    //       return node.data.age >= 25 && node.data.age <= 50;
    //     case 'above50':
    //       return node.data.age > 50;
    //     case 'dateAfter2008':
    //       return asDate(node.data.date) > new Date(2008, 1, 1);
    //     default:
    //       return true;
    //   }
    // }
    return true;
  }

  openDeleteDialog() {
    const dialogRef = this.dialog.open(DeletepopupComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result == true && this.selectedRowNode?.data?.id != null) {
        // call delete folder API
        this.reportService.deleteQlrReport(this.selectedRowNode.data.id).subscribe(
          (result: any) => {
            if (this.selectedRowNode?.data?.id) {              
              // remove folder from grid
              this.gridAPI.applyTransaction({ remove: [this.selectedRowNode?.data] });
              //this.removeSelected();
              this.selectedRowNode = null;
              this.closeDialog();
            }        
          }
        );        
      }
    });
  }

  unselectSelectedRow() {
    //unselect the selected row.
    if (this.selectedRowNode) {
      this.selectedRowNode.setSelected(false);
    }
    this.selectedRowNode = null;
    this.isRowSelected = false;
  }

  onNewButtonClick() {
    this.unselectSelectedRow();

    // clear templateQlrReport
    this.templateQlrReport = {} as QlrReports;
    if (this.selectedServerId?.id) {
      this.templateQlrReport.serverId = this.selectedServerId.id;
    }

    // clear other variables.         
    this.formSelectedFolder = null;  
    this.formSelectedQuery = null;   
    this.formSelectedLayout =  null; 

    this.isNew = true;

    this.validateNewReportForm();
  } 
  
  filterServer(event: any) {
    let filtered: any[] = [];
    let query = event.query

    for (let i = 0; i < this.viewDetails.qlrServers.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrServers[i]);
      let country = this.viewDetails.qlrServers[i];
      if (country.name.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredServer = filtered;
  }

  filterFolder(event: any) {
    let filtered: any[] = [];
    let query = event.query

    for (let i = 0; i < this.viewDetails.qlrFolders.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
      let country = this.viewDetails.qlrFolders[i];
      if (country.name.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredFolder = filtered;
  }

filteredQuery : any[]; 
filterQuery(event: any) {
  let filtered: any[] = [];
  let query = event.query

  for (let i = 0; i < this.viewDetails.qlrQueries.length; i++) {
    // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
    let country = this.viewDetails.qlrQueries[i];
    if (country.name.toLowerCase().includes(query.toLowerCase())) {
      filtered.push(country);
    }
  }
  this.filteredQuery = filtered;
}
filteredLayout: any[];
filterLayout(event: any) {
  let filtered: any[] = [];
  let query = event.query
  for (let i = 0; i < this.viewDetails.qlrLayouts.length; i++) {
    // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
    let country = this.viewDetails.qlrLayouts[i];
    if (country && country.name && country.name.toLowerCase().includes(query.toLowerCase())) {
      filtered.push(country);
    }
  }
  this.filteredLayout = filtered;
}

  filterSite(event: any) {
    let filtered: any[] = [];
    let query = event.query

    for (let i = 0; i < this.viewDetails.refSites.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
      let country = this.viewDetails.refSites[i];
      if (country.description.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredSite = filtered;
  }

  filterPermissiongroup(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.viewDetails.permissionGroups.length; i++) {
      // let country = JSON.stringify(this.viewDetails.qlrFolders[i]);
      let country = this.viewDetails.permissionGroups[i];
      if (country.permissionGroupDesc.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredPermissiongroup = filtered;
  }
  gridApi: any;
  columnDefs: ColDef[] = this.colDefs;
  onSelectionChange(event: any) {
    console.log(event.value);
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  onClearLineType() {
    // Handle the clear event here, you can reset the form control value
    this.templateQlrReport.query = '';
  }
  getVisibleOptions(): any[] {
    return this.colDefs.filter(option => !option.hide);
  }
}

import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { end } from '@popperjs/core';
import {
  ColDef,
  GridApi,
  GridOptions,
  GridReadyEvent,
  INumberFilterParams,
} from 'ag-grid-community';
import * as moment from 'moment';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import {
  ResourceAllocation,
  ResourceAllocationTable,
  TruckUnavailability,
} from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';
import { FilterMenuComponent } from './filter-menu/filter-menu.component';
import { TripInformationSettingsDialogComponent } from './trip-information-settings-dialog/trip-information-settings-dialog.component';

@Component({
  selector: 'app-plan-resource-allocation',
  templateUrl: './plan-resource-allocation.component.html',
  styleUrls: ['./plan-resource-allocation.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class PlanResourceAllocationComponent implements OnInit {
  //sending data to dialog
  @Output() resourceAllocationSelect: EventEmitter<ResourceAllocation> =
    new EventEmitter<ResourceAllocation>();
  @Output() truckUnavilabilitySelect: EventEmitter<TruckUnavailability> =
    new EventEmitter<TruckUnavailability>();
  @ViewChild('agGrid') agGrid: any;
  @Input() dateCycleResult: any;
  selectedOptions: any[];

  //AG Grid configuration
  private gridApi!: GridApi<ResourceAllocationTable>;
  public rowSelection: 'single' | 'multiple' = 'single';
  rowData: ResourceAllocationTable[] = [];
  trucksWithTrips = [];
  columnFields: ColDef[] = [
    {
      field: 'name',
      headerName: 'Name',
      floatingFilter: true,
      filter: true,
      filterParams: { apply: true },
    },
    { field: 'type', headerName: 'Type', headerComponent: FilterMenuComponent },
    {
      field: 'capacity',
      headerName: 'Capacity',
      filter: 'agNumberColumnFilter',
      floatingFilter: true,
      filterParams: {
        numAlwaysVisibleConditions: 2,
        defaultJoinOperator: 'OR',
      } as INumberFilterParams,
    },
    { field: 'fleet', headerName: 'Fleet', filter: true, floatingFilter: true },
    {
      field: 'fsthour',
      headerName: '00:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      tooltipField: 'fsthour'
    },
    {
      field: 'secondhour',
      headerName: '02:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '04:00',
      headerName: '04:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '06:00 ',
      headerName: '06:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '08:00',
      headerName: '08:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '10:00 ',
      headerName: '10:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '12:00 ',
      headerName: '12:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '14:00 ',
      headerName: '14:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '16:00 ',
      headerName: '16:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '18:00 ',
      headerName: '18:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '20:00 ',
      headerName: '20:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '22:00 ',
      headerName: '22:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    minWidth: 80,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  //Testing for FilterMenu
  components = {
    filterMenu: FilterMenuComponent,
  };
  TableValues: any[] = [];
  TempTable: any[] = [];

  applyTypeFilter() {
    this.planService.FilterData.subscribe((res) => {
      if (res.length != 0) {
        this.TempTable = [];
        let temp = this.TableValues;
        temp.forEach((row) => {
          res.forEach((type: any) => {
            if (row.type == type.type) {
              this.TempTable.push(row);
            }
          });
        });
        this.rowData = this.TempTable;
      }
      else {
        this.rowData = this.TableValues
      }
    });
  }

  rectangleRenderer(params: any) {

    let width = '80px';
    let remainingwidth = '0px';
    let widthColor = 'grey';
    let remainingDivColor = 'transparent';
    const column = params.column;
    const headerName = column.getColDef().headerName;
    //console.log(headerName);
    let isChart: boolean = false;
    let isNew: boolean = false;
    //const column = params.column;
    let fromDate, fromTime, toDate, toTime;
    // const headerName = column.getColDef().headerName;
    //console.log("called", headerName)
    this.dateCycleResult.
      unavailability.forEach((trip: any) => {
        if (params.data.name === trip.truckId) {
          let dateCycleFromDate, dateCycleToDate;
          dateCycleFromDate = this.convertDatetoMilliseconds2(this.dateCycleResult.dateCycle.from);
          //console.log("date cycle from date:", dateCycleFromDate);
          dateCycleToDate = this.convertDatetoMilliseconds2(this.dateCycleResult.dateCycle.to);
          fromDate = this.millisecondsToDateTime(trip.windowFrom)[0];
          fromTime = this.millisecondsToDateTime(trip.windowFrom)[1];
          toDate = this.millisecondsToDateTime(trip.windowTo)[0];
          toTime = this.millisecondsToDateTime(trip.windowTo)[1];
          //console.log(dateCycleFromDate, toDate)
          if ((dateCycleFromDate === fromDate)) {
            //from
            //console.log("time:",trip.windowFrom, fromTime)
            let compareHeaderTimeWithFromTime = this.compareTimes(headerName, fromTime);
            if (compareHeaderTimeWithFromTime <= 0) {
              //header smaller than pickup end
              //add 2 hrs

              let timeMoment = moment(headerName, 'HH:mm');
              let columnEndTime = timeMoment.add(2, 'hours').format('HH:mm');
              //  console.log("2nd time:",columnEndTime, fromTime)

              let compareFromTimeWithColumnEnd = this.compareTimes(columnEndTime, fromTime);
              if (compareFromTimeWithColumnEnd > 0) {
                isChart = true;
                isNew = true;
                let widthInHrs = this.substractHrs(fromTime, headerName);
                let value = this.calculatePixelsBasedOnTime(widthInHrs);
                remainingwidth = value + 'px';
                width = 80 - value + 'px';
                widthColor = 'transparent';
                remainingDivColor = 'grey';
                console.log("from:", width, remainingwidth)
              } else {
                isChart = false;
              }

            } else {
              isChart = true;
            }
          }
          else if (dateCycleToDate === toDate) {
            console.log("to date:", dateCycleToDate, toTime)
            let compareHeaderTimeWithFromTime = this.compareTimes(headerName, toTime);
            if (compareHeaderTimeWithFromTime <= 0) {
              //header smaller than pickup end
              //add 2 hrs

              let timeMoment = moment(headerName, 'HH:mm');
              let columnEndTime = timeMoment.add(2, 'hours').format('HH:mm');
              //console.log("2nd time:",columnEndTime, toTime)

              let compareFromTimeWithColumnEnd = this.compareTimes(columnEndTime, toTime);
              if (compareFromTimeWithColumnEnd <= 0) {
                isChart = true;
                isNew = true;
                let widthInHrs = this.substractHrs(headerName, toTime);
                let value = this.calculatePixelsBasedOnTime(widthInHrs);
                width = value + 'px';
                remainingwidth = 80 - value + 'px';
                width = 'grey';
                remainingDivColor = 'transparent';
                //console.log("ischart:", isChart)
              } else {
                isChart = false;
              }

            }
          }
        }




      }

      )

    this.dateCycleResult.
      capacityResources.truckResources
      .forEach((trip: any) => {
        if (params.data.name === trip.truckId) {
          console.log("found:", headerName,params.data.name);
          let tripId = trip.trips[0].tripId;
          this.dateCycleResult.trips.forEach((trip: any) => {
            if (tripId === trip.id) {

              let startTime, endTime, startDate, endDate;
              startTime = this.convertMiliSeconds(trip.plannedStartTime);
              endTime = this.convertMiliSeconds(trip.plannedFinishTime);
              startDate = this.convertDatetoMilliseconds2(trip.plannedStartTime);
              endDate = this.convertDatetoMilliseconds2(trip.plannedFinishTime);
              console.log("trip:", trip, startTime, endTime, startDate, endDate);
              let compareHeaderTimeWithFromTime = this.compareTimes(headerName, startTime);
              if (compareHeaderTimeWithFromTime <= 0) {
                //header smaller than pickup end
                //add 2 hrs

                let timeMoment = moment(headerName, 'HH:mm');
                let columnEndTime = timeMoment.add(2, 'hours').format('HH:mm');
                //  console.log("2nd time:",columnEndTime, fromTime)

                let compareFromTimeWithColumnEnd = this.compareTimes(columnEndTime, startTime);
                if (compareFromTimeWithColumnEnd >= 0) {
                  isChart = true;
                  isNew = true;
                  if ((startDate == endDate) && (startTime == endTime)) {
                    console.log("checked", headerName)

                    widthColor = this.getColor(trip.cachedStatus)!;

                    console.log("new width:", width);
                    width = '40px';
                    remainingwidth = '40px';
                    remainingDivColor = 'tranparent';
                  } else {
                    let widthInHrs = this.substractHrs(startTime, headerName);
                    let value = this.calculatePixelsBasedOnTime(widthInHrs);
                    remainingwidth = value + 'px';
                    width = 80 - value + 'px';
                    widthColor = 'transparent';
                    remainingDivColor = this.getColor(trip.cachedStatus)!;
                  }
                }else{
                  isChart = true;
                }
              }

            }
          })

        }
      });

      this.dateCycleResult.
      trips
      .forEach((trip: any) => {
        if (params.data.name === trip.truckId) {
          // console.log("found in trip:", headerName,params.data.name);
          //let tripId = trip.trips[0].tripId;
          //this.dateCycleResult.trips.forEach((trip: any) => {
            //if (tripId === trip.id) {

              let startTime, endTime, startDate, endDate;
              startTime = this.convertMiliSeconds(trip.plannedStartTime);
              endTime = this.convertMiliSeconds(trip.plannedFinishTime);
              startDate = this.convertDatetoMilliseconds2(trip.plannedStartTime);
              endDate = this.convertDatetoMilliseconds2(trip.plannedFinishTime);
              // console.log("trip:", trip, startTime, endTime, startDate, endDate);
              let compareHeaderTimeWithFromTime = this.compareTimes(headerName, startTime);
              if (compareHeaderTimeWithFromTime <= 0) {
                //header smaller than pickup end
                //add 2 hrs

                let timeMoment = moment(headerName, 'HH:mm');
                let columnEndTime = timeMoment.add(2, 'hours').format('HH:mm');
                //  console.log("2nd time:",columnEndTime, fromTime)

                let compareFromTimeWithColumnEnd = this.compareTimes(columnEndTime, startTime);
                if (compareFromTimeWithColumnEnd >= 0) {
                  isChart = true;
                  isNew = true;
                  if ((startDate == endDate) && (startTime == endTime)) {
                    console.log("checked", headerName)

                    widthColor = this.getColor(trip.cachedStatus)!;

                    console.log("new width:", width);
                    width = '40px';
                    remainingwidth = '40px';
                    remainingDivColor = 'tranparent';
                  } else {
                    let widthInHrs = this.substractHrs(startTime, headerName);
                    let value = this.calculatePixelsBasedOnTime(widthInHrs);
                    remainingwidth = value + 'px';
                    width = 80 - value + 'px';
                    widthColor = 'transparent';
                    remainingDivColor = this.getColor(trip.cachedStatus)!;
                  }
                }else{
                  isChart = true;
                }
              }

            //}
         // })

        }
      });

    if (isChart && isNew) {
      const container = document.createElement('div');
      container.style.display = 'flex';

      const yellowDiv = document.createElement('div');
      yellowDiv.style.width = width;
      yellowDiv.style.height = '40px';
      yellowDiv.style.background = widthColor;

      const redDiv = document.createElement('div');
      redDiv.style.width = remainingwidth;
      redDiv.style.height = '40px';
      redDiv.style.background = remainingDivColor;

      container.appendChild(yellowDiv);
      container.appendChild(redDiv); // You can also add event listeners or other logic here if neededreturn container;;

      return container;
    }
    if (isChart) {
      // const container = document.createElement('div');

      // const div = document.createElement('div');
      // div.style.width = '80px';
      // div.style.height = '40px';
      // div.style.position = 'relative';
      // div.style.backgroundColor = 'grey';

      // const tooltipDiv = document.createElement('div');
      // div.style.width = '30px';
      // div.style.height = '20px';
      // div.style.position = 'absolute';
      // div.style.backgroundColor = 'white';
      // const pTag = document.createElement('p');
      // pTag.textContent= 'sample reasons';
      // tooltipDiv.appendChild(pTag);

      // container.appendChild(div);
      // container.appendChild(tooltipDiv); // You can also add event listeners or other logic here if neededreturn container;;

      // return container;
      // //console.log("show chart",params.data.name,headerName);
      const div = document.createElement('div');
      div.style.width = '80px';
      div.style.height = '40px';
      div.style.backgroundColor = 'grey';
      //div.title = displayToolTipTravell;
      //return 1;
      return div.outerHTML;
    }
    else {
      //console.log("no chart",params.data.name,headerName);
      const div = document.createElement('div');
      div.style.width = '80px';
      div.style.height = '40px';
      div.style.backgroundColor = 'transparent';
      // div.title = displayToolTipTravell;
      //return 2;
      return div.outerHTML;
    }

    //return headerName;
  }

  getColor(status: any) {
    let tripColor, travelColor;
    if (status == 'D ') {
      //despatched
      tripColor = '#f5911f';
      travelColor = '#a75c07';
      87;
    } else if (status == 'P ') {
      //Planned
      tripColor = '#00aaa6';
      travelColor = '#004442';
    } else if (status === 'U ') {
      //despatched
      tripColor = '#f5911f';
      travelColor = '#a75c07';
    } else if (status === 'L ') {
      //transit
      tripColor = '#d450c5';
      travelColor = '#99258b';
    } else if (status === 'T ') {
      //transit
      tripColor = '#d450c5';
      travelColor = '#99258b';
    } else if (status === 'RD ') {
      //ready
      tripColor = '#00aaa6';
      travelColor = '#004442';
    }
    return tripColor;
  }


  substractHrs(time1: any, time2: any) {
    const [hours1, minutes1] = time1.split(':').map(Number);
    const [hours2, minutes2] = time2.split(':').map(Number);

    let resultHours = hours1 - hours2;
    let resultMinutes = minutes1 - minutes2;

    if (resultMinutes < 0) {
      resultHours -= 1;
      resultMinutes += 60;
    }

    // Ensure the result is in 24-hour format
    resultHours = (resultHours + 24) % 24;

    const formattedResult = `${resultHours
      .toString()
      .padStart(2, '0')}:${resultMinutes.toString().padStart(2, '0')}`;
    return formattedResult;
  }

  calculatePixelsBasedOnTime(timeInHrs: any) {
    const [hours1, minutes1] = timeInHrs.split(':').map(Number);
    const totalMinutes = hours1 * 60 + minutes1;
    const width = totalMinutes / 1.5;
    return width;
  }

  convertDatetoMilliseconds2(date: any) {
    const formattedValue = moment
      .unix(date / 1000)
      .tz('Australia/Melbourne')
      .format('YYYY-MM-DD')
      .toLowerCase();
    //const formattedFilter = filter.filterText;

    return formattedValue;

  }

  convertDatetoMilliseconds(date: any) {
    const formattedValue = moment
      .unix(date / 1000)
      .tz('Australia/Melbourne')
      .format('YYYY-MM-DD HH mm')
      .toLowerCase();
    //const formattedFilter = filter.filterText;

    return formattedValue;

  }

  convertMiliSeconds(miliseconds: any) {
    const formattedValue = moment
      .unix(miliseconds / 1000)
      .tz('Australia/Melbourne')
      .format('HH:mm')
      .toLowerCase();


    return formattedValue;
  }

  millisecondsToDateTime(miliseconds: any) {
    const date = new Date(miliseconds);

    const hrs = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    let dt = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
    let time = `${hrs}:${minutes}`;
    return [dt, time]

  }

  compareTimes(time1: any, time2: any) {
    const [hours1, minutes1] = time1.split(':').map(Number);
    const [hours2, minutes2] = time2.split(':').map(Number);

    const totalMinutes1 = hours1 * 60 + minutes1;
    const totalMinutes2 = hours2 * 60 + minutes2;

    return totalMinutes1 - totalMinutes2;
  }

  millisecondsToDate(milliseconds: any) {
    const date = new Date(milliseconds);

    const formattedDate = date.toLocaleDateString('en-US'); // Adjust locale if needed

    console.log(formattedDate);
  }

  //testinf end for filtermenu
  constructor(public planService: PlanService, public dialog: MatDialog,private authenticationService:AuthenticationService) { }
  ViewDataTrucks: any[] = [];
  trucks: ResourceAllocationTable[] = [];
  resource: ResourceAllocationTable = {
    name: '',
    type: '',
    capacity: 0,
    fleet: '',
  };

  onGridReady(params: GridReadyEvent<ResourceAllocationTable>) {
    this.gridApi = params.api;
    this.authenticationService.viewAPI.subscribe((result) => {
      this.ViewDataTrucks = result['ref'].trucks;
      this.getRATrucks(this.ViewDataTrucks);

    });
    // TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("in ngonchnages:", this.dateCycleResult);
    let dateCycleFromDate = this.convertDatetoMilliseconds2(this.dateCycleResult.dateCycle.from);
    console.log("date cycle from date:", dateCycleFromDate);
  }
  ngOnInit(): void {
    this.planService.FilterData.subscribe((res) => {
      this.applyTypeFilter();
    });
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    console.log("in ngoninte:", this.dateCycleResult);
    let dateCycleFromDate = this.convertDatetoMilliseconds2(this.dateCycleResult.dateCycle.from);
    console.log("date cycle from date:", dateCycleFromDate);
  }
  //Get Resource Allocation Trucks
  getRATrucks(viewtrucks: any[]) {
    viewtrucks.forEach((element) => {
      this.resource = { name: '', type: '', capacity: 0, fleet: '' };
      if (element.active == true) {
        this.resource.name = element.truckId;
        this.resource.type = element.truckTypeId;
        this.resource.capacity = element.routeCapacity;
        this.resource.fleet = element.fleetNumber;
        this.trucks.push(this.resource);
      }
    });
    this.rowData = this.trucks;
    this.TableValues = this.rowData;

  }
  //on row selection
  //hard coded truck info
  truckunavail: TruckUnavailability = {
    id: 1581,
    lastModified: 1702442884660,
    reasonId: '105',
    siteId: 999,
    trailerId: '',
    truckId: 'CEMENT',
    windowFrom: 1702443177542,
    windowTo: 1702529577542,
  };
  info: ResourceAllocation;
  selectedTruckId: any;
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.ViewDataTrucks.forEach((element) => {
      if (element.truckId == selectedRows[0].name) {
        this.info = element;
        this.selectedTruckId = element.truckId;
      }
    });
    this.resourceAllocationSelect.emit(this.info);
    this.planService
      .getResourceAllocation(this.selectedTruckId)
      .subscribe((result: any) => {
        if (result.length != 0) {
          this.planService.truckUnavailability = result[0];
          this.truckUnavilabilitySelect.emit(
            this.planService.truckUnavailability
          );
        }
        //putting hardcoded value for check
        // this.truckUnavilabilitySelect.emit(
        //   this.truckunavail
        //   );
      });
    //emit the truck unavailability data here to parent
  }
  clearFilters() {
    this.columnFields.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.columnFields.filter((column) =>
     event.value.includes(column.field) || !this.isExcludedTime(column.headerName)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  isExcludedTime(headerName: any): boolean {
    // Define the excluded time values
    const excludedTimes = ['00:00', "02:00", '04:00', "06:00", "08:00", "10:00", "12:00", "14:00", "16:00", "18:00", "20:00", "22:00"];
    // Check if the headerName is in the excludedTimes array
    const ans = !excludedTimes.includes(headerName);
    return ans;
  }

  filtersRow: boolean = true;
  HideFilters(event: any) {
    this.columnDefs.forEach((columnDef) => {
      if (columnDef.floatingFilter == true) {
        columnDef.floatingFilter = false; // Hide floating filters
        columnDef.filter = false; // Hide header filters
        this.filtersRow = false;
      } else if (columnDef.floatingFilter == false) {
        columnDef.floatingFilter = true; // show floating filters
        columnDef.filter = true; // show header filters
        this.filtersRow = true;
      }
    });
    this.agGrid.api.setColumnDefs(this.columnDefs); // Apply updated column definitions
  }

  //Popup for Adding Container
  TripInfoSettings() {
    const dialogRef = this.dialog.open(TripInformationSettingsDialogComponent);
  }
}

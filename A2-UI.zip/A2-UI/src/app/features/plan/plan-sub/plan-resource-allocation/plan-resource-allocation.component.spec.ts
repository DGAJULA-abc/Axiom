import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanResourceAllocationComponent } from './plan-resource-allocation.component';

describe('PlanResourceAllocationComponent', () => {
  let component: PlanResourceAllocationComponent;
  let fixture: ComponentFixture<PlanResourceAllocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanResourceAllocationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanResourceAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { IHeaderAngularComp } from 'ag-grid-angular';
import { IHeaderParams } from 'ag-grid-community';
import { AgGridCustomComponent } from 'src/app/shared/ag-grid-custom/ag-grid-custom.component';
import { PlanService } from '../../../services/plan.service';
import { PlanResourceAllocationComponent } from '../plan-resource-allocation.component';
import { FilterDialogComponent } from './filter-dialog/filter-dialog.component';

@Component({
  selector: 'app-filter-menu',
  templateUrl: './filter-menu.component.html',
  styleUrls: ['./filter-menu.component.scss'],
})
export class FilterMenuComponent implements IHeaderAngularComp {
  
  public params: any;
  gridApi: any;
  showcross:boolean=false;
  clear(){
    this.showcross=false;
    this.planService.FilterData.next([])
  }

  constructor(public dialog: MatDialog,public planService:PlanService) {}

  agInit(params: any): void {
    this.params = params;
    this.gridApi = this.params.api;
  }

  onButtonClick(): void {
    const dialogRef = this.dialog.open(FilterDialogComponent);
    dialogRef.afterClosed().subscribe((res) => {
      if (res.data.length != 0) {
        this.showcross=true
        this.planService.FilterData.next(res.data)

      }
    });
  }
  refresh(params: IHeaderParams<any, any>): boolean {
    return false;
  }
}

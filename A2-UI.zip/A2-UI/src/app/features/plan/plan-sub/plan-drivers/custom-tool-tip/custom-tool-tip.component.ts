import { Component } from '@angular/core';
import { ITooltipParams } from 'ag-grid-community';

@Component({
  selector: 'app-custom-tool-tip',
  templateUrl: './custom-tool-tip.component.html',
  styleUrls: ['./custom-tool-tip.component.scss']
})
export class CustomTooltip {
 
  public data!: any;
  public color!: string;

  agInit(params: { color: string } & ITooltipParams): void {
    

    this.data = params.api!.getDisplayedRowAtIndex(params.rowIndex!)!.data;
  }
}

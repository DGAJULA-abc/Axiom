import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewEncapsulation,
} from '@angular/core';
//import * as moment from 'moment';
import { Router } from '@angular/router';
import { start } from '@popperjs/core';
import { time } from 'ag-charts-community';
import { linear } from 'ag-charts-community/dist/esm/es6/motion/easing';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  IGroupCellRendererParams,
} from 'ag-grid-community';
import * as moment from 'moment';
import { last, of, Subscription } from 'rxjs';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { Driver } from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';
import { GanttCellRendererComponent } from '../plan-prime-movers/gantt-cell-renderer/gantt-cell-renderer.component';
import { CustomTooltip } from './custom-tool-tip/custom-tool-tip.component';

@Component({
  selector: 'app-plan-drivers',
  templateUrl: './plan-drivers.component.html',
  styleUrls: ['./plan-drivers.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class PlanDriversComponent implements OnInit, OnChanges {
  @Output() driverSelect: EventEmitter<any[]> = new EventEmitter<any[]>();
  @Input() dateCycleResult: any;
  all_unique_activities: any[] = [];
  driverWithTrip: any[] = [];
  //AG Grid configuration
  private gridApi!: GridApi<Driver>;

  public rowSelection: 'single' | 'multiple' = 'single';
  rowData: Driver[] = [];
  columnFields: ColDef[] = [
    { field: 'driverId', headerName: 'Driver Id', hide: true,tooltipField: 'driverId'},
    { field: 'name', headerName: 'Name', tooltipField: 'name',  filter: 'agTextColumnFilter',
    floatingFilter: true, },
    { field: 'company', headerName: 'Company',tooltipField: 'company',  filter: 'agTextColumnFilter',
    floatingFilter: true, },
    { field: 'pdtloginId', headerName: 'PDT Login ID',  filter: 'agTextColumnFilter',
    floatingFilter: true, tooltipField: 'pdtloginId', tooltipComponent: CustomTooltip},
    {
      field: 'fsthour',
      headerName: '00:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      tooltipField: 'fsthour'
      , tooltipComponent: CustomTooltip
    },
    {
      field: 'secondhour',
      headerName: '02:00',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
      tooltipComponent: CustomTooltip
    },
    {
      field: '04:00 ',
      headerName: '04:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
      tooltipComponent: CustomTooltip
    },
    {
      field: '06:00 ',
      headerName: '06:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '08:00 ',
      headerName: '08:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '10:00 ',
      headerName: '10:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '12:00 ',
      headerName: '12:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '14:00 ',
      headerName: '14:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '16:00 ',
      headerName: '16:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '18:00 ',
      headerName: '18:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '20:00 ',
      headerName: '20:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
    {
      field: '22:00 ',
      headerName: '22:00 ',
      cellRenderer: this.rectangleRenderer.bind(this),
      width: 80,
      cellStyle: { padding: 0 },
    },
  ];
  gridOptions = {
    enableCellChangeFlash: true,
    columnDefs: this.columnFields,
  };
  public defaultColDef: ColDef = {
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    minWidth: 80,
    // filter: 'agTextColumnFilter',
    // floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  public tooltipShowDelay = 0;
  //public tooltipHideDelay = 2000;
  constructor(
    public planService: PlanService,
    private router: Router,
    public timeService: TimeRunsheetService,
    private authenticationService:AuthenticationService
  ) {}
  trip_activities: any[] = [];
  all_activities: any[] = [];
  subscription: Subscription;
  dataCycleArray: any;
  // @Input() datecycleresult:any;
  ngOnChanges(changes: SimpleChanges): void {
    if (this.dateCycleResult) {
      this.gridApi.refreshCells({ force: true });
      let trips = this.dateCycleResult?.trips;
      trips.forEach((trip: any) => {
        this.rowData.forEach((driver: any) => {
          if (driver.id === trip.driverId) {
            this.driverWithTrip.push(driver);
          }
        });
      });

      this.getDrivers(this.ViewDataDrivers);
    }
    //////////////////

    if (!this.dateCycleResult) {
      return;
    }
    this.all_activities = [];
    this.dateCycleResult.trips.forEach((trip: any) => {
      if (trip.activities.length != 0 && trip.cachedStatus != 'P ') {
        this.trip_activities = [];
        trip.activities.forEach((element: any) => {
          this.trip_activities.push({
            time: element.activityTime,
            tripId: element.tripId,
          });
        });
        this.all_activities.push({
          driver: trip.driverId,
          status: trip.cachedStatus,
          starttime: this.timeService.convertMillisecondsToDateTimeS(
            trip.plannedStartTime
          ),
          endtime: this.timeService.convertMillisecondsToDateTimeS(
            trip.plannedFinishTime
          ),
          activity: this.trip_activities,
        });
      }
    });
    this.all_unique_activities = [];
    this.all_unique_activities = this.all_activities.filter((obj, pos, arr) => {
      return (
        arr.map((mapObj) => mapObj['driver']).indexOf(obj['driver']) === pos
      );
    });
  }

  addtimes(time1: any, time2: any) {
    const [hours1, minutes1] = time1.split(':').map(Number);
    const [hours2, minutes2] = time2.split(':').map(Number);

    let totalHrs = hours1 + hours2;
    let totalMinutes = minutes1 + minutes2;

    if (totalMinutes >= 60) {
      totalHrs += Math.floor(totalMinutes / 60);
      totalMinutes %= 60;
    }

    const formattedHrs = String(totalHrs).padStart(2, '0');
    const formattedMinutes = String(totalMinutes).padStart(2, '0');

    const result = formattedHrs + ':' + formattedMinutes;
    return result;
  }

  compareTimes(time1: any, time2: any) {
    const [hours1, minutes1] = time1.split(':').map(Number);
    const [hours2, minutes2] = time2.split(':').map(Number);

    const totalMinutes1 = hours1 * 60 + minutes1;
    const totalMinutes2 = hours2 * 60 + minutes2;

    return totalMinutes1 - totalMinutes2;
  }

  rectangleRenderer(params: any) {
    const column = params.column;
    const headerName = column.getColDef().headerName;
    let color = 'grey';
    let width = '80px';
    let remainingwidth = '0px';
    let remainingDivColor = 'grey';
    let isDrop: boolean = false;
    let isPickup: boolean = false;
    let pickupHeadername: any;
    let dropHeadername: any;
    let pickupwidth = '0px';
    let travelwidth = '0px';
    let dropwidth = '0px';
    let isNew: boolean = false;
    let displayToolTip: any;
    let displayToolTipTravell: any;
    let displayToolDriverDetails: any;
    let displayToolTipDrop: any;
    let tripColour: any;
    let travellColour: any;
    let travel = params.data.travelTime;

    this.driverAssignTrip.forEach((trip: any) => {
      if (params.data.id === trip.driverId) {
        //first pickup
        let firstPickup: any;
        let lastDrop: any;
        if (params.data.pickupTime.length > 0) {
          firstPickup = params.data.pickupTime[0].pickupTime;
        }

        if (params.data.dropTime) {
          let length = params.data.dropTime.length;
          let dropObj = params.data.dropTime;
          lastDrop = dropObj[length - 1]?.dropTime;
        }

        let compareHeaderWithPickUp;
        let compareHeaderWithDrop;

        if (lastDrop == null) {
          //color = 'red';
          const [tripColor, travelColor] = this.getColor(params.data.colour);
          if (travelColor) color = travelColor;
        } else if (firstPickup == null && lastDrop != null) {
          compareHeaderWithDrop = this.compareTimes(headerName, lastDrop);
          if (compareHeaderWithDrop <= 0) {
            //color = 'red';
            const [tripColor, travelColor] = this.getColor(params.data.colour);
            if (travelColor) color = travelColor;
          }
        } else if (firstPickup != null && lastDrop != null) {
          compareHeaderWithPickUp = this.compareTimes(headerName, firstPickup);
          compareHeaderWithDrop = this.compareTimes(headerName, lastDrop);

          if (compareHeaderWithPickUp >= 0 || compareHeaderWithDrop <= 0) {
            //color = 'red';
            const [tripColor, travelColor] = this.getColor(params.data.colour);
            if (travelColor) color = travelColor;
          }
        }

        /// for pickup time /////////////////
        if (params.data.pickupTime) {
          let pickupTimeArr = params.data.pickupTime;

          pickupTimeArr.forEach((obj: any) => {
            let pickup = obj.pickupTime;
            /**set the  pick tooltip here */
            let compareHeaderTimeWithPickup = this.compareTimes(
              headerName,
              pickup
            );
            if (compareHeaderTimeWithPickup <= 0) {
              //header smaller than pickup end
              //add 2 hrs

              // let columnEndTime = headerName.split(':')[0];
              //columnEndTime = ((columnEndTime + 2) % 24).toString();
              //columnEndTime = columnEndTime + ':00';

              let timeMoment = moment(headerName, 'HH:mm');
              let columnEndTime = timeMoment.add(2, 'hours').format('HH:mm');
              if (columnEndTime == '00:00') columnEndTime = '24:00';

              let comparePickupWithColumnEnd = this.compareTimes(
                columnEndTime,
                pickup
              );

              travel.forEach((element: any) => {
                if (obj.pickupLocationid === element.travelFrom) {
                  displayToolTipTravell =
                    'Travell ' +
                    element.travelFrom +
                    ' to  ' +
                    element.travelTo +
                    ' ' +
                    element.travelTimeinHrs +
                    ' (' +
                    element.travelactivityTime +
                    ')';
                }
              });
              if (comparePickupWithColumnEnd > 0) {
                //show pick
                isPickup = true;
                pickupHeadername = headerName;
                let widthInHrs = this.substractHrs(pickup, headerName);
                let value = this.calculatePixelsBasedOnTime(widthInHrs);
                width = value + 'px';
                remainingwidth = 80 - value + 'px';
                const [tripColor, travelColor] = this.getColor(
                  params.data.colour
                );
                if (tripColor) color = tripColor;
                if (travelColor) remainingDivColor = travelColor;
                displayToolTip =
                  'Pickup at ' +
                  obj.pickupLocationid +
                  ' ' +
                  obj.pickupTime +
                  ' (' +
                  obj.pickupactivityTime +
                  ')';
                travel.forEach((element: any) => {
                  if (obj.pickupLocationid === element.travelFrom) {
                    displayToolTipTravell =
                      'Travell ' +
                      element.travelFrom +
                      ' to  ' +
                      element.travelTo +
                      ' ' +
                      element.travelTimeinHrs +
                      ' (' +
                      element.travelactivityTime +
                      ')';
                  }
                });
              }
            }
            travel.forEach((element: any) => {
              if (obj.pickupLocationid === element.travelFrom) {
                displayToolTipTravell =
                  'Travell ' +
                  element.travelFrom +
                  ' to  ' +
                  element.travelTo +
                  ' ' +
                  element.travelTimeinHrs +
                  ' (' +
                  element.travelactivityTime +
                  ')';
              }
            });

            //////////////////pickup start time
            let pickupInitialtime = obj.pickupInitialtime;
            if (pickupInitialtime != '00:00') {
              let compareHeaderTimeWithPickupStart = this.compareTimes(
                headerName,
                pickupInitialtime
              );
              if (compareHeaderTimeWithPickupStart <= 0) {
                let timeMoment = moment(headerName, 'HH:mm');
                let columnEndTime = timeMoment.add(2, 'hours').format('HH:mm');
                let comparePickupWithColumnEnd = this.compareTimes(
                  columnEndTime,
                  pickupInitialtime
                );

                if (comparePickupWithColumnEnd > 0) {
                  isPickup = true;
                  pickupHeadername = headerName;
                  let widthInHrs = this.substractHrs(
                    columnEndTime,
                    pickupInitialtime
                  );
                  let value = this.calculatePixelsBasedOnTime(widthInHrs);
                  remainingwidth = value + 'px';
                  width = 80 - value + 'px';
                  //color = 'red';
                  //remainingDivColor = 'yellow';

                  const [tripColor, travelColor] = this.getColor(
                    params.data.colour
                  );
                  if (travelColor) color = travelColor;
                  if (tripColor) remainingDivColor = tripColor;

                  travel.forEach((element: any) => {
                    if (obj.pickupLocationid === element.travelFrom) {
                      displayToolTip =
                        'Travell ' +
                        element.travelFrom +
                        ' to  ' +
                        element.travelTo +
                        ' ' +
                        element.travelTimeinHrs +
                        ' (' +
                        element.travelactivityTime +
                        ')';
                    }
                  });
                  // displayToolTip = "Pickup at "+ obj.pickupLocationid +" "+ obj.pickupTime +" ("+ obj.pickupactivityTime +")"
                  displayToolTipTravell =
                    'Pickup at ' +
                    obj.pickupLocationid +
                    ' ' +
                    obj.pickupTime +
                    ' (' +
                    obj.pickupactivityTime +
                    ')';
                }
              }
            }
          });
        }
        if (params.data.dropTime) {
          let dropTimeArr = params.data.dropTime;
          dropTimeArr.forEach((obj: any) => {
            let drop = obj.dropTime;

            let compareHeaderTimeWithDrop = this.compareTimes(headerName, drop);
            if (compareHeaderTimeWithDrop <= 0) {
              //add 2 hrs
              let timeMoment = moment(headerName, 'HH:mm');
              let columnEndTime = timeMoment.add(2, 'hours').format('HH:mm');
              let compareDropWithColumnEnd = this.compareTimes(
                columnEndTime,
                drop
              );

              if (compareDropWithColumnEnd > 0) {
                //show drop
                isDrop = true;
                dropHeadername = headerName;
                let widthInHrs = this.substractHrs(drop, headerName);
                let value = this.calculatePixelsBasedOnTime(widthInHrs);
                width = value + 'px';
                remainingwidth = 80 - value + 'px';
                //color = 'black';
                const [tripColor, travelColor] = this.getColor(
                  params.data.colour
                );
                if (tripColor) color = tripColor;

                displayToolTip =
                  'Drop at ' +
                  obj.dropLocationId +
                  ' ' +
                  obj.dropTime +
                  ' (' +
                  obj.dropactivityTime +
                  ')';
                if (lastDrop === drop) {
                  remainingDivColor = 'transparent';
                  displayToolTipTravell = '';
                } else {
                  //remainingDivColor = 'red';
                  if (travelColor) remainingDivColor = travelColor;
                  travel.forEach((element: any) => {
                    if (obj.dropLocationId === element.travelFrom) {
                      displayToolTipTravell =
                        'Travell ' +
                        element.travelFrom +
                        'to  ' +
                        element.travelTo +
                        ' ' +
                        element.travelTimeinHrs +
                        ' (' +
                        element.travelactivityTime +
                        ')';
                    }
                  });
                }
              }
            }

            let compareLastdropWithHeader = this.compareTimes(
              headerName,
              lastDrop
            );
            if (compareLastdropWithHeader > 0) color = 'transparent';
            else
              travel.forEach((element: any) => {
                if (obj.dropLocationId === element.travelFrom) {
                  displayToolTipTravell =
                    'Travell ' +
                    element.travelFrom +
                    'to  ' +
                    element.travelTo +
                    ' ' +
                    element.travelTimeinHrs +
                    ' (' +
                    element.travelactivityTime +
                    ')';
                }
              });
            //remainingwidth = '80px';
          });
        }
      }
    });

    if (isPickup && isDrop && pickupHeadername === dropHeadername) {
      isNew = true;
      let pickup = params.data.pickupTime[0].pickupTime;
      let drop = params.data.dropTime[0].dropTime;
      let initialDroptime = params.data.dropTime[0].dropInitialTime;
      let travelTimeinHrs = params.data.travelTime[0].travelTimeinHrs;
      let widthInHrs = this.substractHrs(pickup, headerName);
      let value = this.calculatePixelsBasedOnTime(widthInHrs);
      pickupwidth = value + 'px';
      displayToolTip =
        'Pickup at ' +
        params.data.pickupTime[0].pickupLocationid +
        ' ' +
        params.data.pickupTime[0].pickupTime +
        ' (' +
        params.data.pickupTime[0].pickupactivityTime +
        ')';

      widthInHrs = this.substractHrs(initialDroptime, pickup);
      value = this.calculatePixelsBasedOnTime(widthInHrs);
      travelwidth = value + 'px';
      displayToolTip =
        'Travell ' +
        params.data.travelTime[0].travelFrom +
        ' to  ' +
        params.data.travelTime[0].travelTo +
        ' ' +
        params.data.travelTime[0].travelTimeinHrs +
        ' (' +
        params.data.travelTime[0].travelTimeinMin +
        ')';

      if (travelwidth == '0px') travelwidth = '2px';

      widthInHrs = this.substractHrs(drop, travelTimeinHrs);
      value = this.calculatePixelsBasedOnTime(widthInHrs);
      dropwidth = value + 'px';
      displayToolTipDrop =
        'Drop at ' +
        params.data.dropTime[0].dropLocationId +
        ' ' +
        params.data.dropTime[0].dropTime +
        ' (' +
        params.data.dropTime[0].dropactivityTime +
        ')';
      if (dropwidth == '0px') dropwidth = '2px';
      //if(drop)
    }

    if ((isPickup || isDrop) && !isNew) {
      const container = document.createElement('div');
      container.style.display = 'flex';
     
      // Create custom tooltip div
      const customTooltip = document.createElement('div');
      customTooltip.classList.add('custom-tooltip');
      customTooltip.innerHTML = `
          <p><span>Trip No:</span>${this.driver.id}</p>
          <p><span>Driver: </span>${this.driver.name}</p>
          <p><span>Truck: </span>${this.driver.id}</p>
          <p><span>Trailer1: </span>${this.driver.travelTime}</p>
          <p><span>Trailer2: </span>${this.driver.travelTime}</p>
          <p><span></span>⚠ Trip contains invalid activities</p>
      `;
      container.appendChild(customTooltip);
  
      // Create button
      const button = document.createElement('button');
      const buttonContent = document.createElement('div');
      buttonContent.classList.add('Logos');
      buttonContent.innerHTML = `
          <mat-icon>report_problem</mat-icon>
          <span>|</span>${this.driver.name}<span>|</span>
          <mat-icon>person</mat-icon>
          <span>|</span>
          <mat-icon class="flipped-icon">local_shipping</mat-icon>
          <span>|</span>
          <mat-icon>directions_car</mat-icon>
          <span>|</span>*
          <span>|</span>
      `;
      button.appendChild(buttonContent);
      container.appendChild(button);
  
      // Append the container to the document or any other parent element
      document.body.appendChild(container);
      const yellowDiv = document.createElement('div');
      yellowDiv.style.width = width;
      yellowDiv.style.height = '40px';
      yellowDiv.title = displayToolTip;
      yellowDiv.style.background = color;

      const redDiv = document.createElement('div');
      redDiv.style.width = remainingwidth;
      redDiv.style.height = '40px';
      redDiv.title = displayToolTipTravell;
      redDiv.style.background = remainingDivColor;

      container.appendChild(yellowDiv);
      container.appendChild(redDiv); // You can also add event listeners or other logic here if neededreturn container;;
      
      return container;
    } else if (isNew) {
      const [tripColor, travelColor] = this.getColor(params.data.colour);
      if (travelColor) color = travelColor;
      if (tripColor) remainingDivColor = tripColor;
      const container = document.createElement('div');
      container.style.display = 'flex';
      const pickupDiv = document.createElement('div');
      pickupDiv.style.width = pickupwidth;
      pickupDiv.style.height = '40px';
      pickupDiv.style.background = remainingDivColor;
      displayToolTip =
        'Pickup at ' +
        params.data.pickupTime[0].pickupLocationid +
        ' ' +
        params.data.pickupTime[0].pickupTime +
        ' (' +
        params.data.pickupTime[0].pickupactivityTime +
        'm)';
      pickupDiv.title = displayToolTip;

      displayToolTipTravell =
        'Travel ' +
        params.data.travelTime[0].travelFrom +
        'to ' +
        params.data.travelTime[0].travelTo +
        ' ' +
        params.data.travelTime[0].travelTimeinHrs +
        ' (' +
        params.data.travelTime[0].travelactivityTime +
        'm)';
      const travelDiv = document.createElement('div');
      travelDiv.style.width = travelwidth;
      travelDiv.style.height = '30px';
      travelDiv.style.marginBlockStart = '5px';
      travelDiv.style.marginBlockEnd = '5px';
      travelDiv.style.background = color;
      travelDiv.title = displayToolTipTravell;

      const dropDiv = document.createElement('div');
      dropDiv.style.width = dropwidth;
      dropDiv.style.height = '40px';
      dropDiv.style.background = remainingDivColor;
      dropDiv.title = displayToolTipDrop;

      container.appendChild(pickupDiv);
      container.appendChild(travelDiv);
      container.appendChild(dropDiv); // You can also add event listeners or other logic here if neededreturn container;;

      return container;
    } else {
      const div = document.createElement('div');
      div.style.width = width;
      div.style.height = '40px';
      div.style.backgroundColor = color;
      div.title = displayToolTipTravell;
      return div.outerHTML;
    }
    //})

  }

  getColor(status: any) {
    let tripColor, travelColor;
    if (status == 'D ') {
      //despatched
      tripColor = '#f5911f';
      travelColor = '#a75c07';
      87;
    } else if (status == 'P ') {
      //Planned
      tripColor = '#00aaa6';
      travelColor = '#004442';
    } else if (status === 'U ') {
      //despatched
      tripColor = '#f5911f';
      travelColor = '#a75c07';
    } else if (status === 'L ') {
      //transit
      tripColor = '#d450c5';
      travelColor = '#99258b';
    } else if (status === 'T ') {
      //transit
      tripColor = '#d450c5';
      travelColor = '#99258b';
    } else if (status === 'RD ') {
      //ready
      tripColor = '#00aaa6';
      travelColor = '#004442';
    }
    return [tripColor, travelColor];
  }

  substractHrs(time1: any, time2: any) {
    const [hours1, minutes1] = time1.split(':').map(Number);
    const [hours2, minutes2] = time2.split(':').map(Number);

    let resultHours = hours1 - hours2;
    let resultMinutes = minutes1 - minutes2;

    if (resultMinutes < 0) {
      resultHours -= 1;
      resultMinutes += 60;
    }

    // Ensure the result is in 24-hour format
    resultHours = (resultHours + 24) % 24;

    const formattedResult = `${resultHours
      .toString()
      .padStart(2, '0')}:${resultMinutes.toString().padStart(2, '0')}`;
    return formattedResult;
  }

  calculatePixelsBasedOnTime(timeInHrs: any) {
    const [hours1, minutes1] = timeInHrs.split(':').map(Number);
    const totalMinutes = hours1 * 60 + minutes1;
    const width = totalMinutes / 1.5;
    return width;
  }
  onGridReady(params: GridReadyEvent<Driver>) {
    this.gridApi = params.api;
    this.selectedOptions = [];
    this.columnDefs.forEach((col) => {
      if (col.hide == true) {
        return;
      }
      let a = /^\d+/.test(col.headerName!);
      if (a) {
        return;
      } else {
        this.selectedOptions.push(col.field);
        this.columnFields2.push(col);
      }
    });
  }

  ViewDataDrivers: any[] = [];

  driver: Driver = {
    id: '',
    name: '',
    company: '',
    pdtloginId: '',
    pickupTime: [],
    travelTime: [],
    dropTime: [],
    colour: '',
    truckId: ''
  };

  columnDefs: ColDef[] = this.columnFields;
  columnFields2: ColDef[] = [];
  ngOnInit() {
    // this.selectedOptions = this.columnDefs.map(coulmn => coulmn.field);
    this.authenticationService.viewAPI.subscribe((result) => {
      this.ViewDataDrivers = result['ref'].drivers;
      this.getDrivers(this.ViewDataDrivers);
    });
    // TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
  }

  driverAssignTrip: any;
  selectedOptions: any[];
  //Get Driver info from View API
  getDrivers(viewdrivers: any[]) {
    let drivers: Driver[] = [];
    viewdrivers.forEach((element: any) => {
      this.driver = {
        id: '',
        name: '',
        company: '',
        pdtloginId: '',
        pickupTime: [],
        travelTime: [],
        dropTime: [],
        colour: '',
        truckId: ''
      };
      if (element.active == true) {
        if (element.surname != null && element.firstName != null) {
          this.driver.id = element.id;
          this.driver.name =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName;
          this.driver.company = element.companyId;
          this.driver.pdtloginId = element.mdtCode;
        } else if (element.employeeName != null) {
          this.driver.id = element.id;
          this.driver.name = element.employeeName;
          this.driver.company = element.companyId;
          this.driver.pdtloginId = element.mdtCode;
        }
        // this.driver.Gantttest = this.dateCycleResult.trips;
        this.driverAssignTrip = this.dateCycleResult.trips;
        this.driverAssignTrip.forEach((trip: any) => {
          if (element.id == trip.driverId) {
            /**Starting time assign to time */
            this.driver.colour = trip.cachedStatus;
            let time: any = '00:00';
            let timeinMin: number = 0;
            let pickuplocation;
            let executedOnce = false;
            trip.activities.forEach((activity: any) => {
              if (
                activity.dropLocationId == null &&
                activity.pickupLocationId !== null
              ) {
                let pickupinitialTime = time;
                time = this.calculateTime(time, activity.activityTime);
                if (this.dateCycleResult.dateCycle.from === trip.tripDate) {
                  if (this.isTimeGreaterThan24Hours(time)) {
                  } else {
                    let pickupObj = {
                      pickupLocationid: activity.pickupLocationId,
                      pickupTime: time,
                      pickupactivityTime: activity.activityTime,
                      pickupInitialtime: pickupinitialTime,
                    };
                    this.driver.pickupTime.push(pickupObj);
                  }
                } else {
                  if (this.isTimeGreaterThan24Hours(time)) {
                    let pickupinitialTime = time;
                    let newTime = this.calculateNewTime(time);
                    let pickupObj = {
                      pickupLocationid: activity.pickupLocationId,
                      pickupTime: time,
                      pickupactivityTime: activity.activityTime,
                      pickupInitialtime: pickupinitialTime,
                    };
                    this.driver.pickupTime.push(pickupObj);
                  }
                }
              } else if (
                activity.dropLocationId !== null &&
                activity.pickupLocationId !== null
              ) {
                time = this.calculateTime(time, activity.activityTime);
                if (this.dateCycleResult.dateCycle.from === trip.tripDate) {
                  if (this.isTimeGreaterThan24Hours(time) && !executedOnce) {
                    let newTime = this.calculateNewTime(time);
                    let travekObj = {
                      travelTimeinMin: activity.activityTime,
                      travelTimeinHrs: newTime,
                      travelFrom: activity.pickupLocationId,
                      travelTo: activity.dropLocationId,
                      travelactivityTime: activity.activityTime,
                    };
                    this.driver.travelTime.push(travekObj);
                    executedOnce = true;
                  } else {
                    if (!executedOnce) {
                      let travekObj = {
                        travelTimeinMin: activity.activityTime,
                        travelTimeinHrs: time,
                        travelFrom: activity.pickupLocationId,
                        travelTo: activity.dropLocationId,
                        travelactivityTime: activity.activityTime,
                      };
                      this.driver.travelTime.push(travekObj);
                    }
                  }
                } else {
                  if (this.isTimeGreaterThan24Hours(time)) {
                    let newTime = this.calculateNewTime(time);
                    let travekObj = {
                      travelTimeinMin: activity.activityTime,
                      travelTimeinHrs: newTime,
                      travelFrom: activity.pickupLocationId,
                      travelTo: activity.dropLocationId,
                    };
                    this.driver.travelTime.push(travekObj);
                  }
                }
              } else if (
                activity.dropLocationId !== null &&
                activity.pickupLocationId == null
              ) {
                let dropinitialTime = time;
                time = this.calculateTime(time, activity.activityTime);
                /**Suppose if today date match and time is >24 hour dont push in object */
                if (this.dateCycleResult.dateCycle.from === trip.tripDate) {
                  if (this.isTimeGreaterThan24Hours(time)) {
                  } else {
                    let dropObj = {
                      dropLocationId: activity.dropLocationId,
                      dropTime: time,
                      dropactivityTime: activity.activityTime,
                      dropInitialTime: dropinitialTime,
                    };
                    this.driver.dropTime.push(dropObj);
                  }
                } else {
                  if (this.isTimeGreaterThan24Hours(time)) {
                    // let dropinitialTime = time;
                    let newTime = this.calculateNewTime(time);
                    let dropinitialTime = newTime;
                    let dropObj = {
                      dropLocationId: activity.dropLocationId,
                      dropTime: newTime,
                      dropactivityTime: activity.activityTime,
                      dropInitialTime: dropinitialTime,
                    };
                    this.driver.dropTime.push(dropObj);
                  }
                }
              }
            });
          }
        });
        drivers.push(this.driver);
      }
    });
    this.rowData = drivers;
  }
  /**Compare tine is >24 or not */
  isTimeGreaterThan24Hours(inputTime: string): boolean {
    const [hoursStr, minutesStr] = inputTime.split(':');
    const hours = parseInt(hoursStr, 10);
    const minutes = parseInt(minutesStr, 10);

    const totalMinutes = hours * 60 + minutes;

    return totalMinutes > 24 * 60;
  }
  /**
   * Calculate time is greater than 24 or not
   */
  calculateNewTime(inputTime: string): string {
    const [hoursStr, minutesStr] = inputTime.split(':');
    const hours = parseInt(hoursStr, 10);
    const minutes = parseInt(minutesStr, 10);

    const totalMinutes = hours * 60 + minutes;

    let resultTime: string;

    if (totalMinutes > 24 * 60) {
      const newTotalMinutes = totalMinutes - 24 * 60;
      const newHours = Math.floor(newTotalMinutes / 60);
      const newMinutes = newTotalMinutes % 60;
      resultTime = `${this.padZero(newHours)}:${this.padZero(newMinutes)}`;
    } else {
      resultTime = inputTime;
    }

    return resultTime;
  }
  /**
   *
   */
  findIntervalStart(timeToCheck: string): string {
    const timeArray: string[] = timeToCheck.split(':');
    const hours: number = parseInt(timeArray[0], 10);

    // Calculate the start of the interval
    const intervalStartHours: number = Math.floor(hours / 2) * 2;

    // Format the result time
    const resultHours: string = this.padZero(intervalStartHours);

    return `${resultHours}:00`;
  }

  /**Min time converter */
  calculateTime(initialTime: string, minutesToAdd: number): string {
    // Convert initial time to minutes
    const initialTimeArray: string[] = initialTime.split(':');
    const initialHours: number = parseInt(initialTimeArray[0], 10);
    const initialMinutes: number = parseInt(initialTimeArray[1], 10);
    const initialTimeInMinutes: number = initialHours * 60 + initialMinutes;

    // Add minutes to initial time
    const totalMinutes: number = initialTimeInMinutes + minutesToAdd;

    // Calculate hours and remaining minutes
    const hours: number = Math.floor(totalMinutes / 60);
    const remainingMinutes: number = totalMinutes % 60;

    // Format the result time
    const resultHours: string = this.padZero(hours);
    const resultMinutes: string = this.padZero(remainingMinutes);

    return resultHours + ':' + resultMinutes;
  }

  padZero(value: number): string {
    return value < 10 ? `0${value}` : `${value}`;
  }

  //on row selection
  info: any[];
  onSelectionChanged(event: any) {
    this.info=[];
    const selectedRows = this.gridApi.getSelectedRows();
    if(selectedRows.length!=0){
      this.ViewDataDrivers.forEach((element) => {
        if (element.id == selectedRows[0].id) {
          this.info = element;
        }
      });
      this.driverSelect.emit(this.info);

    }
    else{
      this.driverSelect.emit(this.info);
    }
   
  }
  
  //Go to Driver Roster page
  EditDriverRoster() {
    // this.router.navigate(['/driverroster']);
    window.open('/driverroster');
  }
  clearFilters() {
    this.columnFields.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.columnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
}

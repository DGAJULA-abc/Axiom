import { AfterViewInit, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AgEditorComponent, ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { PlanService } from '../../../services/plan.service';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';

@Component({
  selector: 'app-date-cell-renderer',
  templateUrl: './date-cell-renderer.component.html',
  styleUrls: ['./date-cell-renderer.component.scss']
})
export class DateCellRendererComponent implements ICellRendererAngularComp {
  // dateValue: string;
  // selectedDate:Date
  params: any;
 xyz:any="";
//  onDateChange(event: any) {
//   // Emit event when a date is selected
//   // this.planService.setDateSelected(true);
//   // this.planService.dateSelectedSubject.next(true);
//   // console.log('heloooo')
//     // Check if the event contains the date information
//     console.log(event)
//     if (event && event.data && event.data.date) {
//       // If a date is present in the row, call the service method
//       this.planService.setDateSelected(true);
//       console.log('Date selected:', event.data.date);
//     } else {
//       console.log('No date selected in this row.');
//     }
// }
// onDateChange(date: Date) {
//   if (date) {
//     // If a date is selected, perform necessary actions
//     this.planService.dateSelectedSubject.next(true);
//     console.log('Date selected:', date);
//   } else {
//     // If no date is selected (date is null or undefined), perform necessary actions
//     this.planService.dateSelectedSubject.next(false);
//     console.log('No date selected.');
//   }
// }
// onDateCleared() {
//   console.log('Date cleared:',);
//   this.planService.dateSelectedSubject.next(false); // Set onDateChange to false when the date is cleared
// }
 
 //harcode the value from calendar for now
//  getValue() {
//     //  return Number(moment(this.selectedDate,'DD-MM-YYYY HH:mm:ss').format('x'));
//     let x = moment(this.selectedDate) .set({
//       second: 0,
//     })
//     let y =  moment(
//       moment.tz(x, 'Australia/Melbourne').clone().tz('Asia/Kolkata')
//     ).valueOf()
//     return moment(y).format('DD/MM/YY HH:mm:ss');
//  }

  constructor(public planService: PlanService,public timeService:TimeRunsheetService
    ){ 
  }
 
  agInit(params: ICellRendererParams<any, any>): void {
    this.params=params;
    console.log(this.params)
    if(params.value!=""){
      if(params.value.split(' ')[0].includes("/")){
        this.xyz=params.value.split(' ')[0];
      }
      else{
        this.xyz = this.timeService.convertMillisecondsToDate(Number(params.value));

      }
      this.planService.dateSelectedSubject.next(false);
    }
    else{
      this.planService.dateSelectedSubject.next(false);
    }
   
  }

  ngOnInit(): void {
    
  }
  refresh(params: ICellRendererParams) {
    return false;
  }
  
}

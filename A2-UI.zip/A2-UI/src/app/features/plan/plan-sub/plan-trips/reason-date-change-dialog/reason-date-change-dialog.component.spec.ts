import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasonDateChangeDialogComponent } from './reason-date-change-dialog.component';

describe('ReasonDateChangeDialogComponent', () => {
  let component: ReasonDateChangeDialogComponent;
  let fixture: ComponentFixture<ReasonDateChangeDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReasonDateChangeDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReasonDateChangeDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

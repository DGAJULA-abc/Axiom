import {
  Component,
  ElementRef,
  Inject,
  OnInit,
  ViewEncapsulation,
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import {
  AllocateEventPayload,
  TripDateCycle,
} from '../../../models/plan.model';
import { PlanService } from '../../../services/plan.service';

@Component({
  selector: 'app-allocated-dialog',
  templateUrl: './allocated-dialog.component.html',
  styleUrls: ['./allocated-dialog.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None,
})
export class AllocatedDialogComponent implements OnInit {
  date_today: Date = new Date();
  eventdatetime: Date = this.date_today;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public planService: PlanService,
    public dialogRef: MatDialogRef<AllocatedDialogComponent>,
    private messageService: MessageService,
    private el: ElementRef
  ) {}
  ngOnInit(): void {
  }
 
  payload_arr: AllocateEventPayload[] = [];
  payload: AllocateEventPayload = {
    datasourceId: '',
    driverId: 0,
    eventTypeId: 0,
    loggedDateTime: 0,
    siteId: 0,
    trailerId: '',
    trailerTagId: '',
    tripId: 0,
    truckId: '',
  };
  selectedtripId: number;
  onOk() {
    this.data.trips.forEach((element: TripDateCycle) => {
      this.payload.datasourceId = this.data.datasource;
      this.payload.driverId = element.driverId;
      this.payload.eventTypeId = this.data.eventType.id;
      let start_date;
      start_date = moment(this.eventdatetime);
      start_date = start_date.format('YYYY-MM-DD HH:mm:ss');
      let a = moment(
        moment.tz(start_date, 'Australia/Melbourne').clone().tz('Asia/Kolkata')
      ).valueOf();
      this.payload.loggedDateTime = a;
      this.payload.siteId = this.data.eventType.siteId;
      this.payload.trailerId = element.trailerId;
      this.payload.trailerTagId = element.trailerIdTag;
      this.payload.tripId = element.id;
      this.selectedtripId = element.id;
      this.payload.truckId = element.truckId;
      this.payload_arr.push(this.payload);
    });

    this.planService.putEvent(this.payload_arr).subscribe((result: any) => {
      if (result) {
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
      // this.planService.getTripEvent(this.selectedtripId).subscribe((res:any) =>{
      // })
    });
    this.dialogRef.close();
  }
  onCancel() {
    this.dialogRef.close();
  }
}

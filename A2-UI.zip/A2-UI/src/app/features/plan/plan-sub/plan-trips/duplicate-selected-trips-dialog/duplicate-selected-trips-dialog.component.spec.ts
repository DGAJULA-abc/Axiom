import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DuplicateSelectedTripsDialogComponent } from './duplicate-selected-trips-dialog.component';

describe('DuplicateSelectedTripsDialogComponent', () => {
  let component: DuplicateSelectedTripsDialogComponent;
  let fixture: ComponentFixture<DuplicateSelectedTripsDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DuplicateSelectedTripsDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DuplicateSelectedTripsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

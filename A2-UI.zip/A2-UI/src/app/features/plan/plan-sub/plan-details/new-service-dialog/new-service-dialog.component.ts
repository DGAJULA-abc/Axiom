import { Component, Inject, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PlanService } from '../../../services/plan.service';
import {
  EventTable,
  GetEvent,
  ResourceAllocation,
  ServiceDateCycle,
  ViewContainers,
  ViewDriver,
} from '../../../models/plan.model';
import { result } from 'lodash';

@Component({
  selector: 'app-new-service-dialog',
  templateUrl: './new-service-dialog.component.html',
  styleUrls: ['./new-service-dialog.component.scss'],
})
export class NewServiceDialogComponent {
  containerForm: FormGroup;
  constructor(
    public dialogRef: MatDialogRef<NewServiceDialogComponent>,
    private planService: PlanService,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}
  customers: any[] = [];
  vessels: any[] = [];
  locations: any[] = [];
  depot: any[] = [];
  Priority: any[] = [
    { id: 1, name: 'Low' },
    { id: 2, name: 'Medium' },
    { id: 3, name: 'High' },
  ];

  isLoading: boolean = true;
  selectedsitedescription: any = '';
  sites: any[] = [];
  addbutton: boolean = true;
  ViewTrucks: ResourceAllocation[] = [];

  customerIdforFeild: any;
  selectedsite: any;
  datatime: any = new Date();
  ViewApidata: any;

  ngOnInit(): void {
    this.getMetaData();
    this.ViewApidata = this.data.viewdata;
    this.getCustomers(this.ViewApidata['ref'].customers);
    this.getCustomers1(this.ViewApidata['ref'].customers);
    this.getVessels(this.ViewApidata['ref'].vessels);
    this.getHomeLocations(this.ViewApidata['ref'].locations);
    this.getContainers(this.ViewApidata['ref'].containers);
    this.selectedsite = this.ViewApidata.selectedSite;
    this.getSites(this.ViewApidata['ref'].sites);
    this.customerIdforFeild = this.data.selectedcustomerdata.customerId;
    this.getPriority();
    this.containerForm = this.formBuilder.group({
      conNote: '',
      containerId: '',
      customerId: '',
      customerReference: '',
      customerSite: '',
      dehireDeadline: '',
      dehirePark: '',
      deliveryClose: ['', Validators.required],
      deliveryOpen: ['', Validators.required],
      depot: '',
      finalDestinationLocation: '',
      finalDestinationSite: [''],
      importExportOptions: ['', Validators.required],
      loadNo: '',
      numberOfLoads: '',
      numberOfPallets: '',
      primaryOriginLocation: '',
      primaryOriginSite: [''],
      priority: '',
      remarks: '',
      shippingDate: this.datatime,
      vesselEta: '',
      vesselId: '',
      weightInTonnes: '',
      wharf: '',
    });
    this.selectingSite();
  }

  metadata: any;
  ServicesImport: any[] = [];
  ServicesExport: any[] = [];
  ImportExportbutton: boolean = false;
  defaultButtonToggle: string = 'Import';
  getMetaData() {
    this.planService.getMetadata().subscribe((res: any) => {
      this.metadata = res.container.options;
      this.metadata.forEach((ele: any) => {
        if (ele.type == 'import') {
          this.ServicesImport.push(ele.importExportOptions);
        } else if (ele.type == 'export') {
          this.ServicesExport.push(ele.importExportOptions);
        }
      });
      this.ImportExportButtons(this.defaultButtonToggle);
    });
  }

  Services: any[] = [];
  ImportExportButtons(ButtonName: any) {
    if (ButtonName == 'Import') {
      this.Services = this.ServicesImport;
    } else if (ButtonName == 'Export') {
      this.Services = this.ServicesExport;
    }
  }

  getCustomers(customers: any[]) {
    customers.forEach((element) => {
      this.customers.push(element.customerId);
    });
  }
  customers1: any[] = [];
  getCustomers1(customers1: any[]) {
    customers1.forEach((element) => {
      this.customers1.push(element);
    });
  }
  filteredCustomers: any;
  filterCustomers(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    // console.log(this.customers);
    // console.log('Group hello user setup');
    for (let i = 0; i < this.customers.length; i++) {
      // let country = JSON.stringify(this.permissionGroups[i]);
      let country = this.customers[i];
      // console.log(country);
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredCustomers = filtered;
  }
  vesselsdata:any;
  getVessels(vessels: any[]) {
    this.vesselsdata=vessels;
    vessels.forEach((element) => {
      this.vessels.push(element.vessel);
    });
  }
  filteredVessels: any;
  filterVessels(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    // console.log(this.vessels);
    // console.log('Group hello user setup');
    for (let i = 0; i < this.vessels.length; i++) {
      // let country = JSON.stringify(this.permissionGroups[i]);
      let country = this.vessels[i];
      // console.log(country);
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredVessels = filtered;
  }
  getHomeLocations(locations: any[]) {
    locations.forEach((element) => {
      this.locations.push(element.locationId);
    });
  }
  filteredHomeLocations: any;
  filterHomeLocations(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    // console.log(this.locations);
    // console.log('Group hello user setup');
    for (let i = 0; i < this.locations.length; i++) {
      // let country = JSON.stringify(this.permissionGroups[i]);
      let country = this.locations[i];
      // console.log(country);
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredHomeLocations = filtered;
  }
  getSites(sites: any[]) {
    sites.forEach((element) => {
      if (element.id == this.selectedsite.id)
        this.sites.push(element.description);
    });
  }
  id: any;
  selectingSite() {
    // console.log(event);
    this.id = this.selectedsite.id;
    this.planService.getAllData(this.id).subscribe((res: any) => {
      this.getLocationsSite(res);
    });
  }
  location: any[] = [];
  getLocationsSite(locationssite: any[]) {
    locationssite.forEach((ele: any) => {
      this.location.push(ele.locationId);
    });
  }

  Priority1: any[] = [];
  getPriority() {
    if (this.Priority) {
      this.Priority.forEach((ele: any) => {
        this.Priority1.push(ele.name);
      });
    }
  }
  filteredPriority: any;
  filterPriority(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    // console.log(this.Priority1);
    // console.log('Group hello user setup');
    for (let i = 0; i < this.Priority1.length; i++) {
      // let country = JSON.stringify(this.permissionGroups[i]);
      let country = this.Priority1[i];
      // console.log(country);
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredPriority = filtered;
  }
  filteredServices: any;
  filterServices(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    //console.log(this.Services);
    //console.log('Group hello user setup');
    for (let i = 0; i < this.Services.length; i++) {
      // let country = JSON.stringify(this.permissionGroups[i]);
      let country = this.Services[i];
      //console.log(country);
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredServices = filtered;
  }
  filteredServicesExport: any;
  filterServicesExport(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    //console.log(this.ServicesExport);
    //console.log('Group hello user setup');
    for (let i = 0; i < this.ServicesExport.length; i++) {
      // let country = JSON.stringify(this.permissionGroups[i]);
      let country = this.ServicesExport[i];
      //console.log(country);
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredServicesExport = filtered;
  }
  

  containers: any[] = [];
  ViewContainers: ViewContainers[] = [];
  getContainers(data: any) {
    data.forEach((ele: any) => {
      this.containers.push(ele.containerId);
    });
  }
  filteredContainers: any[]=[];
  searcheddata:any[]=[];
  labelsdata:any[]=[];
  filterContainer(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    this.planService.searchdata(query).subscribe((res:any)=>{
      this.searcheddata=res;
      this.searcheddata.forEach((label)=>{
        this.labelsdata.push(label.label)
      })
      for (let i = 0; i < this.labelsdata.length; i++) {
        let country = this.labelsdata[i];
        if (country.toLowerCase().includes(query.toLowerCase())) {
          filtered.push(country);
        }
      }
  
      this.filteredContainers = filtered;
    });
  }

  formvalues: any;
  containerData: any;
  VesselEta: any;
  shipdate: any;
  vesselid:any;
  onFormSubmit() {
    this.formvalues = this.containerForm.value;
    this.VesselEta = this.containerForm.controls['vesselEta'].value;
    const vesseleta = new Date(this.VesselEta).getTime();
    this.shipdate = this.containerForm.controls['shippingDate'].value;
    const Shippingdate = new Date(this.shipdate).getTime();

    const matchingSite = this.vesselsdata.find(
      (vessel:any) => vessel.vessel == this.formvalues.vesselId
    );
    if (matchingSite) {
      this.formvalues.vesselId = matchingSite.id;
    }

    const matchingPriority = this.Priority.find(
      (p:any) => p.name == this.formvalues.priority
    );
    if (matchingPriority) {
      this.formvalues.priority = matchingPriority.id;
    }

    const matchingConatiner = this.searcheddata.find(
      (p:any) => p.label == this.formvalues.containerId
    );
    if (matchingConatiner) {
      this.formvalues.containerId = matchingConatiner.id;
    }

     
    this.containerData = {
      conNote: this.containerForm.controls['conNote'].value || null,
      containerId:this.formvalues.containerId||null,
      customerId: this.containerForm.controls['customerId'].value || null,
      customerReference:
        this.containerForm.controls['customerReference'].value || null,
      customerSite: this.containerForm.controls['customerSite'].value || null,
      dehireDeadline: new Date(this.containerForm.controls['dehireDeadline'].value).getTime(),
      dehirePark: this.containerForm.controls['dehirePark'].value || null,
      deliveryClose: new Date(this.containerForm.controls['deliveryClose'].value).getTime(),
      deliveryOpen: new Date(this.containerForm.controls['deliveryOpen'].value).getTime(),
      depot: this.containerForm.controls['depot'].value || null,
      finalDestinationLocation:
        this.containerForm.controls['finalDestinationLocation'].value || null,
      finalDestinationSite: this.id,
      importExportOptions:
        this.containerForm.controls['importExportOptions'].value,
      loadNo: this.containerForm.controls['loadNo'].value || null,
      numberOfLoads: this.containerForm.controls['numberOfLoads'].value || null,
      numberOfPallets:
        this.containerForm.controls['numberOfPallets'].value || null,
      primaryOriginLocation:
        this.containerForm.controls['primaryOriginLocation'].value || null,
      primaryOriginSite: this.id,
      priority: this.formvalues.priority,
      remarks: this.containerForm.controls['remarks'].value || null,
      shippingDate: Shippingdate,
      vesselEta: vesseleta,
      vesselId: this.formvalues.vesselId,
      weightInTonnes:
        this.containerForm.controls['weightInTonnes'].value || null,
      wharf: this.containerForm.controls['wharf'].value || null,
    };
    console.log(this.containerData);

    this.planService
      .validationContainer(this.containerData)
      .subscribe((res: any) => {
        const message = res;
        console.log(message);
      });

    this.planService
      .PostContainer(this.containerData)
      .subscribe((result: any) => {
        console.log(result);
      });

     this.planService.getAllData(this.id).subscribe((res)=>{
      console.log(res);
     }) 
  }
}

import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-add-return-service-dialog',
  templateUrl: './add-return-service-dialog.component.html',
  styleUrls: ['./add-return-service-dialog.component.scss'],
})
export class AddReturnServiceDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<AddReturnServiceDialogComponent>
  ) {}
  flag: boolean = false;

  onYes() {
    this.flag = true;
    this.dialogRef.close({ data: this.flag });
  }

  onNo(): void {
    this.flag = false;
    this.dialogRef.close();
  }
}

import { Component, Inject, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PlanService } from '../../../services/plan.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-new-service-dynon-dialog',
  templateUrl: './new-service-dynon-dialog.component.html',
  styleUrls: ['./new-service-dynon-dialog.component.scss'],
})
export class NewServiceDynonDialogComponent {
  ViewApidata: any;
  selectedsite: any;
  dynonForm: FormGroup;
  customerIdforFeild: any;
  shippingCurrentdate = new Date();
  userOptionData: any;
  LabelBatchName: any;

  times: any[] = [
    '00:00',
    '01:00',
    '02:00',
    '03:00',
    '04:00',
    '05:00',
    '06:00',
    '07:00',
    '08:00',
    '09:00',
    '10:00',
    '11:00',
    '12:00',
    '13:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
    '18:00',
    '19:00',
    '20:00',
    '21:00',
    '22:00',
    '23:00',
  ];

  constructor(
    public dialogRef: MatDialogRef<NewServiceDynonDialogComponent>,
    private planService: PlanService,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}
  ngOnInit() {
    this.getDyonmetadata();
    this.ViewApidata = this.data.viewdata;
    this.getCustomers(this.ViewApidata['ref'].customers);
    this.getLocations(this.ViewApidata['ref'].locations);
    this.selectedsite = this.ViewApidata.selectedSite;
    this.getLoadType(this.ViewApidata['ref'].loadTypes);
    this.getSites(this.ViewApidata['ref'].sites);
    this.customerIdforFeild = this.data.selectedcustomerdata.customerId;

    this.userOptionData = this.ViewApidata['ref'].userOptions;

    const matchinguserOption = this.userOptionData.find(
      (ele: any) => ele.optionName == 'LabelBatchNo'
    );
    if (matchinguserOption) {
      this.LabelBatchName = matchinguserOption.optionValue;
    }

    //Dynon Form
    this.dynonForm = this.formBuilder.group({
      bookedTime: '', //local
      conNote: '',
      containerId: '',
      containerPark: '', //only for importExport
      customerId: '',
      customerReference: '',
      customerSiteRail: '', //only for importExport
      dynonImportExportOptions: '', //only for importExport
      fromSiteRailDepot: '', //Local
      toSiteRailDepot: '', //local
      finalDestination: '', //Local
      finalDestinationLocation: '',
      finalDestinationSite: '',
      loadNo: '',
      loadTypeId: '',
      numberOfLoads: '',
      primaryOriginLocation: '', //Only for import export
      primaryOriginSite: '', // Only for for import export
      remarks: '',
      shippingDate: '',
      weightInTonnes: '',
      wharf: '', //Only for import export
    });

    this.selectingSite();
  }

  //metadata
  metaData: any[];
  Services: any[] = [];
  getDyonmetadata() {
    this.planService.getDyonmetadata().subscribe((res: any) => {
      this.metaData = res.dynon.options;
      this.metaData.forEach((ele) => {
        if (ele.dynonImportExportOptions) {
          this.Services.push(ele.dynonImportExportOptions);
        }
      });
    });
  }

  Local: boolean = false;
  ImportExport: boolean = true;
  ImportExportLocalButtons(buttonName: any) {
    if (buttonName == 'ImportExport') {
      this.Local = false;
      this.ImportExport = true;
    } else if (buttonName == 'Local') {
      this.Local = true;
      this.ImportExport = false;
    }
  }

  //Customer
  customers: any[] = [];
  getCustomers(customers: any[]) {
    customers.forEach((element) => {
      this.customers.push(element.customerId);
    });
  }
  filteredCustomers: any;
  filterCustomers(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.customers.length; i++) {
      let country = this.customers[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredCustomers = filtered;
  }

  //Load Type
  LoadType: any[] = [];
  getLoadType(loadType: any[]) {
    loadType.forEach((element) => {
      this.LoadType.push(element.loadTypeId);
    });
  }
  filteredLoadType: any;
  filterLoadType(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.LoadType.length; i++) {
      let country = this.LoadType[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredLoadType = filtered;
  }

  //Location
  locations: any[] = [];
  getLocations(locations: any[]) {
    locations.forEach((element) => {
      this.locations.push(element.locationId);
    });
  }
  filteredLocations: any;
  filterLocations(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.locations.length; i++) {
      let country = this.locations[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredLocations = filtered;
  }

  //sites
  sites: any[] = [];
  getSites(sites: any[]) {
    sites.forEach((element) => {
      if (element.id == this.selectedsite.id)
        this.sites.push(element.description);
    });
  }

  //forselected site
  id: any;
  selectingSite() {
    // console.log(event);
    this.id = this.selectedsite.id;
    this.planService.getAllData(this.id).subscribe((res: any) => {
      this.getLocationsSite(res);
    });
  }
  locationsites: any[] = [];
  getLocationsSite(locationssite: any[]) {
    locationssite.forEach((ele: any) => {
      this.locationsites.push(ele.locationId);
    });
  }

  //Container and it's api
  filteredContainers: any[] = [];
  searcheddata: any[] = [];
  labelsdata: any[] = [];
  filterContainer(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    this.planService.searchdata(query).subscribe((res: any) => {
      this.searcheddata = res;
      this.searcheddata.forEach((label) => {
        this.labelsdata.push(label.label);
      });
      for (let i = 0; i < this.labelsdata.length; i++) {
        let country = this.labelsdata[i];
        if (country.toLowerCase().includes(query.toLowerCase())) {
          filtered.push(country);
        }
      }

      this.filteredContainers = filtered;
    });
  }

  idassociate: any;
  formdata: any;
  ImportExportdata: any;
  Localdata: any;
  onFormSubmit() {
    console.log(this.dynonForm.value);
    this.formdata = this.dynonForm.value;
    const matchingConatiner = this.searcheddata.find(
      (p: any) => p.label == this.formdata.containerId
    );
    if (matchingConatiner) {
      this.formdata.containerId = matchingConatiner.id;
    }
    let shipdate = this.dynonForm.controls['shippingDate'].value;
    const Shippingdate = new Date(shipdate).getTime();

    if (this.ImportExport) {
      this.ImportExportdata = {
        conNote: this.dynonForm.controls['conNote'].value || null,
        containerId: this.formdata.containerId || null,
        customerId: this.dynonForm.controls['customerId'].value,
        containerPark: this.dynonForm.controls['customerId'].value,
        customerReference:
          this.dynonForm.controls['customerReference'].value || null,
        customerSiteRail:
          this.dynonForm.controls['customerSiteRail'].value || null,
        dynonImportExportOptions:
          this.dynonForm.controls['dynonImportExportOptions'].value || null,
        finalDestinationLocation:
          this.dynonForm.controls['finalDestinationLocation'].value || null,
        finalDestinationSite: this.selectedsite.id,
        loadNo: this.dynonForm.controls['loadNo'].value || null,
        loadTypeId: this.dynonForm.controls['loadTypeId'].value || null,
        numberOfLoads: this.dynonForm.controls['numberOfLoads'].value || null,
        primaryOriginLocation:
          this.dynonForm.controls['primaryOriginLocation'].value || null,
        primaryOriginSite: this.selectedsite.id,
        remarks: this.dynonForm.controls['remarks'].value || null,
        shippingDate: Shippingdate,
        weightInTonnes: this.dynonForm.controls['weightInTonnes'].value || null,
        wharf: this.dynonForm.controls['wharf'].value || null,
      };
      this.planService
        .PostImportExportValidation(this.ImportExportdata)
        .subscribe((res: any) => {
          console.log(res);
        });
      this.planService
        .PostImportExportDyonServices(this.ImportExportdata)
        .subscribe((mes) => {
          this.idassociate = mes[0].id;
          this.planService
            .getAssociatedData(this.idassociate)
            .subscribe((res: any) => {
              console.log(res);
            });
        });
    } else if (this.Local) {
      this.Localdata = {};
      this.planService
        .PostDyonValidation(this.Localdata)
        .subscribe((mes: any) => {
          console.log(mes);
        });
      this.planService
        .PostLocalDyonServices(this.Localdata)
        .subscribe((mes: any) => {
          this.idassociate = mes[0].id;
          this.planService
            .getAssociatedData(this.idassociate)
            .subscribe((res: any) => {
              console.log(res);
            });
        });
    }
  }
}

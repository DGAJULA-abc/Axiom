import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddReturnServiceDialogComponent } from './add-return-service-dialog.component';

describe('AddReturnServiceDialogComponent', () => {
  let component: AddReturnServiceDialogComponent;
  let fixture: ComponentFixture<AddReturnServiceDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddReturnServiceDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddReturnServiceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

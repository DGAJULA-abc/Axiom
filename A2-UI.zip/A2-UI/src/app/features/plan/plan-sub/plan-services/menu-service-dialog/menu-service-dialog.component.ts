import { Component, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';

@Component({
  selector: 'app-menu-service-dialog',
  templateUrl: './menu-service-dialog.component.html',
  styleUrls: ['./menu-service-dialog.component.scss'],
  
})
export class MenuServiceDialogComponent {
  dialogdata:any;
  totalrecords: any;
  totalallocated: any;
  totalunallocated: any;
  allocatedwidth:any;
  unallocatedwidth:any;
  datecheckhere:any;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public timeService:TimeRunsheetService
  ) {}

  ngOnInit(){
    this.dialogdata=this.data;
    this.totalallocated=this.dialogdata.allocate;
    this.totalunallocated=this.dialogdata.unallocate;
    this.totalrecords=this.dialogdata.total;
    this.allocatedwidth=this.dialogdata.allocatewidth;
    this.unallocatedwidth=this.dialogdata.unallocatewidth;
    this.datecheckhere=this.timeService.convertMillisecondsToDate(this.data.date);
    
  }
}

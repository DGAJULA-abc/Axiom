import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { PlanService } from '../../../services/plan.service';
import { Message } from 'primeng/api';
import * as moment from 'moment';

@Component({
  selector: 'app-bulk-copy-dialog',
  templateUrl: './bulk-copy-dialog.component.html',
  styleUrls: ['./bulk-copy-dialog.component.scss'],
})
export class BulkCopyDialogComponent implements OnInit {
  //setting default dates in form calendar
  date_today: Date = new Date();
  date_instance: Date = new Date();
  date_tomorrow = new Date(
    this.date_instance.setDate(this.date_instance.getDate() + 1)
  );
  date_dayAfterTomorrow=new Date( this.date_instance.setDate(this.date_instance.getDate() + 1))
  minDate: Date;

  ngOnInit(): void {
    this.minDate = this.date_today;
  }
  constructor(
    public dialogRef: MatDialogRef<BulkCopyDialogComponent>,
    public planService: PlanService
  ) {}
  //onclicking cancel
  onCancel() {
    this.dialogRef.close();
  }
  //sending harcoded date for now
  fromServiceDate: number;
  toServiceDate: number;
  messages: Message[];
  onBulkCopy() {
    let start_date;
    start_date = moment(this.date_today);
    start_date = start_date
      .set({
        hour:0,
        minute: 0,
        second: 0,
      })
      .format('YYYY-MM-DD HH:mm:ss');
    var s_australia_time = moment.tz(start_date, 'Australia/Melbourne');
    var s_india = s_australia_time.clone().tz('Asia/Kolkata');
    this.fromServiceDate = moment(s_india).valueOf();
    let end_date;
    end_date = moment(this.date_tomorrow);
    end_date = end_date
      .set({
        hour:0,
        minute: 0,
        second: 0,
      })
      .format('YYYY-MM-DD HH:mm:ss');
    var e_australia_time = moment.tz(end_date, 'Australia/Melbourne');
    var e_india = e_australia_time.clone().tz('Asia/Kolkata');
    this.toServiceDate = moment(e_india).valueOf();
    let tempmessage: string = '';
    this.planService
      .BulkCopy(this.fromServiceDate, this.toServiceDate)
      .subscribe((result: any) => {
        tempmessage =
          'Bulk Copy for service(s): ' +
          String(result.services.length) +
          ' completed';
        this.messages = [{
          severity: 'success',
          summary: '',
          detail: tempmessage,
        }];
      });
  }
}

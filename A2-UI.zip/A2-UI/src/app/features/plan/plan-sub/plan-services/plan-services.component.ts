import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
  ViewEncapsulation,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  IRowNode,
  IsRowSelectable,
} from 'ag-grid-community';
import {
  ConfirmationService,
  ConfirmEventType,
  MessageService,
} from 'primeng/api';
import { DateformatComponent } from '../../services/dateformat/dateformat.component';
import {
  CopyService,
  ServiceDateCycle,
  TripDateCycle,
} from '../../models/plan.model';

import { PlanService } from '../../services/plan.service';
import { BulkCopyDialogComponent } from './bulk-copy-dialog/bulk-copy-dialog.component';
import { ServiceStatusComponent } from '../../services/service-status/service-status.component';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { Subscription, throwError } from 'rxjs';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import * as moment from 'moment';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { MenuServiceDialogComponent } from './menu-service-dialog/menu-service-dialog.component';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
@Component({
  selector: 'app-plan-services',
  templateUrl: './plan-services.component.html',
  styleUrls: ['./plan-services.component.scss'],
  providers: [ConfirmationService, MessageService],
  encapsulation: ViewEncapsulation.None,
})
export class PlanServicesComponent implements OnChanges, OnInit, OnDestroy {
  @Output() getselectedservice: EventEmitter<ServiceDateCycle[]> =
    new EventEmitter<ServiceDateCycle[]>();
  @Output() bulkeditmode: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() Tripcreatednotify: EventEmitter<TripDateCycle[]> = new EventEmitter<
    TripDateCycle[]
  >();
  @Output() TripcreatedServicenotify :EventEmitter<ServiceDateCycle[]>=new EventEmitter<ServiceDateCycle[]>
  @Input() servicecreated: boolean;
  @Input() serviceupdated:ServiceDateCycle[];
  @Input() tobedeletedService: ServiceDateCycle;
  @Input() Locationselected: string;
  @Input() selecteddate_hm:any;

  trip_deliverydate:any;

  selectedOptions: any[];

  constructor(
    public dialog: MatDialog,
    public planService: PlanService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    public navbarService: NavbarService,
    public dialogService: DialogService,
    public timeService:TimeRunsheetService
  ) {
    this.gridOptions = {
      context: { Component: this },
      rowDragManaged: true,
      rowDragEntireRow: true,
      onRowDragEnd: () => {
        console.log('Row dragged in services'); // Trigger your method here
      },
      onDragStopped: (event: any) => {
        const selectedNodes = this.gridApi.getSelectedNodes();
        const selectedData = selectedNodes.map((node) => node.data);
        let s: any[] = [];
        this.SelectedRows.forEach((row) => {
          s.push(row.id);
          this.trip_deliverydate= row.loadScheduledDate
        });
        let obj = {
          plannedStartTime:this.trip_deliverydate,
          serviceIds: s,
          siteId: parseInt(sessionStorage.getItem('selectedSiteId')!),
          tripDate: this.trip_deliverydate,
        };
        this.planService
          .TripCreate(obj)
          .pipe(
            catchError((error) => {
              // Handle the error here
              console.log('Error caught in component: ', error);
              let errormessage = error.error.errorList.ErrorMessage;
              let errorurl = error.url;
              let errortime = error.error.errorList.ExceptionTime;
              let multiLineString = `${errormessage}.
URL: ${errorurl}.
Time: ${errortime}.`;

              this.messageService.add({
                severity: 'error',
                summary: error.status,
                detail: multiLineString,
                life: 20000,
              });
              // You can also re-throw the error if needed
              return throwError(error);
            })
          )
          .subscribe((res) => {
            if (res) {
              this.Tripcreatednotify.emit(res.trips);
              this.TripcreatedServicenotify.emit(res.services);
            }
          }, (err: any) => {
            console.log("Undespach error", err);
          let toastmessage = "Trip cannot be created";
          this.messageService.add({
                     severity: 'error',
                      summary: '',
                      detail: toastmessage,
                  });
          });
      },
    };
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          this.dialogService.savaLayout(data);
        }
      }
    );
  }
  /**check for atmosphere */
  AtmosphereData: any;
  private dataSubscription: Subscription;

  ngOnInit(): void {
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);

    this.planService.selectedRowGridT.subscribe((flagT)=>{
      if(flagT){
        this.gridApi.deselectAll();
      }
    })
    // this.dataSubscription = this.navbarService.data$.subscribe((data) => {
    //   this.AtmosphereData = data;
    //   if (this.AtmosphereData) {
    //     if (this.AtmosphereData.services.length != 0) {
    //       const matchingrowindex = this.rowData.findIndex(
    //         (n) => n.id == this.AtmosphereData.services[0].id
    //       );
    //       if (matchingrowindex !== -1) {
    //         var rowNode = this.gridApi.getRowNode(String(matchingrowindex));

    //         rowNode?.setData(this.AtmosphereData.services[0]);

    //         this.messageService.add({
    //           severity: 'success',
    //           summary: '',
    //           detail: 'Service updated after atmosphere!',
    //         });
    //       }
    //     }
    //   }
    // });
  }

  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter,
        };
        columns.push(customColumn);
      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
      return {
        applicationOptionId: 9777,
        optionName: 'a2v3.plan.service-list.grid.layout',
        optionValue: columnValueObj,
        siteId: this.selectedSite,
        userId: this.userName,
      };
    }
  }

  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item['optionName'] === 'a2v3.plan.service-list.grid.layout')
            this.columnState = JSON.parse(item['optionValue']);
          if (this.columnState) {
            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ('name' in column) {
                  column.colId = column.name;
                  delete column.name;
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        });
      }
    );
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true,
    };
    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width }: { colId: any; width: any }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
      }
    });
  }

  columnApi: any;
  columnState: any;
  userName: any;
  selectedSite: any;
  gridOptions: any;
  layoutSubscription: Subscription;
  delete_services: any[] = [];
  serviceselected: boolean = true;
  totalrecords: number = 0;
  totalallocated: number = 0;
  totalunallocated: number = 0;
  allocatedwidth = 'width:';
  unallocatedwidth = 'width:';
  //Service Table data coming from Date Cycle Api
  isServiceDataThere: boolean = true;
  datefromDateCycle:any;
  @Input() servicesdatecycle: ServiceDateCycle[];
  ngOnChanges(changes: SimpleChanges) {
    this.totalrecords = 0;
    this.totalallocated = 0;
    this.totalunallocated = 0;
    this.allocatedwidth = 'width:';
    this.unallocatedwidth = 'width:';

    if (this.servicesdatecycle.length != 0) {
      this.datefromDateCycle=this.selecteddate_hm;
      this.rowData = this.servicesdatecycle;
      this.totalrecords = this.servicesdatecycle.length;
      this.totalallocated = 0;
      this.totalunallocated = 0;
      this.allocatedwidth = 'width:';
      this.unallocatedwidth = 'width:';
      this.rowData.forEach((row) => {
        if (row.driverId == null) {
          //unallocated
          this.totalunallocated += 1;
        } else {
          //allocated
          this.totalallocated += 1;
        }
      });
      //progress bar updates
      if (this.totalunallocated != 0) {
        this.unallocatedwidth =
          this.unallocatedwidth +
          String((this.totalunallocated / this.totalrecords) * 100) +
          '%';
      } else {
        this.unallocatedwidth = this.unallocatedwidth + '0%';
      }

      if (this.totalallocated != 0) {
        this.allocatedwidth =
          this.allocatedwidth +
          String((this.totalallocated / this.totalrecords) * 100) +
          '%';
      } else {
        this.allocatedwidth = this.allocatedwidth + '0%';
      }
    }
    else{
      this.rowData=[];
    }
    if (this.servicecreated == true) {
      this.gridApi.refreshCells();
    }
    if(this.serviceupdated){
      const matchingrowindex = this.rowData.findIndex(
        (n) => n.id == this.serviceupdated[0].id
      );
      if (matchingrowindex !== -1) {
        this.UpdateTable(this.serviceupdated,matchingrowindex)
      }

    }
    if (this.tobedeletedService) {
      this.delete_services.push(this.tobedeletedService);
      const res = this.gridApi.applyTransaction({
        remove: this.delete_services,
      })!;
      this.gridApi.refreshCells();
    }
    if (this.Locationselected != '' && this.Locationselected != 'na') {
      this.rowData = this.rowData.filter(
        (x) => x.locationIdPickup == this.Locationselected
      );
    }
    if (this.Locationselected == 'na') {
      this.rowData = this.servicesdatecycle;
    }
  }
  //AG Grid configuration
  private gridApi!: GridApi<ServiceDateCycle>;

  public rowSelection: 'single' | 'multiple' = 'multiple';
  rowData: ServiceDateCycle[] = [];
  columnFields: ColDef[] = [
    {
      field: 'serviceNo',
      headerName: 'Service No.',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      rowDrag: true,
    },
    { field: 'docket', headerName: 'Docket' },
    { field: 'customerId', headerName: 'Customer' },
    {
      field: 'deliverydate',
      headerName: 'Delivery Date',
      cellRenderer: DateformatComponent,
    },
    {
      field: 'createddatetime',
      headerName: 'Created Date/Time',
      cellRenderer: DateformatComponent,
    },
    {
      field: 'createddate',
      headerName: 'Create Date',
      cellRenderer: DateformatComponent,
    },
    {
      field: 'createdtime',
      headerName: 'Create Time',
      cellRenderer: DateformatComponent,
    },
    { field: 'locationIdDrop', headerName: 'Drop' },
    { field: 'locationIdPickup', headerName: 'Pickup' },
    { field: 'serviceDesc', headerName: 'Service Desc' },
    { field: 'bookedTimeDrop', headerName: 'Drop Time' },
    { field: 'bookedTimePickup', headerName: 'Pickup Time' },
    { field: 'serviceTypeId', headerName: 'Service Type' },
    { field: 'loadTypeId', headerName: 'Load Type' },
    {
      field: 'status',
      headerName: 'Status',
      cellRenderer: ServiceStatusComponent,
    },
    { field: 'tripSeq', headerName: 'Seq' },
    { field: 'loadBatchNo', headerName: 'Cust Ref' },
    { field: 'remarks', headerName: 'Remarks' },
    { field: 'loadNo', headerName: 'Load No.' },
    { field: 'tripId', headerName: 'Trip No.' },
    { field: 'connote', headerName: 'ConNote' },
    { field: 'containerId', headerName: 'Container No' },
    { field: 'containerTypeId', headerName: 'Container Type' },
    { field: 'vesselId', headerName: 'Vessel No' },
    { field: 'enteredBy', headerName: 'Entered By' },
    { field: 'deliverywindow', headerName: 'Delivery Window' },
    { field: 'dropSuburb', headerName: 'Drop Suburb' },
    { field: 'tonnes', headerName: 'TONNES' },
    { field: 'qty1', headerName: 'Qty1.' },
    { field: 'qty2', headerName: 'Qty2.' },
    { field: 'qty3', headerName: 'Qty3.' },
    { field: 'qty4', headerName: 'Qty4.' },
    { field: 'qty5', headerName: 'Qty5.' },
    { field: 'qty6', headerName: 'Qty6.' },
    { field: 'qty7', headerName: 'Qty7.' },
    { field: 'qty8', headerName: 'Qty8.' },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  onGridReady(params: GridReadyEvent<ServiceDateCycle>) {
    this.gridApi = params.api;
  }
  //on row selection
  SelectedRows: ServiceDateCycle[] = [];
  Selectedservice: ServiceDateCycle[] = [];
  Selectedservice2: ServiceDateCycle[] = [];
  duplicatedlink: boolean = false;
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.SelectedRows = selectedRows;

    if(selectedRows.length == 0){
      this.getselectedservice.emit(this.Selectedservice2);
      this.serviceselected = true;
      this.planService.selectedRowGridS.next(false);
    }
    else if (selectedRows.length > 1) {
      this.planService.selectedRowGridS.next(true);
      this.Selectedservice = [];
      this.isServiceDataThere = false;
      selectedRows.forEach((element) => {
        if(element.runsheetId){
          this.isServiceDataThere = true;
        }
        this.Selectedservice.push(element);
      });
      this.bulkeditmode.emit(true);
      this.serviceselected = false;
    } else if(selectedRows.length ==1){
      this.planService.selectedRowGridS.next(true);
      this.Selectedservice = [];
      this.isServiceDataThere = false;
      this.serviceselected = false;
      selectedRows.forEach((element) => {
        if(element.runsheetId){
          this.isServiceDataThere = true;
        }
        this.Selectedservice.push(element);
      });
      this.bulkeditmode.emit(false);
      this.getselectedservice.emit(this.Selectedservice);
      /*ends here*/
    }
    // if(selectedRows.length>=1){
    //   this.serviceselected = false;
    // }
    // else{
    //   this.serviceselected = true;
    // }
  }

  //Popup for Bulk Copy
  openDialog() {
    const dialogRef = this.dialog.open(BulkCopyDialogComponent);
  }
  //Duplicate the selected rows
  noOfCopies: number = 1;
  temp: CopyService = {
    newScheduledDate: '',
    noOfCopies: 0,
    newServiceDate: '',
    serviceId: 0,
  };



  DuplicateService(event:any) {
    if (this.noOfCopies <= 0) {
      event.preventDefault(); // Prevent the default action of duplicate
      return;
    }
    this.Selectedservice.forEach((service) => {
      this.temp.newScheduledDate = null;
      this.temp.newServiceDate = null;
      this.temp.noOfCopies = 0;
      this.temp.serviceId = 0;
      this.temp.serviceId = service.id;
      this.temp.noOfCopies = this.noOfCopies;
      this.temp.newScheduledDate = null;
      this.temp.newServiceDate = null;
      this.planService.CopyService(this.temp).subscribe((result: any) => {
        result.forEach((rows: any) => {
          this.servicesdatecycle.push(rows);
          if (rows.truckId == null) {
            //unallocated
            this.totalunallocated += 1;
          } else {
            //allocated
            this.totalallocated += 1;
          }
        });
        this.totalrecords = this.servicesdatecycle.length;
        //progress bar updates
        this.allocatedwidth = 'width:';
        this.unallocatedwidth = 'width:';
        if (this.totalunallocated != 0) {
          this.unallocatedwidth =
            this.unallocatedwidth +
            String((this.totalunallocated / this.totalrecords) * 100) +
            '%';
        } else {
          this.unallocatedwidth = this.unallocatedwidth + '0%';
        }

        if (this.totalallocated != 0) {
          this.allocatedwidth =
            this.allocatedwidth +
            String((this.totalallocated / this.totalrecords) * 100) +
            '%';
        } else {
          this.allocatedwidth = this.allocatedwidth + '0%';
        }

        this.gridApi.setRowData(this.servicesdatecycle);
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Service duplicated',
        });
      });
    });
  }

  //Deletion of selected service row
  onDelete() {
    // let toastrNO: string = '';
    this.confirmationService.confirm({
      header: '',
      message: 'Click OK to Continue',

      accept: () => {
        this.getIdsforDelete();
        // this.Selectedservice.forEach((element) => {
        //   toastrNO += element.serviceNo + ' ';
        // });
        // let mess = 'Service(s): ' + toastrNO + ' deleted.';
        // this.messageService.add({
        //   severity: 'success',
        //   summary: '',
        //   detail: mess,
        // });
      },
    });
  }
  //Delete the row and refresh the grid
  onRemoveSelected() {
    const selectedData = this.gridApi.getSelectedRows();
     const res = this.gridApi.applyTransaction({ remove: selectedData })!;
    this.planService
      .DeleteService(this.selectedIds)
      .subscribe((result: any) => {
        if(result){
          let toastrNO: string = '';
          let sids:any[]=[];
          let tids:any[]=[];
          this.Selectedservice.forEach((element) => {
            toastrNO += element.serviceNo + ' ';
            sids.push(element.id)
          });
          let mess = 'Service(s): ' + toastrNO + ' deleted.';
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: mess,
          });
          //fetch trips and services
        
          let payload_obj={
            serviceIds:sids,tripIds:tids
          }
          this.planService.fetchTripsandServices(payload_obj).subscribe((res)=>{

          })
          this.getselectedservice.emit(this.Selectedservice2);
        }
        this.gridApi.refreshCells();
      });
    this.totalrecords -= 1;
  }
  //Getting Ids of selected row
  selectedIds: any[] = [];
  getIdsforDelete() {
    this.selectedIds = [];
    if (this.Selectedservice != null) {
      this.Selectedservice.forEach((element) => {
        this.selectedIds.push(element.id);
      });
      this.onRemoveSelected();
    }
  }
  clearFilters() {
    this.columnFields.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.columnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  text1: string = 'Hide Services on a trip';
  hidetripflag: boolean = false;

  HideTrip() {
    this.text1 = !this.hidetripflag
      ? 'Show Services on a trip'
      : 'Hide Services on a trip';
    this.hidetripflag = !this.hidetripflag;
    if (this.hidetripflag) {
      this.rowData = this.rowData.filter((x) => x.tripId != '');
    } else {
      this.rowData = this.servicesdatecycle;
    }
  }
  menuHumbergurDialog() {
    const dialogRef = this.dialog.open(MenuServiceDialogComponent,  {
      data: {
        allocate: this.totalallocated,
        unallocate: this.totalunallocated,
        allocatewidth: this.allocatedwidth,
        unallocatewidth: this.unallocatedwidth,
       total:this.totalrecords,
       date:this.datefromDateCycle
      }
    });
  }

  ngOnDestroy() {
    this.layoutSubscription.unsubscribe();
  }
  UpdateTable(services:ServiceDateCycle[],matchingrow:any){
    var rowNode = this.gridApi.getRowNode(String(matchingrow));
    rowNode?.setData(services[0]);

  }
}

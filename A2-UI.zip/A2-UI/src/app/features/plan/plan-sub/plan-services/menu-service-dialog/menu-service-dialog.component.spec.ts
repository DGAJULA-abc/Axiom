import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuServiceDialogComponent } from './menu-service-dialog.component';

describe('MenuServiceDialogComponent', () => {
  let component: MenuServiceDialogComponent;
  let fixture: ComponentFixture<MenuServiceDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenuServiceDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MenuServiceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import {
  Component,
  Input,
  OnInit,
  SimpleChanges,
  ViewEncapsulation,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
import {
  Reasons,
  ResourceAllocation,
  TruckUnavailability,
} from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';

@Component({
  selector: 'app-plan-resource-details',
  templateUrl: './plan-resource-details.component.html',

  styleUrls: ['./plan-resource-details.component.scss'],
  providers: [MessageService],
})
export class PlanResourceDetailsComponent implements OnInit {
  //Details from Resource Allocation
  @Input() truckUnavail: any;
  @Input() resource: ResourceAllocation;
  FleetNumber: string = '';
  Capacitytypecompany: string = '';
  // fromdate:Date
  // todate:Date
  canWrite:boolean;
  addUnavail: boolean = true;
  resourcedetailform: FormGroup;
  constructor(
    public permission: PermissionsService,
    public planService: PlanService,
    private formBuilder: FormBuilder,
    public navbarService:NavbarService,
    public timeService: TimeRunsheetService,
    private messageService: MessageService,
    private authenticationService:AuthenticationService
  ) {}
  ngOnInit() {
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
    // this.resourcedetailform = this.formBuilder.group({
    //   fromdate: [],
    //   todate: [],
    //   reason: ['', Validators.required],
    // });
    // console.log("ngon inittttttttttttttttttttttttttt")
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('AllocationByRoute');
      if(result1){
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }
      //console.log("Result:", this.canWrite,result1,; // Use the result here
      
    } catch (error) {
      console.error("Error:", error);
    }
  }

  isLoading: boolean = true;
  showfromdate: any;
  showtodate: any;
  ngOnChanges(changes: SimpleChanges) {
    this.resourcedetailform = this.formBuilder.group({
      fromdate: [],
      todate: [],
      reason: ['', Validators.required],
    });
    console.log("onchnageeeeeeeeeeeeeeeeeee")
    this.showReason.reasonDescription = '';
    if (this.truckUnavail == undefined) {
      this.addUnavail = false;
      this.resourcedetailform.get('reason')?.setValue('');
      console.log(this.addUnavail)
    }
    console.log("Am i hereeeeeeeeeeeeeeeee")
    this.Capacitytypecompany = '';
    if(this.resource.fleetNumber!=null){

      this.FleetNumber = this.resource.fleetNumber;
    }
    else{
      this.FleetNumber=this.resource.truckId
    }
    if (this.resource.routeCapacity != null) {
      this.Capacitytypecompany =
        this.resource.routeCapacity.toString() +
        ',' +
        this.resource.truckTypeId +
        ',' +
        this.resource.companyId;
    } else {
      this.Capacitytypecompany =
        this.resource.truckTypeId + ',' + this.resource.companyId;
    }
    this.isLoading = true;
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        this.isLoading = false;
        this.getReason(result['ref'].reasons);
        if (this.truckUnavail) {
          this.addUnavail = true;
          (this.showfromdate = this.timeService.convertMillisecondsToDateTimeF(
            this.truckUnavail.windowFrom
          )),
            (this.showtodate = this.timeService.convertMillisecondsToDateTimeF(
              this.truckUnavail.windowTo
            ));
            const chosenReason = this.getchosenReason(this.truckUnavail.reasonId);
            this.resourcedetailform.get('reason')?.setValue(chosenReason); // Set the value of the 'reason' FormControl
            console.log(this.resourcedetailform.get('reason')?.value)
            console.log(this.truckUnavail)
            this.truckUnavail = undefined;
        }
        this.resourcedetailform.get('fromdate')?.setValue(this.showfromdate)
        this.resourcedetailform.get('todate')?.setValue(this.showtodate)
      }

    });
    //TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
    //this.truckUnavail = undefined;
  }
  getchosenReason(reasonid: any): Reasons {
    return this.reasons.find((r) => r.reasonId == reasonid);
  }
  reasons: any[] = [];
  getReason(viewreasons: Reasons[]) {
    this.reasons = [];
    viewreasons.forEach((element) => {
      // let temp = '';
      // temp = element.reasonId + '_' + element.reasonDescription;
      this.reasons.push(element);
    });
  }
  filteredReasons: any[] = [];
  filterReason(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    this.filteredReasons = this.reasons.filter(option => option.reasonDescription.toLowerCase().includes(query.toLowerCase()));

  }
  showReason: Reasons = {
    active: false,
    driver: false,
    reasonDescription: '',
    reasonId: '',
    siteId: 0,
  };
  onReasonSelection() {
    this.showReason.reasonDescription = this.resourcedetailform.controls['reason'].value.reasonDescription;
    console.log(this.resourcedetailform.controls['reason'].value)
    console.log(this.showReason)
  }
  addUnavailability() {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
  
    this.resourcedetailform.patchValue({
      fromdate: today,
      todate: tomorrow
    });
    this.addUnavail = !this.addUnavail;
  }
  ids: number[] = [];
  onDelete() {
    this.ids.push(this.truckUnavail.id);
    this.planService.DeleteRA(this.ids).subscribe((res) => {
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: 'Unavailability removed',
      });
      this.resourcedetailform.reset();
    });
  }
  temp_truckunavail: TruckUnavailability;
  truckUnavail_arr: TruckUnavailability[] = [];
  onSave() {
    this.temp_truckunavail = {
      id: null,
      lastModified: 0,
      reasonId: '',
      siteId: 0,
      trailerId: '',
      truckId: '',
      windowFrom: 0,
      windowTo: 0,
    };
    this.truckUnavail_arr = [];
    if (this.truckUnavail == undefined) {
      this.temp_truckunavail.windowFrom = this.timeService.getmomentfromdate(
        this.resourcedetailform.controls['fromdate'].value
      );
      this.temp_truckunavail.windowTo = this.timeService.getmomentfromdate(
        this.resourcedetailform.controls['todate'].value
      );
      let today_date = moment(new Date()).format('YYYY-MM-DD HH:mm');
      this.temp_truckunavail.lastModified =
        this.timeService.getmomentfromdate(today_date);
      this.temp_truckunavail.reasonId =
        this.resourcedetailform.controls['reason'].value.reasonId;
      this.temp_truckunavail.siteId = parseInt(sessionStorage.getItem('selectedSiteId')!);
      this.temp_truckunavail.trailerId = null;
      this.temp_truckunavail.truckId = this.resource.truckId;
      this.truckUnavail_arr.push(this.temp_truckunavail);
      this.planService
        .putUnavailability(this.truckUnavail_arr)
        .subscribe((result) => {
          if(result){
            console.log("detailsssssssssssssssssssssss")
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: 'Unavailability saved successfully',
          });
          // this.resourcedetailform.reset();
          }
        });
    } else {
      this.temp_truckunavail.windowFrom = this.timeService.getmomentfromdate(
        this.resourcedetailform.controls['fromdate'].value
      );
      this.temp_truckunavail.windowTo = this.timeService.getmomentfromdate(
        this.resourcedetailform.controls['todate'].value
      );
      this.temp_truckunavail.id = this.truckUnavail.id;
      let today_date = moment(new Date()).format('YYYY-MM-DD HH:mm');
      this.temp_truckunavail.lastModified =
        this.timeService.getmomentfromdate(today_date);
      this.temp_truckunavail.reasonId =
        this.resourcedetailform.controls['reason'].value.reasonId;
      this.temp_truckunavail.siteId = this.truckUnavail.siteId;
      this.temp_truckunavail.trailerId = null;
      this.temp_truckunavail.truckId = this.truckUnavail.truckId;
      this.truckUnavail_arr.push(this.temp_truckunavail);
      this.planService
        .saveUnavailability(this.truckUnavail_arr)
        .subscribe((result) => {
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: 'Unavailability saved successfully',
          });
          // this.resourcedetailform.reset();
        });
    }
  }
}

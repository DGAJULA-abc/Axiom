import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverRosterComponent } from './driver-roster.component';

describe('DriverRosterComponent', () => {
  let component: DriverRosterComponent;
  let fixture: ComponentFixture<DriverRosterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DriverRosterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DriverRosterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, NgForm, Validators, FormGroup } from '@angular/forms';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import {
  BulkCreateFetch,
  DriverRoster,
  DriverRosterTable,
  MultiLegSiteLocation,
} from '../models/plan.model';
import { PlanService } from '../services/plan.service';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-driver-roster',
  templateUrl: './driver-roster.component.html',
  styleUrls: ['./driver-roster.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None,
})
export class DriverRosterComponent implements OnInit {
  //display current date in header + tomorrow's date in calendar
  selectedOptions: any[];
  date_header: any = new Date();
  date_instance: Date = new Date();
  date_tomorrow = new Date(
    this.date_instance.setDate(this.date_instance.getDate() + 1)
  );
  rosterdate: any;
  starttime: any;
  endtime: any;
  dateForm = this.fb.group({
    dateField: [''],
  });
  driverrosterduplicateform = this.fb.group({
    duplicatedatefield: [''],
  });
  duplicatecalendar: boolean = true;
  minDate: Date;
  selectedsiteid: number = 0;
  isLoading: boolean = true;

  driverrosterform: FormGroup;
  ngOnInit(): void {
    this.driverrosterform = this.formBuilder.group({
      startlocation: [],
      rosterdate: [],
      starttime: [],
      endtime: [],
      comments: [],
    });
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.minDate = this.date_header;
    this.selectedsiteid = this.navbarService.selectedSiteId;
    // this.AllCustomerId(this.selectedsiteid);
    this.authenticationService.viewAPI.subscribe((result) => {
      this.ViewDataDrivers = result['ref'].drivers;
      this.ViewLocations = result['ref'].locations;
      // this.bulkCreateFetch();
      this.getDrivers(this.ViewDataDrivers);
      this.GetRosters();
    });
    //ToDO: Remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
  }
  duplicatedate: any;
  onDuplicateDateChange() {
    this.duplicatedate = this.getmomentfromdate(
      this.driverrosterduplicateform.controls['duplicatedatefield'].value
    );
  }
  selecteddate: any;
  onDateChange() {
    this.date_header = this.getmomentfromdate(
      this.dateForm.controls['dateField'].value
    );
    
    this.date_header = moment(this.date_header)
      .tz('Australia/Melbourne')
      .format('YYYY-MM-DD HH:mm:ss');
  }
  getmomentfromdate(sentdate: any): number {
    var newYork = moment.tz(sentdate, 'Australia/Melbourne');
    var india = newYork.clone().tz('Asia/Kolkata').subtract(1, 'days');
    let moment_num = moment(india).valueOf();
    return moment_num;
  }
  constructor(
    private messageService: MessageService,
    public planService: PlanService,
    private fb: FormBuilder,
    private authenticationService:AuthenticationService,
    public navbarService: NavbarService,
    private formBuilder: FormBuilder
  ) {}
  //AG Grid configuration
  private gridApi!: GridApi<DriverRosterTable>;
  public rowSelection: 'single' | 'multiple' = 'multiple';
  rowData: DriverRosterTable[] = [];
  isFormDirty = true;
  columnFields: ColDef[] = [
    {
      field: 'Driver',
      headerName: 'Driver',
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    { field: 'StartLocation', headerName: 'Start Location' },
    { field: 'Start', headerName: 'Start' },
    { field: 'Finish', headerName: 'Finish' },
    { field: 'Duration', headerName: 'Duration' },
    { field: 'Comments', headerName: 'Comments' },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  ViewDataDrivers: any[];
  ViewLocations: MultiLegSiteLocation[] = [];
  driver: DriverRoster;
  drivers: DriverRoster[] = [];
  onGridReady(params: GridReadyEvent<DriverRosterTable>) {
    this.gridApi = params.api;
  }
  date_from_form: Date;
  date_now: any;
  date_now2: any;
  //Get Rosters API
  GetRosters() {
    this.isLoading = true;
    let start_date;
    if (this.dateForm.controls['dateField'].touched) {
      start_date = moment(this.dateForm.controls['dateField'].value);
      start_date = start_date
        .set({
          hour: 0,
          minute: 0,
          second: 0,
        })
        .format('YYYY-MM-DD HH:mm:ss');
    } else {
      //commenting for testing purpose
      start_date = moment(this.date_tomorrow);
      this.date_now2 = start_date
        .set({
          hour: 0,
          minute: 0,
          second: 0,
        })
        .format('YYYY-MM-DD HH:mm:ss');
      start_date = start_date
        .set({
          hour: 5,
          minute: 30,
          second: 0,
        })
        .format('YYYY-MM-DD HH:mm:ss');
        //start_date='03/01/24';
        this.date_now = start_date;
    }

    var s_australia_time = moment.tz(start_date, 'Australia/Melbourne');
    var s_india = s_australia_time.clone().tz('Asia/Kolkata');
    let chosendate = moment(s_india).valueOf();
    let payload ={
      rosterDate:chosendate
    }
    this.planService.bulkCreateFetch(payload).subscribe((result) => {
      if (result) {
        this.isLoading = false;
        this.Bulkcre = result['rosters'];
        this.bulkCreateFetch(this.Bulkcre);
      }
    });
    this.rosterdate = moment(chosendate)
      .tz('Australia/Melbourne')
      .format('DD/MM/YYYY');
  }
  Bulkcre: BulkCreateFetch[];
  driversTable: DriverRosterTable[] = [];
  driverTable: DriverRosterTable;
  bulkCreateFetch(result: BulkCreateFetch[]) {
    this.driversTable = [];
    
    this.drivers.forEach((driver) => {
      this.driverTable = {
        Driver: '',
        Duration: '',
        Start: 0,
        Finish: 0,
        Comments: '',
        StartLocation: '',
      };
      result.forEach((element) => {
        this.driverTable = {
          Driver: '',
          Duration: '',
          Start: 0,
          Finish: 0,
          Comments: '',
          StartLocation: '',
        };
        if (driver.Id == element.driverId) {
          this.driverTable.Driver = driver.Driver;
          if (element.startTime) {
            this.driverTable.Start = moment(element.startTime)
              .tz('Australia/Melbourne')
              .format('HH:mm');
          } else {
            this.driverTable.Start = '';
          }
          if (element.endTime) {
            this.driverTable.Finish = moment(element.endTime)
              .tz('Australia/Melbourne')
              .format('HH:mm');
          } else {
            this.driverTable.Finish = '';
          }
          this.driverTable.StartLocation = element.startLocation;
          this.driverTable.Comments = element.comments;
          const mil = element.endTime - element.startTime;
          const hours = Math.floor(mil / 3600000);
          const minutes = Math.floor((mil % 3600000) / 60000);
          this.driverTable.Duration = hours + 'h ' + minutes + 'm';
          this.driversTable.push(this.driverTable);
        }
      });
    });
    this.rowData = this.driversTable;
  }

  //Get Driver List from View API
  getDrivers(viewdrivers: any[]) {
    this.drivers=[];
    viewdrivers.forEach((element) => {
      this.driver = {
        Id: 0,
        Driver: '',
        TruckId: '',
        CompanyId: '',
      };
      if (element.active == true) {
        if (element.surname != null && element.firstName != null) {
          this.driver.Driver =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName +
            ' (' +
            element.companyId +
            ')';
          this.driver.TruckId = element.truckId;
          this.driver.CompanyId = element.companyId;
          this.driver.Id = element.id;
        } else if (element.employeeName != null) {
          this.driver.Driver =
            element.employeeName + ' (' + element.companyId + ')';
          this.driver.TruckId = element.truckId;
          this.driver.CompanyId = element.companyId;
          this.driver.Id = element.id;
        }
        this.drivers.push(this.driver);
      }
    });
    // this.rowData = this.drivers;
  }
  SelectedRow: DriverRosterTable;
  SelectedRows: DriverRosterTable[];
  //on Row Selection
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.SelectedRows = selectedRows;
    if (selectedRows.length > 1) {
      this.SelectedRow = {
        Driver: '',
        StartLocation: '',
        Start: 0,
        Finish: 0,
        Duration: '',
        Comments: '',
      };
      this.isDivVisible = false;
      this.duplicatecalendar = true;
      this.isFormDirty = true;
    } else if (selectedRows.length == 0) {
      this.onClose();
    } else {
      this.SelectedRow = selectedRows[0];
      this.duplicatecalendar = false;
      this.isDivVisible = true;
      selectedRows.forEach((row) => {
        if (row.Start) {
          this.starttime = row.Start;
        } else {
          this.starttime = '00:00';
        }
        if (row.Finish) {
          this.endtime = row.Finish;
        } else {
          this.endtime = '00:00';
        }
        this.driverrosterform.patchValue({
          startlocation: row.StartLocation,
          comments: row.Comments,
        });
        this.Loc = row.StartLocation;
      });
    }
  }
  Loc: any;
  customers: string[] = [];
  AllData: any[] = [];
  arr: string[] = [];
  // public AllCustomerId(selectedId: number) {
  //   let unique: any[];
  //   this.planService.getAllData(selectedId).subscribe((result: any) => {
  //     this.AllData = result;
  //   });
  // }
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  getLocationIds() {
    this.locationIds = [];
    this.ViewLocations.forEach((element) => {
      this.locationIds.push(element.locationId);
    });
  }
  filterLocation(event: any) {
    this.getLocationIds();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredLocations = this.locationIds.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }

  //Right side Card
  isDivVisible: boolean = false;
  submitForm() {}
  onClose() {
    this.isDivVisible = false;
    this.driverrosterform.reset;
  }
  clearFilters() {
    this.columnFields.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.columnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  driverId: number = 0;
  findDriver(dname: string) {
    this.drivers.forEach((element) => {
      if (element.Driver == dname) {
        this.driverId = element.Id;
      }
    });
  }
  payload: BulkCreateFetch[] = [];
  bulkfetchobj: BulkCreateFetch;
  onSave() {
    //TODO: Save functionality
    this.payload = [];
    this.bulkfetchobj = {
      id: 0,
      siteId: 0,
      driverId: 0,
      truckId: '',
      trailerId: undefined,
      trailerIdTag: undefined,
      startDate: 0,
      startTime: undefined,
      start: 0,
      endDate: 0,
      endTime: undefined,
      end: 0,
      rosterTypeId: undefined,
      startLocation: undefined,
      comments: undefined,
      warnings: [],
    };

    //comments
    this.bulkfetchobj.comments =
      this.driverrosterform.controls['comments'].value;

    //driverId
    this.findDriver(this.SelectedRow.Driver);
    this.bulkfetchobj.driverId = this.driverId;

    //id,trailer,tag,truck,roster,warnings
    this.Bulkcre.forEach((row) => {
      if (row.driverId == this.driverId) {
        this.bulkfetchobj.id = row.id;
        this.bulkfetchobj.trailerId = row.trailerId;
        this.bulkfetchobj.trailerIdTag = row.trailerIdTag;
        this.bulkfetchobj.truckId = row.truckId;
        this.bulkfetchobj.rosterTypeId = row.rosterTypeId;
        this.bulkfetchobj.warnings = row.warnings;
      }
    });
    //siteid
    this.bulkfetchobj.siteId = this.navbarService.selectedSiteId;

    //startlocation
    this.bulkfetchobj.startLocation =
      this.driverrosterform.controls['startlocation'].value;

    //start date and end date
    this.bulkfetchobj.startDate = moment(
      moment
        .tz(
          moment(this.date_now).format('YYYY-MM-DD HH:mm:ss'),
          'Australia/Melbourne'
        )
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
    this.bulkfetchobj.endDate = moment(
      moment
        .tz(
          moment(this.date_now).format('YYYY-MM-DD HH:mm:ss'),
          'Australia/Melbourne'
        )
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();

    //starttime
    this.bulkfetchobj.startTime = moment(
      moment
        .tz(
          moment(this.driverrosterform.controls['starttime'].value).format(
            'YYYY-MM-DD HH:mm:ss'
          ),
          'Australia/Melbourne'
        )
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();

    //endtime
    this.bulkfetchobj.endTime = moment(
      moment
        .tz(
          moment(this.driverrosterform.controls['endtime'].value).format(
            'YYYY-MM-DD HH:mm:ss'
          ),
          'Australia/Melbourne'
        )
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();

    //start and end
    this.bulkfetchobj.start = moment(
      moment
        .tz(
          moment(this.date_now2).format('YYYY-MM-DD HH:mm:ss'),
          'Australia/Melbourne'
        )
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
    this.bulkfetchobj.end = moment(
      moment
        .tz(
          moment(this.date_now2).format('YYYY-MM-DD HH:mm:ss'),
          'Australia/Melbourne'
        )
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
    console.log(this.bulkfetchobj);
    this.payload.push(this.bulkfetchobj);

    this.planService.rosters(this.payload).subscribe((result) => {
      if (result) {
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Roster Added',
        });
        // this.planService
        //   .bulkCreateFetch(
        //     moment(
        //       moment
        //         .tz(
        //           moment(this.date_now).format('YYYY-MM-DD HH:mm:ss'),
        //           'Australia/Melbourne'
        //         )
        //         .clone()
        //         .tz('Asia/Kolkata')
        //     ).valueOf()
        //   )
        //   .subscribe((result) => {
        //     this.Bulkcre = result['rosters'];
        //     this.bulkCreateFetch(this.Bulkcre);
        //   });
        this.GetRosters();
      }
    });
  }
  delete_Id_arr: number[] = [];
  ClearSelectedRoster() {
    this.delete_Id_arr = [];
    this.SelectedRows.forEach((row) => {
      this.findDriver(row.Driver);
      this.Bulkcre.forEach((temp) => {
        if (temp.driverId == this.driverId) {
          this.delete_Id_arr.push(temp.id);
        }
      });
    });
    this.planService.deleteRoster(this.delete_Id_arr).subscribe((result) => {
      if (result) {
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Roster Deleted',
        });
        this.planService
          .bulkCreateFetch(
            moment(
              moment
                .tz(
                  moment(this.date_now).format('YYYY-MM-DD HH:mm:ss'),
                  'Australia/Melbourne'
                )
                .clone()
                .tz('Asia/Kolkata')
            ).valueOf()
          )
          .subscribe((result) => {
            this.Bulkcre = result['rosters'];
            this.bulkCreateFetch(this.Bulkcre);
          });
      }
    });
  }
  DuplicateSelected() {
    this.selecteddate = this.getmomentfromdate(
      this.dateForm.controls['dateField'].value
    );

    let rosterid_arr: number[] = [];
    this.SelectedRows.forEach((row) => {
      this.findDriver(row.Driver);
      this.Bulkcre.forEach((temp) => {
        if (temp.driverId == this.driverId) {
          rosterid_arr.push(temp.id);
        }
      });
    });
    let payload = {
      rosterIdsToCopy: rosterid_arr,
      sourceDate: this.selecteddate,
      targetDate: this.duplicatedate,
    };

    this.planService
      .DuplicateSelectedDriverRoster(payload)
      .subscribe((result) => {
        if (result) {
        }
      });
  }
}

import { Component } from '@angular/core';
import { SearchService } from './services/search.service';
import { ViewSearch } from './model/search.model';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent  {
  isClicked = false;
  viewDetails: ViewSearch;
  activeButton: string = ''; // Initialize activeButton variable to empty string

  constructor( 
    private searchServices: SearchService
  ) { }

  setActiveButton(buttonId: string): void {
    this.activeButton = buttonId; // Set activeButton to the clicked button's ID
  }

  ngOnInit(): void {
    this.getSerchviewDetails();
    this.getSearchContextViews();
  }

  getSerchviewDetails() {
    this.searchServices.getSearchView()
    .subscribe(
      (result: any) => {
        this.viewDetails = result;
        console.log(this.viewDetails);
      }
    );
  }

  getSearchContextViews(){
     this.searchServices.getSearchContextView().subscribe((result:any)=>{
      console.log(result);
     })
  }
}

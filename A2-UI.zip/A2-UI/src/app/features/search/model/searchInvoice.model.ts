export interface Line {
    invoiceId: number;
    siteid: number ;
    customerid: string;
    customergroupid: string;
    duedate: number| 'MM/dd/yy';
    fromdate: number| 'MM/dd/yy';
    todate: number| 'MM/dd/yy';
    issuedate: number| 'MM/dd/yy';
    invoicestatusid:string;
    documenttype: string;
    exported: boolean;
    invformat: string;
    cnformat: string;
    exgst: number;
    fuellevy: number;
    discountamt: string;
    totalexgst: number;
    defaultinvformat: string;
    defaultcnformat: string;
    showzero: boolean;
    created:number| 'MM/dd/yy';
    serviceNumber: string;
    effectiveDate: number;
    lineAmount: number;
    invoicePeriod:number;
  }
  export interface Invoice {
    id: number;
    siteid: number ;
    statusid:string;
    customerid: string;
    customergroupid: string;
    duedate: number| 'MM/dd/yy';
    fromdate: number| 'MM/dd/yy';
    todate: number| 'MM/dd/yy';
    issuedate: number| 'MM/dd/yy';
    invoicestatusid:string;
    documenttype: string;
    daystopay:number;
    exported: boolean;
    invformat: string;
    cnformat: string;
    exgst: number;
    applyGST:boolean;
    fuellevy: number;
    discountamt: string;
    totalexgst: number;
    defaultinvformat: string;
    defaultcnformat: string;
    showzero: boolean;
    created:number| 'MM/dd/yy';
  }  
  export interface InvoicesAPI {
      invoice: Invoice;
      lines: Line[];
      }  
  
  export interface InvoiceLines {
        id: number;
        serviceid: number ;
        serviceno:string;
        effectivedate:  number;
        parentid: string;
        adjustmenttypeid: string;
        linetext: string;
        lineamt: number;
        customerid: string;
        enteredby:string;
        payrollcode: string;
        driver:string;
        linetype: string;
    }      
  
   export interface InvoiceDemoData {
    invoiceDate: any;
    pagination: {
      pageNumber: number;
      recordsPerPage: number;
      orderType: string;
      orderByField: string;
    };
    likeInvoiceId?: any; 
    status?: any; 
    customer?: any; 
    customerGroup?: any;
    
    // invoiceDate?: any;
    issuedDate?: any; 
    dueDate?: any;
    documentType?: any;
    selectFields?: any;
  }
  export interface InvoiceLinesGetData {
    id: number;
  siteId: number;
  customerId: string;
  invoiceId: string;
   serviceId: number ;
  lineAmount: number;
  lineText: string;
  invoicePeriod: string;
   qty1: number;
    unit1: string;
    qty2: number;
    unit2: string;
    qty3: number;
  unit3: string;
  qty4: string;
  unit4: string;
  qty5: string;
  unit5: string;
  qty6: string;
  unit6: string;
  qty7: string;
  unit7: string;
  qty8: string;
  unit8: string;
  qtyExtra: string;
dataSourceId: string;
effectiveDate:  number;
  adjustmentTypeId: string; 
    parentid: string;
  enteredBy:string;
    fuelLevyAmount: number;
    adjustmentReference: string;
  serviceNumber:string;
  partitionDate:number;
  discountAmount: string;
} 

export interface InvoicelinesData {
  unAllocatedOnly: boolean;
  adjustmentLineType:any,
  pagination: {
    pageNumber: number;
    recordsPerPage: number;
    orderType: string;
    orderByField: string;
  };
    description?: any,
    company?: any,
    driverId?: any,
    loadNo?: any,
    serviceNo?: any,
    serviceType?: any,
    loadType?: any,
    adjustmentType?: any,
    // adjustmentLineType?:any,
    effectiveFrom?: any,
    effectiveTo?: any,
    customer?: any,
    customerGroup?: any,
    companyType?: any,
    amoutFrom?: any,
    amoutTo?: any,
    selectFields?: any;
}

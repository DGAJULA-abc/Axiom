import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';
import { InvoiceDemoData, InvoiceLinesGetData, InvoicesAPI } from '../model/searchInvoice.model';


interface InvoicelinesData {
  unAllocatedOnly: boolean;
  adjustmentLineType: any;
  pagination: {
    pageNumber: number;
    recordsPerPage: number;
    orderType: string;
    orderByField: string;
  };
    description?: any,
    company?: any,
    driverId?: any,
    loadNo?: any,
    serviceNo?: any,
    serviceType?: any,
    loadType?: any,
    adjustmentType?: any,
    // adjustmentLineType?:any,
    effectiveFrom?: any,
    effectiveTo?: any,
    customer?: any,
    customerGroup?: any,
    companyType?: any,
    amoutFrom?: any,
    amoutTo?: any
}

@Injectable({
  providedIn: 'root'
})
export class PayAdviceLineService {

  public panelBehSubject = new BehaviorSubject<any>(false);

  private _cellSubdata: Subject<any> = new Subject();
  getCellSubdata: any;

  constructor(private http: HttpClient) { }


//   InvoiceCsvDownload(form_data:any){
//     let invoiceData: InvoiceDemoData ={
//       invoiceDate:null,
//       pagination :{
//         pageNumber: 1,
//         recordsPerPage: 100,
//         orderType: 'DESC',
//         orderByField: 'id',
//       },
//     };
//   if (form_data.id !== null) {
//     invoiceData.likeInvoiceId = form_data.id;
//   }
//   if (form_data.status !== null) {
//     invoiceData.status = form_data.status;
//   }
//   if (form_data.customerID !== null) {
//     invoiceData.customerID = form_data.customerID;
//   }
// if (form_data.customerGroup !== null) {
//     invoiceData.customerGroup = form_data.customerGroup;
//   }
// if (form_data.issuedDate !== null) {
//     invoiceData.issuedDate = form_data.issuedDate;
//   }
// if (form_data.invoiceDate !== null) {
//     invoiceData.invoiceDate = form_data.invoiceDate;
//   }
// if (form_data.dueDate !== null) {
//     invoiceData.dueDate = form_data.dueDate;
//   }
//   if (form_data.documentType !== null) {
//     invoiceData.documentType= form_data.documentType;
//   }
//     invoiceData.selectFields = [];
//     console.log('hii csvvvv',invoiceData)    
//     return this.http.post(apiEndpoint.invoiceCsv, invoiceData, { responseType: 'arraybuffer' });

//     }
//     getDropDownData(){
//       return this.http.get<any>(`${apiEndpoint.contextView}`)
//     }
//   postInvoiceData(form_data : any) : any {
//     let invoiceData: InvoiceDemoData ={
//       invoiceDate:null,
//       pagination :{
//         pageNumber: 1,
//         recordsPerPage: 100,
//         orderType: 'DESC',
//         orderByField: 'id',
//       },
//     };
//   if (form_data.id !== null) {
//     invoiceData.likeInvoiceId = form_data.id;
//   }
//   if (form_data.status !== null) {
//     invoiceData.status = form_data.status;
//   }
//   if (form_data.customerID !== null) {
//     invoiceData.customerID = form_data.customerID;
//   }
// if (form_data.customerGroup !== null) {
//     invoiceData.customerGroup = form_data.customerGroup;
//   }
// if (form_data.issuedDate !== null) {
//     invoiceData.issuedDate = form_data.issuedDate;
//   }
// if (form_data.invoiceDate !== null) {
//     invoiceData.invoiceDate = form_data.invoiceDate;
//   }
// if (form_data.dueDate !== null) {
//     invoiceData.dueDate = form_data.dueDate;
//   }
//   if (form_data.documentType !== null) {
//     invoiceData.documentType= form_data.documentType;
//   }
//      return this.http.post<any>(`${apiEndpoint.searchInvoice}`, invoiceData);
// }
//   getInvoiceList(invoiceId: any){
//     return this.http.get<InvoicesAPI>(`${apiEndpoint.invoice}/${invoiceId}`)
//   }
//   setCellSubData(cellData: any) {
//     console.log('cellData >> ', cellData);
//     this._cellSubdata.next(cellData);
//   }


  /**
   *  Payload form Data to pass
   */
  private formData(form_data: any):any{
    const payAdviceLineData: InvoicelinesData ={
      unAllocatedOnly:form_data.unAllocatedOnly,
      adjustmentLineType: form_data.adjustmentLineType,
      pagination :{
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      },
    };
      if (form_data.description !== null) {
        payAdviceLineData.description = form_data.description;
      }
      if (form_data.companyId !== null) {
        payAdviceLineData.company = form_data.companyId;
      }
      if (form_data.driver !== null) {
        payAdviceLineData.driverId = form_data.driver;
      }
      if (form_data.loadNo !== null) {
        payAdviceLineData.loadNo = form_data.loadNo;
      }
      if (form_data.serviceNo !== null) {
        payAdviceLineData.serviceNo = form_data.serviceNo;
      }
      if (form_data.serviceType !== null) {
        payAdviceLineData.serviceType = form_data.serviceType;
      }
      if (form_data.loadType !== null) {
        payAdviceLineData.loadType = form_data.loadType;
      }
      if (form_data.adjustmentLineType !== null) {
        payAdviceLineData.adjustmentLineType = form_data.adjustmentLineType;
      }
      if (form_data.adjustmentType !== null) {
        payAdviceLineData.adjustmentType = form_data.adjustmentType;
      }
      if (form_data.effectiveFrom !== null) {
        payAdviceLineData.effectiveFrom = form_data.effectiveFrom;
      }
      if (form_data.effectiveTo !== null) {
        payAdviceLineData.effectiveTo = form_data.effectiveTo;
      }
      if (form_data.customerId  !== null) {
        payAdviceLineData.customer = form_data.customerId;
      }
      if (form_data.customerGroup !== null) {
        payAdviceLineData.customerGroup = form_data.customerGroup;
      }
      if (form_data.companyType !== null) {
        payAdviceLineData.companyType = form_data.companyType;
      }
      if (form_data.amoutFrom !== null) {
        payAdviceLineData.amoutFrom = form_data.amoutFrom;
      }
      if (form_data.amoutTo !== null) {
        payAdviceLineData.amoutTo = form_data.amoutTo;
      }
      return payAdviceLineData;
  }

  
/**
 * 
 * @param form_data 
 * @returns 
 */
  postpayAdviceLineTableData(form_data : any) : any{
    const payAdviceLinesForm = this.formData(form_data);
     return this.http.post<any>(`${apiEndpoint.searchPayAdviceLine}`, payAdviceLinesForm);
}

/**
 * getting id based on which we are getting right side data
 * @param id 
 * @returns payAdviceLine data of type object(any)
 * So we can display it in right card.
 */
  getpayAdviceLineById(id :any){
    return this.http.get<any>(`${apiEndpoint.payAdviceLine}/${id}`)
    }

    /**
     * Post method for CSV Files
     */
        postCsvDownload(form_data:any){
          const demoData = this.formData(form_data);
          demoData.selectFields = [];
          console.log('hii csvvvv',demoData)
          // return this.http.post<any>(`${apiEndpoint.payAdvicesCsv}`, demoData  ,{responseType: 'arraybuffer'});  
          return this.http.post(apiEndpoint.payAdvicesLineCsv, demoData, { responseType: 'arraybuffer' });
          }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CellRendarComponent } from './cell-rendar.component';

describe('CellRendarComponent', () => {
  let component: CellRendarComponent;
  let fixture: ComponentFixture<CellRendarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CellRendarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CellRendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

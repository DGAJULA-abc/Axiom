import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import * as moment from 'moment';

@Component({
  selector: 'app-date-formate',
  templateUrl: './date-formate.component.html',
  styleUrls: ['./date-formate.component.scss']
})
export class DateFormateComponent implements ICellRendererAngularComp  {
  public params: any;

  agInit(params: any): void {
    console.log(" okkkkkk", params);
    this.params = this. convertMillisecondsToDate(params.value);
  }

  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
  convertMillisecondsToDate(milliseconds: number) {
    return moment(milliseconds).tz('Australia/Melbourne').format('DD/MM/YYYY');
  }

}

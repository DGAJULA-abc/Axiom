import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DateFormateComponent } from './date-formate.component';

describe('DateFormateComponent', () => {
  let component: DateFormateComponent;
  let fixture: ComponentFixture<DateFormateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DateFormateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DateFormateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

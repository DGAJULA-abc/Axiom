import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';
import { InvoiceDemoData, InvoiceLinesGetData, InvoicelinesData, InvoicesAPI } from '../model/searchInvoice.model';
import { TimeRunsheetService } from '../../reconcile/services/time-runsheet.service';



@Injectable({
  providedIn: 'root'
})
export class SearchInvoiceService {

  public panelBehSubject = new BehaviorSubject<any>(false);

  private _cellSubdata: Subject<any> = new Subject();
  getCellSubdata: any;

  constructor(private http: HttpClient ,    private timezone: TimeRunsheetService) { }
  InvoiceCsvDownload(form_data:any){
    let invoiceData: InvoiceDemoData ={
      invoiceDate: null,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      },

    };
  if (form_data.likeInvoiceId !== null) {
    invoiceData.likeInvoiceId = form_data.likeInvoiceId;
  }
  if (form_data.status !== null) {
    invoiceData.status = form_data.status;
  }
  if (form_data.customerID !== null) {
    invoiceData.customer = form_data.customerID;
  }
if (form_data.customerGroup !== null) {
    invoiceData.customerGroup = form_data.customerGroup;
  }
if (form_data.issuedDate !== null) {
    invoiceData.issuedDate = form_data.issuedDate;
  }
if (form_data.invoiceDate !== null) {
    invoiceData.invoiceDate = form_data.invoiceDate;
  }
if (form_data.dueDate !== null) {
    invoiceData.dueDate = form_data.dueDate;
  }
  if (form_data.documentType !== null) {
    invoiceData.documentType= form_data.documentType;
  }
    invoiceData.selectFields = [];
    console.log('hii csvvvv',invoiceData)    
    return this.http.post(apiEndpoint.invoiceCsv, invoiceData, { responseType: 'arraybuffer' });

    }
    getDropDownData(){
      return this.http.get<any>(`${apiEndpoint.contextView}`)
    }
    getDropDownDataSearch(){
      return this.http.get<any>(`${apiEndpoint.searchContextView}`)
    }
 
  postInvoiceData(form_data : any){
    let invoiceData: InvoiceDemoData ={
      invoiceDate: null,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      },
    };
    
  if (form_data.likeInvoiceId !== null) {
    invoiceData.likeInvoiceId= form_data.likeInvoiceId;
  }
  if (form_data.status !== null) {
    invoiceData.status = form_data.status;
  }
  if (form_data.customerID !== null) {
    invoiceData.customer = form_data.customerID;
  }
if (form_data.customerGroup !== null) {
    invoiceData.customerGroup = form_data.customerGroup;
  }
if (form_data.issuedDate !== null) {
    invoiceData.issuedDate = form_data.issuedDate;
  }
if (form_data.invoiceDate !== null) {
    invoiceData.invoiceDate = form_data.invoiceDate;
  }
if (form_data.dueDate !== null) {
    invoiceData.dueDate = form_data.dueDate;
  }
  if (form_data.documentType !== null) {
    invoiceData.documentType= form_data.documentType;
  }
  console.log('Invoice data --' + invoiceData);
     return this.http.post<any>(`${apiEndpoint.searchInvoice}`, invoiceData);
}

  getInvoiceList(invoiceId: any){

    return this.http.get<InvoicesAPI>(`${apiEndpoint.invoice}/${invoiceId}`)

  }


  setCellSubData(cellData: any) {
    console.log('cellData >> ', cellData);
    this._cellSubdata.next(cellData);
  }

  
  postInvoiceLineData(form_data : any) {
    
    let invoiceLinesData: InvoicelinesData ={
  
      adjustmentLineType: form_data.adjustmentLineType,
      pagination :{
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      },
      unAllocatedOnly:form_data.unAllocatedOnly,
      // adjustmentLineType:""
        };
      let searchQuery = form_data.adjustmentLineType;

    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: searchQuery
    }
  if (form_data.description !== null) {
    invoiceLinesData.description = form_data.description;
  }
  if (form_data.company !== null) {
    invoiceLinesData.company = form_data.company;
  }
  if (form_data.driverId !== null) {
    invoiceLinesData.driverId = form_data.driverId;
  }
  if (form_data.loadNo !== null) {
    invoiceLinesData.loadNo = form_data.loadNo;
  }
  if (form_data.serviceNo !== null) {
    invoiceLinesData.serviceNo = form_data.serviceNo;
  }
  if (form_data.serviceType !== null) {
    invoiceLinesData.serviceType = form_data.serviceType;
  }
  if (form_data.loadType !== null) {
    invoiceLinesData.loadType = form_data.loadType;
  }
  if (form_data.adjustmentLineType !== null) {
    invoiceLinesData.adjustmentLineType = form_data.adjustmentLineType;
  }
  if (form_data.adjustmentType !== null) {
    invoiceLinesData.adjustmentType = form_data.adjustmentType;
  }
  if (form_data.effectiveFrom !== null) {
    invoiceLinesData.effectiveFrom = form_data.effectiveFrom.getTime();
  }
  if (form_data.effectiveTo !== null) {
    invoiceLinesData.effectiveTo = form_data.effectiveTo.getTime();
  }
  if (form_data.customer !== null) {
    invoiceLinesData.customer = form_data.customer;
  }
  if (form_data.customerGroup !== null) {
    invoiceLinesData.customerGroup = form_data.customerGroup;
  }
  if (form_data.companyType !== null) {
    invoiceLinesData.companyType = form_data.companyType;
  }
  if (form_data.amoutFrom !== null) {
    invoiceLinesData.amoutFrom = form_data.amoutFrom.getTime();
  }
  if (form_data.amoutTo !== null) {
    invoiceLinesData.amoutTo = form_data.amoutTo.getTime();
  }
  console.log(invoiceLinesData);
 return this.http.post<any>(`${apiEndpoint.searchInvoiceLine}`, invoiceLinesData);
}

getInvoiceLineById(id :any){
return this.http.get<InvoiceLinesGetData>(`${apiEndpoint.invoiceLine}/${id}`)
}

// Download csv file for Invoice Lines

InvoiceLineCsvDownload(form_data : any) : any{
  
  let invoiceLinesData: InvoicelinesData ={
    adjustmentLineType: form_data.adjustmentLineType,
    pagination :{
      pageNumber: 1,
      recordsPerPage: 100,
      orderType: 'DESC',
      orderByField: 'id',
    },
    unAllocatedOnly:true,
    // adjustmentLineType:""
      };
if (form_data.description !== null) {
  invoiceLinesData.description = form_data.description;
}
if (form_data.company !== null) {
  invoiceLinesData.company = form_data.company;
}
if (form_data.driverId !== null) {
  invoiceLinesData.driverId = form_data.driverId;
}
if (form_data.loadNo !== null) {
  invoiceLinesData.loadNo = form_data.loadNo;
}
if (form_data.serviceNo !== null) {
  invoiceLinesData.serviceNo = form_data.serviceNo;
}
if (form_data.serviceType !== null) {
  invoiceLinesData.serviceType = form_data.serviceType;
}
if (form_data.loadType !== null) {
  invoiceLinesData.loadType = form_data.loadType;
}
if (form_data.adjustmentLineType !== null) {
  invoiceLinesData.adjustmentLineType = form_data.adjustmentLineType;
}
if (form_data.adjustmentType !== null) {
  invoiceLinesData.adjustmentType = form_data.adjustmentType;
}
if (form_data.effectiveFrom !== null) {
  invoiceLinesData.effectiveFrom = form_data.effectiveFrom;
}
if (form_data.effectiveTo !== null) {
  invoiceLinesData.effectiveTo = form_data.effectiveTo;
}
if (form_data.customer !== null) {
  invoiceLinesData.customer = form_data.customer;
}
if (form_data.customerGroup !== null) {
  invoiceLinesData.customerGroup = form_data.customerGroup;
}
if (form_data.companyType !== null) {
  invoiceLinesData.companyType = form_data.companyType;
}
if (form_data.amoutFrom !== null) {
  invoiceLinesData.amoutFrom = form_data.amoutFrom;
}
if (form_data.amoutTo !== null) {
  invoiceLinesData.amoutTo = form_data.amoutTo;
}
invoiceLinesData.selectFields = [];
return this.http.post(apiEndpoint.searchInvoiceLineCsv, invoiceLinesData, { responseType: 'arraybuffer' });

}

deleteInvoiceLines (id: number) {
  let options: any = {
    body: [id]
  };  
  return this.http.delete<any>(apiEndpoint.invoiceLines, options);
}

deletePayAdviceLines (id: number) {
  let options: any = {
    body: [id]
  };  
  return this.http.delete<any>(apiEndpoint.payAdviceLines, options);
}
canDelete(line: any): boolean {
  if (line.linetype === 'ADJUST') {
    return true; // Assuming EnterAdjustments permission is granted
  } else if (line.linetype === 'PERIODIC') {
    return true; // Assuming ApplyPeriodicCharges permission is granted
  } else {
    return false;
  }
}

}
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-mat-auto-complete',
  templateUrl: './mat-auto-complete.component.html',
  styleUrls: ['./mat-auto-complete.component.scss']
})
export class MatAutoCompleteComponent {
  @Input() dropDownList: any;
  @Input() selectedOption?: any;
  @Input() field: any
  @Output() valueUpdated = new EventEmitter<string>();
  filteredData: any;
  noDropdownIcon: boolean = false;

  constructor() {
  }
  ngOnInit() {
    this.filteredData = this.dropDownList;
    console.log("drop down:", this.field);
    console.log("selected option:", this.selectedOption);
    if(this.field){
      if(this.field.name == 'svcContainer') {
       this.noDropdownIcon = true;
      }
    }
  }

  validateFields() {
    if(this.field)
    {
      if(this.field.name == 'svcContainer'){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
    //return true;
  }

  onSelect(selectedValue: string) {
    if (selectedValue) {
      this.filteredData = this.dropDownList.filter((item: any) => (item.name) === selectedValue || item.name.toLocaleLowerCase().indexOf(selectedValue.toLocaleLowerCase()) >= 0);
      let list = this.dropDownList.filter((list:any) => list.name == selectedValue);
      this.valueUpdated.emit(list[0].id);
    } 
    else {
      this.selectedOption = '';
      this.filteredData = this.dropDownList;
    }
  }

  clearSelection() {
    this.filteredData = this.dropDownList;
    this.selectedOption = '';
    this.valueUpdated.emit(this.selectedOption);
  }
}

import { Component, Input, ViewChild, ViewEncapsulation } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Router } from '@angular/router';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  IGroupCellRendererParams,
} from 'ag-grid-community';

import { SearchInvoiceService } from '../services/search-invoice.service';
import { Invoice, Line } from '../model/searchInvoice.model';
import {
  InvoicePreviewRequest,
  InvoicePreview,
} from '../../reportview/model/report-view.model';
import { DateFormateComponent } from '../services/date-formate/date-formate.component';
import { CellRendarComponent } from '../services/cell-rendar/cell-rendar.component';
// import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import { DatePipe } from '@angular/common';
import { MomentInput } from 'moment';
import * as moment from 'moment';
import { MatSelect } from '@angular/material/select';
import { AgGridAngular } from 'ag-grid-angular';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { TimeRunsheetService } from '../../reconcile/services/time-runsheet.service';
import { PlanService } from '../../plan/services/plan.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss'],
})
export class InvoiceComponent {
  public rowData: Invoice[] = [];
  lines: Line[] = [];
  invoice: Invoice;
  private gridApi!: GridApi;
  @Input() printMenu: any;
  @Input() pageName: any;
  customers: any[] = [];
  invoiceDetails: any = {};
  invoiceReportFormats: any[];
  customerGroups: any[] = [];
  filteredCustomerID: any[];
  filteredCustomerGroup: any[];
  documentType: any[] = ['Credit Note', 'Invoice'];
  status: any[] = ['HOLD', 'PRINTED', 'READY'];
  filteredDocumentType: any[];
  filteredStatus: any[];
  selectedOptions: any[];
  showZero: boolean = false;
  columnApi: any;
  columnState: any;
  userName: any;
  selectedSite: any;
  gridOptions: any;
  applicationOptions: any;
  applicationId: any;
  layoutSubscription: Subscription;
  selectedIds: any = [];
  creditNoteReportFormats: any[];
  @ViewChild('mySelect') mySelect: MatSelect;
  // @ViewChild(AgGridAngular) agGrid!: AgGridAngular;

  ngOnInit(): void {
    this.service.getDropDownData().subscribe((data: any) => {
      console.log('onInit', data.ref.customers);
      this.customers = data.ref.customers.map(
        (obj: { customerId: any }) => obj.customerId
      );
      console.log(this.customers);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      console.log('onInit', data.ref.customerGroups);
      this.customerGroups = data.ref.customerGroups.map(
        (obj: { groupId: any }) => obj.groupId
      );
      console.log(this.customerGroups);
    });

    this.service.getDropDownData().subscribe((data: any) => {
      console.log('onInit', data.ref.invoiceReportFormats);
      this.invoiceReportFormats = data.ref.invoiceReportFormats;
      this.creditNoteReportFormats = data.ref.creditNoteReportFormats;
    });
    this.selectedOptions = this.colDefs.map((coulmn) => coulmn.field);
  }
  constructor(
    public planService: PlanService,
    private service: SearchInvoiceService,
    private datePipe: DatePipe,
    private timeService: TimeRunsheetService,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    private timezone: TimeRunsheetService
  ) {
    this.gridOptions = {
      context: { Component: this },
    };
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          console.log('create:', data);
          this.dialogService.savaLayout(data);
        }
      }
    );
    this.getView();
  }
  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.setup.Search.Invoices.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Invoices.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Invoices.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }
  formData: any = {
    likeInvoiceId: null,
    status: null,
    customerID: null,
    customerGroup: null,
    issuedDate: null,
    invoiceDate: null,
    dueDate: null,
    documentType: null,
  };
  ok: boolean = false;
  sum: number = 0;
  selectedRow: any = null;
  closeDialog() {
    this.ok = false;
    this.isDivVisible = false;
    this.sum = 0;

    var gridApi = this.gridOptions.api;
    // Call deselectAll to unselect all selected rows
    gridApi.deselectAll();
  }
  onSelectionChange(event: any) {
    console.log(event.value);
    this.clearFilters();
    this.columnDefs = this.colDefs.filter(
      (column) => event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  InvoiceDate: Date;
  IssuedDate: Date;
  DueDate: Date;
  onCleaStatus() {
    this.formData.status = '';
  }
  onCleaCustomerID() {
    this.formData.customerID = '';
  }
  onCleaCustomerGroup() {
    this.formData.customerGroup = '';
  }
  onCleaDocument() {
    this.formData.documentType = '';
  }
  submitForm() {
    if (this.InvoiceDate != null) {
      this.formData.invoiceDate = this.timezone.convertDatetoMilliseconds(this.InvoiceDate);
    }
    else if (this.InvoiceDate == null) {
      this.formData.invoiceDate = null;
    }
    if (this.IssuedDate != null) {
      this.formData.issuedDate = this.timezone.convertDatetoMilliseconds(
        this.IssuedDate
      );
    } else {
      this.formData.issuedDate = null;
    }
    if (this.DueDate != null) {
      this.formData.dueDate = this.timezone.convertDatetoMilliseconds(this.DueDate);
    } else {
      this.formData.dueDate = null;
    }

    //this.formData.issuedDate =  moment(this.formData.issuedDate, "YYYY-MM-DD HH:mm:ss").format("x")
    // if (this.formData.issuedDate != null) {
    //   this.formData.issuedDate = this.timeService.convertDatetoMilliseconds(
    //     this.formData.issuedDate
    //   );
    // }
    // if (this.formData.dueDate != null) {
    //   this.formData.dueDate = this.timeService.convertDatetoMilliseconds(
    //     this.formData.dueDate
    //   );
    // }
    this.service.postInvoiceData(this.formData).subscribe((response: any) => {
      // Handle the response here if needed
      console.log('Response:', response);
      this.rowData = response.invoices;
      console.log('hiii', this.rowData);
      // this.formData = {
      //   likeInvoiceId: null,
      //   status: null,
      //   customerID: null,
      //   customerGroup: null,
      //   issuedDate: null,
      //   invoiceDate: null,
      //   dueDate: null,
      //   documentType: null,
      // };
    });
  }
  displayedColumns: string[] = [
    'demo-position',
    'demo-name',
    'demo-weight',
    'demo-symbol',
    'demo-amount',
    'demo-period',
  ];
  dataSource: any;
  public popupParent: HTMLElement | null = document.body;
  checkboxClicked: boolean = false;
  CurrencyCellRendererUSD(params: any) {
    var inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    });
    return inrFormat.format(params.value);
  }
  colDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'id',
      headerName: 'Invoice No',
      cellDataType: 'text',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'customerid',
      headerName: 'Customer ID',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'customergroupid',
      headerName: 'Customer Group',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'duedate',
      headerName: 'Due Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    },
    {
      field: 'fromdate',
      headerName: 'From Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
    },
    {
      field: 'todate',
      headerName: 'To Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
    },
    {
      field: 'issuedate',
      headerName: 'Issue Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
    },
    {
      field: 'invoicestatusid',
      headerName: 'Invoice status',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'documenttype',
      headerName: 'Type',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'exported',
      headerName: 'Exported',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'exgst',
      headerName: 'Base Charge Ex GST',
      resizable: true,
      floatingFilter: true,
      filter: true,
      cellRenderer: this.CurrencyCellRendererUSD 
    },
    {
      field: 'fuellevy',
      headerName: 'Fuel Levy',
      resizable: true,
      floatingFilter: true,
      filter: true,
      cellRenderer: this.CurrencyCellRendererUSD 
    },
    {
      field: 'discountamt',
      headerName: 'Discount',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'totalexgst',
      headerName: 'Total Ex GST',
      resizable: true,
      floatingFilter: true,
      filter: true,
      cellRenderer: this.CurrencyCellRendererUSD 
    },
    {
      field: 'created',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      headerName: 'Created On',
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
    },
  ];

  public defaultColDef: ColDef = {
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  /**

   * For toggle button

   */
  columnDefs: ColDef[] = this.colDefs;
  isDivVisible: boolean = false;

  rightSideForm(event: any) {
    this.printRowValue = event.data;
    console.log('row click', event);
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code in row clicked', rowCount);
    if (rowCount > 1) {
      // Get a reference to the grid API
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
      // Select the clicked row
      event.node.setSelected(true);
    }
  }

  setCellSubData(intvalue: any, selectedRows: any, checkboxEnabled: boolean) {
    if (intvalue == 0) {
      this.sum = 0;
    }
    this.sum += intvalue;
    console.log('selected rows', this.selectedIds, this.sum);
    if (this.sum === 1) {
      console.log('right');
      this.isDivVisible = this.ok = true;
      this.ok = true;
    } else {
      this.ok = false;
      this.isDivVisible = false;
    }

    if (checkboxEnabled) {
      this.selectedIds.push(selectedRows);
    } else {
      if (this.selectedIds.includes(selectedRows)) {
        this.selectedIds = this.selectedIds.filter(
          (id: any) => id !== selectedRows
        );
      }
    }
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(
      (document.getElementById('filter-text-box') as HTMLInputElement).value
    );
  }
  // isChecked: boolean = true;
  isChecked = false;
  showRunsheetDetail: boolean = false;
  public autoGroupColumnDef: ColDef = {
    headerName: 'Group',
    minWidth: 250,
    field: 'runsheetid',
    valueGetter: (params) => {
      if (params.node!.group) {
        return params.node!.key;
      } else {
        return params.data[params.colDef.field!];
      }
    },
    headerCheckboxSelection: true,
    cellRenderer: 'agGroupCellRenderer',
    cellRendererParams: {
      checkbox: true,
    } as IGroupCellRendererParams,
  };

  public rowSelection: 'single' | 'multiple' = 'multiple';
  public rowGroupPanelShow: 'always' | 'onlyWhenGrouping' | 'never' = 'always';
  public pivotPanelShow: 'always' | 'onlyWhenPivoting' | 'never' = 'always';

  showInvoiceDetail: boolean = false;

  downloadCsv() {
    this.service.InvoiceCsvDownload(this.formData).subscribe((res: any) => {
      // Assuming 'response' is the array buffer received from your HTTP request
      var arrayBuffer = res;
      var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
      var url = window.URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'report.csv'; // Set the desired file name
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  selectedCustomers: any;
  // onPrintWithCustomerFormatClick() {

  //   // TODO: this is just mock parameters. replace with data from selected rows in grid.
  //   let invoicesParam: InvoicePreview[] = [
  //     {
  //     id: 215587,
  //     siteid: 296,
  //     documenttype: 'Invoice',
  //     exported: true,
  //     invformat: '16',
  //     cnformat: '1',
  //     defaultinvformat: '3',
  //     defaultcnformat: '1'
  //   }
  // ];

  //   // create request params
  //   let invoicePreviewParam: InvoicePreviewRequest = {
  //     defaultCustFormat: true,
  //     cnFormat: null,
  //     invFormat: null,
  //     showZero: null,
  //     invoices: invoicesParam
  //   };

  //   // encode params
  //   let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

  //   // open report view window
  //   window.open('/reportview?invoicePreview=' + requestParam, '_blank');

  // }

  // onPrintInvoiceFormatClick() {

  // TODO: this is just mock parameters. replace with data from selected rows in grid that are documenttype='Invoice' only
  //   let invoicesParam: InvoicePreview[] = [{
  //     id: 215587,
  //     siteid: 296,
  //     documenttype: 'Invoice',
  //     exported: true,
  //     invformat: '16',
  //     cnformat: '1',
  //     defaultinvformat: '3',
  //     defaultcnformat: '1'
  //   }];

  //   // create request params
  //   let invoicePreviewParam: InvoicePreviewRequest = {
  //     defaultCustFormat: false,
  //     cnFormat: null,
  //     invFormat: 16, // TODO: change this to what was chosen in the invoice format list.
  //     showZero: null,
  //     invoices: invoicesParam
  //   };

  //   // encode params
  //   let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

  //   // open report view window
  //   window.open('/reportview?invoicePreview=' + requestParam, '_blank');

  //}

  filterCustomerID(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.customers.length; i++) {
      let country = this.customers[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredCustomerID = filtered;
  }

  filterCustomerGroup(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.customerGroups.length; i++) {
      let country = this.customerGroups[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredCustomerGroup = filtered;
  }

  filterDocumentType(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.documentType.length; i++) {
      let country = this.documentType[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredDocumentType = filtered;
  }

  selectedStatus: any;
  filterStatus(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.status.length; i++) {
      let country = this.status[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredStatus = filtered;
  }

  filteredCustomers: any[];
  filteredCustomer(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.customers.length; i++) {
      let country = this.customers[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredCustomers = filtered;
  }

  dataForRightSideForm(id: any) {
    this.isDivVisible = true;
    this.ok = true;

    console.log(event);
    this.service.getInvoiceList(id).subscribe((response) => {
      console.log('Left side :', response);
      this.invoice = response.invoice;
      // console.log('right',this.invoice);
      this.lines = response.lines;
      console.log('right', this.lines);
      this.dataSource = this.lines;
    });
  }
  printRowValue: any;
  onPrintWithCustomerFormatClick() {
    let invoicesParam: InvoicePreview[] = [
      {
        id: this.printRowValue.id,
        siteid: this.printRowValue.sideid,
        documenttype: this.printRowValue.documenttype,
        exported: this.printRowValue.exported,
        invformat: this.printRowValue.invformat,
        cnformat: this.printRowValue.cnformat,
        defaultinvformat: this.printRowValue.defaultinvformat,
        defaultcnformat: this.printRowValue.defaultcnformat,
      },
    ];
    let invoicePreviewParam: InvoicePreviewRequest = {
      defaultCustFormat: true,
      cnFormat: null,
      invFormat:null,
      showZero: null,
      invoices: invoicesParam,
    };

    let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));
    window.open('/reportview?invoicePreview=' + requestParam, '_blank');
  }
  onPrintInvoiceFormatClick(id: any) {
    let invoicesParam: InvoicePreview[] = [
      {
        id: this.printRowValue.id,
        siteid: this.printRowValue.sideid,
        documenttype: 'Invoice',
        exported: this.printRowValue.exported,
        invformat: this.printRowValue.invformat,
        cnformat: this.printRowValue.cnformat,
        defaultinvformat: this.printRowValue.defaultinvformat,
        defaultcnformat: this.printRowValue.defaultcnformat,
      },
    ];
    let invoicePreviewParam: InvoicePreviewRequest = {
      defaultCustFormat: false,
      cnFormat: null,
      invFormat:id,
      showZero: null,
      invoices: invoicesParam,
    };

    let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));
    window.open('/reportview?invoicePreview=' + requestParam, '_blank');
  }
  onPrintWithCreditFormatClick(id: any) {
    let invoicesParam: InvoicePreview[] = [
      {
        id: this.printRowValue.id,
        siteid: this.printRowValue.sideid,
        documenttype: 'Credit Note',
        exported: this.printRowValue.exported,
        invformat: this.printRowValue.invformat,
        cnformat: this.printRowValue.cnformat,
        defaultinvformat: this.printRowValue.defaultinvformat,
        defaultcnformat: this.printRowValue.defaultcnformat,
      },
    ];
    let invoicePreviewParam: InvoicePreviewRequest = {
      defaultCustFormat: false,
      cnFormat: id,
      invFormat:null,
      showZero: null,
      invoices: invoicesParam,
    };

    let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));
    window.open('/reportview?invoicePreview=' + requestParam, '_blank');
  }
  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code', rowCount);
    if (rowCount == 1) {
      this.printRowValue = event.api.getSelectedNodes()[0].data;
      console.log('here', event.api.getSelectedNodes()[0].data);
      this.isDivVisible = true;
      this.ok = true;
      this.dataForRightSideForm(event.api.getSelectedNodes()[0].data.id);
    } else {
      this.isDivVisible = false;
      this.ok = false;
    }
  }
}

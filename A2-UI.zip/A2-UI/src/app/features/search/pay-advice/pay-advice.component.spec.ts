import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayAdviceComponent } from './pay-advice.component';

describe('PayAdviceComponent', () => {
  let component: PayAdviceComponent;
  let fixture: ComponentFixture<PayAdviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayAdviceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PayAdviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent {
  siteSelected:boolean=true;
  username: any;

  constructor(private navbarService: NavbarService) {}

  ngOnInit() {
    this.getUsername();
  }

  getUsername() {
    this.navbarService.usernameSubject.subscribe((data: any) => {
      this.username = data;
    })
    this.navbarService.siteSelectedInDrop.subscribe((data: any) => {
      if(data) {
        this.siteSelected = true;
      } else {
        this.siteSelected = false;
      }
    })
  }
}

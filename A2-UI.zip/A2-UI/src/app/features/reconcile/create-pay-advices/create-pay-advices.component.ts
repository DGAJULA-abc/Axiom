import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { SearchService } from '../../search/services/search.service';
import { ReconcileService } from '../services/reconcile.service';

@Component({
  selector: 'app-create-pay-advices',
  templateUrl: './create-pay-advices.component.html',
  styleUrls: ['./create-pay-advices.component.scss'],
})
export class CreatePayAdvicesComponent {
  layoutSubscription: Subscription;
  constructor(private service: SearchService, private messageService: MessageService,private reconcileService: ReconcileService, private router: Router, private _formBuilder: FormBuilder, public dialogService: DialogService) { 
    this.layoutSubscription= this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) =>{
      if(shouldSubscribe){
        this.dialogService.savaLayout('create pay advice');
      }
    })
  }
  rightTitle: string = 'Create Pay Advices';
  disableCreatePayAdvice : boolean = false;
  driverNamesList: any =[];
  public defaultIssueDate: Date;
  public defaultFromDate: Date;
  public defaultToDate: Date;
  CurrencyCellRendererUSD(params: any) {
    var inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    });
    return inrFormat.format(params.value);
  }

  public columnDefs: any[] = [
    { field: 'companyId', headerName: 'Company' },
    { field: 'companytype', headerName: 'Company Type' },
    { field: 'driverId', headerName: 'Driver',
    cellRenderer: (data: any) => {
      let name;
      this.driverNamesList.filter((driver:any)=>{
        
        if(driver.id === data.value) {
          name = driver.employeeName;
        }
      })
      return name;
    } },
    {
      field: 'effectiveDate', headerName: 'Effective Date', 
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;
           console.log("formatted filter:", formattedFilter);
           console.log("formatted value:", formattedValue)
          return formattedValue.includes(formattedFilter);
        }
      },
      floatingFilter: true,
    },
    { field: 'lineText', headerName: 'Description' },
    { field: 'loadNumber', headerName: 'Load No' },
    { field: 'payAmount', headerName: 'Amount' , cellRenderer: this.CurrencyCellRendererUSD,},
    { field: 'runsheetId', headerName: 'Runsheet' },
    { field: 'adjustmentTypeId', headerName: 'Adjustment' },
    { field: 'serviceNumber', headerName: 'ServiceNo' },


  ];

  public rowData = [];
  payAdviceForm = new FormGroup({
    issueDate: new FormControl(),
    toDate: new FormControl(),
    fromDate: new FormControl()
  });

  formattedYesterday: any;
  @Output() not: EventEmitter<string> = new EventEmitter<string>();

  ngOnInit() {
    this.reconcileService.pageTitleSubject.next('Create Pay Advices');
    this.not.emit(this.rightTitle);
    this.service.getDropDownData().subscribe((data: any) => {
      this.driverNamesList = data.ref.drivers;

    });
    let yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 4);
    let fromDate = new Date()
    fromDate.setDate(fromDate.getDate() - 10);

    this.defaultIssueDate = yesterday;
    this.defaultFromDate = fromDate;
    this.defaultToDate = yesterday;

    this.getRowData();

    
  }

  
  setpageLayout() {
    console.log("create pay advices")
    // const currentPageData = 'Create Invoice';
    this.dialogService.savaLayout('create pay advices');
  }

  getRowData() {
    const payAdviceFormSubmit = {
      issueDate: this.defaultIssueDate.getTime(),
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime()
    }
    this.reconcileService.createPayAdvices(payAdviceFormSubmit)
      .subscribe(
        (result: any) => {
          console.log("result complete runsheet data > ", result);

          
          console.log("length:", this.rowData, result)
          if(!result.targetPayAdviceLines){
          this.disableCreatePayAdvice = true;
          this.rowData = [];  
        }else{
          this.rowData = result.targetPayAdviceLines;
          this.disableCreatePayAdvice = false;
        }
        }
      );


  }

  close() {
    this.reconcileService.pageTitleSubject.next('Reconcile');
    this.router.navigate(['/reconcile']);
  }

  payAdvice() {
    const payAdviceFormSubmit = {
      issueDate: this.defaultIssueDate.getTime(),
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime()
    }
    this.reconcileService.payAdvice(payAdviceFormSubmit)
      .subscribe(
        (result: any) => {
          console.log("created pay advice > ", result);
          this.getRowData();
          if(result) {
       const createPatIssue = `Creating pay advices ${moment(this.defaultIssueDate.getTime()).format('DD/MM/YYYY')}`;
       const messageDetail = `Pay Advice creation: ${result?.payAdvicesCreated} documents created,
                                ${result?.payAdviceLinesProcessed} lines (${result?.totalAmount})`
        console.log('invoice > ', result, result?.status);
        this.getRowData();
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: messageDetail,
          life: 3000,
          key: 'printCreateDetail'
        });

        this.messageService.add({
          key: 'printCreate',
          detail: createPatIssue,
          severity: 'success',
          life: 30000,
        });
          // this.messageService.add({
          //   severity: 'success',
          //   summary: '',
          //   detail: ' Pay Advice Creation. 1 Document created. 2 lines($20)',
          // });

          // this.messageService.add({
          //  // key: 'customToast',
          //   severity: 'success',
          //   summary: '',
          //   detail: ' Pay Advice Creation. 1 Document created. 2 lines($20)'
          //  // life: 30000,
          // });
        }
        })
  }
}

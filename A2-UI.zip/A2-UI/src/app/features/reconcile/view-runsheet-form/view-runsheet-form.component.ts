import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { NgIf, JsonPipe, DatePipe } from '@angular/common';
import { FormGroup } from '@angular/forms';

import { MessageService, SelectItem } from 'primeng/api';
import { ReconcileService } from '../services/reconcile.service';
import { ActivatedRoute, Router } from '@angular/router';
import {
  FormArray,
  FormBuilder,
  FormControl,
  Validators,
} from '@angular/forms';
import * as _ from 'lodash';
import { SetupService } from '../../setup/service/setup.service';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import {
  ErrorList,
  ExceptionInfo,
  GenericError,
  ReasonCode,
  ReasonLine,
  Runsheet,
  RunsheetConfig,
  RunsheetFormRequest,
  ViewRunsheetRunsheetId,
} from './ViewRunsheetId.model';
import * as moment from 'moment';
import { Driver } from '../models/view.reconcile.model';
import { RunsheetFormService } from '../services/runsheet-form.service';
import { RunsheetDetail, TripResponse } from '../detail/detail2.model';
import {
  Observable,
  catchError,
  combineLatest,
  finalize,
  forkJoin,
  interval,
  map,
  of,
  sample,
  switchMap,
  switchMapTo,
  tap,
  throwError,
} from 'rxjs';
import { Subscription, take } from 'rxjs';
import { TimeRunsheetService } from '../services/time-runsheet.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { Permission } from 'src/app/core/model/navbar.model';
import { SearchService } from '../../search/services/search.service';
import { RunsheetObjCreation } from '../services/runsheet-obj-creation.service';
import { ConfirmationService } from 'primeng/api';
import { PlanService } from '../../plan/services/plan.service';
import { Ref } from '../models/reference-model';
import { ReferenceDataService } from '../services/reference-data.service';
import { result, takeWhile } from 'lodash';
import { RunsheetService } from '../services/runsheet.service';
import { TimezoneServiceService } from '../services/timezone-service.service';
import { RunsheetAutofillModalService } from '../services/runsheet-autofill-modal.service';
import { Tooltip } from 'primeng/tooltip';
import { RunsheetLineDetailService } from '../detail/runsheet-line-detail/runsheet-line-detail.service';
import { DetailService } from '../detail/detail.service';
import { HttpErrorResponse } from '@angular/common/http';
import { AddServiceByService } from '../detail/add-services-by/add-service-by.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmingsavedornotsaveddialogComponent } from './confirmingsavedornotsaveddialog/confirmingsavedornotsaveddialog.component';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';

@Component({
  selector: 'app-view-runsheet-form',
  templateUrl: './view-runsheet-form.component.html',
  styleUrls: ['./view-runsheet-form.component.scss'],
  providers: [
    DatePipe,
    TimeRunsheetService,
    ConfirmationService,
    RunsheetAutofillModalService,
  ],
})
export class ViewRunsheetFormComponent implements OnInit, OnChanges {
  formStateSubmit: boolean = false;
  items: SelectItem[];
  isNew: boolean = false;
  // runsheetTypeId: SelectItem[];
  runsheetTypeId: any;

  data: any[] = [];
  alldata: any[] = [];
  rowData: any[] = [];
  isFormEnaabled: boolean = false;
  isChange: boolean = false;

  selectedItem: string | undefined;
  runsheetId: any = '';
  shiftId: any;
  //type
  filteredRunsheetTypes: any[];
  runsheetsTypeId: any[] = [];
  selectedRunsheetTypeId: any[] | any;
  runsheetTypeValueDrop: any;
  runsheetTypeDropArr: any[] = [];
  runsheetOptionSelectedVal: any;
  reasonData: any[];
  StartEndKMSwapped = 'Start/End kilometres are around the wrong way';
  odoMeterWarning: boolean = false;

  //Driver
  filteredDriver: any[] = [];
  driverId: any[] = [];
  allDriver: any[] = [];
  selectedDriverId: any[] | any;
  driverIdRequest: any;
  driverIdVal: any;

  //Odometer
  startkm: number;
  endkm: number;
  rateId: any;
  reconcileRunsheetInputHoldcode: any;
  serviceDetailComboboxReason: any;

  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];
  gridOptions: any;
  selectedReasonId: any[] | any;

  idRunsheetData: RunsheetFormRequest | any = {};

  lockUserName = '';
  editDeliverydateDate: any;
  editEndTime: any;

  //RunSheetData
  selectedRunSheetLinedata: any;
  canWrite: any;
  canRead: any;

  //driverbreak merges
  breakmerge:any;
  locmerge:any;
  commentmerge:any;
  starttimemerge:any;
  endtimemerge:any;
 driverbreakfromtable :any[]=[]



  formEnabled: any = false;
  showLookup: any = false;

  private pollerCount = 0;
  private maxPollerCount = 60; // The maximum number of intervals to attempt

  columnDefs: any[] = [
    {
      field: 'runsheetid',
      headerName: 'Runsheet Id',
      cellRenderer: CellrenderComponent,
      filter: 'agNumberColumnFilter',
    },
    { field: 'runsheettypeid', headerName: 'Runsheet Type Id' },
    { field: 'deliverydate', headerName: 'Delivery Date' },
    { field: 'publicholidayapplies', headerName: 'Public Holiday Applies' },
    { field: 'driverid', headerName: 'Driver Id' },
    { field: 'driver', headerName: 'Driver' },
  ];
  errFirst: any;
  runsheetLineId: any;
  errorId: any;

  editFormObj = {
    startkm: null,
    endkm: null,
    rateId: null,
    payamt: null,
    paydesc: null,
    holdcode: null,
    remarks: null,
    createdby: '',
    reasonLines: [
      {
        id: null,
        reasonId: null,
        siteId: null,
        reasoncomment: null,
        reasonrefEvent: null,
        reasonrefRunsheet: null,
        reasonrefService: null,
      },
    ],
  };

  runsheetDetailLIneFormObj = {};
  loadLocationFormObj = {};
  containerFormObj = {};
  breakFormObj = {};
  ratingFormObj = {};
  driverBreaksObj: {};
  driverBreaksObjEdit: {};

  runsheetLines = [];
  runsheetLinesObj: any[] = [];
  serviceFormReceivedData: any = {};
  loadFormReceivedData: any = {};
  containerFormReceivedData: any = {};
  breakFormReceivedData: any = {};

  obsServiceDetail$: Observable<any>;
  obsloadDetail$: Observable<any>;
  obsContainerDetail$: Observable<any>;
  obsTripDetail$: Observable<any>;

  subscription: Subscription;

  // runsheetLines: FormArray;
  errorDetail: any;
  errorInner: any;
  exceptionTime: any;
  errorHeader2: any;

  endTime: any;
  deliveryDateStamp: any;
  editReturndepotTime: any;
  createdTime: any;

  runsheetStatus: any;
  lockStatus: any = 'Open';
  resaonLength: any;

  isLoading = false;

  reasonLinesObjData: any[] = [];
  breakTypeIdData: any;
  autoFillRunsheetLines: any;
  tripDataObjData: any;

  bulkEditMode: boolean = false;

  unitDataServiceDetail: any;
  ViewServiceTypes: any;
  selectedDetailType: any;
  runsheetState: RunsheetConfig = {
    runsheetTypeId: null,
    displayLookupButton: false,
    displayNextRunsheetButton: false,
    deliveryDateStamp: null,
    enddateStamp: null,
    shiftId: null,
    showLookup: false,
    showGrid: false,
    showTime: false,
    StartEndKMSwappedCondition: false,
    completed: false,
    formEnabled: false,
    locked: false,
  };

  bulkeditIdsData: any[] = [];
  ViewDrivers: any[] = [];
  isSelectedRow: any;

  runsheetData = {
    returndepotdateStamp: new Date(), // Initialize with proper value
    deliveryDateStamp: new Date(), // Initialize with proper value
  };

  headerRunsheet: any;
  compleBtnHidePop: any = false;
  deleteTypeBreakId: any;

  initialFormValue = {};
  changesFormField: any = {};
  modifyShow: boolean = false;
  selectedHoldCode: any;
  displayStyle = "none";
  autoFillRes: any;
  ratedRunsheet: boolean = false;

  constructor(
    public permission: PermissionsService,
    private reconsileService: ReconcileService,
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router,
    private navbarService:NavbarService,
    private confirmationService: ConfirmationService,
    private runsheetFormService: RunsheetFormService,
    private messageService: MessageService,
    public datepipe: DatePipe,
    private timeService: TimeRunsheetService,
    private searchServices: SearchService,
    private runsheetObjCreation: RunsheetObjCreation,
    private planService: PlanService,
    private refDataService: ReferenceDataService,
    private runsheetService: RunsheetService,
    private runsheetformService:RunsheetFormService,
    private timezoneService: TimezoneServiceService,
    private runsheetAutofillModalService: RunsheetAutofillModalService,
    private runsheetLineDetails: RunsheetLineDetailService,
    private detailService: DetailService,
    private addServiceByService: AddServiceByService,
    private authenticationService: AuthenticationService,
    private dialog: MatDialog
  ) {
    this.reconsileService.pageTitleSubject.next('Create Runsheet');
  }

  reconcileFormCreateRunsheet = this.fb.group({
    runsheetTypeId: ['', Validators.required],
    driverId: ['', Validators.required],
    starttime: ['', Validators.required],
    endtime: ['', Validators.required],
    returndepottime: ['', Validators.required],
    startkm: ['', Validators.required],
    endkm: ['', Validators.required],
    remarks: ['', Validators.required],
    holdcode: ['', Validators.required],
    reasonId: ['', Validators.required],
    payamt: ['', Validators.required],
    // serviceDetailComboboxReason: ['', Validators.required],
    driverBreaks: [],
    payAdviceLines: [],
    invoiceLines: [],
    reasonLines: [],
  });

  detailCombinedFormValues: any = {};
  selectedSite:any;

  ngOnInit() {
    this.runsheetId =
    this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
    this.getRefData();
    this.checkRoute();

    this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
    console.log("SelectedSiteId in viewrunsheetform",this.selectedSite)
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
   
    // this.getDriver();
    this.obsServiceDetail$ = this.runsheetFormService.formData$;

    // this.runsheetFormService.detailSubjectForm.subscribe(((data: any) => {
    //   this.obsServiceDetail$ = data;
    // }))
    this.obsloadDetail$ = this.runsheetFormService.loadFormData$;
    this.obsContainerDetail$ = this.runsheetFormService.containerFormData$;
    this.obsTripDetail$ = this.runsheetFormService.tripFormDataSubject$;

   this.ratedRunsheet = false;

    const combinedDetailForm$ = combineLatest([
      this.obsServiceDetail$,
      this.obsloadDetail$,
      this.obsContainerDetail$,
    ]).subscribe((resultArry) => {
      // if(this.formStateSubmit) {
      this.serviceFormReceivedData = resultArry[0];
      this.loadFormReceivedData = resultArry[1];
      this.containerFormReceivedData = resultArry[2];
      this.detailCombinedFormValues = {
        ...this.serviceFormReceivedData,
        ...this.loadFormReceivedData,
        ...this.containerFormReceivedData,
      };

      //   this.formStateSubmit = false;
      // }
      this.calculateDateDifference();
     
    });


    this.subscription =
      this.runsheetFormService.breeakFormDataSubject$.subscribe((data) => {
        this.breakFormReceivedData = data.value;
      });

    this.subscription =
      this.runsheetFormService.reasonFormDataSubject$.subscribe((data) => {
        this.reasonLinesObjData = [];
        const resonsData = data.value;
        if (resonsData && resonsData.reasons.length > 0) {
          resonsData.reasons.forEach((reason: any) => {
            if (reason.reasonId && reason.reasoncomment) {
              this.reasonLinesObjData.push(reason);
            }
          });
        }
        // console.log('reason form', this.reasonLinesObjData);
      });

    this.subscription = this.runsheetFormService.tripFormDataSubject$.subscribe(
      (data) => {
        // console.log('trip Form form', data.value);

        this.tripDataObjData = data;
      }
    );

    this.subscription = this.runsheetFormService.unitDataSubject.subscribe(
      (unitData: any) => {
        this.unitDataServiceDetail = unitData;
      }
    );
    // setInterval(() => {
    //   this.renewLocks();
    // }, 5000);
    // console.log('runsheetId >> ', this.runsheetId);
    this.getRefData();
    // this.getRunsheetTypes();
    // this.getDriver();
    // this.getReasonCode();
    // this.checkRoute();
    // this.getRunseetIdData(this.runsheetId);
    // this.runshheetMode(+this.runsheetId);
    this.getMultiLegData();
    this.listenSelectitemType();
    this.dirtyFormCheck();
    // this.getPermission();
    this.fetchPermissions();

    // this.changeOdoApi();
    // this.runsheetStatusFun();
    // this.runsheetFormObjMapping();
    // this.toggleFormState();
  }

  checkRoute() {
    if (this.runsheetId) {
      this.getRunseetIdData(+this.runsheetId);
      this.runshheetMode(+this.runsheetId);
    } else {
      this.router.navigate(['reconcile/CreateRunsheet']);
      let today = new Date();
      this.editDeliverydateDate = new Date(today);
      this.editDeliverydateDate.setDate(today.getDate()-1)
      this.editDeliverydateDate.setHours(0);
      this.editDeliverydateDate.setMinutes(0);
    }
  }

  renewLocks() {
    this.reconsileService.renew().subscribe((response) => { });
  }

  adjustWith8HoursPolicy() {
    // return TimeRunsheetService.adjustWith8HoursPolicy(a, b, false);
  }

  ngOnChanges(changes: SimpleChanges) {
    this.calculateDateDifference();
  }

  getRefData() {
    this.authenticationService.viewAPI.subscribe((result: any) => {

      if (result) {
        //   this.isLoading = false;
        this.getRunsheetTypes(result['ref'].runsheetTypes);
        //   this.getLoadTypes(result['ref'].loadTypes);
        //   this.selectedsite = result['selectedSite'];
        this.ViewServiceTypes = result['ref'].serviceTypes;
        this.ViewDrivers = result['ref'].drivers;
        // this.getDriver();
        //   this.ViewTrucks = result['ref'].trucks;
        //   this.ViewContainers = result['ref'].containers;
        //   this.ViewCustomers = result['ref'].customers;
        //   this.ViewTrailers = result['ref'].trailers;
        //   this.ViewVessels = result['ref'].vessels;
        //   this.ViewLocations = result['ref'].locations;
        this.getReasonCode(result['ref'].reasons);
        this.checkRoute();
        //   this.getReason(result['ref'].reasons);
        //   if (
        //     this.selectedService.originSite == this.selectedsiteid &&
        //     this.selectedService.destinationSite == this.selectedsiteid
        //   ) {
        //     this.selectedsitedescription = this.selectedsite.description;
        //     this.sites.push(this.selectedsite.description);
        //   }
      }
      // this.getRunseetIdData(+this.runsheetId);
      // this.runshheetMode(+this.runsheetId);
    });
  }
  filteredCompareObj: any;
  runshheetMode(id: any) {
    this.reconsileService
      .showErrors(id, this.shiftId)
      .subscribe((renewLockData: any) => {
        // console.log('renewLocks >>', renewLockData);
      });

    this.reconsileService.lockRunsheet(id).subscribe((renewLockData: any) => {
      // console.log('renewLocks >>', renewLockData);
    });
  }
    onFormSubmit()
    //  : Observable<any> 
     {
      // return new Observable(observer =>{

      
    this.formStateSubmit = !this.formStateSubmit;
    this.headerRunsheet = 'Save Runsheet?';
    this.confirmationService.confirm({
      message:
        'The runsheet is not valid, some data is missing or incorrect. Continue saving runsheet anyway?',
      // header: 'Save Runsheet?',
      // icon: 'pi pi-exclamation-triangle',
      accept: () => {
        // this.submitForm();
        setTimeout(() => {
          this.reconcileFormCreateRunsheetSubmit();
          // observer.complete();
        }, 200);
        this.runsheetStatus = "Saved";
      },
      reject: () => {
        // If needed, handle rejection
      },
    });
    
  // })
  }
  reconcileFormCreateRunsheetSubmit() {
    this.breakmerge='';
    this.locmerge='';
    this.commentmerge='';
    this.starttimemerge='';
    this.endtimemerge='';
    // this.runsheetFormService.formStateSubmit.
    const breakstarttimeVal = +moment(
      this.breakFormReceivedData.breakstarttime,
      'YYYY-MM-DD[T]HH:mm:ss'
    )
      .format('x')
      .valueOf();

    const breakendtimeVal = +moment(
      this.breakFormReceivedData.breakendtime,
      'YYYY-MM-DD[T]HH:mm:ss'
    )
      .format('x')
      .valueOf();
    this.driverBreaksObj = [
      {
        id: this.breakTypeIdData || null,
        breakstarttime: breakstarttimeVal || null,
        breakendtime: breakendtimeVal || null,
        ...this.runsheetFormService.getDriverBreaksObj(
          this.breakFormReceivedData
        ),
      },
    ];
    // // console.log('this.tripDataObjData.id >> ', this.tripDataObjData.id);
    //  const typeCheckRunsheetId = this.runsheetFormService.checkRunsheetTypeType(this.runsheetLineId);
    // if(typeCheckRunsheetId === 'String') {
    //   this.runsheetLineId = this.tripDataObjData.id;
    // }
    const formRunsheet = this.reconcileFormCreateRunsheet.value;
    this.runsheetLinesObj = [
      {
        id: this.runsheetLineId || null,
        ...this.runsheetFormService.getRunsheetLinesObj(
          formRunsheet.payamt,
          this.tripDataObjData,
          this.loadFormReceivedData,
          this.serviceFormReceivedData,
          this.selectedRunSheetLinedata,
          this.containerFormReceivedData,
          this.unitDataServiceDetail
        ),
      },
    ];
    // const driverIdCrea = Number(formRunsheet.driverId?.split('-')[0]);
    const driverIdCrea = this.driverIdPayload;
    // this.runsheetLineId ? this.runsheetLineId : null;
    // let tripSeqCalculate: any;
    // this.runsheetLineDetails.gridDataArrayServiceDetail.map((item: any) => {
    //     if(typeof item?.tripseq === 'string' && item?.tripseq.split('.').length > 0) {
    //       tripSeqCalculate = Number(item?.tripseq.split('.')[1]);
    //       console.log("tripSeqCalculate string", tripSeqCalculate);
          
    //     } else if(!isNaN(item?.tripseq) && typeof item?.tripseq === 'number') {
    //       tripSeqCalculate = item?.tripseq
    //       console.log("tripSeqCalculate number", tripSeqCalculate);

    //     } else {
    //       tripSeqCalculate = null
    //       console.log("tripSeqCalculate null", tripSeqCalculate);

    //     }
    // })
    console.log("Trip group",  this.runsheetLineDetails.gridDataArrayServiceDetail);
    
    const payloadRunseetLine =
      this.runsheetLineDetails.gridDataArrayServiceDetail.map((item: any) => {
        delete item.seqDisplay;
       // we only set the tripodostart and tripodoend on the first runsheet line of the trip (tripseq=1).                            
       if (item.tripseq === 1) {                                
        item.tripodostart = item.tripodostart;
        item.tripodoend = item.tripodoend;
         } else {                                
        item.tripodostart = null;
        item.tripodoend = null;
        }    
        return {
        ...item,
        lineServiceTO: {
          ...item.lineServiceTO,
          pickupLocation: {
            ...item.lineServiceTO.pickupLocation,
            locationDesc: item.lineServiceTO.pickupLocation.locationDesc, // .lName === 'lineServiceTO.pickupLocation.locationDesc' ? row.lValue: null,
            zoneChargeId: item.lineServiceTO.pickupLocation.zoneChargeId, // .lName === 'lineServiceTO.pickupLocation.zoneChargeId' ? row.lValue: null,
            zonePayId: item.lineServiceTO.pickupLocation.zonePayId, // .lName === 'lineServiceTO.pickupLocation.zonePayId' ? row.lValue: null,
          },
          loadLocation: {
            ...item.lineServiceTO.loadLocation,
            locationId: item.lineServiceTO.loadLocation.locationId, // row.lName === 'lineServiceTO.loadLocation.locationId' ? row.lValue: null,
            locationDesc: item.lineServiceTO.loadLocation.locationDesc, // row.lName === 'lineServiceTO.loadLocation.locationDesc' ? row.lValue: null,
          },
          dropLocation: {
            ...item.lineServiceTO.loadLocation,
            locationDesc: item.lineServiceTO.loadLocation.locationDesc, // row.lName === 'lineServiceTO.dropLocation.locationDesc' ? row.lValue: null,
            zoneChargeId: item.lineServiceTO.loadLocation.zoneChargeId, // row.lName === 'lineServiceTO.dropLocation.zoneChargeId' ? row.lValue: null,
            zonePayId: item.lineServiceTO.loadLocation.zonePayId, // row.lName === 'lineServiceTO.dropLocation.zoneChargeId' ? row.lValue: null,
          },
        },
      //  tripseq: typeof item?.tripseq === 'string' && item?.tripseq.split('.').length > 0 
      //          ? Number(item?.tripseq.split('.')[1]) 
      //          : !isNaN(item?.tripseq) && typeof item?.tripseq === 'number' ? item?.tripseq : null, 
      //          // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        // tripseq: tripSeqCalculate,
        // groupseq: typeof item?.tripseq === 'string' && item?.tripseq.split('.').length > 2 
        // ? Number(item?.tripseq.split('.')[2]) : null, 
        qty1: typeof item?.qty1 === 'string' && item?.qty1.split(' ').length > 0 ? item?.qty1.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        qty2: typeof item?.qty2 === 'string' && item?.qty2.split(' ').length > 0 ? item?.qty2.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        qty3: typeof item?.qty3 === 'string' && item?.qty3.split(' ').length > 0 ? item?.qty3.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        qty4: typeof item?.qty4 === 'string' && item?.qty4.split(' ').length > 0 ? item?.qty4.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        qty5: typeof item?.qty5 === 'string' && item?.qty5.split(' ').length > 0 ? item?.qty5.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        qty6: typeof item?.qty6 === 'string' && item?.qty6.split(' ').length > 0 ? item?.qty6.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        qty7: typeof item?.qty7 === 'string' && item?.qty7.split(' ').length > 0 ? item?.qty7.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        qty8: typeof item?.qty8 === 'string' && item?.qty8.split(' ').length > 0 ? item?.qty8.split(' ')[0] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,

        unit1: typeof item?.qty1 === 'string' && item?.qty1.split(' ').length > 0 ? item?.qty1.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        unit2: typeof item?.qty2 === 'string' && item?.qty2.split(' ').length > 0 ? item?.qty2.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        unit3: typeof item?.qty3 === 'string' && item?.qty3.split(' ').length > 0 ? item?.qty3.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        unit4: typeof item?.qty4 === 'string' && item?.qty4.split(' ').length > 0 ? item?.qty4.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        unit5: typeof item?.qty5 === 'string' && item?.qty5.split(' ').length > 0 ? item?.qty5.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        unit6: typeof item?.qty6 === 'string' && item?.qty6.split(' ').length > 0 ? item?.qty6.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        unit7: typeof item?.qty7 === 'string' && item?.qty7.split(' ').length > 0 ? item?.qty7.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
        unit8: typeof item?.qty8 === 'string' && item?.qty8.split(' ').length > 0 ? item?.qty8.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,

        // unit1: item.qty1.split(' ').length > 0 ? item.qty1.split(' ')[1] : null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        // unit2: row['lName'] === 'qty2' ? row['lValue'].split(' ')[1]: null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        // unit3: row['lName'] === 'qty3' ? row['lValue'].split(' ')[1]: null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        // unit4: row['lName'] === 'qty4' ? row['lValue'].split(' ')[1]: null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        // unit5: row['lName'] === 'qty5' ? row['lValue'].split(' ')[1]: null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        // unit6: row['lName'] === 'qty6' ? row['lValue'].split(' ')[1]: null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        // unit7: row['lName'] === 'qty7' ? row['lValue'].split(' ')[1]: null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        // unit8: row['lName'] === 'qty8' ? row['lValue'].split(' ')[1]: null, // ?.split(' ').length > 0 ? row?.qty.split(' ')[1] : null,
        }
    });
      // console.log("PALAK BREAK->",this.runsheetLineDetails.gridDataArrayBreakDetail)
      console.log("payloadRunseetLine  ->", payloadRunseetLine)

      
const savenewpayloadCommons = {
  deducted: false,
  siteId: this.selectedSite,
  planned: false,
  id:null
}
this.driverbreakfromtable=[];

const startIndex = this.runsheetLineDetails.gridDataArrayBreakDetail.findIndex((element:any) => element.id === 1);
if(startIndex!==-1){
  for (let i = 0; i < startIndex; i++) {
    let Obj={
      breakTypeId:this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakTypeId,
      breakendtime:this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakendtime,
      breakstarttime:this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakstarttime,
      commentA:this.runsheetLineDetails.gridDataArrayBreakDetail[i].commentA,
      deducted:false,
      driverId:null,
      drivershiftId:null,
      id:this.runsheetLineDetails.gridDataArrayBreakDetail[i].id,
      locationId:this.runsheetLineDetails.gridDataArrayBreakDetail[i].locationId,
      locationPlannedId:null,
      planned:false,
      plannedendtime:null,
      plannedstarttime:null,
      siteId:this.selectedSite,
      tripId:null,
  
    }
    this.driverbreakfromtable.push(Obj);
  }
  
  for (let i = startIndex; i < this.runsheetLineDetails.gridDataArrayBreakDetail.length; i++) {
    if(this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakTypeId){
      const Obj={
        breakTypeId:this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakTypeId
      }
      this.breakmerge={...savenewpayloadCommons,...Obj}
     }
     if(this.runsheetLineDetails.gridDataArrayBreakDetail[i].locationId){
      const Obj={
        locationId:this.runsheetLineDetails.gridDataArrayBreakDetail[i].locationId
      }
      this.locmerge={...savenewpayloadCommons,...Obj}
     }
     if(this.runsheetLineDetails.gridDataArrayBreakDetail[i].commentA){
      const Obj={
        commentA:this.runsheetLineDetails.gridDataArrayBreakDetail[i].commentA
      }
      this.commentmerge={...savenewpayloadCommons,...Obj}
     }
     if(this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakstarttime){
      const Obj={
        breakstarttime:this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakstarttime
      }
      this.starttimemerge={...savenewpayloadCommons,...Obj}
     }
     if(this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakendtime){
      const Obj={
        breakendtime:this.runsheetLineDetails.gridDataArrayBreakDetail[i].breakendtime
      }
      this.endtimemerge={...savenewpayloadCommons,...Obj}
     }
     const finalmerge = {
      ...this.breakmerge,
      ...this.locmerge,
      ...this.commentmerge,
      ...this.starttimemerge,
      ...this.endtimemerge
     }
     this.driverbreakfromtable.push(finalmerge)
  }
}


console.log(this.reconcileFormCreateRunsheet.controls['starttime'].value)
let s = this.millisecondsCheck(this.reconcileFormCreateRunsheet.controls['starttime'].value)
let e = this.millisecondsCheck(this.reconcileFormCreateRunsheet.controls['endtime'].value)
let r = this.millisecondsCheck(this.reconcileFormCreateRunsheet.controls['returndepottime'].value)

    const realFormData = {
      runsheetTypeId: this.reconcileFormCreateRunsheet.value.runsheetTypeId
        ? this.reconcileFormCreateRunsheet.value.runsheetTypeId
        : this.idRunsheetData.runsheetTypeId,
      driverId: driverIdCrea ? driverIdCrea : this.idRunsheetData.driverId,
      starttime:s,
      endtime: e,
      returndepottime:r,

      startkm: formRunsheet.startkm,
      endkm: formRunsheet.endkm,
      holdcode: formRunsheet.holdcode,
      remarks: formRunsheet.remarks,
      payamt: formRunsheet.payamt,
      reasonLines: this.reasonLinesObjData,
      // runsheetLines: this.getUpdatedRunSheetLineData(
      //   this.idRunsheetData.runsheetLines,
      //   this.runsheetLinesObj,
      //   this.tripDataObjData
      // ),
      runsheetLines: payloadRunseetLine,
      // if data is coming from the api and form is not updated, return existing driver obj
      // if data is coming from the api or form is updated, return new driver obj

     

      driverBreaks:this.driverbreakfromtable
        // this.selectedDetailType === 'break' || this.idRunsheetData.driverBreaks
        //   ? this.getUpdateBreakLineData(
        //     this.idRunsheetData.driverBreaks,
        //     breakstarttimeVal && breakendtimeVal ? this.driverBreaksObj : null
        //   )
        //   : [],
    };

    // if (
    //   Object.keys(this.serviceFormReceivedData).length === 0 &&
    //   Object.keys(this.loadFormReceivedData).length === 0 &&
    //   Object.keys(this.containerFormReceivedData).length === 0 &&
    //   Object.keys(this.breakFormReceivedData).length === 0
    // ) {
    //   this.runsheetLinesObj = [];
    // } else {

    const compareObj = this.runsheetObjCreation.runsheetObjCompare(
      this.idRunsheetData,
      realFormData
    );


    let loadArray: any[] = [];
    this.searchServices.loadSeachArray$.subscribe((dataArray) => {
      loadArray = dataArray;
    });
    if (loadArray && Object.keys(loadArray).length != 0) {
      loadArray.forEach((item) => {
        this.runsheetLinesObj.push(item);
      });
    }

    let serviceArray: any[] = [];
    this.searchServices.serviceSeachArray$.subscribe((dataArray) => {
      serviceArray = dataArray;
    });
    if (serviceArray && Object.keys(serviceArray).length != 0) {
      serviceArray.forEach((item) => {
        this.runsheetLinesObj.push(item);
      });
    }
    this.runsheetFormService.runsheetLinesObj.next(realFormData.runsheetLines);
    // let updatedRunsheetLines;
    // this.runsheetFormService.gridData$.subscribe((data) => {
    //   updatedRunsheetLines = data;
    //   console.log('UPDATE:', updatedRunsheetLines);
    // });

    this.runsheetFormService.runSheetFormSubject.next(compareObj);

    // console.log('obj: compareObj', compareObj, this.gridOptions);
    // let gridALlRows: any = [];

    // this.filteredCompareObj = {
    //   ...compareObj,
    //   runsheetLines: compareObj.runsheetLines.map((item: any) => {
    //     if (item.id.indexOf("temp") > -1) {
    //       return { ...item, id: null };
    //     }
    //     return item;
    //   }),
    // };
    // console.log("gridALlRows >>", compareObj, this.filteredCompareObj);

    // gridALlRows = this.runsheetLineDetails.gridDataArrayServiceDetail;
    // this.submitRunsheetForm(gridALlRows);
    this.filteredCompareObj = compareObj;
    this.submitRunsheetForm(compareObj);
  }
  /**
   * Check this function since getting some error
   *
   * */

  millisecondsCheck(x:any):any{
    var newYork = moment.tz(x, 'Australia/Melbourne');
    var india = newYork.clone().tz('Asia/Kolkata');
    let y = moment(india).valueOf();
   return y
  }
  getUpdateBreakLineData(breakApiData: any, formBreakData: any) {
    const deleteBreakId = this.runsheetFormService.breakDeleteId;

    let breakApiDataArray: any[] = [];
    let breakFormDataArray = [];
    if (
      breakApiData &&
      breakApiData.length === 0 &&
      formBreakData &&
      formBreakData.length === 0
    ) {
      breakApiDataArray = [];
      formBreakData = [];
      return [...breakApiDataArray, ...formBreakData];
    } else {
      if (breakApiData && breakApiData.length > 0) {
        breakApiDataArray = breakApiData;

        if (deleteBreakId && !formBreakData) {
          return breakApiData.filter((data: any) => data.id !== deleteBreakId);
        }
      }

      if (formBreakData && formBreakData.length > 0) {
        if (formBreakData[0].id === null) {
          breakFormDataArray = formBreakData;
        } else {
          breakApiDataArray = breakApiDataArray.map(
            (obj: any) => formBreakData.find((o: any) => o.id === obj.id) || obj
          );
        }
      }

      return [...breakApiDataArray, ...breakFormDataArray];
    }
  }

  getUpdatedRunSheetLineData(
    runsheetApiData: any,
    formData: any,
    tripData: any
  ) {
    // if (this.bulkEditMode) {
    //   let changeMultipleRunsheet: any = [];
    //   changeMultipleRunsheet = this.runsheetService.bulkUpdateField(
    //     runsheetApiData,
    //     this.bulkeditIdsData,
    //     this.detailCombinedFormValues
    //   );
    //   console.log('changeMultipleRunsheet >>', changeMultipleRunsheet);
    // }
    let resultDataCommon = [];
    let runsheetApiDataArray = [];
    let runsheetFormDataArray = [];
    if (runsheetApiData && runsheetApiData.length > 0) {
      runsheetApiDataArray = runsheetApiData;
    }

    if (tripData) {
      this.runsheetFormService.updateLinesByTrip(runsheetApiData, tripData);
      resultDataCommon = [...runsheetApiData];
    } else {
      if (formData && formData.length > 0) {
        if (
          typeof formData[0].id === 'string' &&
          formData[0].id.indexOf('temp') > -1
        ) {
          formData[0].id = null;
        }
        if (formData[0].id === null) {
          runsheetFormDataArray.push(formData[0]);
        } else {
          runsheetApiDataArray = runsheetApiDataArray.map(
            (obj: any) => formData.find((o: any) => o.id === obj.id) || obj
          );
        }
        // console.log("runsheetLineApiDataArray view form>>",runsheetApiDataArray);
      }
      resultDataCommon = [...runsheetApiDataArray, ...runsheetFormDataArray];
    }
    // return [...runsheetApiDataArray, ...runsheetFormDataArray];
    return resultDataCommon;
  }

  runsheetLinesFormObj: any;
  submitRunsheetForm(runsheetFormMerge: any) {
    this.isLoading = true;
    // console.log(
    //   'runsheetFormMerge >>',
    //   runsheetFormMerge,
    //   this.idRunsheetData.invoiceLines
    // );
    this.postRunsheetValidation(this.filteredCompareObj.runsheetLines)
    this.runshheetMode(this.runsheetId);
    this.reconsileService
      .viewRunsheetSubmit(runsheetFormMerge)
      .pipe(take(1))
      .subscribe(
        (runseetSubsCribeData: any) => {
          this.isLoading = false;
          // this.messageService.add({
          //   severity: 'success',
          //   summary: '',
          //   detail: 'Runsheet created',
          // });
          this.runsheetFormService.dialogResultSubject.next(true);
          this.idRunsheetData = runseetSubsCribeData;
          if (runseetSubsCribeData != undefined) {
            this.runsheetFormService.emitRunseetSubsCribeData(
              runseetSubsCribeData
            );
            this.detailService.runseetReasonApidata = runseetSubsCribeData;
          }
          else {
            this.runsheetFormService.emitRunseetSubsCribeData(
              runseetSubsCribeData.runsheetLines
            );
          }
          this.reconsileService.setSelectedItemType('detail-page');
        },
        (err: any) => {
          this.isLoading = false;
          this.lockStatus = 'Locked';

          const lockErr: ErrorList = err.error.errorList;
          const lockErrDetail: ExceptionInfo =
            err.error.errorList.ExceptionInfos[0];
          this.errFirst = '';
          this.errorHeader2 = lockErr.ErrorMessage;
          this.errorInner = lockErrDetail.UserErrorDescription;
          this.errorId = lockErrDetail.ErrorId;
          this.exceptionTime = lockErr.ExceptionTime;
          const lockUsername =
            lockErrDetail.UserErrorDescription.indexOf('BY ') + 3;
          this.lockUserName =
            lockErrDetail.UserErrorDescription.substring(lockUsername);
          if (lockErrDetail.ContextId === 'INTERNAL') {
            this.errFirst = '500 Internal Server Error';
          }

          // console.log('Runsheet Error', lockErr);

          this.messageService.add({
            key: 'customToast',
            severity: 'error',
            life: 30000,
          });
        },
       
      );
    this.checkDemurrage(this.filteredCompareObj.runsheetLines);

    // this.checkDemurrage(this.runsheetLinesObj);
  }

  postRunsheetValidation(runsheetLines: any) {
    this.reconsileService.postRunsheetLinesValidation(runsheetLines).subscribe((runsheetLoadValidation: any) => {

    })
  }

  // runsheet Type
  filteredRunsheetTypesFun(event: any) {
    let runsheetTypeArr: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.runsheetsTypeId.length; i++) {
      // console.log("runsheetsTypeId >", this.runsheetsTypeId);
      let runsheetType = this.runsheetsTypeId[i];
      if (runsheetType.toLowerCase().includes(query.toLowerCase())) {
        runsheetTypeArr.push(runsheetType);
      }
    }

    this.filteredRunsheetTypes = runsheetTypeArr;
  }
  afterDeleteselectedRunsheetTypeId: any;
  //onchange typeeditDeliverydateDate
  onChangeRunsheetType(runsheetValue: any) {
    // console.log('runsheetValue >', runsheetValue);
    this.selectedRunsheetTypeId = runsheetValue;
    this.afterDeleteselectedRunsheetTypeId = this.selectedRunsheetTypeId;
    this.runsheetTypeValueDrop = runsheetValue;
    // console.log("filteredRunsheetTypes mm> ", this.filteredRunsheetTypes);

    this.runsheetTypeDropArr.filter((runsheetSecectedData: any) => {
      if (runsheetSecectedData.runsheetsTypeId === runsheetValue) {
        // console.log('runsheetSecectedData', runsheetSecectedData);
        this.runsheetOptionSelectedVal = runsheetSecectedData;
      }
    });
  }
  getRunsheetTypes(runsheetTypes: any) {
    // this.reconsileService.getRunsheetTypes().subscribe((runsheetTypes: any) => {
    this.runsheetsTypeId = [];
    if(runsheetTypes.length > 0) {
      runsheetTypes.map((runsheetType: any) => {
        //  console.log("getRunsheetTypes >>", adjustData);
        this.runsheetTypeDropArr = runsheetTypes;
        this.runsheetsTypeId.push(runsheetType.runsheetTypeId);
        let selectedType = runsheetTypes.find((item: any) => item.runsheetTypeId === "STANDARD")
        this.selectedRunsheetTypeId = selectedType ? selectedType.runsheetTypeId : runsheetTypes[0].runsheetTypeId;
        this.afterDeleteselectedRunsheetTypeId = this.selectedRunsheetTypeId;
      });
    } else {
      this.reconcileFormCreateRunsheet.get('runsheetTypeId')?.disable();
    }
    // });
  }
  //reason code
  getReasonCode(reasonCodes: any) {
    // this.reconsileService.getReasonCode().subscribe((reasonCodes: any) => {
    // console.log('getReasonCode >> ', reasonCodes);
    reasonCodes.map((reasonDrop: ReasonCode) => {
      if (reasonDrop.reasonDescription !== null) {
        const reasonCodeFormat =
          this.reconsileService.getReasonIdVal(reasonDrop);

        this.reasonCode.push(reasonCodeFormat);
      }
    });
    // console.log('reasonCode >>', this.reasonCode);
    // });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;
    this.reasonCode.map((reason: any) => {
      const resonId = reason.split('-')[0];

      if (resonId.toLowerCase().includes(query.toLowerCase())) {
        reasonArr.push(resonId);
      }
    });
    this.filteredReasons = reasonArr;
  }

  onChangeReason(selectedReasonCode: any) {
    // console.log("selectedReasonCode >", selectedReasonCode);
    let extractReasonCode = selectedReasonCode.split('_')[0];
    // console.log('strLen >> ', extractReasonCode);
    this.reasonCodeUnique = extractReasonCode;

    // this.reasonCode.filter((reasonVal: any) => {
    //   let fileterResonStr = reasonVal.split('_')[0];

    //   console.log("reasonVal >>", fileterResonStr);

    //   if (fileterResonStr === extractReasonCode) {
    //      this.reasonCodeUnique =
    //     // this.drivrIdRequest = this.allReasonCode;
    //   }
    // });
  }

  // Driver
  driverIdPayload: any;
  driverDropVal: any;
  getDriver() {
    // this.reconsileService.getDriver().subscribe((drivers: any) => {
    // console.log('driversList >>', drivers);
    this.allDriver = this.ViewDrivers;
    this.ViewDrivers.map((driver: Driver) => {
      if(driver.active){
        if (driver.employeeName != null) {
          this.driverDropVal =
            this.reconsileService.getDriverDropProperVal(driver);
        }
        else {
          this.driverDropVal =
            this.reconsileService.getDriverDropProperVal2(driver);
          }
      }
       this.driverId.push(this.driverDropVal);
      });
    // });
  }

  // filteredDriverFn(event: any) {
  //   let driverArr: any[] = [];
  //   let query = event.query;
  //   this.allDriver = this.ViewDrivers;
  //     this.ViewDrivers.map((driver: Driver) => {
  //       const driverDropVal =
  //         this.reconsileService.getDriverDropProperVal(driver);
  //       // console.log('driverDropVal', driverDropVal);

  //       this.driverId.push(driverDropVal);
  //     });
  //   this.driverId.map((driver: any) => {
  //     const driverIdSeperate = driver.split('-')[0];
  //     if (driverIdSeperate.toLowerCase().includes(query.toLowerCase())) {
  //       driverArr.push(driver);
  //     }
  //   });
  //   this.filteredDriver = driverArr;
  // }

  filteredDriverFn(event: any) {
    let driverArr: any[] = [];
    this.driverId = [];
    let query = event.query;
    this.allDriver = this.ViewDrivers;
    this.ViewDrivers.map((driver: Driver) => {
      if(driver.active) {
        const driverDropVal =
        this.reconsileService.getDriverDropProperVal(driver);
      // console.log('driverDropVal', driverDropVal);

      if (!this.driverId.includes(driverDropVal)) {
        this.driverId.push(driverDropVal);
      }
      }
      
    });
    this.driverId.map((driver: any) => {
      const driverIdSeperate = driver.split('-')[0];
      if (driverIdSeperate.toLowerCase().includes(query.toLowerCase())) {
        driverArr.push(driver);
      }
    });
    this.filteredDriver = driverArr;
  }



  onChangeDriver(selectedDriver: any) {
    this.runsheetState.showLookup = true;
    this.runsheetState.displayNextRunsheetButton = false;
    //  const driverId: any =  this.allDriver.find((driver: Driver) => selectedDriver.indexOf(driver.employeeName) > -1)
    const driverId = this.reconsileService.findDriverId(this.allDriver, selectedDriver);
    this.driverIdPayload = driverId.id;

    const starttime = this.reconcileFormCreateRunsheet.get('starttime')?.value;
    const starttimeTimesatamp = +moment(
      starttime,
      'YYYY-MM-DD[T]HH:mm:ss'
    ).format('x');
    if (starttime) {
      this.runsheetState.displayLookupButton = true;

      const request = {
        driverId: driverId?.id,
        shiftSTartDate: starttimeTimesatamp,
      };

      this.getShiftDetails(request);
    } else {
      this.isLoading = false;
    }

  }

  getShiftDetails(request: any) {
    this.isLoading = true;
    this.reconsileService
      .getShiftDetails(request)
      .subscribe((shiftData: any) => {
        this.isLoading = false;
      });
  }

  getRunseetIdData(runsheetId: any) {
    this.isLoading = true;
    this.reconsileService
      .getViewRunsheetId(runsheetId)
      .subscribe((resRunsheet: ViewRunsheetRunsheetId) => {
        this.isLoading = false;
        this.loadRunsheet();
        this.isNew = resRunsheet.isNew;
        if (this.isNew) {
          this.router.navigate(['reconcile/CreateRunsheet']);
        }
        this.reconsileService.pageTitleSubject.next('View Runsheet');
        this.idRunsheetData = resRunsheet.runsheet;
        this.runsheetState.completed = this.idRunsheetData?.complete;
        this.detailService.runsheetStateConf = this.idRunsheetData;

        this.getShowGrid(this.idRunsheetData);

        this.runsheetStatusFun(this.idRunsheetData);
        this.getPermission(this.idRunsheetData);
        this.fetchPermissions();
        this.editDeliverydateDate=resRunsheet.runsheet
        this.ViewDrivers.map((filterDriver: any) => {
          if (filterDriver.id === resRunsheet.runsheet.driverId) {
            if (filterDriver.employeeName == null) {
              this.selectedDriverId =
                this.reconsileService.getDriverDropProperVal2(filterDriver);
            }
            else {
              // console.log('driverId >>', filterDriver);
              this.selectedDriverId =
                this.reconsileService.getDriverDropProperVal(filterDriver);

            }
          }
        });

        this.runsheetTypeId = resRunsheet.runsheet.runsheetTypeId;
        this.driverIdVal = resRunsheet.runsheet.driverId;
        this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].setValue(
          this.runsheetTypeId
        );

        this.reconsileService.lockRunsheet(runsheetId).subscribe(
          (lockRunsheet: any) => {
            // this.lockStatus = 'Locked';
          },
          (err: any) => {
            this.isLoading = false;
            this.lockStatus = 'Locked';

            const lockErr: ErrorList = err.error.errorList;
            const lockErrDetail: ExceptionInfo =
              err.error.errorList.ExceptionInfos[0];
            this.errFirst = '';
            this.errorHeader2 = lockErr.ErrorMessage;
            this.errorId = lockErrDetail.ErrorId;
            this.errorInner = lockErrDetail.UserErrorDescription;
            this.exceptionTime = lockErr.ExceptionTime;
            const lockUsername =
              lockErrDetail.UserErrorDescription.indexOf('BY ') + 3;
            this.lockUserName =
              lockErrDetail.UserErrorDescription.substring(lockUsername);
            if (lockErrDetail.ContextId === 'INTERNAL') {
              this.errFirst = '500 Internal Server Error';
            }


            this.messageService.add({
              key: 'customToast',
              severity: 'error',
              life: 30000,
            });
          }
        );

        // this.selectedReasonId  = '112_Dhaval';
        this.reasonCode.filter((reasonCode: ReasonLine) => {
          if (reasonCode.id === this.editFormObj.reasonLines[0].id) {
            this.selectedReasonId =
              this.reconsileService.getReasonIdVal(reasonCode);
          }
        });

        this.resaonLength = this.editFormObj.reasonLines.length;
        
        this.editDeliverydateDate = new Date(resRunsheet.runsheet.starttime);
        this.editEndTime = new Date(resRunsheet.runsheet.endtime);
        this.editReturndepotTime = new Date(
          resRunsheet.runsheet.returndepottime
        );
        this.deliveryDateStamp = new Date(resRunsheet.runsheet.deliverydate);    
        this.createdTime = moment(resRunsheet?.runsheet?.created).tz('Australia/Melbourne').format(
          'YYYY-MM-DD HH:mm'
        );

        this.editFormObj.createdby = resRunsheet.runsheet.createdby;
        //odometer
        this.editFormObj.startkm = resRunsheet.runsheet.startkm;
        this.editFormObj.endkm = resRunsheet.runsheet.endkm;
        this.changeOdoApi(this.editFormObj.startkm, this.editFormObj.endkm);
        this.editFormObj.rateId = resRunsheet.runsheet.rateId;
        this.selectedHoldCode = resRunsheet.runsheet.holdcode;
        this.editFormObj.remarks = resRunsheet.runsheet.remarks;
        this.editFormObj.payamt = resRunsheet.runsheet.payamt;
        this.editFormObj.paydesc = resRunsheet.runsheet.paydesc;
        const tmpDate = moment(resRunsheet.runsheet.deliverydate).format(
          'YYYY.MM.DD HH:MM:SS'
        );
        let distance =
          +resRunsheet.runsheet.endkm - Number(resRunsheet.runsheet.startkm);

        if (distance > 500) {
          let message =
            'Truck travel exceeds 500km. SDP to be attached to paperwork. Refer to ops manager if SDP not attached.';
          this.messageService.add({
            severity: 'error',
            summary: '',
            detail: message,
          });
        } else if (distance < 0) {
          this.odoMeterWarning = true;
        }
      });
  }
  currentDriverValue: any = '';
  previousDriverValue: any = '';


  currentFromDateValue: any = '';
  previousFromValue: any = '';

  breakTimeValidation: any;
  datasavedorunsaved: any;
  dirtyFormCheck() {

    this.initialFormValue = _.cloneDeep(this.reconcileFormCreateRunsheet.value);
    this.reconcileFormCreateRunsheet.valueChanges.subscribe((newValue) => {
      this.breakTimeValidation = {
        breakStartTime: newValue.starttime,
        breakEndTime: newValue.endtime
      }
      //  console.log("break time valida",this.breakTimeValidation);
      this.detailService.runsheetBreakTime = this.breakTimeValidation;
      this.previousDriverValue = this.currentDriverValue;
      this.currentDriverValue = newValue.driverId;
      this.changesFormField = this.getChanges(this.previousDriverValue, this.currentDriverValue);
      this.previousFromValue = this.currentFromDateValue;
      this.currentFromDateValue = newValue.starttime;
      this.changesFormField = this.getChanges(this.previousFromValue, this.currentFromDateValue);
      if (this.reconcileFormCreateRunsheet.dirty) {

        this.runsheetStatus = 'Unsaved';
        this.datasavedorunsaved = this.reconcileFormCreateRunsheet.dirty;
      }
      // else {
      //   this.runsheetStatus = 'Saved';
      // }
    });

  }

  runsheetStatusFun(runsheetData: any) {
    if (runsheetData.exported) {
      this.runsheetStatus = 'Exported';
    } else if (runsheetData.complete) {
      this.runsheetStatus = 'Completed';
      this.lockStatus="Locked"
    } else {
      this.runsheetStatus = 'Saved';
    }
  }

  getChanges(previous: any, current: any): any {
    if (previous !== current) {
      this.modifyShow = true;
    }
  }

  getMetaDataJson() {
    this.reconsileService.getMetaDataJson().subscribe((fieldssData: any) => {
      // console.log('FieldsData >', fieldssData);
    });
  }
  getHoldCode() {
    // console.log(this.selectedHoldCode)
    if (this.selectedHoldCode.indexOf('User: ') < 0) {
      this.selectedHoldCode = 'User: ' + this.selectedHoldCode;
    } else if (this.selectedHoldCode === 'User: ') {
      this.selectedHoldCode = '';
    }
  }

  //dropdown type

  reload() {
    window.location.reload();
    const baseUrl = this.router.serializeUrl(
      this.router.createUrlTree(['reconcile/ViewRunsheet'], {
        queryParams: { runsheetId: this.runsheetId },
        queryParamsHandling: 'merge',
      })
    );
    // .then(data => this.reloadCurrentRoute())

    // Open the new tab
    window.open(baseUrl, '');
  }

  getMultiLegData() {
    this.reconsileService._multiLangData.subscribe(
      // (runsheet: RunsheetDetail) => {
      (runsheet: any) => {
        // console.log('RunsheetLine Id  show>> ', runsheet.runsheetDetails.runsheet.id);
        this.isLoading = false;
        if (runsheet) {
          if (runsheet.breakTypeId) {
            this.breakTypeIdData = runsheet.id;
          }
          // this.runsheetLineId = runsheet[0].id ||  runsheet[0]?.firstRunsheetLine?.id;
          this.runsheetLineId =  runsheet?.runsheetDetails?.runsheet?.id;
          this.selectedRunSheetLinedata =  runsheet?.runsheetDetails?.runsheet?.runsheetLines;
          
          const runsheetLastChildArr = runsheet[runsheet.length - 1];
          this.bulkeditIdsData.push(runsheetLastChildArr);

          this.isSelectedRow = this.runsheetService.isSelectionBulk(
            this.bulkeditIdsData
          );
          if (this.isSelectedRow) {
            this.bulkEditMode = true;
          }

          // this.breakLineId = runsheet

          // this.selectedItemType = "runsheet-line";
        }
      },
      (err: any) => {
        if (err) {

          this.isLoading = false;
        }
      }
    );
  }
  deleteAction: any = false;

  confirmDelete() {
    this.isLoading = true;
    this.lockRunsheet(+this.runsheetId);
    this.headerRunsheet = 'Are you sure you want to delete?';
    const body = `You can not undo this action.`;
    this.confirmationService.confirm({
      message: body,
      header: 'Are you sure you want to delete?',
      // icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.reconsileService
          .deleteRunsheet(this.runsheetId)
          .subscribe((res) => {
            this.isLoading = false;
            this.router.navigate(['reconcile/CreateRunsheet']);
            this.reconsileService.pageTitleSubject.next('Create Runsheet');
          });
        this.isLoading = false;
        this.showGrid = false;
        this.runsheetState.showTime = false;
        this.runsheetState.showGrid = false;
        this.runsheetState.displayLookupButton = false;
        this.deleteAction = true;
        this.runsheetState.displayNextRunsheetButton = false;
        // this.isNew = true;
        this.runsheetStatus = '';
        this.reconcileFormCreateRunsheet.reset();
        this.reconcileFormCreateRunsheet.patchValue({
          runsheetTypeId: this.afterDeleteselectedRunsheetTypeId
        });
        this.editDeliverydateDate = new Date();

      },
      reject: () => {
        this.isLoading = false;
        // subscriber.next(null);
        // subscriber.complete();
      },
    });
  }

  backoutRunsheet() {
    this.isLoading = true;

    this.reconsileService.backoutRunsheet(this.runsheetId)
      .subscribe(
        (res) => {
          this.isLoading = false;
          if(res.runsheet?.complete) {
            this.runsheetStatus = 'Completed'
            this.lockStatus ='Locked'

          } else if(res.runsheet?.complete==false && res.runsheet?.exported==false) {
            this.runsheetStatus = 'Saved'
            this.lockStatus ='Open'
            this.runsheetState.completed = res.runsheet?.complete;
            this.reconcileFormCreateRunsheet.controls['payamt'].setValue('')
            this.fetchPermissions()
          }

        },
        (err) => {
          this.isLoading = false;
          const userDescriptionErr = `Runsheet backout failed: [Runsheet ${this.runsheetId} backout failed because it has invoice lines linked to an invoice. You must delete the invoice before you can backout the runsheet.]`


          this.messageService.add({
            severity: 'error',
            summary: userDescriptionErr,
            detail: '500 Internal Server Error',
            life: 3000,
            closable: true
          });

          // this.handleErrorResponse(err);
        }
      );
  }


  public handleErrorResponse(err: any): void {
    this.isLoading = false;
    if (err === "Precondition Failed") {
      this.messageService.add({
        severity: 'error',
        summary: this.errorHeader2,
        detail: "Precondition Failed",
      });
    }
    const lockErr: ErrorList = err.error.errorList;
    const lockErrDetail: ExceptionInfo = lockErr.ExceptionInfos[0];
    this.errFirst = '';
    this.errorHeader2 = lockErr.ErrorMessage;
    this.errorInner = lockErrDetail.UserErrorDescription;
    this.errorId = lockErrDetail.ErrorId;
    this.exceptionTime = lockErr.ExceptionTime;
    this.messageService.add({
      severity: 'error',
      summary: this.errorHeader2,
      detail: this.errorInner,
    });
  }

  completeRunsheet() {
    this.isLoading = true;
    this.headerRunsheet = 'Save Runsheet ?';

    this.confirmationService.confirm({
      message: "The runsheet is not valid, some data is missing or incorrect. Continue saving runsheet anyway?",
      header: "Save Runsheet?",
      // icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.reconsileService.completeRunsheet(this.runsheetId)
          //         .pipe(
          //           catchError((error) => {
          //             // Handle the error here
          //             let errormessage = error.error.errorList.ErrorMessage;
          //             let errorurl=  error.url;
          //             let errortime= error.error.errorList.ExceptionTime;
          //             let multiLineString = `${errormessage}.
          // URL: ${errorurl}.
          // Time: ${errortime}.`;

          //             this.messageService.add({
          //               severity: 'error',
          //               summary: error.status,
          //               detail:multiLineString,
          //               life: 20000

          //             });
          //             // You can also re-throw the error if needed
          //             return throwError(error);
          //           })
          //         )
          .subscribe(
            (res) => {
              this.isLoading = false;
              // this.messageService.add({
              //   severity: 'success',
              //   summary: '',
              //   detail: 'Runsheet Completed',
              // });
              this.reconsileService.runsheetProcessing(this.runsheetId).subscribe((result) => {
                if (result) {
                  this.runsheetFormService.emitRunseetSubsCribeData(
                    result?.runsheetDetails?.runsheet?.runsheetLines
                  );
                  this.selectedHoldCode = result?.runsheetDetails?.runsheet?.holdcode;
                  // this.reconsileService._multiLangData.next(result)
                  // this.editFormObj.rateId = result?.runsheetDetails?.runsheet?.rateId;
                  // this.editFormObj.payamt = result?.runsheetDetails?.runsheet?.payamt;
                  // this.editFormObj.paydesc = result?.runsheetDetails?.runsheet?.paydesc;
                  // this.ratedRunsheet = true;
                }
              });
            }
            , (err: any) => {
              this.handleErrorResponse(err);
            }
          );
      },
      reject: () => {
        this.isLoading = false;
      },
    });


  }

  // completeRunsheet(): void {
  //   this.isLoading = true;
  //   this.validate(false, false).subscribe({
  //     next: () => {
  //       // this.updateWritability(false);
  //       this.runsheetFormService
  //         .completeRunsheetPOST(this.runsheetId)
  //         .subscribe({
  //           next: (response) => {
  //             // this.runsheetPoller(this.runsheetId).subscribe({
  //             //   complete: () => this.finalizeCompletion(),
  //             // });
  //             console.log("response >>", response);

  //           },
  //           error: () => {
  //             this.finalizeCompletion();
  //             const body = `Sorry, you can not complete runsheet ${this.runsheetId} because runsheet completion has been disabled.`;
  //             this.confirmationService.confirm({
  //               message: body,
  //               header: 'Runsheet Completion',
  //               icon: 'pi pi-exclamation-triangle',
  //               accept: () => {
  //                 console.log('Run Service not accept');
  //               },
  //               reject: () => {
  //                 this.isLoading = false;
  //                 // subscriber.next(null);
  //                 // subscriber.complete();
  //               },
  //             });
  //           },
  //         });
  //     },
  //     error: (err: any) => {
  //       // Handle validation error
  //     },
  //   });
  // }

  finalizeCompletion() {
    this.isLoading = false;
  }

  validate(toCheckDemurrage: boolean, toByPassValidation: boolean, popupContent?: any): any {
    this.isLoading = true;

    // Your existing logic for creating 'checks' goes here...
    // Create a copy and perform cleanup
    const runsheetCopy = this.idRunsheetData;
    // this.runsheetFormService.saveCleanup(this.runsheetLinesFormObj, runsheetCopy);

    // Replace $q.resolve with of() to create an observable
    const checks = [
      of(this.runsheetFormService.checkInvalidRunsheetKm(runsheetCopy)),
      of(
        this.runsheetFormService.checkInvalidServiceUnit(
          runsheetCopy,
          this.ViewServiceTypes
        )
      ),
      of(
        this.runsheetFormService.checkInvalidResources(
          runsheetCopy,
          this.ViewServiceTypes
        )
      ),
    ];

    // if (this.refDataService.getUserOptionValue('Amcor.DuplicateCheck')) {
    const validateLoadNoMsg = this.runsheetFormService.validateRunsheetLines(
      runsheetCopy.runsheetLines
    );
    checks.push(of(validateLoadNoMsg));
    // }

    combineLatest(checks)
      .pipe(
        switchMap((results: any[]): Observable<any> => {
          const hasErrors = results.some((result) => !!result);

          if (hasErrors && !toByPassValidation) {
            // let joinedMsg = this.constructValidationMessage(results);
            // this.headerRunsheet = 'Runsheet Completion';
            // let joinedMsg = `Sorry, you can not complete runsheet Runsheet ${this.runsheetId} because runsheet completion has been disabled.`;

            this.headerRunsheet = popupContent.header;
            //  let joinedMsg = popupContent.body;
            return new Observable((subscriber) => {
              this.compleBtnHidePop = true;
              this.confirmationService.confirm({
                message: popupContent.body,
                header: popupContent.header,
                // icon: 'pi pi-exclamation-triangle',
                accept: () => {
                  subscriber.next(this.saveRunsheet(this.idRunsheetData));
                  subscriber.complete();
                },
                reject: () => {
                  this.isLoading = false;
                  subscriber.next(null);
                  subscriber.complete();
                },
              });
            });
          } else {
            return of(this.saveRunsheet(this.idRunsheetData));
          }
        }),
        catchError((error: any) => {
          this.isLoading = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'An error occurred',
          });
          return throwError(() => new Error(error));
        })
      )
      .subscribe({
        next: (result) => {
          this.isLoading = false;
          // Handle result if needed
        },
        error: (error) => {
          this.isLoading = false;
          // Handle error if needed
        },
      });
  }

  /**
   * Check validation of required fields
   * @param runsheet
   */
  checkInvalidResources(runsheetCopy: any) {
    return (runsheetCopy.data.runsheet.runsheetLines || []).some(
      (runsheetLine: any) => {
        // return RunsheetLineService.validateRunsheetLineResources(runsheetLine);
      }
    );
  }

  saveRunsheet(runsheet: any): void {
    this.runsheetFormService
      .updateRunsheetPUT(runsheet)
      // .pipe(
      //   switchMap((response) => {
      //     return of(this.updateRunsheetPUTSuccess(response));
      //   }),
      //   tap(() => {
      //     // Assuming you have a form reference, mark it as pristine after saving
      //     // This replaces $scope.RunsheetForm.$setPristine();
      //     // this.runsheetFormService.markAsPristine();
      //   })
      // )
      .subscribe((res) => {
        if (res) {
          this.runsheetFormService.emitRunseetSubsCribeData(
            res
          );
          this.editFormObj.rateId = res?.rateId;
          this.editFormObj.payamt = res?.payamt;
          this.editFormObj.paydesc = res?.paydesc;
          this.reconsileService.setSelectedItemType('detail-page');
          this.ratedRunsheet = false;
          if(res?.complete) {
            this.runsheetStatus = 'Completed'
            this.lockStatus="Locked"
          } else {
            this.runsheetStatus = 'Open'
            this.runsheetState.completed = res?.complete;
          }
        }
      });
  }

  runsheetPoller(runsheetId: string): Observable<any> {
    return interval(5000).pipe(
      tap(() => {
        this.pollerCount++;
      }),
      // takeWhile((_value: number, index: number) => index < this.maxPollerCount),
      switchMap((): Observable<any> => {
        return this.runsheetFormService.runsheetProcessing(runsheetId);
      }),
      switchMap((response) => {
        if (
          response.data.status === 'READY_FOR_UPDATES' ||
          response.data.status === 'COMPLETED'
        ) {
          // Do something with response.data.runsheetDetails
          if (response.data.status === 'COMPLETED') {
            // If the runsheet processing is completed, stop the polling
            return this.completeRunsheetProcessing(
              response.runsheetDetails
            );
          }
        }
        return new Observable((observer) =>
          observer.error(
            new Error('Runsheet status not ready for updates or not completed')
          )
        );
      }),
      catchError((error) => {
        // Handle error scenario, stop the polling
        return new Observable((observer) => observer.error(error));
      }),
      finalize(() => {
        // Cleanup logic if needed, stop the polling
        this.pollerCount = 0;
      })
    );
  }

  private completeRunsheetProcessing(runsheetDetails: any): Observable<any> {
    // Implement the logic that should occur when the polling is successful
    return of(runsheetDetails); // Replace with actual logic
  }

  private updateRunsheetPUTSuccess(response: any): any {
    // Handle the successful PUT response
    // Perform any additional operations or return the response
  }
  rateRunsheet() {
    // this.reconsileService.rateRunsheet(this.runsheetId).subscribe((res) => {
    //   console.log('rate runsheet', res);
    // });
    this.headerRunsheet = 'Save Runsheet ?';
    this.confirmationService.confirm({
      message: "The runsheet is not valid, some data is missing or incorrect. Continue saving runsheet anyway?",
      header: "Save Runsheet?",
      // icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.reconcileFormCreateRunsheetSubmit();
        this.reconsileService.rateRunsheet(this.runsheetId)
          .subscribe(
            (res) => {
              this.isLoading = false;
              this.reconsileService.runsheetProcessing(this.runsheetId).subscribe((result) => {
                if (result) {
                  this.runsheetFormService.emitRunseetSubsCribeData(
                    result?.runsheetDetails?.runsheet
                  );
                  this.reconsileService._multiLangData.next(result)
                  this.editFormObj.rateId = result?.runsheetDetails?.runsheet?.rateId;
                  this.editFormObj.payamt = result?.runsheetDetails?.runsheet?.payamt;
                  this.editFormObj.paydesc = result?.runsheetDetails?.runsheet?.paydesc;
                  this.selectedHoldCode = result?.runsheetDetails?.runsheet?.holdcode;
                  this.ratedRunsheet = true;
                  this.idRunsheetData= result?.runsheetDetails?.runsheet
                  this.idRunsheetData.runsheetLines.forEach((runsheetLine: any) => {
                    Object.assign(runsheetLine, {
                      tripseq: typeof runsheetLine?.tripseq === 'string' && runsheetLine?.tripseq.split('.').length > 0 ? Number(runsheetLine?.tripseq.split('.')[1]) : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
                    });
                  });
                  
                }
                if(result?.status === "READY_FOR_UPDATES") {
                  this.runsheetStatus = 'Saved';
                } else {
                  this.runsheetStatus = 'Unsaved';
                }
              });
              // this.messageService.add({
              //   severity: 'success',
              //   summary: '',
              //   detail: 'Rate Runsheet Completed',
              // });
            }
            , (err: any) => {
              this.handleErrorResponse(err);
            }
          );
      },
      reject: () => {
        this.isLoading = false;
      },
    });

  }

  checkDemurrage(runsheetLineAll: any) {
    this.reconsileService.checkDemurrage(runsheetLineAll).subscribe((res) => {
    });
  }

  clearRunsheetRate() {
    const popupContent: any = {
      header: 'Save Runsheet',
      body: 'The runsheet is not valid, some data is missing or incorrect. Continue saving runsheet anyway?'
    }
    const runsheetRate = this.idRunsheetData;
    Object.assign(runsheetRate, {
      rateId: null,
      payamt: null,
      paydesc: null,
      calcpaybyhour: false,
      calcpaybyload: false,
      payhourly: null,
      payincentive: null,
      payallowance: null,
      holdcode: null,
    });
    this.selectedHoldCode=''
    this.rated = false;

    this.idRunsheetData.runsheetLines.forEach((runsheetLine: any) => {
      Object.assign(runsheetLine, {
        rateId: null,
        payamt: null,
        paydesc: null,
        payestimated: null,
        servicehours: null,
        lineServiceTO: { ...runsheetLine.lineServiceTO, clearCharge: true },
        tripseq: typeof runsheetLine?.tripseq === 'string' && runsheetLine?.tripseq.split('.').length > 0 ? Number(runsheetLine?.tripseq.split('.')[1]) : null, // ?.split(' ').length > 0 ? row?.qty1.split(' ')[0] : null,
      });
    });

    this.validate(false, false, popupContent);
  }

  onClearType() {
    this.reconcileFormCreateRunsheet.get('runsheetTypeId')?.setValue('');
  }

  onClearDriverType() {
    this.reconcileFormCreateRunsheet.get('driverId')?.setValue('');
    this.runsheetState.showLookup = false;
    //this.runsheetState.displayLookupButton=false;
  }

  checkingsavedornot: boolean = false;
  hasUnsavedChanges(): boolean {
    if (this.datasavedorunsaved == true && this.runsheetStatus == 'Unsaved') {
     return true
    } else {
     return false
    }
   
  }
  nextRunsheet() {
    this.isChange = false;
    if (this.datasavedorunsaved == true && this.runsheetStatus == 'Unsaved') {
      const dialogRef = this.dialog.open(
        ConfirmingsavedornotsaveddialogComponent
      );
      dialogRef.afterClosed().subscribe((result) => {
        if (result === 'discard') {
          this.isNew = true;
          this.reconcileFormCreateRunsheet.reset();
          this.runsheetState.showLookup = false;
          this.runsheetState.displayLookupButton = false;
          this.runsheetState.displayNextRunsheetButton = false;
          this.runsheetState.showGrid = false;
          this.runsheetState.showTime = false;
          this.deleteAction = false;
          this.runsheetId = null;
          this.reconsileService.pageTitleSubject.next('Create Runsheet');
          this.router.navigate(['reconcile/CreateRunsheet']);
        } else if (result === 'save') {
          this.onFormSubmit();
          this.isNew = true;
          this.reconcileFormCreateRunsheet.reset();
          this.runsheetState.showLookup = false;
          this.runsheetState.displayLookupButton = false;
          this.runsheetState.displayNextRunsheetButton = false;
          this.runsheetState.showGrid = false;
          this.runsheetState.showTime = false;
          this.deleteAction = false;
          this.runsheetId = null;
        } else if (result === 'cancel') {
          dialogRef.close();
        }
      });
    } else {
      this.isNew = true;
      this.reconcileFormCreateRunsheet.reset();
      this.runsheetState.showLookup = true;
      this.runsheetState.displayLookupButton = false;
      this.runsheetState.displayNextRunsheetButton = false;
      this.runsheetState.showGrid = false;
      this.runsheetState.showTime = false;
      this.deleteAction = false;
      
      //this.runsheetTypeId = resRunsheet.runsheet.runsheetTypeId;
       // this.driverIdVal = resRunsheet.runsheet.driverId;
        this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].setValue(
          this.idRunsheetData.runsheetTypeId
        );
        // this.selectedDriverId =
        //         this.reconsileService.getDriverDropProperVal(this.idRunsheetData.driverId);
        // this.reconcileFormCreateRunsheet.controls['driverId'].setValue(
        //   this.selectedDriverId
        // );
        //this.getDriver();
        let today = new Date();
        this.editDeliverydateDate = new Date(today);
        this.editDeliverydateDate.setDate(today.getDate()-1)
        this.editDeliverydateDate.setHours(0);
        this.editDeliverydateDate.setMinutes(0);
      this.reconsileService.pageTitleSubject.next('Create Runsheet');
      this.router.navigate(['reconcile/CreateRunsheet']);
    }
  }
  checkAndShowTooltip(tooltip: Tooltip) {
    if (!this.selectedDriverId) {
      tooltip.activate(); // Manually activate the tooltip if the condition is met
    }
  }

  reasonDetail() {
    this.reconsileService.selectedItemType.next('reason-lines');
    this.runsheetFormService.sendReasonApiData(this.reasonData);
  }

  listenSelectitemType() {
    this.reconsileService.selectedItemType.subscribe((selectedType: any) => {
      this.selectedDetailType = selectedType;
    });
  }
  dateTimeJone(timeFormat: any) {
    // console.log('timeFormat > ', timeFormat);

    return this.timeService.dateTime(timeFormat);
  }

  runsheetDateTime(selectTime: any) {
    return +moment(selectTime, 'YYYY-MM-DD[T]HH:mm:ss').format('x').valueOf();
  }

  fetchPermissions() {
    if (this.canWrite) {
      this.reconcileFormCreateRunsheet.controls['returndepottime'].disable();
      this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].disable();

      this.showLookup = !this.canWrite;
      if (this.canWrite && this.runsheetState.completed) {
        this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].disable();
        this.reconcileFormCreateRunsheet.controls['driverId'].disable();
        this.reconcileFormCreateRunsheet.controls['starttime'].disable();
        this.reconcileFormCreateRunsheet.controls['endtime'].disable();
      }
      else{
        this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].enable();
        this.reconcileFormCreateRunsheet.controls['driverId'].enable();
        this.reconcileFormCreateRunsheet.controls['starttime'].enable();
        this.reconcileFormCreateRunsheet.controls['endtime'].enable();
        this.reconcileFormCreateRunsheet.controls['returndepottime'].enable();
        this.reconcileFormCreateRunsheet.controls['holdcode'].enable();
        this.reconcileFormCreateRunsheet.controls['remarks'].enable();
        this.reconcileFormCreateRunsheet.controls['reasonId'].enable();
        this.reconcileFormCreateRunsheet.controls['startkm'].enable();
        this.reconcileFormCreateRunsheet.controls['endkm'].enable();
        this.reconcileFormCreateRunsheet.controls['payamt'].enable();
        this.reconcileFormCreateRunsheet.controls['reasonId'].enable();

      }
    } else {
      this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].enable();
      this.reconcileFormCreateRunsheet.controls['driverId'].enable();
      this.reconcileFormCreateRunsheet.controls['starttime'].enable();
      this.reconcileFormCreateRunsheet.controls['endtime'].enable();
      this.reconcileFormCreateRunsheet.controls['returndepottime'].enable();
    }
    if (this.runsheetState.completed) {
      this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].disable();
      this.reconcileFormCreateRunsheet.controls['driverId'].disable();
      this.reconcileFormCreateRunsheet.controls['starttime'].disable();
      this.reconcileFormCreateRunsheet.controls['endtime'].disable();
      this.reconcileFormCreateRunsheet.controls['returndepottime'].disable();
      this.reconcileFormCreateRunsheet.controls['holdcode'].disable();
      this.reconcileFormCreateRunsheet.controls['remarks'].disable();
      this.reconcileFormCreateRunsheet.controls['reasonId'].disable();
      this.reconcileFormCreateRunsheet.controls['startkm'].disable();
      this.reconcileFormCreateRunsheet.controls['endkm'].disable();
      this.reconcileFormCreateRunsheet.controls['payamt'].disable();
      this.reconcileFormCreateRunsheet.controls['reasonId'].disable();
      this.runsheetState.displayLookupButton = false;
    }


    this.runsheetFormService.permissionFields.subscribe((permissions: any) => {
      // console.log("Permisions>> ", permission);
      // const permisionMatch = permissions.map((per: any) =>
      //   per.permissions.find((perm: any) => perm.id === 'Runsheet2')
      // );
      // this.canWrite = permisionMatch[0].write;
      // if (!this.canWrite) {
      //   this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].disable();
      //   this.reconcileFormCreateRunsheet.controls['driverId'].disable();
      //   this.reconcileFormCreateRunsheet.controls['starttime'].disable();
      //   this.reconcileFormCreateRunsheet.controls['endtime'].disable();
      //   this.reconcileFormCreateRunsheet.controls['returndepottime'].disable();
      //   this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].disable();
      //   this.showLookup = !this.canWrite;
      // } else {
      //   this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].enable();
      //   this.reconcileFormCreateRunsheet.controls['driverId'].enable();
      //   this.reconcileFormCreateRunsheet.controls['starttime'].enable();
      //   this.reconcileFormCreateRunsheet.controls['endtime'].enable();
      //   this.reconcileFormCreateRunsheet.controls['returndepottime'].enable();
      //   this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].enable();
      // }
      // console.log('permisionMatch >>', this.canWrite);
    });
  }

  // Enable/disable form control
  public toggleFormState() {
    // this.formEnabled = !this.formEnabled;
    const state = this.formEnabled ? 'disable' : 'enable';

    Object.keys(this.reconcileFormCreateRunsheet.controls).forEach(
      (controlName) => {
        this.formEnabled.controls[controlName][state](); // disables/enables each form control based on 'this.formDisabled'
      }
    );
  }

  updateWritability(allowWrite: any) {
    this.runsheetState.formEnabled = this.canWrite && allowWrite;
    this.runsheetState.locked = this.canWrite && !allowWrite;
  }

  validateInputStart() {
    const control = this.reconcileFormCreateRunsheet.get('startkm');
    const controlEndKm = this.reconcileFormCreateRunsheet.get('endkm');
    if (control && typeof control.value === 'string') {
      const value = +control.value; // Convert to a number using unary plus
      if (value < 0) {
        control.setValue('');
      } else if (controlEndKm && typeof controlEndKm.value === 'string') {
        if (controlEndKm.value === '') {
          this.runsheetState.StartEndKMSwappedCondition = false;
        }
      }
    }
  }
  distanceOdo: any;
  startKmLess: boolean = false;
  warningOdometer: boolean = false;
  changeOdo(event: any) {
    let endKm = Number(event.target.value); // consistent type conversion
    let startKmControl = this.reconcileFormCreateRunsheet.get('startkm')?.value;
    const control = this.reconcileFormCreateRunsheet.get('endkm');
    if (control && typeof control.value === 'string') {
      const value = +control.value; // Convert to a number using unary plus
      if (value < 0) {
        control.setValue('');
      } else if (startKmControl) {
        this.runsheetState.StartEndKMSwappedCondition = true;
        let startKm = Number(startKmControl); // assuming startkm is a number
        let distance = endKm - startKm;
  
        if (distance > 500) { 
          this.warningOdometer = true;
          this.runsheetState.StartEndKMSwappedCondition = true;
          this.odoMeterWarning = true;
          this.distanceOdo = distance;
          this.startKmLess = false;
          let message =
            'Truck travel exceeds 500km. SDP to be attached to paperwork. Refer to ops manager if SDP not attached.';
          this.messageService.add({
            severity: 'error',
            summary: '',
            detail: message,
          });
        } else if (distance < 0) {
          this.startKmLess = true;
          this.runsheetState.StartEndKMSwappedCondition = false;
          this.startKmLess = true;
          this.distanceOdo = distance;
        } else {
          // this.odoMeterWarning = false; // reset the warning if the distance is valid
          this.startKmLess = false;
          this.distanceOdo = distance;
          this.warningOdometer = false;
        }
      } else {
        console.error('startkm control is not found in the form group');
      }
    }


  }

  changeOdoApi(startkm: any, endKmVal: any) {
    let endKm =  +endKmVal;// consistent type conversion
    let startKmControl = +startkm;
    const control = this.reconcileFormCreateRunsheet.get('endkm');

    // let distance = endKm - startKmControl;
    // console.log("distance api",distance);
    
    // if (control && typeof control.value === 'string') {
      // const value = +control.value; // Convert to a number using unary plus
      // if (value < 0) {
      //   control.setValue('');
      // } else 
      if (startKmControl) {
        this.runsheetState.StartEndKMSwappedCondition = true;
        let startKm = Number(startKmControl); // assuming startkm is a number
        let distance = endKm - startKm;
  
        if (distance > 500) { 
          this.warningOdometer = true;
          this.runsheetState.StartEndKMSwappedCondition = true;
          this.odoMeterWarning = true;
          this.distanceOdo = distance;
          this.startKmLess = false;
          let message =
            'Truck travel exceeds 500km. SDP to be attached to paperwork. Refer to ops manager if SDP not attached.';
          this.messageService.add({
            severity: 'error',
            summary: '',
            detail: message,
          });
        } else if (distance < 0) {
          this.startKmLess = true;
          this.runsheetState.StartEndKMSwappedCondition = false;
          this.startKmLess = true;
          this.distanceOdo = distance;
        } else {
          // this.odoMeterWarning = false; // reset the warning if the distance is valid
          this.startKmLess = false;
          this.distanceOdo = distance;
          this.warningOdometer = false;
        }
      } else {
        console.error('startkm control is not found in the form group');
      }
    // }
    
    
  }
  showConfirm() {
    this.confirmationService.confirm({
      message:
        'The runsheet is not valid, some data is missing or incorrect. Continue saving runsheet anyway?',
      accept: () => {
        // Action to execute when confirmed
        this.onConfirm();
      },
      reject: () => {
        // Action to execute when rejected
        this.onReject();
      },
    });
  }

  onConfirm() {
    // Handle confirmation
    this.onFormSubmit();
  }

  onReject() {
    // Handle rejection
  }

  showGrid: any;
  getShowGrid(runsheet: any) {
    this.showGrid = this.runsheetFormService.showGrid(runsheet);
  }
  renewInterval: any = null;

  daysDifference: any;
  remainingHours: any;
  remainingMinutes: any;
  datesbreakform: any;

  calculateDateDifference() {
    const starttime = this.editDeliverydateDate;
    const endtime = this.editEndTime;

    // const fromDate = new Date(this.editDeliverydateDate); // Assuming editDeliverydateDate is already a valid Date object
    // fromDate.setHours(fromDate.getHours() + 8); // Add 8 hours to the "From" date
    // this.editEndTime = fromDate;
    // this.editReturndepotTime = fromDate;
    // Calculate difference in milliseconds
    const differenceInMilliseconds = Math.abs(endtime - starttime);

    // Calculate days, hours, minutes, and milliseconds
    this.daysDifference = Math.floor(differenceInMilliseconds / (1000 * 3600 * 24));
    this.remainingHours = Math.floor((differenceInMilliseconds % (1000 * 3600 * 24)) / (1000 * 3600));
    this.remainingMinutes = Math.floor((differenceInMilliseconds % (1000 * 3600)) / (1000 * 60));
    // this.remainingMilliseconds = differenceInMilliseconds % (1000 * 60);           

    if (this.remainingMinutes == null) {
      this.remainingMinutes = 0;
    }

    this.datesbreakform = {
      fromdate: this.editDeliverydateDate,
      todate: this.editEndTime
    }
    this.detailService.startandenddate = this.datesbreakform;

  }

  calculateToandReturn() {
    if(this.isChange) {
    const fromDate = new Date(this.editDeliverydateDate); // Assuming editDeliverydateDate is already a valid Date object
    fromDate.setHours(fromDate.getHours() + 8); // Add 8 hours to the "From" date
    this.editEndTime = fromDate;
    this.editReturndepotTime = fromDate;
    }
    this.calculateDateDifference();
  }

  calculateReturnDate() {
    //if(this.isChange) {
    this.editReturndepotTime = this.editEndTime;
   // }
    this.calculateDateDifference();
  }


  lookup(): void {
    // this.resetUrl();
    // this.reconcileFormCreateRunsheet.reset()
    this.isLoading = true;
    if (this.showGrid) {
      this.runsheetService.unlockRunsheet(this.runsheetId);
    }

    // this.updateWritability(true);
    // this.runsheet.locked = false;
    this.runsheetState.deliveryDateStamp =
      this.reconcileFormCreateRunsheet.controls['starttime'].value;
    // if (
    //   !this.runsheetFormService.isReadyToLookup(
    //     this.idRunsheetData,
    //     this.runsheetState.deliveryDateStamp
    //   )
    // ) {
    //   return;
    // }
    if (this.runsheetState.deliveryDateStamp) {
      const formRunsheet = this.reconcileFormCreateRunsheet.value;

      this.runsheetState.runsheetTypeId =
        this.reconcileFormCreateRunsheet.controls['runsheetTypeId'].value;

      this.runsheetState.enddateStamp =
        this.reconcileFormCreateRunsheet.controls['endtime'].value;

      this.runsheetState.displayNextRunsheetButton = true;

      let lookupDate: any = moment(this.runsheetState.deliveryDateStamp).clone();
      let toDate: any = moment(this.runsheetState.enddateStamp).clone();
      // const driverIdCrea = Number(formRunsheet.driverId?.split('-')[0]);
      const driverIdCrea = this.driverIdPayload;

      let json = {
        driverId: driverIdCrea,
        type: this.runsheetState.runsheetTypeId,
        from: this.timezoneService.unLocalize(lookupDate.toDate()),
        to: this.timezoneService.unLocalize(toDate.toDate()),
        shiftId: this.runsheetState.shiftId || null,
      };


      this.runsheetService.getRunsheetLookup(json).subscribe(
        (response) => {
          // Handle response
          // Convert then-chains into RxJS observables
          this.isLoading = false;
          this.isNew = false;
          this.isChange = true;
          this.runsheetState.displayNextRunsheetButton = true;
          this.runsheetState.displayLookupButton = false;
          this.runsheetId = response?.runsheet?.id;
          this.addServiceByService.runsheetIdSeriviceBy = response?.runsheet?.id;
          this.detailService.runseetLookupApidata = response;
          this.editFormObj.createdby = response?.runsheet?.createdby;
          this.createdTime = moment(response?.runsheet?.created).tz('Australia/Melbourne').format(
            'YYYY-MM-DD HH:mm'
          );

          if (this.runsheetId) {
            this.runsheetState.showTime = true;
            if (!this.editEndTime) {
              const fromDate = new Date(this.editDeliverydateDate); // Assuming editDeliverydateDate is already a valid Date object
              fromDate.setHours(fromDate.getHours() + 8); // Add 8 hours to the "From" date
              this.editEndTime = fromDate; // Set "To" date to "From" date plus 8 hours            
            }
            this.calculateDateDifference();
            this.editReturndepotTime = this.editEndTime;
            this.runsheetState.showGrid = true;
            this.idRunsheetData = response.runsheet;
            this.lockRunsheet(+this.runsheetId);
            this.renewInterval = setInterval(() => {
              this.renewLocks();
            }, 5000);
            this.reconcileFormCreateRunsheet.markAsPristine();
            this.runsheetStatus = 'Saved';
            this.modifyShow = false
            this.isFormEnaabled = true;
            this.deleteAction = false;
          }
        },
        (error) => {
          // Handle error
          this.runsheetState.displayLookupButton = true;

          this.isLoading = false;
          this.modifyShow = false
          this.isFormEnaabled = true;

          this.messageService.add({
            severity: 'error',
            summary: error.statusText,
            detail: error.message,
          });

          //   if (error?.errorList?.ExceptionInfos[0]?.ContextId === 'LockService') {
          //     var bindActiveUserName = error.errorList.ExceptionInfos[0].UserErrorDescription.indexOf('BY ') + 3;
          //     this.lockUserName = error.errorList.ExceptionInfos[0].UserErrorDescription.substring(bindActiveUserName);
          //     // $scope.updateWritability(false);
          //     this.handleErrorResponse(error)

          // }
        }
      );
    } else {
      this.isLoading = false;
      return
    }


    // Other logic
  }
  rated: any;
  isComponentAlive = true; // Used for unsubscribing from observables when the component is destroyed
  lockRunsheet(runsheetId: number) {
    //this.checkAutofill(runsheetId);
    this.runsheetService.lockRunsheet(runsheetId).subscribe({
      next: () => {
        this.checkAutofill()
        this.rated = this.idRunsheetData?.payamt ? true : false;
        // if (this.devUserOptions.AutoFillRunsheets && this.isNewRunsheet) {
        //   this.checkAutofill(this.runsheetData.runsheet);
        // }
        // this.checkAutofill(this.idRunsheetData.runsheet);

        // if (this.idRunsheetData.isNew) {
        //   this.checkAutofill(this.idRunsheetData.runsheet);
        // }

        // Renew locksheet every 2 mins
        interval(120000)
          .pipe
          // takeWhile(() => this.isComponentAlive)
          ()
          .subscribe(() => {
            this.reconsileService.renewLocks(this.runsheetId);
          });
        //this.checkAutofill(this.idRunsheetData.runsheet);

        // this.setRunsheetFormPristine();
        // if (this.runsheetData.runsheet.complete) {
        //   this.updateWritability(false);
        // }

        this.runsheetErrors(this.idRunsheetData.runsheet.shiftId);

      },
      error: (response) => {
        if (response.errorList.ExceptionInfos[0].ContextId === 'LockService') {
          const bindActiveUserName =
            response.errorList.ExceptionInfos[0].UserErrorDescription.indexOf(
              'BY '
            ) + 3;
          this.lockUserName =
            response.errorList.ExceptionInfos[0].UserErrorDescription.substring(
              bindActiveUserName
            );
          // this.updateWritability(false);
        }
      },
    });
  }

  checkAutofill() {
    this.runsheetService.checkAutofill(this.idRunsheetData).subscribe((res) => {
      if (res) {
        if (res) {
          this.displayStyle = "block";
          this.autoFillRes = res;
          // this.runsheetAutofillModalService
          //   .show(res, this.idRunsheetData)
          //   .subscribe({
          //     next: (autoFillResult: any) => {
          //       if (autoFillResult.filled) {
          //         // Assuming there's a method to mark the form as dirty
          //         // this.markRunsheetFormDirty();
          //         // Emit event using Angular's EventEmitter
          //         // this.emitRunsheetUpdateEvent(runsheet);
          //       }
          //     },
          //   });
        }

      }
    })
    // this.runsheetService.checkAutofill(runsheet).subscribe({
    //   next: (autofillResponse) => {
    //     if (autofillResponse.data) {
    //       this.runsheetAutofillModalService
    //         .show(autofillResponse.data, runsheet)
    //         .subscribe({
    //           next: (autoFillResult: any) => {
    //             if (autoFillResult.filled) {
    //               // Assuming there's a method to mark the form as dirty
    //               // this.markRunsheetFormDirty();
    //               // Emit event using Angular's EventEmitter
    //               // this.emitRunsheetUpdateEvent(runsheet);
    //             }
    //           },
    //         });
    //     }
    //   },
    // });
  }

  autoFill() {
    this.runsheetService.autoFill(this.idRunsheetData, false).subscribe((res) => {
      this.autoFillRunsheetLines = res;
      if (this.autoFillRunsheetLines) {
        this.runsheetFormService.emitRunseetSubsCribeData(
          this.autoFillRunsheetLines
        );
      }
      this.displayStyle = "none";
    });

  }

  noFill() {
    this.displayStyle = "none";
  }
  resetUrl() {
    this.router.navigateByUrl('/Reconcile/Runsheets/CreateRunsheet/');
  }

  showError: any;
  listError: any;
  runsheetErrors(id?: string) {
    const shiftId = id || 'null';
    const runsheetId = this.runsheetId; // Assuming 'this.runsheet' is defined and has an 'id' property

    this.runsheetFormService
      .runsheetErrorList(runsheetId, shiftId)
      .subscribe((response: any) => {
        this.showError = response.length;
        this.listError = response;
      });
  }
  loadRunsheet() {
    this.runsheetState.showLookup = true;
    this.runsheetState.displayLookupButton = false;
    this.runsheetState.displayNextRunsheetButton = true;
    this.runsheetState.showGrid = true;
    this.runsheetState.showTime = true;
    this.updateWritability(true);
    // this.runsheetState.showGrid = this.runsheetFormService.showGrid(
    //   this.runsheetState
    // );
    // this.runsheetState.showTime = this.runsheetFormService.showTime(
    //   this.runsheetState
    // );
    if (this.runsheetState.completed) {
      this.updateWritability(false);
    }
  }
  modify() {
    // this.runsheetState.formEnabled = true;
    this.modifyShow = false;
    this.runsheetState.displayLookupButton = false;
    this.runsheetState.displayNextRunsheetButton = true;
  }

  ngOnDestroy() {
    this.isComponentAlive = false;
    clearInterval(this.renewInterval);
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('EnterRunsheets');
      const result2 = await this.permission.canWrite('Runsheet2');
      if (result1 && result2) {
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }

    } catch (error) {
    }
  }

  async getPermission(runsheetDataApi: any) {
    //this.canWrite = this.runsheetService.getCanWrite();
    try {
      const result1 = await this.permission.canWrite('EnterRunsheets');
      const result2 = await this.permission.canWrite('Runsheet2');
      if (result1 && result2) {
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }

    } catch (error) {
      console.error("Error:", error);
    }

    this.runsheetState.completed = runsheetDataApi?.complete;
   
  }

  closeRunsheet() {
    this.router.navigate(['reconcile']);
  }
}
function complete(): (() => void) | null | undefined {
  throw new Error('Function not implemented.');
}


export interface ViewRunsheetRunsheetId {
  runsheet: Runsheet
  isNew: boolean
  payAdvices: any
  invoices: any
}

export interface Runsheet {
  id: number
  runsheetTypeId: string
  rateId: any
  truckId: string
  siteId: number
  driverId: number
  deliverydate: number
  publicholidayapplies: boolean
  starttime: number
  endtime: number
  returndepottime: number
  startkm: any
  endkm: any
  cashshortage: any
  stockshortage: any
  calcpaybyload: boolean
  calcpaybyhour: boolean
  payamt: any
  payhourly: any
  payincentive: any
  payallowance: any
  hoursnormal: any
  hoursthalf: any
  hoursdouble: any
  shiftrate: any
  shifthours: any
  shiftamt: any
  holdcode: any
  complete: boolean
  remarks: any
  createdby: string
  paydesc: any
  exported: boolean
  odokm: any
  gpskm: any
  enddate: number
  eventgenerated: boolean
  globaldropbonus: any
  created: number
  runsheetLines: RunsheetLine[]
  invoiceLines: any[]
  payAdviceLines: any[]
  reasonLines: any[]
  driverBreaks: any[]
  shiftId: any
  shiftUUID: any
}

export interface RunsheetLine {
  id: number
  seqDisplay?: any;
  locationContDropId: any
  locationContPickupId: any
  locationDropId: string
  locationPickupId: string
  locationReturnId: any
  serviceId: number
  trailerId: any
  containerId: any
  loadTypeId: string
  trailerTagId: any
  serviceTypeId: string
  rateId: any
  truckId: string
  siteId: number
  qty1: any
  unit1: string
  qty2: any
  unit2: string
  qty3: any
  unit3: string
  qty4: any
  unit4: any
  qty5: any
  unit5: any
  qty6: any
  unit6: any
  qty7: any
  unit7: any
  qty8: any
  unit8: any
  owntrailer: boolean
  offsiderused: boolean
  pickuparrivetime: any
  pickupdeparttime: any
  droparrivetime: any
  dropreadytime: any
  dropdeparttime: any
  docket: any
  payamt: any
  payestimated: boolean
  directfromdepot: boolean
  remarks: any
  nextstoptime: any
  tripkm: number
  paydesc: any
  pickupreadytime: any
  dropdoctime: any
  pickupdoctime: any
  createdby: string
  tripno: number
  tripseq: number
  servicehours: any
  hiretruck: boolean
  globaldropbonus: any
  deliverydate: number
  tripodostart: any
  tripodoend: any
  groupseq: any
  tripstarttime: any
  tripendtime: any
  lineTemperature: any
  lineServiceTO: LineServiceTo
  events: any
  loadNoDuplicated: any
}

export interface LineServiceTo {
  serviceId: number
  dataSource: string
  created: number
  tripIdCust: any
  serviceGroup: any
  serviceDesc: any
  customerId: string
  consignmentMasterCustomerId: string
  loadId: number
  serviceNo: string
  reasonId: any
  chargeAmt: any
  chargeDesc: any
  rateId: any
  complete: boolean
  loadNo: string
  batchNo: any
  custRef: any
  scheduleDate: number
  despatchBy: any
  deliveryOpen: any
  deliveryClose: any
  returnLocationId: any
  pickupLocation: PickupLocation
  dropLocation: DropLocation
  loadLocation: LoadLocation
  lastGroupSeq: any
  clearCharge: boolean
  totalChargeAmt: any
  svcReasonLines: any
  dehireDeadline: any
  vesselEta: any
  vesselId: any
  priority: any
  wharf: any
  depot: any
  customerSite: any
  dehirePark: any
  originSite: number
  originLoc: any
  destinationSite: number
  destinationLoc: any
}

export interface PickupLocation {
  locationId: string
  siteId: number
  locationTypeId: any
  locationDesc: string
  zonePayId: any
  zoneChargeId: any
  suburb: string
  active: any
  loadTimeMins: any
  address1: string
  address2: string
  state: any
  postCode: any
  window1From: any
  window1To: any
  window2From: any
  window2To: any
  window3From: any
  window3To: any
  personIdContact: any
  personIdContactName: any
  customerId: any
  locationCode: any
  latitude: any
  longitude: any
  geofence: any
  mapSourceId: any
  mapReference: any
  remarks: any
  truckSizeLimit: any
  defaultTripSeq: any
  routeId: any
  permanent: any
  loadTimeMinsPerUnit: any
  loadTimeUnit: any
  waitTimeMins: any
  waitTimeMinsPerUnit: any
  waitTimeUnit: any
  accShortCut: any
  locationIdGroup: any
  siteTravelTime: any
  disableWPUpdated: any
  externalLookUp: any
  internalLookUp: any
  segManaged: any
  segExported: any
  routeCapacity: any
}

export interface DropLocation {
  locationId: string
  siteId: number
  locationTypeId: any
  locationDesc: string
  zonePayId: string
  zoneChargeId: string
  suburb: string
  active: any
  loadTimeMins: any
  address1: string
  address2: any
  state: any
  postCode: any
  window1From: any
  window1To: any
  window2From: any
  window2To: any
  window3From: any
  window3To: any
  personIdContact: any
  personIdContactName: any
  customerId: any
  locationCode: any
  latitude: any
  longitude: any
  geofence: any
  mapSourceId: any
  mapReference: any
  remarks: any
  truckSizeLimit: any
  defaultTripSeq: any
  routeId: any
  permanent: any
  loadTimeMinsPerUnit: any
  loadTimeUnit: any
  waitTimeMins: any
  waitTimeMinsPerUnit: any
  waitTimeUnit: any
  accShortCut: any
  locationIdGroup: any
  siteTravelTime: any
  disableWPUpdated: any
  externalLookUp: any
  internalLookUp: any
  segManaged: any
  segExported: any
  routeCapacity: any
}

export interface LoadLocation {
  locationId: string
  siteId: number
  locationTypeId: any
  locationDesc: string
  zonePayId: any
  zoneChargeId: any
  suburb: any
  active: any
  loadTimeMins: any
  address1: any
  address2: any
  state: any
  postCode: any
  window1From: any
  window1To: any
  window2From: any
  window2To: any
  window3From: any
  window3To: any
  personIdContact: any
  personIdContactName: any
  customerId: any
  locationCode: any
  latitude: any
  longitude: any
  geofence: any
  mapSourceId: any
  mapReference: any
  remarks: any
  truckSizeLimit: any
  defaultTripSeq: any
  routeId: any
  permanent: any
  loadTimeMinsPerUnit: any
  loadTimeUnit: any
  waitTimeMins: any
  waitTimeMinsPerUnit: any
  waitTimeUnit: any
  accShortCut: any
  locationIdGroup: any
  siteTravelTime: any
  disableWPUpdated: any
  externalLookUp: any
  internalLookUp: any
  segManaged: any
  segExported: any
  routeCapacity: any
}


export interface ReasonCode {
  reasonId: string
  siteId: number
  reasonDescription: any
  driver: boolean
  active: boolean
}


export interface RunsheetFormRequest {
  id: number
  runsheetTypeId: string
  rateId: any
  truckId: any
  siteId: number
  driverId: number
  deliverydate: Date
  publicholidayapplies: boolean
  starttime: number
  endtime: number
  returndepottime: number
  startkm: any
  endkm: any
  cashshortage: any
  stockshortage: any
  calcpaybyload: boolean
  calcpaybyhour: boolean
  payamt: any
  payhourly: any
  payincentive: any
  payallowance: any
  hoursnormal: any
  hoursthalf: any
  hoursdouble: any
  shiftrate: any
  shifthours: any
  shiftamt: any
  holdcode: any
  complete: boolean
  remarks: any
  createdby: string
  paydesc: any
  exported: boolean
  odokm: any
  gpskm: any
  enddate: number
  eventgenerated: boolean
  globaldropbonus: any
  created: number
  runsheetLines: any[]
  invoiceLines: any
  payAdviceLines: any[]
  reasonLines: ReasonLine[]
  driverBreaks: any[]
  shiftId: any
  shiftUUID: any
}

export interface ReasonLine {
  id: number
  reasonId: string
  siteId: number
  reasoncomment: any
  reasonrefEvent: any
  reasonrefRunsheet: any
  reasonrefService: any
}

export interface GenericError {
  errorList: ErrorList
}

export interface ErrorList {
  ExceptionClass: string
  ExceptionId: string
  ExceptionTime: string
  ErrorMessage: string
  ExceptionInfos: ExceptionInfo[]
}

export interface ExceptionInfo {
  ContextId: string
  ErrorId: string
  ErrorType: string
  ErrorCode: string
  ErrorCodeId: string
  Severity: string
  UserErrorDescription: string
  ErrorDescription: string
  ErrorCorrection: string
}

export interface RunsheetConfig {
  runsheetTypeId: any,
  displayLookupButton: any,
  displayNextRunsheetButton: any,
  deliveryDateStamp: any,
  enddateStamp: any,
  shiftId: any,
  showLookup: any,
  showGrid: any,
  showTime: any,
  StartEndKMSwappedCondition: boolean,
  completed: boolean,
  formEnabled: boolean,
  locked: any
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmingsavedornotsaveddialogComponent } from './confirmingsavedornotsaveddialog.component';

describe('ConfirmingsavedornotsaveddialogComponent', () => {
  let component: ConfirmingsavedornotsaveddialogComponent;
  let fixture: ComponentFixture<ConfirmingsavedornotsaveddialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmingsavedornotsaveddialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConfirmingsavedornotsaveddialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

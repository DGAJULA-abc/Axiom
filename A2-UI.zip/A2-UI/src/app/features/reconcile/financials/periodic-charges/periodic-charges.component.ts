import { Component } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ApplychargesComponent } from './applycharges/applycharges.component';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { PlanService } from 'src/app/features/plan/services/plan.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';

@Component({
  selector: 'app-periodic-charges',
  templateUrl: './periodic-charges.component.html',
  styleUrls: ['./periodic-charges.component.scss'],
  providers: [ConfirmationService, MessageService],
})
export class PeriodicChargesComponent {
  gridOptions: any;
  gridApi!: GridApi<any>;
  showPanelLeft: boolean = false;
  rowData: any[] = [];
  selectedOptions: any[];
  ageventdata: any;
  ok: boolean = false;
  columnApi: any;
  rowClickedData: any;
  isButtonDisabled: boolean = true;
  //AG Grid configuration
  CurrencyCellRendererUSD(params: any) {
    var inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    });
    return inrFormat.format(params.value);
  }
  colDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'id',
      headerName: 'Id',
      width: 100,
      filter: true,
      cellDataType: 'text',
      floatingFilter: true,
    },
    {
      field: 'customerId',
      headerName: 'Customer',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'serviceTypeId',
      headerName: 'Service Type',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'period',
      headerName: 'Period',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'serviceDesc',
      headerName: 'Description',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'chargeAmount',
      headerName: 'Amount',
      width: 100,
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
      cellRenderer: this.CurrencyCellRendererUSD 
    },
    {
      field: 'lastCharged',
      headerName: 'Last applied',
      width: 100,
      cellRenderer: (milliseconds: any) => {
        if (milliseconds.value === null) {
          return '';
        }
        console.log(milliseconds.value);
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },

    {
      field: 'invoiceId',
      headerName: 'Invoice No',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',
    },
    {
      field: 'invoiceExported',
      headerName: 'Exported',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
  ];
  columnDefs: ColDef[] = this.colDefs;
  showRunsheetDetail: boolean = true;
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    // editable: true,
  };

  canWrite: boolean = true
  constructor(
    public planService: PlanService,
    private reconcileService: ReconcileService,
    public matdialog: MatDialog,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    public navbarService: NavbarService,
    public dialogService: DialogService,
    public permission: PermissionsService
  ) {
    this.reconcileService.pageTitleSubject.next('Periodic Charges');
    this.gridOptions = {
      context: { Component: this },
      getRowStyle: (params: any) => {
        if (params.node.rowIndex % 2 === 0) {
          return { background: '#fdfdfd' }; // Color for even rows
        } else {
          return { background: '#f3f3f3' }; // Color for odd rows
        }
      },
    };
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
      if (shouldSubscribe) {
        let data = this.saveLayout();
        console.log("create:", data)
        this.dialogService.savaLayout(data);
      }
    })
    this.getView();
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  async permissionMethod() {
    try {
      const result = await this.permission.canWrite('ApplyPeriodicCharges');
      console.log("Result:", result); // Use the result here
      this.canWrite = result
    } catch (error) {
      console.error("Error:", error);
    }
  }
  
  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  ngOnInit(): void {
    this.columnDefs = this.colDefs;
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.getRowData();
  }

  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column: any) =>
      event.value.includes(column.field)|| column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  onSelctionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    console.log(event);
  }

  getRowData() {
    this.reconcileService.getPeriodicCharges().subscribe((result: any) => {
      console.log('result getPeriodicCharges > ', result);

      this.rowData = result;
    });
  }

  rightSideForm(event: any) {
    event;
    this.ageventdata = event;
    console.log('row click', event);
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code in row clicked', rowCount);
    if (rowCount > 1) {
      // Get a reference to the grid API
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
      // Select the clicked row
      event.node.setSelected(true);
    }
  }
  dialogdata: any[] = [];
  selectedIds: any[] = [];
  rowdatacount: any;
  onSelectionChanged(event: any) {
    var selectedNodes = event.api.getSelectedNodes();
    var rowCount = event.api.getSelectedNodes().length;
    this.rowdatacount = rowCount;
    this.showPanelLeft = false;
    this.ok = false;
    // Delete button will be disabled till row click
    if (rowCount >= 1) {
      this.isButtonDisabled = false;
    } else {
      this.isButtonDisabled = true;
    }
    if (rowCount <= 1) {
      this.rowClickedData = event.api.getSelectedNodes()[0].data;
      this.showPanelLeft = true;
      this.ok = true;
      this.isButtonDisabled = false;
    } else {
      this.showPanelLeft = false;
      this.ok = false;
    }
    // Clear the selectedIds array before populating it again
    this.selectedIds = [];
    // Run a loop for the selected rows and store IDs in selectedIds array
    for (let i = 0; i < rowCount; i++) {
      this.selectedIds.push(selectedNodes[i].data.id); // Assuming 'id' is the property you want to store
    }
    this.dialogdata = [this.rowClickedData, this.selectedIds];
  }

  NewDetailPanel() {
    if (this.rowdatacount >= 1) {
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
    }
    this.showPanelLeft = true;
    this.ok = true;
    this.rowClickedData = null;
  }

  Updatetabledata(mes: boolean) {
    if (mes == true) {
      this.getRowData();
    }
  }

  closingdetailPanel(show: boolean) {
    this.showPanelLeft = show;
    this.ok = show;
    console.log('ag event data', this.ageventdata);
    this.rowdatacount = 0;
    // Get a reference to the grid API
    var gridApi = this.gridOptions.api;
    // Call deselectAll to unselect all selected rows
    gridApi.deselectAll();
  }
  servicesnoanddata: any;
  failuremessgae: any;
  applyPayments() {
    const dialogRef = this.matdialog.open(ApplychargesComponent, {
      height: '25%',
      width: '35%',
      data: this.dialogdata, //passing the selected data to Apply Payments
    });
    dialogRef.afterClosed().subscribe((res) => {
      this.servicesnoanddata=res.result.successIds[0];
      this.failuremessgae=res.result.failureMsgs[0];
      if (res.result != null) {
        if(this.servicesnoanddata !=null){
          this.messageService.add({ severity: 'info', detail: "Applied payment for periodics : "+ res.result.successIds[0], });
        }else
        if(this.failuremessgae!=null){
          this.messageService.add({ severity: 'info', detail: res.result.failureMsgs[0] });
        }
        this.getRowData();
        this.isButtonDisabled = true;
        this.showPanelLeft = false;
      } else if (res == 'InternalServiererror') {
        this.messageService.add({
          severity: 'warm',
          detail: res.result.failureMsgs[0],
        });
        this.getRowData();
      }
      this.closingdetailPanel(false);
    });
  }

  idsToDelete: any[] = [];
  getDeleteByIds() {
    this.idsToDelete = this.selectedIds;
    this.reconcileService
      .deletePerdicCharges(this.idsToDelete)
      .subscribe((res: any) => {
        console.log(res);
        this.getRowData();
        this.closingdetailPanel(false);
      });
  }

  DeleteData() {
    this.confirmationService.confirm({
      header: '',
      message: 'Click OK to Continue',

      accept: () => {
        this.getDeleteByIds();
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Delete successfully',
        });
      },
    });
  }

  // Save Layout Functionality
  layoutSubscription: Subscription;
  columnState: any;
  userName: any;
  applicationOptions: any;
  applicationId: any;
  selectedSite: any ='';
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.reconcile.financial.periodic-charge.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.financial.periodic-charge.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.financial.periodic-charge.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }
}

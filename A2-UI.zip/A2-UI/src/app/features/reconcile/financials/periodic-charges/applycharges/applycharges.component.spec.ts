import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplychargesComponent } from './applycharges.component';

describe('ApplychargesComponent', () => {
  let component: ApplychargesComponent;
  let fixture: ComponentFixture<ApplychargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplychargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApplychargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import * as moment from 'moment';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-finalcials-form',
  templateUrl: './finalcials-form.component.html',
  styleUrls: ['./finalcials-form.component.scss'],
})
export class FinalcialsFormComponent {
  @Output() updatetablenotify = new EventEmitter<boolean>();
  @Output() closedetailPanel = new EventEmitter<boolean>();
  @Input() rowClickedData: any;
  @Input() canWrite: any;
  referenceMetaData: any[] = [];
  customerId: any[] = [];
  serviceTypeId: any[] = [];
  ViewCustomers: any[] = [];
  // selectedCustomer: any[] | any;
  selectedCustomer: {};
  selectServiceType: {};
  selectedPeriod: '';
  selectServiceDesc: {};

  serviceDesc: any[] | any;
  period: any[] = ['Day', 'Week', 'Month'];
  chargeAmount: any[] | any;
  selectChargeAmount: any[] | any;

  restFormValues: {};
  financialData: any;

  lastCharged: any;
  financialForm: FormGroup;

  isedit: boolean = false;
  isnew: boolean = false;
  deleteButtonDisable: boolean = false;

  constructor(
    private reconileService: ReconcileService,
    private fb: FormBuilder,
    private navbarService: NavbarService,
    private authenticationService: AuthenticationService
  ) {}

  customerIdname: any;
  ServiceTypeIdname: any;

  ngOnInit() {
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        // this.isLoading = false;
        this.getServiceType(result['ref'].serviceTypes);
        // this.getLoadType(result['ref'].loadTypes);
      //   this.selectedsite = result['selectedSite'];
        // this.ViewAdjustmentTypes = result['ref'].adjustmentTypes;
        // this.ViewDrivers = result['ref'].drivers;
      //   this.ViewTrucks = result['ref'].trucks;
      //   this.ViewContainers = result['ref'].containers;
        this.ViewCustomers = result['ref'].customers;
        // this.adjustTypeDropArr =  result['ref'].adjustmentTypes;
      // //   this.ViewTrailers = result['ref'].trailers;
      // //   this.ViewVessels = result['ref'].vessels;
        // this.ViewLocations = result['ref'].locations;
      // //   this.ViewSites = result['ref'].sites;
      //   this.getReasonCode(result['ref'].reasons);
  
      //   if (this.selectedService.id != 0) {
      //     if (
      //       this.selectedService.originSite == this.selectedsiteid &&
      //       this.selectedService.destinationSite == this.selectedsiteid
      //     ) {
      //       this.selectedsitedescription = this.selectedsite.description;
      //       this.sites.push(this.selectedsite.description);
      //     }
      //   } else {
      //     this.sites.push(
      //       this.ViewSites.filter(
      //         (x: { id: number }) => x.id == this.navbarService.selectedSiteId
      //       )[0].description
      //     );
      //   }
      // }
      }
    });
    //this.getFinancialCellData();
    this.financialForm = this.fb.group({
      chargeAmount: '' || null,
      customerId: ['', Validators.required],
      id: '' || null,
      invoiceExported: '' || null,
      invoiceId: '' || null,
      lastCharged: '' || null,
      period: '' || null,
      serviceDesc: '' || null,
      serviceTypeId: '',
    });
   
    if (this.rowClickedData) {
      this.customerIdname = this.rowClickedData.id;
      this.financialForm.patchValue(this.rowClickedData);
      this.ServiceTypeIdname=this.rowClickedData.serviceTypeId;
      this.customerIdname=this.rowClickedData.customerId;
      this.isedit = true;
    } else {
      this.isnew = true;
    }
    // this.getCustomers();
    // this.getServiceType();
    this.lastCharged = moment(this.rowClickedData.lastCharged).format('L');
    
  }

  financialFormFormSubmit() {
    console.log(this.financialForm.value);
    this.postPeriodicCharges(this.financialForm.value);
  }

  filterCustomerIds: any[];
  // getCustomers() {
  //   // this.reconileService.getCustomers().subscribe((customersArr: any) => {
  //     this.ViewCustomers.map((customer: any) => {
  //       this.customerId.push(customer.customerId);
  //     // });
  //   });
  // }
  filterCustomerId(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.ViewCustomers.map((customer: any) => {
      this.customerId.push(customer.customerId);
    // });
  });

    for (let i = 0; i < this.customerId.length; i++) {
      let country = this.customerId[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filterCustomerIds = filtered;
  }
  onClearCustomerId(){
    this.customerIdname='';
  }


  filteredServicesType: any[];
  getServiceType(serviceTypeArr: any) {
    // this.reconileService.getServiceType().subscribe((serviceTypeArr: any) => {
      // console.log("serviceTypeArr >>", serviceTypeArr);
      serviceTypeArr.map((serviceType: any) => {
        this.serviceTypeId.push(serviceType.serviceTypeId);
      });
    // });
  }
  filterServiceTypeId(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.serviceTypeId.length; i++) {
      let country = this.serviceTypeId[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredServicesType = filtered;
  }
  onClearServicesTypeID(){
    this.ServiceTypeIdname='';
  }

  postPeriodicCharges(chargeFormData: any) {
    if (this.isedit) {
      this.reconileService
        .postPeriodicCharges(chargeFormData)
        .subscribe((chargeFormData: any) => {
          console.log('chargeFormData >>', chargeFormData);
          this.updatetablenotify.emit(true);
          this.closeDetailPanel();
        });
    } else if (this.isnew) {
      this.reconileService
        .putPeriodicCharges(chargeFormData)
        .subscribe((chargeFormData: any) => {
          console.log('chargeFormData >>', chargeFormData);
          this.updatetablenotify.emit(true);
          this.closeDetailPanel();
        });
    }
  }

  getReferenceMetadata() {
    this.navbarService.referenceMetadataSubject.subscribe(
      (referenceData: any) => {
        // console.log("Customers >>", customers.customers);
      }
    );
  }
  closeDetailPanel() {
    this.closedetailPanel.emit(false);
    this.financialForm.reset();
  }
}

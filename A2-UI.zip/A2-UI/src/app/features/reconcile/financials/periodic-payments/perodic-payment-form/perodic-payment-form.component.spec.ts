import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerodicPaymentFormComponent } from './perodic-payment-form.component';

describe('PerodicPaymentFormComponent', () => {
  let component: PerodicPaymentFormComponent;
  let fixture: ComponentFixture<PerodicPaymentFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PerodicPaymentFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PerodicPaymentFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplypayementsComponent } from './applypayements.component';

describe('ApplypayementsComponent', () => {
  let component: ApplypayementsComponent;
  let fixture: ComponentFixture<ApplypayementsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplypayementsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApplypayementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import * as moment from 'moment';
import { ReconcileService } from '../../../services/reconcile.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-perodic-payment-form',
  templateUrl: './perodic-payment-form.component.html',
  styleUrls: ['./perodic-payment-form.component.scss'],
})
export class PerodicPaymentFormComponent {
  @Output() updatetablenotify = new EventEmitter<boolean>();
  @Output() closedetailPanel = new EventEmitter<boolean>();
  @Input() rowClickedData: any;
  @Input() canWrite: any;
  referenceMetaData: any[] = [];
  customers: any[] = [];
  // selectedCustomer: any[] | any;
  //selectedCustomer: { id: 'LUP001'; customerName: 'LUP001' };

  serviceDesc: any[] | any;
  period: any[] = ['Day', 'Week', 'Month'];
  chargeAmount: any[] | any;
  lastCharged: any;

  driverId: any[] = [];
  selectedDriverId = {};
  serviceTypeId: any[] = [];

  ViewDrivers: any[] = [];
  ViewCompany: any[] = [];
  glCode: any;

  companyId: any[] = [];
  selectedCompanyId: {};

  selectedServiceTypeId: any;
  restRowTableValue: any;
  selectedPeriod: any;
  financialPaymentForm: FormGroup;

  isedit: boolean = false;
  isnew: boolean = false;
  deleteButtonDisable: boolean = false;

  constructor(
    private reconileService: ReconcileService,
    private fb: FormBuilder,
    private navbarService: NavbarService,
    private authenticationService: AuthenticationService
  ) {}

  id: any;
  driverIdname: any;
  servicesTypeIdname: any;
  companyIdname: any;
  periodname: any;
  ngOnInit() {
    //this.getFinancialCellData();
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        // this.isLoading = false;
        this.getServiceType(result['ref'].serviceTypes);
        // this.getLoadType(result['ref'].loadTypes);
      //   this.selectedsite = result['selectedSite'];
        // this.ViewAdjustmentTypes = result['ref'].adjustmentTypes;
        this.ViewDrivers = result['ref'].drivers;
        this.ViewCompany = result['ref'].companys;
      //   this.ViewContainers = result['ref'].containers;
        // this.ViewCustomers = result['ref'].customers;
        // this.adjustTypeDropArr =  result['ref'].adjustmentTypes;
      // //   this.ViewTrailers = result['ref'].trailers;
      // //   this.ViewVessels = result['ref'].vessels;
        // this.ViewLocations = result['ref'].locations;
      // //   this.ViewSites = result['ref'].sites;
      //   this.getReasonCode(result['ref'].reasons);
  
      //   if (this.selectedService.id != 0) {
      //     if (
      //       this.selectedService.originSite == this.selectedsiteid &&
      //       this.selectedService.destinationSite == this.selectedsiteid
      //     ) {
      //       this.selectedsitedescription = this.selectedsite.description;
      //       this.sites.push(this.selectedsite.description);
      //     }
      //   } else {
      //     this.sites.push(
      //       this.ViewSites.filter(
      //         (x: { id: number }) => x.id == this.navbarService.selectedSiteId
      //       )[0].description
      //     );
      //   }
      // }
      }
    });
    this.financialPaymentForm = this.fb.group({
      driverId: '' || null,
      serviceTypeId: '' || null,
      companyId: '' || null,
      period: '' || null,
      serviceDesc: '' || null,
      chargeAmount: '' || null,
      glCode: ['', Validators.required],
      lastCharged: [''],
    });

    if (this.rowClickedData) {
      this.financialPaymentForm.patchValue(this.rowClickedData);
      this.lastCharged = new Date(this.rowClickedData.lastCharged)
        .toISOString()
        .split('T')[0];
      this.id = this.rowClickedData.id;
      this.driverIdname = this.rowClickedData.driverId;
      this.servicesTypeIdname = this.rowClickedData.serviceTypeId;
      this.companyIdname = this.rowClickedData.companyId;
      this.periodname = this.rowClickedData.period;
      this.isedit = true;
    } else {
      this.isnew = true;
    }
    // this.getDriver();
    // this.getCompany();
    // this.getServiceType();
    this.isControlEmpty('glCode');
  }
  ngOnChanges(changes: any) {
    // This method will be called whenever the input properties change
    if (changes.childData) {
      console.log('Child data changed:', changes.childData.currentValue);
      // You can perform additional logic or update the display here
      this.rowClickedData;
    }
  }
  financialFormFormSubmit() {
    console.log(this.financialPaymentForm.value);
    this.postPeriodicPayment(this.financialPaymentForm.value);
  }

  isControlEmpty(controlName: string): boolean {
    const control = this.financialPaymentForm.get(controlName);
    return control ? control.value === '' : false;
  }

  filterPeriodnames: any[];
  filterPeriod(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.period.length; i++) {
      let country = this.period[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filterPeriodnames = filtered;
  }
  onClearPeriod() {
    this.periodname = '';
  }

  filterdriverID: any[];
  // driverdata: any[];
  // getDriver() {
  //   // this.reconileService.getDriver().subscribe((drivers: any) => {
  //     //console.log('driversList >>', drivers);
  //     this.driverdata = this.ViewDrivers;
  //     this.ViewDrivers.map((driver: any) => {
  //       this.driverId.push(driver.id);
  //     });
  //   // });
  // }
  filterdriver(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.ViewDrivers.map((driver: any) => {
      this.driverId.push(driver.id);
    });
    for (let i = 0; i < this.driverId.length; i++) {
      let country = this.driverId[i];
      if (country != 0) {
        filtered.push(country);
      }
    }
    this.filterdriverID = filtered;
  }
  onClearDriverID() {
    this.driverIdname = '';
  }

  filtercompanyID: any[];
  // getCompany() {
  //   // this.reconileService.getCompany().subscribe((companies: any) => {
  //     //console.log('Company >>', companies);
  //     this.ViewCompany.map((company: any) => {
  //       // let companyObj = { id: company.companyId, name: company.payAdviceId };
  //       this.companyId.push(company.companyId);
  //     });
  //   // });
  // }
  filtercompany(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.ViewCompany.map((company: any) => {
      // let companyObj = { id: company.companyId, name: company.payAdviceId };
      this.companyId.push(company.companyId);
    });

    for (let i = 0; i < this.companyId.length; i++) {
      let country = this.companyId[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filtercompanyID = filtered;
  }
  onClearComapnyID() {
    this.companyIdname = '';
  }

  filterserviceType: any[];
  getServiceType(serviceTypeArr: any) {
    // this.reconileService.getServiceType().subscribe((serviceTypeArr: any) => {
      // console.log("serviceTypeArr >>", serviceTypeArr);
      serviceTypeArr.map((serviceType: any) => {
        this.serviceTypeId.push(serviceType.serviceTypeId);
      });
    // });
  }
  filterserviceTypeId(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.serviceTypeId.length; i++) {
      let country = this.serviceTypeId[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filterserviceType = filtered;
  }
  onClearServicesID() {
    this.servicesTypeIdname = '';
  }

  getTooltipContent(controlName: any): string {
    const control = this.financialPaymentForm.get(controlName);
    if (controlName === 'glCode' && control?.value === '') {
      return '⚠ This Value cannot be Empty';
    }else{
      return '';
    }
  }

  //const payFormMerge = { ...this.financialPaymentForm.value, ...rowFormData };
  //console

  postPeriodicPayment(chargeFormData: any) {
    if (this.isedit) {
      const rowFormData = {
        id: this.rowClickedData.id,
        lastCharged: this.rowClickedData.lastCharged,
        payAdviceId: this.rowClickedData.payAdviceId,
        payAdviceExported: this.rowClickedData.payAdviceExported,
      };
      const payFormMerge = {
        ...this.financialPaymentForm.value,
        ...rowFormData,
      };
      this.reconileService
        .perdiocPaymentFormApi(payFormMerge)
        .subscribe((chargeFormData: any) => {
          console.log('chargeFormData >>', chargeFormData);
          this.updatetablenotify.emit(true);
          this.closeDetailPanel();
        });
    } else if (this.isnew) {
      this.reconileService
        .putPeriodicPayment(chargeFormData)
        .subscribe((chargeFormData: any) => {
          console.log('chargeFormData >>', chargeFormData);
          this.updatetablenotify.emit(true);
          this.closeDetailPanel();
        });
    }
  }

  getReferenceMetadata() {
    this.navbarService.referenceMetadataSubject.subscribe(
      (referenceData: any) => {}
    );
  }
  closeDetailPanel() {
    this.closedetailPanel.emit(false);
    this.financialPaymentForm.reset();
  }
}

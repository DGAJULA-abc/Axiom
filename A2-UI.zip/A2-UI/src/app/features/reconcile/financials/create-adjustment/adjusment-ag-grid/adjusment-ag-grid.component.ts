import { Component, ViewChild } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import {
  AdjustmentInvoiceLineUndocumentedTo,
  AdjustmentPayAdviceLineUndocumentedTo,
  CreateAdjustment,
} from '../../finaclials.model';
import { CellrenderComponent } from '../../../list-incomplete-services/cellrender/cellrender.component';
import {
  ConfirmEventType,
  ConfirmationService,
  MessageService,
} from 'primeng/api';
import * as moment from 'moment';
import { ColDef, GridApi } from 'ag-grid-community';
import { MatSelect } from '@angular/material/select';

@Component({
  selector: 'app-adjusment-ag-grid',
  templateUrl: './adjusment-ag-grid.component.html',
  styleUrls: ['./adjusment-ag-grid.component.scss'],
  providers: [MessageService, ConfirmationService],
})
export class AdjusmentAgGridComponent {
  adjustmentInvoiceLineUndocumentedTOs: AdjustmentInvoiceLineUndocumentedTo[] =
    [];
  inviceIdSelected: any[] = [];
  payIdSelected: any[] = [];
  public myStyles = {
    width: '600px',
    'z-index': 9999,
  };

  gridApiInvoice: any;
  rowData: any[] = [];
  public rowSelection: 'single' | 'multiple' = 'multiple';

  columnFields: ColDef[] = [
    {
     field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    { field: 'serviceNo', headerName: 'Service No.', minWidth: 90 },
    {
      field: 'effectiveDate',
      headerName: 'Effective Date',
      cellRenderer: (params: any) => {
        if (!params.value) {
          return ''; // Return an empty string or another placeholder
        }
        return moment(params.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          // console.log('Formatted Value:', formattedValue);
          // console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      filter: 'agTextColumnFilter',
      minWidth: 120,
    },
    { field: 'type', headerName: 'Type', minWidth: 150 },
    { field: 'description', headerName: 'Description', minWidth: 120 },
    { field: 'amount', headerName: 'Amount', minWidth: 80 },
    { field: 'fuelLevy', headerName: 'Fuel levy %', minWidth: 80 },
    { field: 'customerIdRechargeTo', headerName: 'Recharge To', minWidth: 120 },
    { field: 'customerId', headerName: 'Customer', minWidth: 120 },
    { field: 'user', headerName: 'User', minWidth: 120 },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  onGridReady(params: any) {
    this.gridApiInvoice = params.api;
    this.gridApi = params.api;
  }
  disablecheck: boolean = true;
  /**
   * @param event
   *  Invoice Selection Events
   */
  onSelectionChangedInvoice(event: any) {
    var selectedNodes = event.api.getSelectedNodes();
    var rowCount = event.api.getSelectedNodes().length;
    this.inviceIdSelected = [];
    // Run a loop for the selected rows and store IDs in selectedIds array
    for (let i = 0; i < rowCount; i++) {
      this.inviceIdSelected.push(selectedNodes[i].data.id); // Assuming 'id' is the property you want to store
    }

    const selectedRows = this.gridApiInvoice.getSelectedRows();
    if (selectedRows.length >= 1) {
      this.disablecheck = false;
    } else {
      this.disablecheck = true;
    }
  }

  payRowData: any[] = [];
  gridApiPay: any;
  columnFieldspay: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    { field: 'serviceNo', headerName: 'Service No.', minWidth: 90 },
    { field: 'runSheetId', headerName: 'Runsheet Id', minWidth: 150 },
    {
      field: 'effectiveDate',
      headerName: 'Effective Date',
      cellRenderer: (params: any) => {
        if (!params.value) {
          return ''; // Return an empty string or another placeholder
        }
        return moment(params.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          // console.log('Formatted Value:', formattedValue);
          // console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      filter: 'agTextColumnFilter',
      minWidth: 120,
    },
    { field: 'type', headerName: 'Type', minWidth: 150 },
    { field: 'description', headerName: 'Description', minWidth: 120 },
    { field: 'amount', headerName: 'Amount', minWidth: 80 },
    { field: 'fuelLevy', headerName: 'Fuel levy %', minWidth: 80 },
    { field: 'driverId', headerName: 'Driver Id', minWidth: 120 },
    { field: 'companyId', headerName: 'Company', minWidth: 120 },
    { field: 'user', headerName: 'User', minWidth: 120 },
  ];
  payColumnDefs: ColDef[] = this.columnFieldspay;
  onGridReadyPay(params: any) {
    this.gridApiPay = params.api;
    this.gridApi2 = params.api;
  }
  disablecheckpay: boolean = true;
  /**
   * This is for PayAdvice
   * @param event 
   */
  onSelectionChangedPay(event: any) {
    var selectedNodes = event.api.getSelectedNodes();
    var rowCount = event.api.getSelectedNodes().length;
    this.payIdSelected = [];
    // Run a loop for the selected rows and store IDs in selectedIds array
    for (let i = 0; i < rowCount; i++) {
      this.payIdSelected.push(selectedNodes[i].data.id); // Assuming 'id' is the property you want to store
    }
    const selectedRows = this.gridApiPay.getSelectedRows();
    if (selectedRows.length >= 1) {
      this.disablecheckpay = false;
    } else {
      this.disablecheckpay = true;
    }
  }

  constructor(
    private reconcileService: ReconcileService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private reconsileService: ReconcileService
  ) {
    // this.gridOptions = {
    //   context: { Component: this }
    // }
  }

  ngOnInit() {
    this.selectedOptions = this.columnDefsInvoice.map((coulmn) => coulmn.field);
    this.selectedOptions2 = this.columnDefPay.map((coulmn) => coulmn.field);

    this.getundocumentedAdjustment();
    this.invoceAdjustmentData();
    this.reconsileService._multiLangData.subscribe((res) => {
      console.log(res);
    });
  }

  getundocumentedAdjustment() {
    this.reconcileService
      .getundocumentedAdjustment()
      .subscribe((undocumentData: CreateAdjustment) => {
        //  console.log("undocumentData >>", undocumentData);
        this.rowData = undocumentData.adjustmentInvoiceLineUndocumentedTOs.map(
          (adjusmentData: AdjustmentInvoiceLineUndocumentedTo) => {
            // console.log("adjusmentData > ", adjusmentData);
            return adjusmentData;
          }
        );

        this.payRowData =
          undocumentData.adjustmentPayAdviceLineUndocumentedTOs.map(
            (payData: AdjustmentPayAdviceLineUndocumentedTo) => {
              console.log('payData >', payData);

              return payData;
            }
          );
      });
  }

  deletebuttoninvoice: boolean = false;
  invoceAdjustmentData() {
    this.reconcileService.getCellSubdata.subscribe((invoiceData: any) => {
      this.inviceIdSelected.push(invoiceData?.data?.id);
    });
  }

  payAdjustmentData() {
    this.reconcileService.getCellSubdata.subscribe((invoiceData: any) => {
      this.payIdSelected.push(invoiceData?.data?.id);
    });
  }
  /**This is for Invoice Delete
   *
   */
  deleteInvoice() {
    console.log('invoiceData adjustment id', this.inviceIdSelected);

    this.confirmationService.confirm({
      message: 'Click OK to Continue',
     // header: 'Are you sure you want to delete?',

      accept: () => {
        this.invoiceApiCallDelete();
      },
      reject: (type: ConfirmEventType) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            this.messageService.add({
              severity: 'error',
              summary: 'Rejected',
              detail: 'You have rejected',
            });
            break;
          case ConfirmEventType.CANCEL:
            this.messageService.add({
              severity: 'warn',
              summary: 'Cancelled',
              detail: 'You have cancelled',
            });
            break;
        }
      },
    });
  }
  /**
   * Here also we are calling delete for Invoice
   */

  invoiceApiCallDelete() {
    this.reconcileService.deleteInvoiceApi(this.inviceIdSelected).subscribe(
      (data: any) => {
        console.log('delete api >>', data);
        if (data?.failureMsgs.length > 0) {
          this.handleResponse(data);
        } else {
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: 'Invoice Deleted',
          });
        }
        this.getundocumentedAdjustment();
      },
      (err: any) => {
        console.log('err >>', err);
        //  this.handleResponse(err);
      }
    );
   
  }

  deletePayAdjustment() {
    this.confirmationService.confirm({
        message: 'Click OK to Continue',
     // header: 'Are you sure you want to delete?',

      accept: () => {
        this.patAdjustmentApiCallDelete();
      },
      reject: (type: ConfirmEventType) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            this.messageService.add({
              severity: 'error',
              summary: 'Rejected',
              detail: 'You have rejected',
            });
            break;
          case ConfirmEventType.CANCEL:
            this.messageService.add({
              severity: 'warn',
              summary: 'Cancelled',
              detail: 'You have cancelled',
            });
            break;
        }
      },
    });
  }

  patAdjustmentApiCallDelete() {
    this.reconcileService.deletePayAdjustMentApi(this.payIdSelected).subscribe(
      (data: any) => {
        console.log('delete api >>', data);
        if (data?.failureMsgs.length > 0) {
          this.handleResponse(data);
        } else {
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: 'PayAjustMentApi Deleted',
          });
        }
        this.getundocumentedAdjustment();
      },
      (err: any) => {
        console.log('err >>', err);
        //  this.handleResponse(err);
      }
    );
  }

  handleResponse(response: any) {
    if (Array.isArray(response?.failureMsgs)) {
      if (response?.failureMsgs && response?.failureMsgs.length > 0) {
        response.failureMsgs.map((msg: any) => {
          // ... do something with item
          this.showMessage('error', 'Error', msg);
        });
        // Handle the undefined or null case
      }
    }
  }

  private showMessage(severity: string, summary: string, detail: string) {
    // this.messageService.add({ severity, summary, detail });
    this.messageService.add({
      key: 'fullWidth',
      severity: severity,
      summary: summary,
      detail: detail,
      life: 1000, // Duration in milliseconds after which the message will be closed
      closable: true,
    });
  }

  private gridApi!: GridApi<any>;
    /**
   * ag-grid top right side corner
   */
    @ViewChild('mySelect') mySelect: MatSelect;
    columnDefsInvoice: ColDef[] = this.columnFields;
    selectedOptions: any[];
    onSelectionChange(event: any) {
      this.clearFilters();
      this.columnDefs = this.columnDefsInvoice.filter(
        (column) => event.value.includes(column.field) || column.field === ''
      );
      this.gridApi.setColumnDefs(this.columnDefs);
    }
    /**
     * This is used to clear all filter
     */
    clearFilters() {
      this.columnDefsInvoice.forEach((element) => {
        this.gridApi.destroyFilter(element.field!);
      });
    }

    private gridApi2!: GridApi<any>;

        /**
   * ag-grid top right side corner
   */
    columnDefPay: ColDef[] = this.columnFieldspay;
    selectedOptions2: any[];
    onSelectionChange2(event: any) {
      this.clearFilters();
      this.columnDefs = this.columnDefPay.filter(
        (column) => event.value.includes(column.field) || column.field === ''
      );
      this.gridApi2.setColumnDefs(this.columnDefs);
    }
    /**
     * This is used to clear all filter
     */
    clearFilters2() {
      this.columnDefPay.forEach((element) => {
        this.gridApi2.destroyFilter(element.field!);
      });
    }
}

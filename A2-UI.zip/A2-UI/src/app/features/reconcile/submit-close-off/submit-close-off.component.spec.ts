import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmitCloseOffComponent } from './submit-close-off.component';

describe('SubmitCloseOffComponent', () => {
  let component: SubmitCloseOffComponent;
  let fixture: ComponentFixture<SubmitCloseOffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmitCloseOffComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubmitCloseOffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

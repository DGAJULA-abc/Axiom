import { NONE_TYPE } from '@angular/compiler';
import { Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
import { ColDef, GridApi } from 'ag-grid-community';
import { InvoicePreview, InvoicePreviewRequest, PayAdvicePreview, PayAdvicePreviewRequest } from '../../reportview/model/report-view.model';
import { ReconcileService } from '../services/reconcile.service';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { MatMenuPanel } from '@angular/material/menu';
import { SearchService } from '../../search/services/search.service';
import { PlanService } from '../../plan/services/plan.service';
@Component({
  selector: 'app-print-custom-page',
  templateUrl: './print-custom-page.component.html',
  styleUrls: ['./print-custom-page.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PrintCustomPageComponent {

  rightTitle: string = 'Print Custom Page';
  gridOptions: any;
  payAdviceReports: any[] = [];
  displayStyle = "none";
  driverId: any;
  driverList: any;
  @Input() statusList: any;
  @Input() columnDefs: any;
  @Input() rowData: any;
  @Input() printMenu: any;
  @Input() pageName: any;
  @Input() columnFields: any;
  @Input() columnData: any;
  @Input() canWrite: any;
  @Input() canDelete:any;
  @Output() not: EventEmitter<string> = new EventEmitter<string>();
  applyGST: boolean = false;
  checkboxValue: boolean = false;
  ok: boolean = false;
  sum: number = 0;
  driverName: any
  isDivVisible: boolean = false;
  selectedRow: any = null;
  checkboxClicked: boolean = false;
  invoiceDetails: any = {};
  lines: any = []
  dataSource: any = [];
  selectedIds: any = [];
  showZero: boolean = false;
  layoutSubscription: Subscription;
  columnState: any;
  userName: any;
  selectedSite: any;
  selectedOptions: any;
  applicationOptions: any;
  applicationId: any;
  private gridApi!: GridApi<any>;
  displayedColumns: string[] = ['demo-position', 'demo-name', 'demo-weight', 'demo-symbol', 'demo-amount'];
  //public invoiceMenu = [{ 'name': 'Standard Invoice' }, { 'name': 'Detailed Wide Format (Service Drop)' }, { 'name': 'Load Level Summary' }, { 'name': 'Date Level Summary' }, { 'name': 'Cover Page' }, { 'name': 'Service Type/Location Summary' }, { 'name': 'Detailed Wide Format' }, { 'name': 'Wide Format With Load#(5 Units)' }, { 'name': 'Service Type/Location Summary/Rate' }, { 'name': 'Detailed Wide Format/Rate' }, { 'name': 'Trip-Based' }, { 'name': 'Special' },
  //{ 'name': 'Detailed Wide Format(Loc Number)' }, { 'name': 'Cover Page With Breakdown' }, { 'name': 'Customer Report' }]
  invoiceMenu: any = [];
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    // editable: true,
  };
  belowMenu: MatMenuPanel<any> | null;

  constructor(public planService: PlanService,private reconsileService: ReconcileService, private service: SearchService, public dialogService: DialogService, public navbarService: NavbarService) {
    //this.setColumns();
    this.gridOptions = {
      context: { Component: this }
    }
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
      if (shouldSubscribe) {
        let data = this.saveLayout();
        console.log("create:", data)
        this.dialogService.savaLayout(data);
      }
    })
    //this.getView();
  }

  ngOnInit() {
    console.log(this.canWrite)
    this.selectedOptions = this.columnDefs.map((coulmn: any) => coulmn.field);
    this.service.getDropDownData().subscribe((data: any) => {
      this.payAdviceReports = data.ref.payAdviceReportFormats;
      this.driverList = data.ref.drivers;
      data.ref.systemOptions.forEach((element: any) => {
        if (element.optionName = "Axiom.Report.Formats.Invoice") {
          let menuList = element.optionValue;
          let list;
          list = menuList.split(';');

          //var formatOptions = [];

          list.forEach((format: any) => {

            format = format.split(',');
            if (format[1] != undefined) {
              var formatItem = {
                id: format[0],
                description: format[1]

              };
              this.invoiceMenu.push(formatItem);
            }

          });

          //return formatOptions;

        };
      })
    })
  }
  columnApi: any;
  onGridReady(params: any) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi
    //this.gridApi = params.api;
   // this.getLayout();
  }
  // saveLayout(): any {
  //   if (this.columnApi) {
  //     this.columnState = this.columnApi.getColumnState();
  //     let columns = [];
  //     for (let column of this.columnState) {
  //       const customColumn = {
  //         name: column.colId,
  //         visible: !column.hide,
  //         width: column.width,
  //         sort: column.sort,
  //         filter: column.filter
  //       }
  //       columns.push(customColumn)

  //     }
  //     let columnValueObj: any = { columns };
  //     columnValueObj = JSON.stringify(columnValueObj);
  //     this.navbarService.usernameSubject.subscribe((username) => {
  //       this.userName = username;
  //     });
  //     this.selectedSite = this.navbarService.selectedSiteId;
  //     console.log("site:", this.selectedSite);
  //     return {
  //       "applicationOptionId": 9706,
  //       "optionName": "a2v3.search.invoices-results.grid.layout",
  //       "optionValue": columnValueObj,
  //       "siteId": this.selectedSite,
  //       "userId": this.userName
  //     }
  //   }
  // }

  // getLayout() {
  //   this.navbarService.applicationOptions.subscribe(
  //     (applicationOptions: any) => {
  //       let appOptions = applicationOptions;
  //       let a = appOptions.filter((item: any) => {
  //         if (item["optionName"] === "a2v3.search.invoices-results.grid.layout")
  //           this.columnState = JSON.parse(item["optionValue"]);
  //         if (this.columnState) {

  //           if (this.columnState.columns) {
  //             this.columnState.columns.forEach((column: any) => {
  //               if ("name" in column) {
  //                 column.colId = column.name;
  //                 delete column.name
  //               }
  //             });
  //             this.columnState = this.columnState.columns;
  //             this.applyLayout();
  //           }
  //         }
  //       })
  //     });
  // }

  // applyLayout() {
  //   console.log("new:", this.columnState)
  //   const applyColumnStateParams = {
  //     state: this.columnState,
  //     applyOrder: true
  //   }
  //   this.columnApi.applyColumnState(applyColumnStateParams);
  //   this.columnState.forEach(({ colId, width }: { colId: any, width: any }) => {
  //     const column = this.columnApi.getColumn(colId);
  //     if (column) {
  //       this.columnApi.setColumnWidth(column, width);
  //     }
  //   })

  // }

  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.search.invoices-results.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  // getView() {
  //   this.planService.getView().subscribe((result: any) => {
  //     if (result) {
  //       this.applicationOptions = result.applicationOptions;
  //       console.log("applicationn optionsss:", this.applicationOptions);
  //       this.applicationOptions.filter((item: any) => {
  //         if (item["optionName"] === "a2v3.search.invoices-results.grid.layout")
  //           this.applicationId = JSON.parse(item["applicationOptionId"]);
  //         console.log("id:", this.applicationId)
  //       })
  //     }
  //   })
  // }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.search.invoices-results.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }
  deleteButton: boolean = true;
  rightSideForm(event: any) {
    const clickedRowData = event.data;
    event.api.forEachNode((node: { data: { isChecked: boolean; }; }) => {
      node.data.isChecked = false;
    });
    event.api.redrawRows();
    if (this.selectedRow) {
      this.selectedRow.isChecked = false;
    }
    clickedRowData.isChecked = true;
    this.selectedRow = clickedRowData;
    event.api.redrawRows({ rowNodes: [event.node] });
    this.sum = 1;
    this.isDivVisible = true;
    this.ok = true;
    this.deleteButton = false;
    if (this.sum > 1) {
      this.deleteButton = false;
      this.isDivVisible = false;
      this.ok = false;
    }

    this.reconsileService
      .getInvoiceDeatails(event.data.id)
      .subscribe((res: any) => {
        console.log(' data >>>>', res);
        this.invoiceDetails = res.invoice;
        this.lines = res.lines;
        this.driverId = res.lines[0].driverId;
        this.dataSource = this.lines;
        this.driverList.forEach((element: any) => {
          if (this.driverId === element.id)
            this.driverName = element.employeeName;

        });
        console.log("get data:", this.driverId, this.driverList, this.driverName)
      }
      )
    // this.printRowValue = event.data;
    // console.log('row click', event);
    // var rowCount = event.api.getSelectedNodes().length;
    // console.log('checcking code in row clicked', rowCount);
    // if (rowCount > 1) {
    //   // Get a reference to the grid API
    //   var gridApi = this.gridOptions.api;
    //   // Call deselectAll to unselect all selected rows
    //   gridApi.deselectAll();
    //   // Select the clicked row
    //   event.node.setSelected(true);
    // }
  }

  clearFilters() {
    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.columnData.forEach((element: any) => {
        this.gridApi.destroyFilter(element.field!);
      });
    } else {
      this.columnFields.forEach((element: any) => {
        this.gridApi.destroyFilter(element.field!);
      });
    }


  }
  onSelectionChange(event: any) {
    this.clearFilters();
    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.columnDefs = this.columnData.filter((column: any) =>
        event.value.includes(column.field) || column.field === ''
      );
      this.gridApi.setColumnDefs(this.columnDefs);
    } else {
      this.columnDefs = this.columnFields.filter((column: any) =>
        event.value.includes(column.field) || column.field === ''
      );
      this.gridApi.setColumnDefs(this.columnDefs);
    }
  }

  setCellSubData(intvalue: any, selectedRows: any, checkboxEnabled: boolean) {

    if (intvalue == 0) {
      this.sum = 0
    }
    this.sum += intvalue;
    console.log("selected rows", this.selectedIds, this.sum);
    if (this.sum === 1) {
      console.log("right")
      this.isDivVisible = this.ok = true;
      this.ok = true;
      this.invoiceDetailsfunction(selectedRows);
    } else {
      this.ok = false;
      this.isDivVisible = false;
    }
    if(this.sum === 1){
      this.deleteButton = false
    }else if(this.sum>1){
      this.deleteButton = false
    }else if(this.sum === 0){
      this.deleteButton = true
    }

    if (checkboxEnabled) {
      this.selectedIds.push(selectedRows);
    } else {
      if (this.selectedIds.includes(selectedRows)) {
        this.selectedIds = this.selectedIds.filter((id: any) => id !== selectedRows);
        if (this.selectedIds.length === 1) {
          this.invoiceDetailsfunction(this.selectedIds[0])
        }
      }
    }


  }




  updateStatus(status: any) {
    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.reconsileService
        .updatePayAdviceStatus(this.selectedIds, status)
        .subscribe((res: any) => {
          // if(res)
          this.getRowData();
          this.isDivVisible = this.ok = false;
        });

    } else if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService
        .updateInvoiceStatus(this.selectedIds, status)
        .subscribe((res: any) => {
          //if(res)
          this.getRowData();
          this.isDivVisible = this.ok = false;
        });
    }
  }


  deleteRows() {
    if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService
        .deleteInvoices(this.selectedIds)
        .subscribe((res: any) => {
          this.getRowData();
          this.closePopup();
          this.selectedIds = [];
          this.gridOptions.api.setRowData(this.rowData);
          this.isDivVisible = this.ok = false;
          //window.location.reload();
        });
    }
    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.reconsileService
        .deletePayAdvices(this.selectedIds)
        .subscribe((res: any) => {
          this.getRowData();
          this.closePopup();
          this.selectedIds =[];
          this.gridOptions.api.setRowData(this.rowData);
          this.isDivVisible = this.ok = false;
          //window.location.reload();
        });

    }

  }
  invoiceDetailsfunction(id: any) {
    console.log("details:", id);
    if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService
        .getInvoiceDeatails(id)
        .subscribe((res: any) => {
          console.log(' data >>>>', res);
          this.invoiceDetails = res.invoice;
          this.lines = res.lines;
          this.dataSource = this.lines;
          this.applyGST = res.invoice.applyGST;
          this.driverId = res.lines[0].driverId;
          this.driverList.forEach((element: any) => {
            if (this.driverId === element.id)
              this.driverName = element.employeeName;

          });
          console.log("get data:", this.driverId, this.driverList, this.driverName)
        });
    }

    if (this.pageName === 'PrintPayAdvicesComponent') {
      this.reconsileService
        .getPayAdviceDetails(id)
        .subscribe((res: any) => {
          console.log(' data pay advice>>>>', res);
          this.invoiceDetails = res.payAdvice;
          this.dataSource = res.lines;
          this.driverId = res.lines[0].driverId;
          this.driverList.forEach((element: any) => {
            if (this.driverId === element.id)
              this.driverName = element.employeeName;

          });
          console.log("get data:", this.driverId, this.driverList, this.driverName)
        });
    }

  }


  onPrintWithCompanyFormatClick() {
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    console.log("details:", this.invoiceDetails);
    let payAdviceParam: PayAdvicePreview[] = [{
      id: this.invoiceDetails.id,// 215587,
      siteId: this.invoiceDetails.siteId,// 296,
      paFormat: this.invoiceDetails.paFormat,// null,
      defaultPaFormat: this.invoiceDetails.defaultPaFormat,// 7
    }];

    // create request params
    let payAdvicePreviewParam: PayAdvicePreviewRequest = {
      defaultCustFormat: true,
      paFormat: null,
      payrollCodeRequired: false,
      payAdvice: payAdviceParam
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(payAdvicePreviewParam));

    // open report view window
    window.open('/reportview?payAdvicePreview=' + requestParam, '_blank');

  }

  onPrintPayAdviceFormatClick(id: any) {
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    console.log("details onPrintPayAdviceFormatClick:", this.invoiceDetails);
    let payAdviceParam: PayAdvicePreview[] = [{
      id: this.invoiceDetails.id,// 215587,
      siteId: this.invoiceDetails.siteId,// 296,
      paFormat: this.invoiceDetails.paFormat,// null,
      defaultPaFormat: this.invoiceDetails.defaultPFormat,// 7
    }];

    // create request params
    let payAdvicePreviewParam: PayAdvicePreviewRequest = {
      defaultCustFormat: false,
      paFormat: id, //id TODO: change this to what was chosen in the pay advice format list.
      payrollCodeRequired: false,
      payAdvice: payAdviceParam
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(payAdvicePreviewParam));

    // open report view window
    window.open('/reportview?payAdvicePreview=' + requestParam, '_blank');

  }

  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }

  getRowData() {
    // this.checkboxValue = !this.checkboxValue;
    if (this.pageName === 'PrintPayAdvicesComponent') {

      this.reconsileService.getPrintPayAdvices(this.checkboxValue)
        .subscribe(
          (result: any) => {
            console.log("result getPrintPayAdvices > ", result);

            this.rowData = result.payadvices;
          }
        );

    } else if (this.pageName == 'PrintInvoicesComponent') {
      this.reconsileService.getPrintInvoices(this.checkboxValue)
        .subscribe(
          (result: any) => {
            console.log("result getPrintInvoices > ", result);

            this.rowData = result.invoices;
            console.log("rowdata:", this.rowData);
          }
        );
    }
  }



  onPrintWithCustomerFormatClick(printMenu: any, id: any) {
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    console.log(this.invoiceDetails);
    let invoicesParam: InvoicePreview[] = [{
      id: this.invoiceDetails.id,
      siteid: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.siteid : this.invoiceDetails.siteId,
      documenttype: printMenu == 'CustomerFormat' ? 'Invoice' : 'Credit Note',
      exported: this.invoiceDetails.exported,
      invformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
      cnformat: printMenu !== 'CustomerFormat' ? id : null,
      defaultinvformat: '3',//this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultinvformat : '3',
      defaultcnformat: '1'//this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultcnformat : '1'
    }];

    console.log("request:", invoicesParam, printMenu)
    // create request params
    let invoicePreviewParam: InvoicePreviewRequest = {
      defaultCustFormat: printMenu == 'CustomerFormat' ? true : false,
      cnFormat: printMenu == 'CustomerFormat' ? null : id,
      invFormat: null,
      showZero: this.showZero,
      invoices: invoicesParam
    };

    console.log("params:", invoicePreviewParam)
    // encode params
    let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

    // open report view window
    window.open('/reportview?invoicePreview=' + requestParam, '_blank');

  }

  onPrintInvoiceFormatClick(id: any) {
    console.log(this.invoiceDetails)
    // TODO: this is just mock parameters. replace with data from selected rows in grid that are documenttype='Invoice' only
    let invoicesParam: InvoicePreview[] = [{
      id: this.invoiceDetails.id,
      siteid: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.siteid : this.invoiceDetails.siteId,
      documenttype: 'Invoice',
      exported: this.invoiceDetails.exported,
      invformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.invformat : null,
      cnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.cnformat : null,
      defaultinvformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultinvformat : null,
      defaultcnformat: this.pageName == 'PrintInvoicesComponent' ? this.invoiceDetails.defaultcnformat : null
    }];


    // create request params
    let invoicePreviewParam: InvoicePreviewRequest = {
      defaultCustFormat: false,
      cnFormat: null,
      invFormat: id,
      showZero: this.showZero, invoices: invoicesParam
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(invoicePreviewParam));

    // open report view window
    window.open('/reportview?invoicePreview=' + requestParam, '_blank');

  }
  printRowValue: any;
  dataForRightSideForm(data: any) {
    // this.isDivVisible = true;
    // this.ok = true;
    // if (this.pageName == 'PrintInvoicesComponent') {
    //   this.reconsileService
    //     .getInvoiceDeatails(data)
    //     .subscribe((res: any) => {
    //       console.log(' data >>>>', res);
    //       this.invoiceDetails = res.invoice;
    //       this.lines = res.lines;
    //       this.dataSource = this.lines;
    //       this.applyGST = res.invoice.applyGST;
    //       this.driverId = res.lines[0].driverId;
    //       this.driverList.forEach((element: any) => {
    //         if (this.driverId === element.id)
    //           this.driverName = element.employeeName;

    //       });
    //       console.log("get data:", this.driverId, this.driverList, this.driverName)
    //     });
    // }

    // if (this.pageName === 'PrintPayAdvicesComponent') {
    //   this.reconsileService
    //     .getPayAdviceDetails(data)
    //     .subscribe((res: any) => {
    //       console.log(' data pay advice>>>>', res);
    //       this.invoiceDetails = res.payAdvice;
    //       this.dataSource = res.lines;
    //       this.driverId = res.lines[0].driverId;
    //       this.driverList.forEach((element: any) => {
    //         if (this.driverId === element.id)
    //           this.driverName = element.employeeName;

    //       });
    //       console.log("get data:", this.driverId, this.driverList, this.driverName)
    //     });
    // }
  }
  onSelectionChanged(event: any) {
    // var rowCount = event.api.getSelectedNodes().length;
    // console.log('checcking code', rowCount);
    // if (rowCount == 1) {
    //   this.printRowValue = event.api.getSelectedNodes()[0].data;
    //   console.log('here', event.api.getSelectedNodes()[0].data);
    //   this.isDivVisible = true;
    //   this.ok = true;
    //   this.dataForRightSideForm(event.api.getSelectedNodes()[0].data.id);
    // } else {
    //   this.isDivVisible = false;
    //   this.ok = false;
    // }
  }
}

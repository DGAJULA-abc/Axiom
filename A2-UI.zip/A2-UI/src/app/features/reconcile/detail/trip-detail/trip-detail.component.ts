import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import * as _ from 'lodash';

import {
  Details,
  LineServiceTo,
  LoadLocation,
  LoadTableData,
  LoadTableResponse,
  Location,
  Trailers,
} from '../detail.model';
import { ReconcileService } from '../../services/reconcile.service';
import { ServiceType } from '../runsheet-line-detail/runsheet-service-detail/runsheet-service-detail.model';
import {
  customers,
  trailers,
  trucks,
} from 'src/app/features/setup/models/setup.model';
import { RunsheetDetail, TripData, TripResponse } from '../detail2.model';
import * as moment from 'moment';
import { RunsheetFormService } from '../../services/runsheet-form.service';
import { TimeRunsheetService } from '../../services/time-runsheet.service';
import { DetailService } from '../detail.service';
import { RunsheetConfig } from '../../view-runsheet-form/ViewRunsheetId.model';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-trip-detail',
  templateUrl: './trip-detail.component.html',
  styleUrls: ['./trip-detail.component.scss'],
})
export class TripDetailComponent implements OnInit, OnChanges {
  // service type
  serviceTypeId: any[] = [];
  filteredServiceType: any[] = [];
  selectedserviceTypeId: any;

  // Truck
  truckId: any[] = [];
  filteredTruck: any[] = [];
  selectedTruck: any;

  // trailer
  trailerId: any[] = [];
  filteredTrailer: any[] = [];
  selectedTrailer: any;
  selectedTrailerId: any[] | any;

  // customer
  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];

  // Load Type
  selectedLoadType: any[] | any;
  loadTypeId: any[] = [];
  filteredLoadType: any[] = [];
  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];

  //autocomplete for locationIds
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  location_arr: any[] = [];
  ViewTrucks: any[] = [];
  ViewTrailers:  any[] = [];
  ViewLocations:  any[] = [];
  loadRow: any[] = [];
  selectedTripendtime: Date|null;
  selcetedTripstarttime: Date|null ;
  selectedTripodoend: any[] | any;
  selectedTripodostart: any[] | any;
  selectedOwnTrailer:  boolean | undefined;
  selectedOffsiderUsed: boolean | undefined;
  selectedHireTruck:  boolean | undefined;
  selectedTrailerTagId: any[] | any;
  tripDistance: any;

  loadColumnDefs: any[] = [
    {
      field: 'serviceno',
      headerName: '',
      filter: 'agNumberColumnFilter',
    },
    { field: 'serviceno', headerName: 'Service No.', minWidth: 120 },
    { field: 'enteredby', headerName: 'Entered By', minWidth: 120 },
    { field: 'loadtypeid', headerName: 'Load Type Id', minWidth: 150 },
    { field: 'servicetypeid', headerName: 'Service Type Id', minWidth: 120 },
    { field: 'servicedesc', headerName: 'Service desc', minWidth: 80 },
  ];
  tripnoFromApi: any;
  tripseqFromApi: any;
  runsheetLineId: any;

  @Input() runsheet: any;

  runsheetState: any;
  // RunsheetConfig = {
  //   runsheetTypeId: null,
  //   displayLookupButton: false,
  //   displayNextRunsheetButton: false,
  //   deliveryDateStamp: null,
  //   enddateStamp: null,
  //   shiftId: null,
  //   showLookup: false,
  //   showGrid: false,
  //   showTime: false,
  //   StartEndKMSwappedCondition: false,
  //   completed: false,
  //   formEnabled: false,
  //   locked: false,
  // };

  tripForm = {
    truckId: null,
    customerId: null,
    returnto: null,
    trailerId: null,
    trailerTagId: null,
    tripodostart: null,
    tripodoend: null,
    tripstarttime: new Date(),
    tripendtime: new Date(),
    hiretruck: null,
    owntrailer: null,
    offsiderused: null,
  };

  ViewCustomers: any[] = [];

  isLoading: boolean = false;

  @Input() formStateSubmit: boolean;

  tripDataObjData: any;
  constructor(
    private fb: FormBuilder,
    private reconcileService: ReconcileService,
    private runsheetFormService: RunsheetFormService,
    private timeService: TimeRunsheetService,
    private detailService: DetailService,
    private authenticationService: AuthenticationService
  ) {
    this.selectedTripendtime=null;
    this.selcetedTripstarttime=null;
  }

  ngOnChanges(changes: SimpleChanges) {

    if(changes['runsheet']) { 
      setTimeout(() => {
        this.getMultiLegData(this.runsheet);
      }, 100);
      this.getRunsheetState();
    } else {
      this.sendData(); 

    }
  }

  ngOnInit() {
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        this.isLoading = false;
        this.getServiceTypesLookup(result['ref'].serviceTypes);
        this.getLoadType(result['ref'].loadTypes);
      //   this.selectedsite = result['selectedSite'];
      //   this.ViewServiceTypes = result['ref'].serviceTypes;
      //   this.ViewDrivers = result['ref'].drivers;
        this.ViewTrucks = result['ref'].trucks;
      //   this.ViewContainers = result['ref'].containers;
        this.ViewCustomers = result['ref'].customers;
        this.ViewTrailers = result['ref'].trailers;
      // //   this.ViewVessels = result['ref'].vessels;
        this.ViewLocations = result['ref'].locations;
      // //   this.ViewSites = result['ref'].sites;
      //   this.getReasonCode(result['ref'].reasons);
  
      //   if (this.selectedService.id != 0) {
      //     if (
      //       this.selectedService.originSite == this.selectedsiteid &&
      //       this.selectedService.destinationSite == this.selectedsiteid
      //     ) {
      //       this.selectedsitedescription = this.selectedsite.description;
      //       this.sites.push(this.selectedsite.description);
      //     }
      //   } else {
      //     this.sites.push(
      //       this.ViewSites.filter(
      //         (x: { id: number }) => x.id == this.navbarService.selectedSiteId
      //       )[0].description
      //     );
      //   }
      // }
      }
    });
    // this.getServiceTypesLookup();
    this.isTripResourceRequired();
    // this.getTrucks();
    // this.getTrailer();
    // this.getLoadType();
    // this.getLocationIds();
    this.getServicesOfLoad();
    //  this.getMultiLegData();
    this.runsheetState = this.detailService.runsheetStateConf;
    console.log("Trip state", this.runsheetState);
    

    this.tripDetailForm.valueChanges.subscribe((res) => {
      console.log(this.tripDetailForm.getRawValue());
      this.runsheetFormService.tripDetailForm =
        this.tripDetailForm.getRawValue();
        // this.runsheetFormService.emittripFormChangesOnGrid(res);
    });
  }

  tripDetailForm = this.fb.group({
    truckId: ['', Validators.required],
    customerId: ['', Validators.required],
    returnto: ['', Validators.required],
    trailerId: ['', Validators.required],
    trailerTagId: ['', Validators.required],
    tripodostart: ['', Validators.required],
    tripodoend: ['', Validators.required],
    tripstarttime: ['', Validators.required],
    tripendtime: ['', Validators.required],
    hiretruck: ['', Validators.required],
    owntrailer: ['', Validators.required],
    offsiderused: new FormControl(false),
  });

  saveTripDetailForm() {}

  onhireTruckChange(hiretruck: MatCheckboxChange) {
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'hiretruck','lValue': hiretruck.checked});      
  }

  onOwnTrailerChange(owntrailer: MatCheckboxChange) {
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'owntrailer','lValue': owntrailer.checked});      
  }

  offsiderusedChange(offsiderused: MatCheckboxChange) {
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'offsiderused','lValue': offsiderused.checked});      
  }

  sendData() {
  //  this.runsheetFormService.sendTripFormData(this.tripDetailForm);
    
    const tripData = this.tripDetailForm.value;
    if (tripData) {
      // tripData.forEach((tripData: TripResponse) => {
        if (tripData) {
          this.tripDataObjData = tripData;
          this.tripDataObjData.id = this.runsheetLineId;
          this.tripDataObjData.tripno = this.tripnoFromApi;
          this.tripDataObjData.tripseq = +this.tripseqFromApi;

          this.tripDataObjData.truckId = this.detailService.extractTruckId(this.tripDataObjData?.truckId);
          // this.tripDataObjData.trailerId = this.detailService.extractTrailerId(this.tripDataObjData?.trailerId);
          // this.tripDataObjData.trailerTagId = this.detailService.extractTrailerId(this.tripDataObjData?.trailerTagId);
          // this.tripDataObjData.trailerIdTag = this.detailService.extractTrailerId(this.tripDataObjData.trailerIdTag);
          // this.tripDataObjData.locationReturnId = this.detailService.extractReturnLoc(this.tripDataObjData.locationReturnId);
          this.tripDataObjData.locationReturnId = (this.tripDataObjData?.locationReturnId?.split(' ')[0]);
          this.tripDataObjData.tripstarttime = this.detailService.convertAusTimeZone(this.tripDataObjData?.tripstarttime);
          this.tripDataObjData.tripendtime = this.detailService.convertAusTimeZone(this.tripDataObjData?.tripendtime);
        }
      // });
    //  return null;
   }
   console.log("Trip formData value >>", this.tripDataObjData);
   
   this.runsheetFormService.sendTripFormData(this.tripDataObjData);

  }

  getRunsheetState() {
    if (this.runsheetState.complete) {
      this.tripDetailForm.controls['truckId'].disable();
      this.tripDetailForm.controls['customerId'].disable();
      this.tripDetailForm.controls['returnto'].disable();
      this.tripDetailForm.controls['trailerId'].disable();
      this.tripDetailForm.controls['trailerTagId'].disable();
      this.tripDetailForm.controls['tripodoend'].disable();
      this.tripDetailForm.controls['tripodostart'].disable();
      this.tripDetailForm.controls['tripstarttime'].disable();
      this.tripDetailForm.controls['tripendtime'].disable();
      this.tripDetailForm.controls['hiretruck'].disable();
      this.tripDetailForm.controls['owntrailer'].disable();
      this.tripDetailForm.controls['offsiderused'].disable();
    }
  }

  // Truck Type
  getTrucks() {
    // this.reconcileService.getTruck().subscribe((truck: any) => {
      //  console.log('truck line> ', truck);
      // this.ViewTrucks.map((truck: trucks) => {
      //   this.truckId.push(truck);
      // });
    // });
  }

  filteredTruckFun(event: any) {
    let truckeArr: any[] = [];
    let query = event.query;
    this.truckId = [];
    // console.log("this.customerId >", this.customerId);
    this.ViewTrucks.map((truck: trucks) => {
      this.truckId.push(truck);
    });
  this.truckId.map((trailer: any) => {
    if (trailer.truckId) {
        const routeCapacity = trailer.routeCapacity ? trailer.routeCapacity : '';
        const trailerTypeId = trailer.truckTypeId ? trailer.truckTypeId : '';
        const companyId = trailer.companyId ? trailer.companyId : '';
        
        let trailerName = trailer.truckId;
        if (routeCapacity || trailerTypeId || companyId) {
            trailerName += ' (';
            if (routeCapacity) {
                trailerName += `${routeCapacity}, `;
            }
            if (trailerTypeId) {
                trailerName += `${trailerTypeId}, `;
            }
            if (companyId) {
                trailerName += `${companyId}`;
            }
            // Remove last comma and space if present
            if (trailerName.endsWith(', ')) {
                trailerName = trailerName.slice(0, -2);
            }
            trailerName += ')';
        }
        
        if (trailerName.toLowerCase().includes(query.toLowerCase())) {
          truckeArr.push(trailerName);
        }
    }
});
  
    this.filteredTruck = truckeArr;
  }

 
  onChangeTruck(truckId: any) {
    const truckIdPayload = this.detailService.extractTruckId(truckId);
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'truckId','lValue': truckIdPayload}); 
  }

  // Trailer
  getTrailer() {
    // this.reconcileService.getTrailer().subscribe((trailer: any) => {
      //  console.log("trailer > ", trailer);
      // this.ViewTrailers.map((trailer: Trailers) => {
      //   this.trailerId.push(trailer);
      // });
    // });
  }

  filteredTrailerFun(event: any) {
    let trailerArr: any[] = [];
    let query = event.query;

    this.ViewTrailers.map((trailer: Trailers) => {
      this.trailerId.push(trailer);
    });

    // console.log("this.customerId >", this.customerId);
    this.trailerId.map((trailer: any) => {
      if (trailer.trailerId) {
          const routeCapacity = trailer.routeCapacity ? trailer.routeCapacity : '';
          const trailerTypeId = trailer.trailerTypeId ? trailer.trailerTypeId : '';
          const companyId = trailer.companyId ? trailer.companyId : '';
          
          let trailerName = trailer.trailerId;
          if (routeCapacity || trailerTypeId || companyId) {
              trailerName += ' (';
              if (routeCapacity) {
                  trailerName += `${routeCapacity}, `;
              }
              if (trailerTypeId) {
                  trailerName += `${trailerTypeId}, `;
              }
              if (companyId) {
                  trailerName += `${companyId}`;
              }
              // Remove last comma and space if present
              if (trailerName.endsWith(', ')) {
                  trailerName = trailerName.slice(0, -2);
              }
              trailerName += ')';
          }
          
          if (trailerName.toLowerCase().includes(query.toLowerCase())) {
              trailerArr.push(trailerName);
          }
      }
  });
   
    this.filteredCustomers = trailerArr;
  }

  onChangeTrailer(trailerId: any) {
    const firstWord = trailerId.split(' ')[0];
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'trailerId','lValue': firstWord});      
  }

  onChangeTrailerTagId(trailerTagId: any) {
    const firstWord = trailerTagId.split(' ')[0];
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'trailerTagId','lValue': firstWord});      
  }

  
  tripOdostartChange(tripodostart: any) {
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'tripodostart','lValue': tripodostart?.value});      
  }

  
  tripodoendChange(tripodoend: any) {
   let endTrip = Number(tripodoend?.value);
   let tripodostart = Number(this.tripDetailForm.get('tripodostart')?.value);
   this.tripDistance = endTrip - tripodostart;

  if (this.tripDistance >= 0) {
    this.tripDistance = `${this.tripDistance}km` ;
  } else {
    this.tripDistance = null; // or do nothing, or set to a default value as needed
  }
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'tripodoend','lValue': tripodoend?.value});      
  }

  
  tripStarttimeChange(tripstarttime: any) {
    const startTime = this.detailService.convertAusTimeZone(tripstarttime);
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'tripstarttime','lValue': startTime});      
  }

  tripEndtimeChange(tripendtime: any) {
    const endTime = this.detailService.convertAusTimeZone(tripendtime);
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'tripendtime','lValue': endTime});      
  }

  // Loadtype
  getLoadType(loadTypeArr: any) {
    // this.reconcileService.getLoadType().subscribe((loadTypeArr: any) => {
      // console.log("Customer > ", customerArr);
      loadTypeArr.map((loadType: any) => {
        this.loadTypeId.push(loadType.loadTypeId);
      });
    // });
  }

  filteredLoadtypeFun(event: any) {
    let loadTypeArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.loadTypeId.map((loadType: any) => {
      if (loadType.toLowerCase().includes(query.toLowerCase())) {
        loadTypeArr.push(loadType);
      }
    });
    this.filteredLoadType = loadTypeArr;
  }

  onChangeLoadType(event: any) {}

  getLocationIds() {
    // this.reconcileService.getLocation().subscribe((locations: any) => {
      // console.log('getReasonCode >> ', reasonCodes);
      this.ViewLocations.map((location: Location) => {
        if (location.locationId !== null) {
          this.location_arr.push(location.locationId);
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    // });
  }
  filteredLoactionFun(event: any) {
    let locationIdArr: any[] = [];
    let query = event.query;

    this.ViewLocations.map((location: Location) => {
      if (location.locationId !== null) {
        this.location_arr.push(location.locationId);
      }
    });

    this.location_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        locationIdArr.push(location);
      }
    });
    this.filteredLocations = locationIdArr;
  }

  onChangeLocation(locationReturnId: any) {
    this.runsheetFormService.emittripFormChangesOnGrid({'lName':'locationReturnId','lValue': locationReturnId});      
  }

  getServicesOfLoad() {
    this.reconcileService._multiLangData.subscribe((fetchLoad: Details) => {
      this.reconcileService
        .getServicesOfLoad(fetchLoad.lineServiceTO.loadId)
        .subscribe((loadData: LoadTableResponse) => {
          this.loadRow = loadData.map((rowLoad: LoadTableData) => {
            return rowLoad;
          });
        });
    });
  }

  getMultiLegData(runsheet: any) {
    // this.reconcileService._multiLangData.subscribe((runsheet: RunsheetDetail) => {
      console.log("Trip Runsheet >> ", runsheet);
      
    if (runsheet) {
      this.tripnoFromApi = runsheet.tripno;
      this.runsheetLineId = runsheet?.firstRunsheetLine?.id;

      // this.tripseqFromApi = this.detailService.extractTripSeq(runsheet.tripseq);
      this.tripseqFromApi = runsheet?.tripseq;


      if(runsheet.firstRunsheetLine.truckId) {
        this.ViewTrucks.filter((truck: trucks) => {
          if (runsheet.firstRunsheetLine.truckId === truck.truckId) {
            this.selectedTruck = `${truck.truckId} , (${truck.routeCapacity} , ${truck.truckTypeId} , ${truck.companyId})`;;
          }
        });
      }
     

      this.ViewTrailers.filter((trailer: any) => {
        if (runsheet.firstRunsheetLine.trailerId === trailer.trailerId) {
          this.selectedTrailerId = this.reconcileService.geTrailerName(trailer);
        }
        if (runsheet.firstRunsheetLine.trailerTagId === trailer.trailerId) {
          this.selectedTrailerTagId = this.reconcileService.geTrailerName(trailer);
        }
      });

      this.ViewLocations.filter((location: any) => {
        // console.log('location trip>>', location);
        if (runsheet.firstRunsheetLine.locationReturnId === location.locationId) {
          this.selectedLocation = location.locationId;
        }
      });

      if(runsheet.firstRunsheetLine.tripendtime==null){
        this.selectedTripendtime=null;
      }
      else{
        this.selectedTripendtime = new Date(runsheet.firstRunsheetLine.tripendtime);
      }
      if(runsheet.firstRunsheetLine.tripstarttime==null){
        this.selcetedTripstarttime=null;
      }
      else{
        this.selcetedTripstarttime = new Date(runsheet.firstRunsheetLine.tripstarttime);
      }
      this.selectedTripodostart = runsheet.firstRunsheetLine.tripodostart;
      this.selectedTripodoend = runsheet.firstRunsheetLine.tripodoend;
      this.selectedOwnTrailer = runsheet.firstRunsheetLine.owntrailer;
      this.selectedHireTruck = runsheet.firstRunsheetLine.hiretruck;
      // this.selectedOffsiderUsed = runsheet.firstRunsheetLine?.offsiderused;
      this.tripDetailForm.controls['hiretruck'].setValue(runsheet.firstRunsheetLine?.hiretruck);
      this.tripDetailForm.controls['owntrailer'].setValue(runsheet.firstRunsheetLine?.owntrailer);
      this.tripDetailForm.controls['offsiderused'].setValue(runsheet.firstRunsheetLine?.offsiderused);      
      this.distanceMeasure(runsheet.firstRunsheetLine)
    }
    //  this.selectedTripendtime   = new Date(runsheet.tripodoend);
    //  this.selcetedTripstarttime = new Date(runsheet.tripstarttime);

    // this.tripDetailForm.patchValue({
    //      trailerId:
    // })

    // this.customerId.filter((customer: customers) => {
    //      if(runsheet..customerId === customer.customerId) {
    //       this.selectedCustomerId = customer.customerId;
    //      }
    // })

    // this.loadTypeId.map((loadtype: any) => {
    //   if(runsheet.loadTypeId === loadtype) {
    //     this.selectedLoadType = loadtype;
    //   }
    // })

    // })
  }

  distanceMeasure(firstRunsheetLine: any) {
    // if (_.get(firstRunsheetLine,'firstRunsheetLine')){
        // var firstRunsheetLine = trip.firstRunsheetLine;
        if (firstRunsheetLine && firstRunsheetLine.tripodostart>=0 &&
            firstRunsheetLine.tripodoend>=0 &&
            firstRunsheetLine.tripodoend>= firstRunsheetLine.tripodostart
        ){
          this.tripDistance = firstRunsheetLine.tripodoend-firstRunsheetLine.tripodostart+'km';
            return firstRunsheetLine.tripodoend-firstRunsheetLine.tripodostart+'km';
        }
    // }
    return null
}

   // Service Type
   getServiceTypesLookup(serviceTypeArr: any) {
    // this.reconcileService
    //   .getServiceTypesLookup()
    //   .subscribe((serviceTypeArr: any) => {
        // console.log('getServiceTypesLookup line> ', serviceTypeArr);
        // this.serviceTypeArray = serviceTypeArr;
        serviceTypeArr.map((serviceTypeIdUniqye: ServiceType) => {
          this.serviceTypeId.push(serviceTypeIdUniqye);
      //   });
      });
  }

   isTripResourceRequired() {
    console.log(_.get(this.serviceTypeId, 'req'));
    
    // var serviceType = RefDataService.get('serviceTypes', trip.firstRunsheetLine.serviceTypeId);
    return _.get(this.serviceTypeId, 'req') || false;
};

dateTimeJone(timeFormat: any) {
  // console.log('timeFormat > ', timeFormat);

  return this.timeService.dateTime(timeFormat);
}

 
}

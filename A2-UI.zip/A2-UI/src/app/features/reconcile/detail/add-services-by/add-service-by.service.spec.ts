import { TestBed } from '@angular/core/testing';

import { AddServiceByService } from './add-service-by.service';

describe('AddServiceByService', () => {
  let service: AddServiceByService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddServiceByService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

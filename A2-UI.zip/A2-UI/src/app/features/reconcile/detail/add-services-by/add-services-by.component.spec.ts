import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddServicesByComponent } from './add-services-by.component';

describe('AddServicesByComponent', () => {
  let component: AddServicesByComponent;
  let fixture: ComponentFixture<AddServicesByComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddServicesByComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddServicesByComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

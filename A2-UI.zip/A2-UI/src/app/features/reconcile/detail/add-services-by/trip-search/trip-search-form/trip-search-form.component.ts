import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-trip-search-form',
  templateUrl: './trip-search-form.component.html',
  styleUrls: ['./trip-search-form.component.scss']
})
export class TripSearchFormComponent {
  @Output() searchDetails = new EventEmitter<any>();
  tripForm: FormGroup;
  currentTime: Date = new Date();
  previousDate: Date = new Date(new Date((new Date()).setDate((new Date()).getDate() - 14)).setHours(0, 0, 0, 0));
  drivers: { id: any, name: string }[] = [];
  truckId: { id: any, name: string }[] = [];
  trailer: { id: any, name: string }[] = [];
  routes: any[] = [];
  locations: { id: any, name: string }[] = [];
  searchForm: any;
  constructor(
      private shareServices: SharedService,
      private fb: FormBuilder
  ) {
      this.tripForm = this.fb.group({
          tripIdCust: new FormControl(''),
          from: new FormControl(''),
          to: new FormControl(''),
          route: new FormControl('')
      });
  }
      /**Drop down  */
      selectedroutes: any;
      filteredroute: any[];
      filteredroutes(event: any) {
        let filtered: any[] = [];
        let query = event.query;

        for (let i = 0; i < this.routes.length; i++) {
          let load = this.routes[i];
          if (load.toLowerCase().includes(query.toLowerCase())) {
            filtered.push(load);
          }
        }
        this.filteredroute = filtered;
      }

  ngOnInit() {
      this.searchViewDetails();
  }

  searchViewDetails() {
      this.shareServices.getContextView().subscribe(
          (result: any) => {
              this.drivers = this.shareServices.getDriverList(result.ref.drivers);
              this.truckId = this.shareServices.getTruckList(result.ref.trucks);
              this.trailer = this.shareServices.getTrailerList(result.ref.trailers);

              result.ref.routes.map((route: any)=> {
                //   if (route.active)
                  this.routes.push(route.routeId);
              });
              result.ref.locations.map((location: any)=> {
                  if (location.active) {
                      let loactionName = [location.locationId, location.accShortCut ?  " ( " + location.accShortCut + " )" : ''].filter(function (val) {
                          return val;
                      }).join(' ');
                      this.locations.push({id: loactionName , name: loactionName});
                  }
              });
              this.searchForm = this.getSearchFormFields();
          }
      );
  }

  getSearchFormFields() {
      this.searchForm = {
          displayName: 'Trips',
          name: 'Search.Trips',
          endpoint: '/search/trip/',
          fields: [{
              name: 'tripIdCust',
              displayName: 'Trip',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              type: 'TEXT'
          }, 
          {
              name: 'from',
              displayName: 'Trip From',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: this.previousDate,
              type: 'DATE'
          }, {
              name: 'to',
              displayName: 'Trip To',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: this.currentTime,
              type: 'DATE'
          },
          {
              name: 'route',
              displayName: 'Route',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              dropDownList: this.routes,
              reference: 'routes',
              type: 'REFERENCE'
          }, 
        ]
      };
      return this.searchForm;
  }

  updateValue(controlName: string, newValue: any) {
      this.tripForm.get(controlName)?.setValue(newValue);
  }

  onSubmit() {
      let formValues = this.tripForm.value;
      if (formValues.from instanceof Date) {
        formValues.from = formValues.from.getTime();
    }
    if (formValues.to instanceof Date) {
        formValues.to = formValues.to.getTime();
    }
    if(this.selectedroutes){
        formValues.route = this.selectedroutes;
    }
      this.searchDetails.emit(formValues);
  }
 
  addTripRunsheet() {
    
  }
}



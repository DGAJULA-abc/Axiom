import { Component, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridApi,
  GridOptions,
  GridReadyEvent,
  RowNode,
} from 'ag-grid-community';

import { pagination } from 'src/app/shared/model/shared.model';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Permissions } from 'src/app/shared/model/context-vew.model';
import { MatDialog } from '@angular/material/dialog';
import { Services } from 'src/app/features/search/model/search.model';
import { SearchService } from 'src/app/features/search/services/search.service';
import { DeleteInvoiceLinesComponent } from 'src/app/features/search/delete-invoice-lines/delete-invoice-lines.component';
import { ActivatedRoute } from '@angular/router';
import { AddServiceByService } from '../add-service-by.service';
import { ReconcileService } from '../../../services/reconcile.service';
import { RunsheetService } from '../../../services/runsheet.service';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
import * as moment from 'moment';

@Component({
  selector: 'app-service-search',
  templateUrl: './service-search.component.html',
  styleUrls: ['./service-search.component.scss'],
})
export class ServiceSearchComponent {
  runsheetId: any;
  runsheetApiData: any = {};

  public colDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'serviceNo',
      headerName: 'Service No.',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'serviceDate',
      headerName: 'Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      sortable: true,
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    },
    {
      field: 'serviceType',
      headerName: 'Type',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'loadNo',
      headerName: 'Load No',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'docket',
      headerName: 'Docket',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'locationDrop',
      headerName: 'Drop Location',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'enteredBy',
      headerName: 'Entered BY',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'customerId',
      headerName: 'Customer',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'containerId',
      headerName: 'Container Number',
      type: 'container',
      filter: true,
      sortable: true,
    },
  ];
  columnDefs: ColDef[] = this.colDefs;

  public rowData: Services[] = [];
  selectedNodes: RowNode[];
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    suppressMenu: true,
  };
  serviceDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  editForm: Services | null;
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 100,
    orderType: 'DESC',
    orderByField: 'serviceid',
  };
  selectedServices: any;

  columnApi: any;
  gridApi!: GridApi<any>;
  selectedOptions: any[];

  totalRecords: number = 0;
  canDelete: boolean = false;
  searchForm: any;
  setupPermission: Permissions;
  gridOptions: GridOptions;
  runsheetIdLookup: any;

  constructor(
    private searchServices: SearchService,
    private sharedDervice: SharedService,
    private dialog: MatDialog,
    private runsheetFormService:RunsheetFormService,
    private activatedRoute: ActivatedRoute,
    private addServiceService: AddServiceByService,
    private reconcileService: ReconcileService,
    private runsheetService: RunsheetService,
    private reconsileService: ReconcileService,
  ) {
    this.gridOptions = <GridOptions>{
      onRowSelected: function (event) {
        if (event.node.isSelected()) {
          event.node.setSelected(true);
        }
      },
    };
  }

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
  }

  ngOnInit(): void {
    this.getRunsheetID();  
    this.columnDefs = this.colDefs;
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    // this.runsheetId =
    //   this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
      this.getRunsheetIDApiData(this.runsheetId);
    this.searchViewDetails();
    let requestParam = {
      svcDateFrom: 1699381800000,
      svcDateTo: 1700637383804,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'serviceid',
      },
    };
    this.ServiceList(requestParam);
  }

  getRunsheetID() {
    this.runsheetIdLookup = this.addServiceService.runsheetIdSeriviceBy;
    console.log("runsheetIdLookup >>", this.runsheetIdLookup);
    if(this.runsheetIdLookup) {
      this.runsheetId = this.runsheetIdLookup;
    } else {
      this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
    }
    console.log("runsheetIdLookup w >>", this.runsheetId);
  }

  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column: any) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  searchViewDetails() {
    this.searchServices.getSearchView().subscribe((result: any) => {
      this.setupPermission = result.permissions.sitePermissions[0].permissions;

      // this.rowData = result;
    });
  }
  canRead() {}

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.ServiceList(event);
  }

  ServiceList(event: any) {
    this.searchForm = event;
    this.searchServices
      .getSearchListreconcile(event)
      .subscribe((result: any) => {
        this.rowData = result.services;
        this.pagination.pageNumber = result.pagination.currentPage;
        this.totalRecords = result.pagination.totalRecords;
      });
  }

  loadIDS:any[]=[];
  disableAddService:boolean=true;
  onSelectionChanged(event: any) {
    this.loadIDS=[];
    if(this.gridApi.getSelectedRows().length!=0){
      this.disableAddService=false;
      console.log(" serviceeecalled" ,event.api.getSelectedNodes()[0].data)
      /* multiple lines start */
      event.api.getSelectedNodes().forEach((element:any) => {
        this.loadIDS.push(element.data.serviceId);
      });
    }
    else{
      this.disableAddService=true;
    }
    // this.loadId = event.api.getSelectedNodes()[0].data.serviceId
  }

  onTabSelectToggle(event: any) {
    console.log(event);
  }

  runSheetLine: any;
  Result_check:any[]=[];
  addTripRunsheet() {
    this.reconsileService.setSelectedItemType('detail-page');
    this.Result_check=[];
    /*Multiple Lines Started */
    this.loadIDS.forEach(loadId => {
      this.addServiceService.getServices(this.runsheetApiData.id,loadId,4,'service').subscribe((runsheetLine: any)=>{
        runsheetLine = runsheetLine.map((item: any) => ({
          ...item,
          lineTemperature: Object.keys(item.lineTemperature).some(function (key) {
            return (
              ["deliverydate", "id"].indexOf(key) > -1 &&
              item.lineTemperature[key] != null
            );
          })
            ? item.lineTemperature
            : null,
        }));
        console.log("service Line", runsheetLine);   
        this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(runsheetLine);
        this.runsheetService.updateRunsheetPUT(this.runsheetApiData).subscribe((result:any)=>{
          this.runsheetFormService.emitRunseetSubsCribeData(result);
        });
      })
    });
  //   this.addServiceService.getServices(this.runsheetApiData.id, this.loadId, 4, 'service').subscribe((result: any) => {
  //     this.runSheetLine = result;
  //     console.log(this.runSheetLine);
  //     this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(this.runSheetLine);
  //     // Add the new runSheetLine object to the runsheetLines array
  //     this.runsheetService.updateRunsheetPUT(this.runsheetApiData).subscribe((result:any)=>{
  //     });
  // });
  /**this is for reload the Search-load data only after adding the load in runsheet-line */
  this.ServiceList(this.searchForm);
}

  getRunsheetIDApiData(runsheetId: any) {
    this.reconcileService
      .getViewRunsheetId(runsheetId)
      .subscribe((apiData: any) => {
        this.runsheetApiData = apiData.runsheet;
        console.log('runsheetApiData assd Api Data', this.runsheetApiData);
      });
  }
}

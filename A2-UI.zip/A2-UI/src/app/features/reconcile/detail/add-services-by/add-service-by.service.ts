import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import { RunsheetLineDetailService } from '../runsheet-line-detail/runsheet-line-detail.service';
import { RunsheetService } from '../../services/runsheet.service';
import { apiEndpoint } from 'src/app/config/config.model';
import { Subject } from 'rxjs';
import { DetailService } from '../detail.service';

@Injectable({
  providedIn: 'root'
})
export class AddServiceByService {

  public _allRunsheetSubject: Subject<any> = new Subject();

  private _runseetId: any;
  constructor(
    private http: HttpClient,
    private runsheetLineService: RunsheetLineDetailService,
    private runsheetService: RunsheetService,
  ) {}

  addToRunsheet(data: any, runsheet: any) {
    const tripIdcust = _.get(data, 'lineServiceTO.tripIdCust');
    // data.lineServiceTO.scheduleDate = data.deliverydate = runsheet.deliverydate;
    data.owntrailer = this.runsheetService.getOwnTrailer(runsheet, data);
    if (tripIdcust) {
      this.runsheetLineService.addRunsheetLineByTrip(data, runsheet);
    } else {
      this.runsheetLineService.updateRunsheetLines([data], runsheet, true);
    }
  }

  addRunsheetLineToLastTrip(runsheetLine: any, runsheet: any) {
    this.runsheetLineService.addRunsheetLineToLastTrip(runsheetLine, runsheet);
  }

  getServices(runsheetId: string, serviceId: string, tripNo: any, type: string) {
    return this.http.post(`${apiEndpoint.runsheetAddBy}/${runsheetId}/add-line-by/${type}`, {
      id: serviceId,
      tripNo: tripNo
    });
  }
 
  getDefaultSearchDates(runsheet: any) {
    return {
      from: (runsheet.deliverydate - 3 * 24 * 60 * 60 * 1000), // 3 days to milliseconds
      to: runsheet.deliverydate
    };
  }

  get runsheetIdSeriviceBy() {
    return this._runseetId;
 }

 set runsheetIdSeriviceBy(value: any) {
   this._runseetId = value;
 }
}
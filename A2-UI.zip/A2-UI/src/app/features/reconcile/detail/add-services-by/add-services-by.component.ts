import { Component, Input } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';

@Component({
  selector: 'app-add-services-by',
  templateUrl: './add-services-by.component.html',
  styleUrls: ['./add-services-by.component.scss']
})
export class AddServicesByComponent {
    @Input() runsheet: any;
    constructor(private reconsileService: ReconcileService){  
    }

    close(){
      this.reconsileService.setSelectedItemType('detail-page');
    }

}

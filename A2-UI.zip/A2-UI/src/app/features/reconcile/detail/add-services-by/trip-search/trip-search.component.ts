import { Component, Input, SimpleChanges, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridApi,
  GridOptions,
  GridReadyEvent,
  RowNode,
} from 'ag-grid-community';

import { Driver, pagination } from 'src/app/shared/model/shared.model';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Permissions } from 'src/app/shared/model/context-vew.model';
import { MatDialog } from '@angular/material/dialog';
import { Services } from 'src/app/features/search/model/search.model';
import { ServiceDateCycle, TripDateCycle } from 'src/app/features/plan/models/plan.model';
import { SearchService } from 'src/app/features/search/services/search.service';
import { AddServiceByService } from '../add-service-by.service';
import { ReconcileService } from '../../../services/reconcile.service';
import { combineLatest, map } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ViewRunsheetRunsheetId } from '../../../view-runsheet-form/ViewRunsheetId.model';
import { RunsheetDetail } from '../../detail2.model';
import { RunsheetService } from '../../../services/runsheet.service';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
import * as moment from 'moment';

@Component({
  selector: 'app-trip-search',
  templateUrl: './trip-search.component.html',
  styleUrls: ['./trip-search.component.scss']
})
export class TripSearchComponent {

  runsheetId: any;
  @Input() runsheet: any;
  public colDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
     
    },
    {
      field: 'tripIdCust',
      headerName: 'Trip',
      type: 'TEXT',
      filter: true,
    }, {
      field: 'tripDate',
      headerName: 'Date',
      type: 'DATE',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    }, {
      field: 'routeId',
      headerName: 'Route',
      type: 'TEXT',
      filter: true,
    },
  ];
  columnDefs: ColDef[] = this.colDefs;
  public rowData: Services[] = [];
  selectedNodes: RowNode[];
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    suppressMenu: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
  };
  
  serviceDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  loadSelected:boolean =false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  editForm: TripDateCycle | null;
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 100,
    orderType: "DESC",
    orderByField: "id"
  }
  selectedTrip: any;
  selectedServices: ServiceDateCycle[];
  selectedTripService: any;
  totalRecords: number = 0;
  drivers: Driver;

  selectedTrips: any[]; 
  runsheetData: any[] =[];
  runsheetApiData: any = {};

  columnApi: any;
  gridApi!: GridApi<any>;
  selectedOptions: any[];
  gridOptions: GridOptions;
  runsheetIdLookup: any;

  // runsheet: any; 
  constructor(
    private reconsileService: ReconcileService,
    private searchServices: SearchService,
    private runsheetFormService:RunsheetFormService,
    private sharedService: SharedService,
    private addServiceService: AddServiceByService,
    private reconcileService: ReconcileService,
    private activatedRoute: ActivatedRoute,
    private runsheetService: RunsheetService
  ) { 
    this.gridOptions = <GridOptions>{
      onRowSelected: function (event) {
        if (event.node.isSelected()) {
          event.node.setSelected(true);
        }
      },
    };
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes['runsheet']) {
      console.log("Runsheet in trip", this.runsheet);
      
      setTimeout(() => {
        // this.getMultiLegData(this.runsheet);
      }, 100);
    } else {
      // this.sendData();
      console.log("Other Changes");
       

    }
   
  }

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
  }

  ngOnInit(): void {
    this.getRunsheetID();  

    this.columnDefs = this.colDefs;
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.runsheetId =
      // this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
      this.getRunsheetIDApiData(this.runsheetId);
    let requestParam = {
      from: 1699448400000,
      to: 1699448400000,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'ASC',
        orderByField: 'scheduledDate',
      },
    };
    this.tripsList(requestParam);
    this.getRunsheet();
    // this.searchViewDetails();
  }

  getRunsheetID() {
    this.runsheetIdLookup = this.addServiceService.runsheetIdSeriviceBy;
    console.log("runsheetIdLookup >>", this.runsheetIdLookup);
    if(this.runsheetIdLookup) {
      this.runsheetId = this.runsheetIdLookup;
    } else {
      this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
    }
    console.log("runsheetIdLookup w >>", this.runsheetId);
  }

  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column: any) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.tripsList(event);
  }

  tripsList(event: any) {
    console.log(event);
    this.searchServices.getSearchTrips(event).subscribe((result: any) => {
      this.rowData = result.trips;
      this.pagination.pageNumber = result.pagination.currentPage !=0 ? result.pagination.currentPage: 1;
      this.totalRecords = result.pagination.totalRecords;
      console.log("rowdata trips:", this.rowData)
    });
  }

  TripIds:any[]=[];
  onSelectionChanged(event: any) {
    if(event.api.getSelectedNodes().length >0){
      this.loadSelected = true;
    }else{
      this.loadSelected = false;
    }
    console.log("called" , event.api.getSelectedNodes())

    this.TripIds=[];
    console.log("called trip" ,event.api.getSelectedNodes()[0].data)
    event.api.getSelectedNodes().forEach((element:any) => {
      this.TripIds.push(element.data.tripId)
    });
    // this.selectedTripGridObj = event.api.getSelectedNodes()[0].data;
    // this.tripId = this.selectedTripGridObj.tripId;

  }
  searchForm: any;
  ServiceList(event: any) {
    this.searchForm = event;
    this.searchServices
      .getSearchListreconcile(event)
      .subscribe((result: any) => {
        this.rowData = result.services;
        this.pagination.pageNumber = result.pagination.currentPage;
        this.totalRecords = result.pagination.totalRecords;
      });
  }

  /**
   * need runsheet id here(https://axiom2-uat.tollgroup.com/api/v1/d/runsheet/3046119/add-line-by/trip)
   * and also post data that we have to send
   * 
   */
  runSheetLine: any;
  Result_check:any[]=[]
  addTripRunsheet() {
    this.reconsileService.setSelectedItemType('detail-page');
    this.Result_check=[];
    /*Multiple Lines Started*/
    this.TripIds.forEach(tripid=>{
       this.addServiceService.getServices(this.runsheetApiData.id, tripid, 4, 'trip').subscribe((runsheetLine: any) => {
      // this.Result_check.push(result)
      // this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(result);

      runsheetLine = runsheetLine.map((item: any) => ({
        ...item,
        lineTemperature: Object.keys(item.lineTemperature).some(function (key) {
          return (
            ["deliverydate", "id"].indexOf(key) > -1 &&
            item.lineTemperature[key] != null
          );
        })
          ? item.lineTemperature
          : null,
      }));
      console.log("service Line", runsheetLine);   
      this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(runsheetLine);
      // this.runsheetService.updateRunsheetPUT(this.runsheetApiData).subscribe((result:any)=>{
      //   this.runsheetFormService.emitRunseetSubsCribeData(result);
      // });
      // Add the new runSheetLine object to the runsheetLines array
      this.runsheetService.updateRunsheetPUT(this.runsheetApiData).subscribe((result:any)=>{
        this.runsheetFormService.emitRunseetSubsCribeData(result);
      });
    })
  });



  //   this.addServiceService.getServices(this.runsheetApiData.id, this.tripId, 4, 'trip').subscribe((result: any) => {
  //     this.runSheetLine = result;
  //     console.log(this.runSheetLine);
  //     this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(this.runSheetLine);
  //     // Add the new runSheetLine object to the runsheetLines array
  //     this.runsheetService.updateRunsheetPUT(this.runsheetApiData).subscribe((result:any)=>{
  //     });
  // });
  /**this is for reload the Search-load data only after adding the load in runsheet-line */
  this.ServiceList(this.searchForm);
  }

  getRunsheet() {
    this.addServiceService._allRunsheetSubject.subscribe((runsheetArr: any) => {
      this.runsheetData = runsheetArr;
    })
  }

  getRunsheetIDApiData(runsheetId: any) {
    this.reconcileService
      .getViewRunsheetId(runsheetId)
      .subscribe((apiData: any) => {
        this.runsheetApiData = apiData.runsheet;
  
        console.log('runsheetApiData assd Api Data', this.runsheetApiData);
      });
  }

  
  
}

import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import * as moment from 'moment';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-load-form',
  templateUrl: './load-form.component.html',
  styleUrls: ['./load-form.component.scss']
})
export class LoadFormComponent {

  @Output() searchDetails = new EventEmitter<any>();
  serviceForm: FormGroup;
  currentTime: Date = new Date();
  previousDate: Date = new Date(new Date((new Date()).setDate((new Date()).getDate() - 14)).setHours(0, 0, 0, 0));
  drivers: { id: any, name: string }[] = [];
  companyId: { id: any, name: string }[] = [];
  routes: { id: any, name: string }[] = [];
  companyTypes: { id: any, name: string }[] = [];
  truckId: { id: any, name: string }[] = [];
  trailer: { id: any, name: string }[] = [];
  locations: { id: any, name: string }[] = [];
  siteUsers: { id: any, name: string }[] = [];
  serviceType: { id: any, name: string }[] = [];
  loadType: any[] = [];
  customer: { id: any, name: string }[] = [];

  searchForm: any = {};

  constructor(
      private sharedServices: SharedService,
      private timeService:TimeRunsheetService
  ) {
  }

    /**Drop down  */
    selectedloadType: any;
    filteredloadType: any[];
    filteredCompanie(event: any) {
      let filtered: any[] = [];
      let query = event.query;

  
      for (let i = 0; i < this.loadType.length; i++) {
        let load = this.loadType[i];
        if (load.toLowerCase().includes(query.toLowerCase())) {
          filtered.push(load);
        }
      }
      this.filteredloadType = filtered;
    }

  ngOnInit() {
      this.getSearchFormWithDropDown();
      this.serviceForm = new FormGroup({
          loadNo: new FormControl(''),
          from: new FormControl(''),
          to: new FormControl(''),
          loadType: new FormControl(''),
          batchNo: new FormControl(''),
      });
  }

  getSearchFormWithDropDown() {
      this.sharedServices.getContextView().subscribe((result: any) => {
          this.drivers = this.sharedServices.getDriverList(result.ref.drivers);
          this.truckId = this.sharedServices.getTruckList(result.ref.trucks);
          this.trailer = this.sharedServices.getTrailerList(result.ref.trailers);
          result.ref.locations.map((location: any)=> {
              if (location.active) {
                  let loactionName = [location.locationId, location.accShortCut ?  " ( " + location.accShortCut + " )" : ''].filter(function (val) {
                      return val;
                  }).join(' ');
                  this.locations.push({id: loactionName , name: loactionName});
              }
          });
          result.ref.companys.map((company: any) => {
              if (company.active)
                  this.companyId.push({ id: company.companyId, name: company.companyId });
          });
          result.ref.companyTypes.map((company: any) => {
              if (company.active)
                  this.companyTypes.push({ id: company.companyTypeId, name: company.companyTypeId });
          });

          result.ref.serviceTypes.map((serviceType: any) => {
              if (serviceType.active)
                  this.serviceType.push({ id: serviceType.serviceTypeId, name: serviceType.serviceTypeId });
          });

          result.ref.loadTypes.map((loaType: any) => {
              if (loaType.active)
                  this.loadType.push(loaType.loadTypeId );
          });

          result.ref.userDatas.map((userData: any) => {
              let useraName = userData.userName + " ("+ userData.userId +" )";
              this.siteUsers.push({ id: userData.userId, name: useraName});
          });

          result.ref.customers.map((customer: any) => {
              if (customer.active){
                  this.customer.push({ id: customer.customerId, name: customer.customerId});
              }
          });

          this.updateSearchFormFields();
      });
  }

  updateSearchFormFields() {
      this.searchForm = {
          displayName: 'Services',
          name: 'Search.Services',
          endpoint: '/search/service/',
          fields: [
              {
                  name: 'loadNo',
                  displayName: 'Load No.',
                  required: false,
                  readonly: false,
                  hidden: false,
                  updatable: true,
                  defaultValue: null,
                  type: 'TEXT'
              }, 
              {
                  name: 'from',
                  displayName: 'Schedule From',
                  required: false,
                  readonly: false,
                  hidden: false,
                  updatable: true,
                  defaultValue: this.previousDate,
                  type: 'DATE'
              }, 
              {
                  name: 'to',
                  displayName: 'Schedule To',
                  required: false,
                  readonly: false,
                  hidden: false,
                  updatable: true,
                  defaultValue: this.currentTime,
                  type: 'DATE'
              }, 
              {
                  name: 'loadType',
                  displayName: 'Load Type',
                  required: false,
                  readonly: false,
                  hidden: false,
                  updatable: true,
                  defaultValue: null,
                  reference: 'loadType',
                  dropDownList: this.loadType,
                  type: 'REFERENCE'
              },
              {
                name: 'batchNo',
                displayName: '1111B',
                required: false,
                readonly: false,
                hidden: false,
                updatable: true,
                defaultValue: null,
                type: 'TEXT'
            }, 
        ],
      };
  }

  updateValue(controlName: string, newValue: any) {
      this.serviceForm.get(controlName)?.setValue(newValue);
  }
  /**
   * When we are submitting form
   * check some condition when Submitting form
   */
  fixTime(milliseconds:number):number{
    let t = this.timeService.convertMillisecondsToDateTime2(milliseconds);
    console.log(t)

    let _date;
    _date = moment(t);
    _date = _date
      .set({
        hour: 0,
        minute: 0,
        second: 0,
      })
      .format('YYYY-MM-DD HH:mm:ss');
    var s_australia_time = moment.tz(_date, 'Australia/Melbourne');
    var s_india = s_australia_time.clone().tz('Asia/Kolkata');
    return moment(s_india).valueOf();
  }
  onSubmit() {
    //set values of from and to by fixing the time
      let formValues = this.serviceForm.value;
      formValues.from = this.fixTime(formValues.from);
      formValues.to = this.fixTime(formValues.to);

    //   if (formValues.from instanceof Date) {
    //       formValues.from = formValues.from.getTime();
    //   }
    //   if (formValues.to instanceof Date) {
    //       formValues.to = formValues.to.getTime();
    //   }
      if(this.selectedloadType){
        formValues.loadType = this.selectedloadType
      }

      this.searchDetails.emit(formValues);
      console.log(formValues);
  }

}

import { Component, OnChanges } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReconcileService } from '../../services/reconcile.service';
import {
  ReasonCode,
  Runsheet,
} from '../../view-runsheet-form/ViewRunsheetId.model';
import { RunsheetFormService } from '../../services/runsheet-form.service';
import { reasonsCode } from 'src/app/features/setup/models/setup.model';
import { ActivatedRoute } from '@angular/router';
import { DetailService } from '../detail.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-reason-detail',
  templateUrl: './reason-detail.component.html',
  styleUrls: ['./reason-detail.component.scss'],
})
export class ReasonDetailComponent implements OnChanges {
  reasonDetailForm: FormGroup;
  reasonCode: any[] = [];
  filteredReasons: any[] = [];
  reasonCodeUnique: any[] = [];
  selectedReasonId: any[] | any;
  isNew: boolean = true;
  reasonLinesObj = {
    id: null,
    reasonId: null,
    siteId: null,
    reasoncomment: null,
    reasonrefEvent: null,
    reasonrefRunsheet: null,
    reasonrefService: null,
  };

  reasonApiData: any[] = [];
  runsheetId: any;

  runsheetLookApidata: any[] = [];
  runsheetAPiParent: any;

  constructor(
    private fb: FormBuilder,
    private reconsileService: ReconcileService,
    private runsheetFormService: RunsheetFormService,
    private activatedRoute: ActivatedRoute,
    private detailService: DetailService,
    private authenticationService: AuthenticationService,
  ) {
    this.reasonDetailForm = this.fb.group({
      reasons: this.fb.array([]),
    });
  }

  
  ngOnChanges() {
    this.runsheetAPiParent = this.detailService?.runseetReasonApidata; 
    console.log("ngon change call", this.runsheetAPiParent);
    
    this.runsheetLookApidata = this.detailService?.runseetLookupApidata?.runsheet?.runsheetLines;
    console.log("lookup api Response",this.runsheetLookApidata);
    
   }

  ngOnInit() {
    this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
      this.runsheetAPiParent = this.detailService?.runseetReasonApidata; 
      console.log("runsheetAPiParent reason", this.runsheetAPiParent);
      
    // this.getReasonCode();
    this.getRefData();
    this.addReasonDetail();
    if(this.runsheetId) {
      this.getReasonApiData(this.runsheetId);
    } else {
        this.runsheetLookApidata = this.detailService?.runseetLookupApidata?.runsheet;
        console.log("lookup api Response",this.runsheetLookApidata);
        if(this.runsheetAPiParent) {
          this.reasonApiData = this.runsheetAPiParent?.reasonLines;
          this.createReasons(this.reasonApiData);
          this.setValues(this.reasonApiData);
        }
     
    }
    this.reasonDetailForm.valueChanges.subscribe((res) => {
      this.runsheetFormService.reasonDetailForm =
        this.reasonDetailForm.getRawValue();
    });
  }

  getRefData() {
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        // this.isLoading = false;
        this.getReasonCode(result['ref'].reasons);
  
      }
    });
  }

  getReasonApiData(runsheetId: any) {
    this.reconsileService
      .getViewRunsheetId(runsheetId)
      .subscribe((apiData: any) => {
        this.reasonApiData = apiData.runsheet.reasonLines;
        this.createReasons(this.reasonApiData);
        this.setValues(this.reasonApiData);

        console.log('Reason Api Data', this.reasonApiData);
      });
  }
  createServiceLineForm() {
    this.reasonDetailForm = this.fb.group({
      reasonId: ['', Validators.required],
      reasoncomment: ['', Validators.required],
    });
  }

  reasons(data?: any): FormArray {
    return this.reasonDetailForm.get('reasons') as FormArray;
  }

  newResonDetail(): FormGroup {
    return this.fb.group({
      reasonId: ['', Validators.required],
      reasoncomment: ['', Validators.required],
    });
  }

  addReasonDetail() {
    this.reasons().push(this.newResonDetail());
  }
  createReasons(data: any) {
    if (data && data.length > 0) {
      //const fArry = this.reasonDetailForm.get('reasons') as FormArray;
      this.reasonApiData.forEach((data, index: number) => {
        this.addReasonDetail();
      });
    }
  }

  setValues(data: any) {
    if (data && data.length > 0) {
      const fArry = this.reasonDetailForm.get('reasons') as FormArray;
      this.reasonApiData.forEach((data1, index: number) => {
        fArry.controls[index].patchValue({
          reasonId: data1.reasonId,
          reasoncomment: data1.reasoncomment,
        });
      });
    }
  }

  removeReasonDetail(resonIndex: number) {
    this.reasons().removeAt(resonIndex);
  }

  getReasonCode(reasonCodes: any) {
    // this.reconsileService.getReasonCode().subscribe((reasonCodes: any) => {
      this.reasonCode = [];
      reasonCodes.map((reasonDrop: ReasonCode) => {
        if (reasonDrop.reasonId !== null) {
          // const reasonCodeFormat =
          // this.reconsileService.getReasonIdVal(reasonDrop);
          this.reasonCode.push(reasonDrop.reasonId);
        }
      });
    // });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;
    this.reasonCode.map((reason: any) => {
      const resonId = reason.split('-')[0];

      if (resonId.toLowerCase().includes(query.toLowerCase())) {
        reasonArr.push(resonId);
      }
    });
    this.filteredReasons = reasonArr;
  }
  buttonEnable :boolean =  false;
  onChangeReason(selectedReasonCode: any) {
    this.buttonEnable = true;
    let extractReasonCode = selectedReasonCode.split('_')[0];
    this.reasonCodeUnique = extractReasonCode;
    this.addReasonDetail();
  }

  sendData() {
    this.runsheetFormService.sendReasonFormData(this.reasonDetailForm);
    return null;
  }
  ok: boolean = false;
  closeDialog(){
    // this.isNew = false;
    // this.ok = false;
    // this.reconsileService.selectedItemType.next('reason-lines');
    /**
     * this method is to negivate to detail page 
     */
    this.reconsileService.setSelectedItemType('detail-page');


  }
}

export interface RunsheetDetail {
  id: number;
  locationContDropId: any;
  locationContPickupId: any;
  locationDropId: string;
  locationPickupId: string;
  locationReturnId: string;
  serviceId: number;
  trailerId: string;
  containerId: any;
  loadTypeId: string;
  trailerTagId: string;
  serviceTypeId: string;
  rateId: string;
  truckId: string;
  siteId: number;
  qty1: any;
  unit1: any;
  qty2: any;
  unit2: any;
  qty3: any;
  unit3: any;
  qty4: any;
  unit4: any;
  qty5: any;
  unit5: any;
  qty6: any;
  unit6: any;
  qty7: any;
  unit7: any;
  qty8: any;
  unit8: any;
  owntrailer: boolean;
  offsiderused: boolean;
  pickuparrivetime: number;
  pickupdeparttime: number;
  droparrivetime: number;
  dropreadytime: any;
  dropdeparttime: number;
  docket: any;
  payamt: number;
  payestimated: boolean;
  directfromdepot: boolean;
  remarks: string;
  nextstoptime: any;
  tripkm: number;
  paydesc: string;
  pickupreadytime: any;
  dropdoctime: any;
  pickupdoctime: any;
  createdby: string;
  tripno: number;
  tripseq: number;
  servicehours: any;
  hiretruck: boolean;
  globaldropbonus: any;
  deliverydate: any;
  tripodostart: any;
  tripodoend: any;
  groupseq: any;
  tripstarttime: number;
  tripendtime: number;
  lineTemperature: any;
  lineServiceTO: LineServiceTo;
  events: any;
  loadNoDuplicated: any;
}

export interface LineServiceTo {
  serviceId: number;
  dataSource: string;
  created: number;
  tripIdCust: any;
  serviceGroup: any;
  serviceDesc: any;
  customerId: string;
  consignmentMasterCustomerId: string;
  loadId: number;
  serviceNo: string;
  reasonId: string;
  chargeAmt: any;
  chargeDesc: any;
  rateId: any;
  complete: boolean;
  loadNo: string;
  batchNo: string;
  custRef: string;
  scheduleDate: number;
  despatchBy: any;
  deliveryOpen: any;
  deliveryClose: any;
  returnLocationId: any;
  pickupLocation: PickupLocation;
  dropLocation: DropLocation;
  loadLocation: LoadLocation;
  lastGroupSeq: any;
  clearCharge: boolean;
  totalChargeAmt: any;
  svcReasonLines: any;
  dehireDeadline: any;
  vesselEta: any;
  vesselId: number;
  priority: any;
  wharf: string;
  depot: string;
  customerSite: string;
  dehirePark: string;
  originSite: number;
  originLoc: string;
  destinationSite: number;
  destinationLoc: string;
}

export interface PickupLocation {
  locationId: string;
  siteId: number;
  locationTypeId: any;
  locationDesc: string;
  zonePayId: string;
  zoneChargeId: string;
  suburb: any;
  active: any;
  loadTimeMins: any;
  address1: any;
  address2: any;
  state: any;
  postCode: any;
  window1From: any;
  window1To: any;
  window2From: any;
  window2To: any;
  window3From: any;
  window3To: any;
  personIdContact: any;
  personIdContactName: any;
  customerId: any;
  locationCode: any;
  latitude: any;
  longitude: any;
  geofence: any;
  mapSourceId: any;
  mapReference: any;
  remarks: any;
  truckSizeLimit: any;
  defaultTripSeq: any;
  routeId: any;
  permanent: any;
  loadTimeMinsPerUnit: any;
  loadTimeUnit: any;
  waitTimeMins: any;
  waitTimeMinsPerUnit: any;
  waitTimeUnit: any;
  accShortCut: any;
  locationIdGroup: any;
  siteTravelTime: any;
  disableWPUpdated: any;
  externalLookUp: any;
  internalLookUp: any;
  segManaged: any;
  segExported: any;
  routeCapacity: any;
}

export interface DropLocation {
  locationId: string;
  siteId: number;
  locationDropId: string;
  locationTypeId: any;
  locationDesc: string;
  zonePayId: string;
  zoneChargeId: string;
  suburb: string;
  active: any;
  loadTimeMins: any;
  address1: any;
  address2: string;
  state: any;
  postCode: any;
  window1From: any;
  window1To: any;
  window2From: any;
  window2To: any;
  window3From: any;
  window3To: any;
  personIdContact: any;
  personIdContactName: any;
  customerId: any;
  locationCode: any;
  latitude: any;
  longitude: any;
  geofence: any;
  mapSourceId: any;
  mapReference: any;
  remarks: any;
  truckSizeLimit: any;
  defaultTripSeq: any;
  routeId: any;
  permanent: any;
  loadTimeMinsPerUnit: any;
  loadTimeUnit: any;
  waitTimeMins: any;
  waitTimeMinsPerUnit: any;
  waitTimeUnit: any;
  accShortCut: any;
  locationIdGroup: any;
  siteTravelTime: any;
  disableWPUpdated: any;
  externalLookUp: any;
  internalLookUp: any;
  segManaged: any;
  segExported: any;
  routeCapacity: any;
}

export interface LoadLocation {
  locationId: string;
  siteId: number;
  locationTypeId: any;
  locationDesc: string;
  zonePayId: any;
  zoneChargeId: any;
  suburb: any;
  active: any;
  loadTimeMins: any;
  address1: any;
  address2: any;
  state: any;
  postCode: any;
  window1From: any;
  window1To: any;
  window2From: any;
  window2To: any;
  window3From: any;
  window3To: any;
  personIdContact: any;
  personIdContactName: any;
  customerId: any;
  locationCode: any;
  latitude: any;
  longitude: any;
  geofence: any;
  mapSourceId: any;
  mapReference: any;
  remarks: any;
  truckSizeLimit: any;
  defaultTripSeq: any;
  routeId: any;
  permanent: any;
  loadTimeMinsPerUnit: any;
  loadTimeUnit: any;
  waitTimeMins: any;
  waitTimeMinsPerUnit: any;
  waitTimeUnit: any;
  accShortCut: any;
  locationIdGroup: any;
  siteTravelTime: any;
  disableWPUpdated: any;
  externalLookUp: any;
  internalLookUp: any;
  segManaged: any;
  segExported: any;
  routeCapacity: any;
}

export interface OriginLoc {
  siteId: number;
  siteDesc: string;
}

export interface breakType {
  drivershiftId: any;
  locationId: string;
  tripId: any;
  locationPlannedId: any;
  siteId: number;
  breakTypeId: string;
  driverId: any;
  breakstarttime: number;
  breakendtime: number;
  commentA: string;
  planned: boolean;
  plannedstarttime: any;
  plannedendtime: any;
  deducted: boolean;
}

export interface breakypeIdData {
  active: boolean;
  breakPaid: boolean;
  description: string;
  maxLength: any;
  minLength: any;
  minutes: any;
  siteId: string;
  typeId: string;
}

export interface BreaktypeResponse {
  id: number
  drivershiftId: any
  locationId: string
  tripId: any
  locationPlannedId: any
  siteId: number
  breakTypeId: string
  driverId: any
  breakstarttime: number
  breakendtime: number
  commentA: string
  planned: boolean
  plannedstarttime: any
  plannedendtime: any
  deducted: boolean
}

export interface TripData {
  truckId: any,
  customerId: any,
  returnto: any,
  trailerId: any,
  trailerTagId: any,
  tripodostart: any,
  tripodoend: any,
  tripstarttime: Date,
  tripendtime: Date,
  hiretruck: any,
  owntrailer: boolean,
  offsiderused: any,
}

export interface TripResponse {
  hiretruck?: boolean;
  locationReturnId?: string;
  offSiderUsed?: boolean;
  ownTrailer?: boolean;
  trailerId: string;
  tripOdoEnd?: any;
  tripOdoStart?: any;
  tripendtime?: any;
  tripno?: number;
  tripseq?: string;
  tripstarttime?: any;
  truckId?: string;
  trailerIdTag?: string;
}

export interface ServiceUnitKeys {
  unit: any;
  qty: any;
  userId: any
  id: any
  title: any
  completed: any
}
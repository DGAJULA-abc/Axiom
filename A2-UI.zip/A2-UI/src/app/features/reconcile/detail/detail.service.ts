import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { RunsheetConfig } from '../view-runsheet-form/ViewRunsheetId.model';

@Injectable({
  providedIn: 'root',
})
export class DetailService {
  constructor() {}
  private _runseetLookupdata: any;
  private _runseetStateData: RunsheetConfig = {
    runsheetTypeId: null,
    displayLookupButton: false,
    displayNextRunsheetButton: false,
    deliveryDateStamp: null,
    enddateStamp: null,
    shiftId: null,
    showLookup: false,
    showGrid: false,
    showTime: false,
    StartEndKMSwappedCondition: false,
    completed: false,
    formEnabled: false,
    locked: false,
  };
  private _viewformstartandenddat:any;

  _runsheetBreakTimeValid: any;
  private _runseetReasonApidata: any;

   extractTripSeq(str: any) {
    let matches = str.match(/\d+/);
    return matches ? matches[0] : null;
}

  extractTruckId(str: any) {
    let matches = str.match(/[A-Z0-9-]+/);
    return matches ? matches[0] : null;
  }

  extractTrailerId(str: any) {
    let matches = str.match(/^([^(\s]+)/); 
    return matches ? matches[0] : null;
  }

  extractReturnLoc(str: any) {
    let matches = str.match(/[0-9]+-[A-Z]+/);
    return matches ? matches[0] : null;
  }

  convertAusTimeZone(dateString: any) {
    // Your date string
    // let dateString = 'Mon Jan 15 2024 11:16:14 GMT+0530 (India Standard Time)';

    // Parse the date in IST timezone
    let dateInIST = moment.tz(dateString, 'Asia/Kolkata');

    // Convert to Australian Eastern Standard Time (AEST)
    let dateInAEST = dateInIST.tz('Australia/Sydney');

    // Get the timestamp
    let timestamp = dateInAEST.valueOf();

    console.log(timestamp); // This will print the timestamp in AEST timezone

    return timestamp
  }

    get runsheetStateConf() {
       return this._runsheetBreakTimeValid;
    }

    set runsheetStateConf(value: any) {
      this._runsheetBreakTimeValid = value;
    }

    get runsheetBreakTime() {
      return this._runseetStateData;
   }

   set startandenddate(value:any){
    this._viewformstartandenddat=value;
   }

   get startandenddate(){
    return this._viewformstartandenddat;
   }

   set runsheetBreakTime(value: any) {
     this._runseetStateData = value;
   }

   get runseetLookupApidata() {
    return this._runseetLookupdata;
 }

 set runseetLookupApidata(value: any) {
   this._runseetLookupdata = value;
 }

 get runseetReasonApidata() {
  return this._runseetReasonApidata;
}

set runseetReasonApidata(value: any) {
 this._runseetReasonApidata = value;
}

 getFullLocationDescription(matchLocation: any) {
 const fullLocation = `${matchLocation?.address1 ?? ''}, ${matchLocation?.suburb ?? ''}, ${matchLocation?.state ?? ''}, ${matchLocation?.postCode ?? ''}`
  .split(',')  // Split the string into an array by commas
  .map(s => s.trim())  // Trim whitespace from each part
  .filter(Boolean)  // Remove empty strings
  .join(', ');  // Join the array back into a string with commas

  return fullLocation;

 }

}

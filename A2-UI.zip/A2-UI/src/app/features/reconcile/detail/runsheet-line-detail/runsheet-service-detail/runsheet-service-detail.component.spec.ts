import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RunsheetServiceDetailComponent } from './runsheet-service-detail.component';

describe('RunsheetServiceDetailComponent', () => {
  let component: RunsheetServiceDetailComponent;
  let fixture: ComponentFixture<RunsheetServiceDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RunsheetServiceDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RunsheetServiceDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

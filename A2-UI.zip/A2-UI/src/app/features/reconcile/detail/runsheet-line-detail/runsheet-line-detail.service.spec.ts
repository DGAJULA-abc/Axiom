import { TestBed } from '@angular/core/testing';

import { RunsheetLineDetailService } from './runsheet-line-detail.service';

describe('RunsheetLineDetailService', () => {
  let service: RunsheetLineDetailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RunsheetLineDetailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

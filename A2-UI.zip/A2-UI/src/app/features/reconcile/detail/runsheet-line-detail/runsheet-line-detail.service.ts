import { Injectable } from '@angular/core';
import { RunsheetLine } from '../../view-runsheet-form/ViewRunsheetId.model';
import * as _ from 'lodash';
import { ReferenceDataService } from '../../services/reference-data.service';

@Injectable({
  providedIn: 'root',
})
export class RunsheetLineDetailService {
  constructor(private RefDataService: ReferenceDataService) {}

  /**
   * @ngdoc function
   * @description
   * Create a unique temp id
   * @return {string} temp id
   */

  private _gridDataArrayServiceDetail: any[] = [];

  get gridDataArrayServiceDetail(): any {
   
    console.log("get line", this._gridDataArrayServiceDetail);
    
  return this._gridDataArrayServiceDetail;
  
  // .map((line: any) => {
  //   console.log("get line", line);
  //   return line
  //   // return{    
  //   //   id: line.id.toString().indexOf('temp') > -1 ? null: line.id,
  //   //   ...line
  //   // }
  // });

    // const dataArr = {
    //   runsheet: {
    //     "id": null,
    //     "tripseq": null,
    //     "loadTypeId": "B-DOUBLE",
    //     "serviceTypeId": "DELVIERY",
    //     "locationPickupId": null,
    //     "locationDropId": null,
    //     "locationReturnId": null,
    //     "payamt": null,
    //     "docket": null,
    //     "containerId": null,
    //     "truckId": null,
    //     "trailerId": null,
    //     "trailerTagId": null,
    //     "createdby": null,
    //     "qty1": null,
    //     "qty2": null,
    //     "qty3": null,
    //     "qty4": null,
    //     "qty5": null,
    //     "qty6": null,
    //     "qty7": null,
    //     "qty8": null,
       
    //     "lineServiceTO": {
    //         "customerId": "1052601",
    //         "pickupLocation": {
    //             "locationDesc": null,
    //             "zoneChargeId": null,
    //             "zonePayId": null
    //         },
    //         "dropLocation": {
    //             "locationDesc": null,
    //             "zoneChargeId": null,
    //             "zonePayId": null
    //         },
    //         "batchNo": null,
    //         "custRef": null,
    //         "loadLocation": {
    //             "locationDesc": null
    //         },
    //         "vesselId": null,
    //         "serviceGroup": null,
    //         "loadNo": null,
    //         "tripIdCust": null,
    //         "complete": null,
    //         "chargeAmt": null,
    //         "serviceNo": null
    //   }

    //     }
    //   };
  
    // return gridData;
  }
  
  set gridDataArrayServiceDetail(value: any) {
    // value.map((lines: any) => {
    //   if(!lines.isTrip) {
    //     this._gridDataArrayServiceDetail = value.map((line: any) => {
    //       if (line.id.indexOf("temp") > -1) {
    //         return { ...line, id: null };
    //       }
    //       return line;
    //     });
    //   }
    // })
    // this._gridDataArrayServiceDetail = value.map((line: any) => {
    //   if (!line.isTrip && line?.id.toString().indexOf("temp") > -1) {
    //     return { ...line, id: null };
    //   }
    //   return line;
    // })
    const filteredTrip = value.filter((item: any) => !item.isTrip);
    this._gridDataArrayServiceDetail = filteredTrip.map((line: any) => {
      // delete line.seqDisplay;
      delete line.tripname;
      if (line?.id.toString().indexOf("temp") > -1) {
        return { ...line, id: null };
      }
      return line;
    })
    console.log("line >>>>", this._gridDataArrayServiceDetail);
  }
  createTempId() {
    return 'temp' + Math.ceil(new Date().getTime() * Math.random());
  }

  private _gridDataArrayBreakDetail: any[] = [];

  get gridDataArrayBreakDetail(): any {
   
    
  return this._gridDataArrayBreakDetail;
  
  }
  
  set gridDataArrayBreakDetail(value: any) {
    this._gridDataArrayBreakDetail = value;
  
    // const filteredTrip = value.filter((item: any) => !item.isTrip);
    // this._gridDataArrayBreakDetail = filteredTrip.map((line: any) => {
    //   delete line.seqDisplay;
    //   delete line.tripname;
    //   if (line?.id.toString().indexOf("temp") > -1) {
    //     return { ...line, id: null };
    //   }
    //   return line;
    // })
  }

  

  /**
   * duplicate runsheetLines from a runsheet
   * @param {Object} selectedRunsheetLines
   * @param {Array} runsheetLines
   */
  selectLineArr: any[];
  duplicateRunsheetLines(
    selectedRunsheetLines: any,
    runsheetLines: RunsheetLine[],
    copyNumber: number
  ): any[] {
    this.selectLineArr = [selectedRunsheetLines];
    const isSelectLineArr = [selectedRunsheetLines].some(
      (line: any) => line.isTrip
    );
    if (isSelectLineArr) {
      return this.duplicateRunsheetLinesByTrip(
        this.selectLineArr,
        runsheetLines,
        copyNumber
      );
    } else {
      let line=[];
      line.push(selectedRunsheetLines)
      return this.duplicateRunsheetLinesByService(
        line,
        runsheetLines,
        copyNumber
      );
    }
  }

  duplicateRunsheetLinesByTrip(
    selectedRunsheetLines: RunsheetLine[],
    runsheetLines: RunsheetLine[],
    copyNumber: number
  ): RunsheetLine[] {
    selectedRunsheetLines.forEach((selectedRunsheetLine) => {
      const tripRunsheetLines = this.getLinesByTrip(
        runsheetLines,
        selectedRunsheetLine.tripno
      );
      for (let i = 0; i < copyNumber; i++) {
        const linesToAdd = JSON.parse(JSON.stringify(tripRunsheetLines));
        const tripNo = this.maxTripNoInRunsheetLines(runsheetLines) + 1;
        linesToAdd.forEach((line: any) => {
          line = this.cleanLineForNew(line);
          line.tripno = tripNo;
          runsheetLines.push(line);
        });
      }
    });
    return this.refreshRunsheetLines(runsheetLines);
  }

  duplicateRunsheetLinesByService(
    selectedRunsheetLines: RunsheetLine[],
    runsheetLines: RunsheetLine[],
    copyNumber: number
  ): RunsheetLine[] {
    selectedRunsheetLines.forEach((selectedRunsheetLine) => {
      for (let i = 0; i < copyNumber; i++) {
        const runsheetLineCopy: RunsheetLine = { ...selectedRunsheetLine }; // Shallow copy, change to deep copy if necessary
        runsheetLines = this.addDuplicateRunsheetLines(
          runsheetLineCopy,
          runsheetLines
        );
      }
    });

    return this.refreshRunsheetLines(runsheetLines);


  }

  getLinesByTrip(runsheetLines: RunsheetLine[], targetTripNo: any) {
    return _.filter(runsheetLines, function (line) {
      return line.tripno === targetTripNo;
    });
  }

  maxTripNoInRunsheetLines(runSheetLines: any[]) {
    return _.maxBy(runSheetLines, 'tripno').tripno;
  }

  cleanLineForNew(duplicateLine: any) {
    delete duplicateLine.serviceId;
    if (_.get(duplicateLine, 'lineServiceTO.loadId')) {
      // delete duplicateLine.lineServiceTO.loadId;
    }
    duplicateLine.id = this.createTempId();
    delete duplicateLine.lineServiceTO.serviceNo;
    delete duplicateLine.lineServiceTO.tripIdCust;
    // if (!RefDataService.getUserOptionValue('RSL.Dup.Locs')) {
    _.set(duplicateLine, 'lineServiceTO.dropLocation.locationDesc', null);
    _.set(duplicateLine, 'lineServiceTO.dropLocation.locationId', null);
    _.set(duplicateLine, 'lineServiceTO.pickupLocation.locationDesc', null);
    _.set(duplicateLine, 'lineServiceTO.pickupLocation.locationId', null);
    _.set(duplicateLine, 'locationDropId', null);
    _.set(duplicateLine, 'locationPickupId', null);
    // }
    // if (!RefDataService.getUserOptionValue('RSL.Dup.Loads')) {
    _.set(duplicateLine, 'lineServiceTO.loadNo', null);
    // }
    // if (!RefDataService.getUserOptionValue('RSL.Dup.Qtys')) {
    for (var i = 1; i <= 8; i++) {
      _.set(duplicateLine, 'qty' + i, null);
    }
    // }
    // if (!RefDataService.getUserOptionValue('RSL.Dup.Times')) {
    _.set(duplicateLine, 'droparrivetime', null);
    _.set(duplicateLine, 'dropdeparttime', null);
    _.set(duplicateLine, 'dropdoctime', null);
    _.set(duplicateLine, 'dropreadytime', null);
    _.set(duplicateLine, 'pickuparrivetime', null);
    _.set(duplicateLine, 'pickupdeparttime', null);
    _.set(duplicateLine, 'pickupdoctime', null);
    _.set(duplicateLine, 'pickupreadytime', null);
    // }
    return duplicateLine;
  }

  /**
   * @ngdoc function
   * @description
   * Refresh tripno, tripseq (TODO and groupseq) of an array of runsheetLines
   * New items go to the end
   * update tripno and tripseq (TODO groupseq) to ensure contiguity
   * nb output is not sorted
   * @param {Array} runsheetLines runsheetLines to process
   * @return {Array} updated runsheetLines
   */
  refreshRunsheetLines(runsheetLines: RunsheetLine[]): RunsheetLine[] {
    // Create hash of runsheet lines grouped by tripno
    const runsheetLinesByTripObject = (runsheetLines || []).reduce(
      (result, runsheetLine) => {
        const tripno = runsheetLine.tripno || 0;
        result[tripno] = result[tripno] || [];
        result[tripno].push(runsheetLine);
        return result;
      },
      {} as Record<number, RunsheetLine[]>
    );

    // Convert to array and sort by tripno
    Object.keys(runsheetLinesByTripObject)
      .map((key) => runsheetLinesByTripObject[+key])
      .sort((a, b) => (a[0]?.tripno || 99999) - (b[0]?.tripno || 99999))
      .forEach((runsheetLinesByTripArray, i) => {
        runsheetLinesByTripArray
          .sort(
            (a, b) =>
              (a.tripseq || 99999) - (b.tripseq || 99999) ||
              (a.groupseq || 99999) - (b.groupseq || 99999)
          )
          .reduce(
            (currentTripseq, runsheetLine, index, runsheetLinesByTripArray) => {
              currentTripseq =
                runsheetLine.groupseq > 1 ? currentTripseq : currentTripseq + 1;
              runsheetLine.tripno = i + 1;
              runsheetLine.tripseq = currentTripseq;
              runsheetLine.seqDisplay = this.getDisplaySeq(runsheetLine);
              runsheetLine.lineServiceTO = runsheetLine.lineServiceTO || {};
              runsheetLine.lineServiceTO.serviceGroup = this.getServiceGroup(
                runsheetLine,
                runsheetLinesByTripArray
              );
              return currentTripseq;
            },
            0
          );
      });

    runsheetLines.sort(
      (a, b) =>
        a.tripno - b.tripno || a.tripseq - b.tripseq || a.groupseq - b.groupseq
    );
    console.log('runsheetLines End >>', runsheetLines);

    return runsheetLines;
  }

  /**
   * @ngdoc function
   * @description Format the tripno, tripseq and groupseq as a string for display
   * @param {Object} rsl runsheet line
   * @return {string}     formatted string
   */

  getDisplaySeq(rsl: any) {
    return rsl.isTrip
      ? 'Trip ' + rsl.tripno
      : [rsl.tripno, rsl.tripseq, rsl.groupseq]
          .filter(function (element) {
            return !!element;
          })
          .join('.');
  }

  /**
   * @ngdoc function
   * @description
   * set servicegroup for runsheetline
   * Only applies to consolidated rsls (ie !!runsheetLine.groupseq)
   * Find the rsl with matching tripno and tripseq and groupseq === 1
   * Return the last 4 chars of its service number
   *
   * @param {Object} targetRunsheetLine  runsheet line to get service group for
   * @param {Object} runsheetLines runsheet lines to search in
   * @return {string}               service group
   */

  getServiceGroup = function (targetRunsheetLine: any, runsheetLines: any) {
    return (runsheetLines || []).reduce(function (
      serviceGroup: any,
      runsheetLine: any
    ) {
      return runsheetLine.tripno === targetRunsheetLine.tripno &&
        runsheetLine.tripseq === targetRunsheetLine.tripseq &&
        runsheetLine.groupseq === 1 &&
        !!runsheetLine.lineServiceTO
        ? (runsheetLine.lineServiceTO.serviceNo || '').substr(-4)
        : serviceGroup;
    },
    null);
  };

  addDuplicateRunsheetLines(duplicateLine: any, runsheetLines: any) {
    duplicateLine = this.cleanLineForNew(duplicateLine);
   // duplicateLine.tripname = `${duplicateLine.tripno}.${duplicateLine.tripseq}`
    duplicateLine.tripseq =
      1 +
      this._getMaxTripSeqInRunsheetLines(
        this._filterrunsheetLinesByTripArray(
          runsheetLines,
          duplicateLine.tripno
        )
      );

    runsheetLines.push(duplicateLine);
    return runsheetLines;
  }

  _getMaxTripSeqInRunsheetLines(runSheetLines: any) {
    return runSheetLines.reduce(function (maxTripSeq: any, runsheetLine: any) {
      return Math.max(maxTripSeq, parseInt(runsheetLine.tripseq));
    }, 0);
  }

  _filterrunsheetLinesByTripArray(runsheetLines: any, tripno: any) {
    return _.filter(runsheetLines, function (line) {
      return line.tripno === tripno;
    });
  }

  /**
   * @ngdoc function
   * @description
   * Consolidate the supplied runsheet lines:
   * assign the same tripseq to all (whichever is lowest)
   * assign groupseq sequentially
   * @param  {Array} runsheetLinesToConsolidate runsheetLines to consolidate
   * @param  {Array} runsheetLines              all runsheetlines
   * @return {Array}                            updated runsheet lines
   */

  consolidateRunsheetLines(
    runsheetLinesToConsolidate: RunsheetLine[],
    runsheetLines: RunsheetLine[]
  ): RunsheetLine[] {
    if (this.canConsolidate(runsheetLinesToConsolidate)) {
      runsheetLinesToConsolidate
        .sort((a, b) => a.tripseq - b.tripseq) // sort by tripseq, so we know the first item has the lowest tripseq
        .forEach((rsl, index, array) => {
          rsl.tripseq = array[0].tripseq; // set all to the first(lowest) tripseq
          rsl.lineServiceTO.serviceGroup = array[0].lineServiceTO.serviceNo; // The service group for each service is set to the service number of the first service in the group
          rsl.groupseq = index + 1; // assign groupseq in sequence (1 based)
        });
    }
    return this.refreshRunsheetLines(runsheetLines);
  }

  /**
   * Return true if the supplied runsheet lines can be consolidated:
   * runsheet lines must be an array of more than 1, have the same tripno,
   * and be not already consolidated (i.e., none have a groupseq, and they do not all have the same tripseq).
   * @param runsheetLinesToConsolidate runsheetLines to consolidate
   * @return true if consolidation is permitted
   */
  canConsolidate(runsheetLinesToConsolidate: RunsheetLine[]): boolean {
    return (
      Array.isArray(runsheetLinesToConsolidate) &&
      runsheetLinesToConsolidate.length > 1 &&
      runsheetLinesToConsolidate.every(
        (rsl) =>
          !rsl.groupseq && rsl.tripno === runsheetLinesToConsolidate[0].tripno
      ) &&
      runsheetLinesToConsolidate.some(
        (rsl) => rsl.tripseq !== runsheetLinesToConsolidate[0].tripseq
      )
    );
  }

  /**
   * Check validation list of required fields
   * @param runsheetLine
   */
  currentServiceType: any;
  validateRunsheetLineResources(runsheetLine: any, serviceType: any) {
    // var serviceType = this.RefDataService.get('serviceTypes', runsheetLine.serviceTypeId);
    // serviceType:
    serviceType.map((serviceType: any) => {
      if ((serviceType.serviceTypeId = runsheetLine.serviceTypeId)) {
        this.currentServiceType = serviceType;
      }
    });
    if (this.currentServiceType) {
      return (
        (this.currentServiceType.reqContainer && !runsheetLine.containerId) ||
        (this.currentServiceType.reqTruck && !runsheetLine.truckId) ||
        (this.currentServiceType.reqPickupLocation && !runsheetLine.locationPickupId) ||
        (this.currentServiceType.reqDropLocation && !runsheetLine.locationDropId) ||
        (this.currentServiceType.reqDropArrTime && !runsheetLine.droparrivetime) ||
        (this.currentServiceType.reqDropDptTime && !runsheetLine.dropdeparttime) ||
        (this.currentServiceType.reqPickupArrTime && !runsheetLine.pickuparrivetime) ||
        (this.currentServiceType.reqPickupDptTime && !runsheetLine.pickupdeparttime) ||
        (this.currentServiceType.reqDocket && !runsheetLine.docket)
      );
    }
  }

  /**
   * @ngdoc function
   * @description
   * Merge a runsheet line into the supplied runsheet
   * Ensure required fields are present
   * Replace by id match or add
   *
   * @param  {Array} runsheetLines array of (possibly modified) runsheetLines
   * @param {Object} runsheet     runsheet to update
   * @param  {boolean} cleanTripData    remove tripno, tripseq and groupseq
   * @return {Array}               modified runsheetLines
   */
  updateRunsheetLines(
    runsheetLines: any[],
    runsheet: any,
    cleanTripData: any
  ): any[] {
    return runsheetLines;
    // return (runsheetLines || []).reduce(
    //   (result: any[], runsheetLine: any, index: number) => {
    //     if (!runsheetLine) {
    //       return;
    //     }
    //     runsheetLine.id = runsheetLine.id || `${this.createTempId()}${index}`;

    //     // Override these properties from the runsheet
    //     runsheetLine.deliverydate = runsheet.deliverydate;
    //     runsheetLine.siteId = runsheet.siteId;
    //     runsheetLine.tripno =
    //       runsheetLine.tripno ||
    //       runsheet.runsheetLines.reduce(
    //         (res: number, rsl: any) => Math.max(rsl.tripno, res),
    //         0
    //       );

    //     // Update lineTemperature
    //     runsheetLine.lineTemperature = {
    //       ...(runsheetLine.lineTemperature || {}),
    //       deliverydate: runsheetLine.deliverydate,
    //     };

    //     // Remove tripno, tripseq, and groupseq if cleanTripData is true
    //     if (cleanTripData) {
    //       runsheetLine = {
    //         ...runsheetLine,
    //         tripno :null,
    //         tripseq:null,
    //         groupseq: null,
    //       }
    //       // runsheetLine.tripno = null;
    //       // runsheetLine.tripseq = null;
    //       // runsheetLine.groupseq = null;
    //     }

    //     // // Set truck and container on rsl
    //     // runsheetLine.truck = this.refDataService.get(
    //     //   'trucks',
    //     //   runsheetLine.truckId
    //     // );
    //     // runsheetLine.container = this.refDataService.get(
    //     //   'containers',
    //     //   runsheetLine.containerId
    //     // );

    //     // Set location details
    //     // this.setLocationDetails(
    //     //   runsheetLine,
    //     //   'locationPickupId',
    //     //   'pickupLocation'
    //     // );
    //     // this.setLocationDetails(runsheetLine, 'locationDropId', 'dropLocation');
    //     // this.setLocationDetailsFromLineServiceTO(runsheetLine, 'loadLocation');

    //     // Merge into runsheet
    //     // const match = runsheet.runsheetLines.find(
    //     //   (rsl: any) => rsl.id === runsheetLine.id
    //     // );
    //     const match = runsheet.runsheetLines.reduce(function (result: any, rsl: any) {
    //       return result || (rsl.id === runsheetLine.id ? rsl : null);
    //   }, null);
    //     if (match) {
    //       Object.assign(match, runsheetLine);
    //     } else {
    //       runsheet.runsheetLines.push(runsheetLine);
    //     }

    //     return result.concat(match || runsheetLine);
    //   },
    //   []
    // );
  }

  private setLocationDetails(
    runsheetLine: any,
    locationIdKey: string,
    locationKey: string
  ) {
    // const location = this.refDataService.get('locations', runsheetLine[locationIdKey]);
    runsheetLine.lineServiceTO[locationKey] = {
      ...runsheetLine.lineServiceTO[locationKey],
      // locationDesc: location?.locationDesc || null,
      // zoneChargeId: location?.zoneChargeId || null,
      // zonePayId: location?.zonePayId || null
    };
  }

  private setLocationDetailsFromLineServiceTO(
    runsheetLine: any,
    locationKey: string
  ) {
    const loadLocationId = runsheetLine.lineServiceTO[locationKey]?.locationId;
    // const loadLocation = this.refDataService.get('locations', loadLocationId);
    runsheetLine.lineServiceTO[locationKey] = {
      ...runsheetLine.lineServiceTO[locationKey],
      // locationDesc: loadLocation?.locationDesc || null
    };
  }

  addRunsheetLineByTrip(runsheetLine: any, runsheet: any) {
    runsheetLine.tripno = this._getTripNo(runsheetLine, runsheet.runsheetLines);
    this.addRunsheetLineStraight(runsheetLine, runsheet);
  }

  private _getTripNo(line: any, lineList: any[]): number {
    const lineOriginTripId = _.get(line, 'lineServiceTO.tripIdCust');
    const serviceLineSameTrip = _.find(lineList, (item) => 
      _.get(item, 'lineServiceTO.tripIdCust') === lineOriginTripId
    );
    return serviceLineSameTrip ? serviceLineSameTrip.tripno : this._getMaxTripNo(lineList) + 1;
  }

  private _getMaxTripNo(runsheetLines: any[]): number {
    return runsheetLines.reduce((result, runsheetLine) => {
      return Math.max(result, runsheetLine.tripno);
    }, 0);
  }

  addRunsheetLineStraight(runsheetLine: any, runsheet: any) {
    this._preFillRunsheetLine(runsheetLine, runsheet);
    runsheet.runsheetLines.push(runsheetLine);
    this.refreshRunsheetLines(runsheet.runsheetLines);
  }

  private _preFillRunsheetLine(runsheetLine: any, runsheet: any) {
    runsheetLine.id = runsheetLine.id || this.createTempId();
    runsheetLine.deliverydate = runsheet.deliverydate;
    runsheetLine.siteId = runsheet.siteId;
    runsheetLine.lineTemperature = {
      ...(runsheetLine.lineTemperature || {}),
      deliverydate: runsheetLine.deliverydate
    };
  }

  addRunsheetLineToLastTrip(runsheetLine: any, runsheet: any) {
    runsheetLine.tripno = this._getMaxTripNo(runsheet.runsheetLines);
    this.addRunsheetLineStraight(runsheetLine, runsheet);
  }

//   addReturnService(selectedLines: any[], runsheetLines: any[]) {
//     const returnServiceLines = (selectedLines || []).map((rsl) => {
//       return {
//         ...JSON.parse(JSON.stringify(rsl)), // Deep copy
//         id: this.createTempId() + (Math.random() * 100),
//         locationDropId: rsl.locationPickupId,
//         locationPickupId: rsl.locationDropId,
//         lineServiceTO: rsl.lineServiceTO
//           ? Object.keys(rsl.lineServiceTO).reduce((result: any, key: any) => {
//               if (!['serviceNo', 'tripIdCust', 'pickupLocation', 'dropLocation'].includes(key)) {
//                 result[key] = rsl.lineServiceTO[key];
//               }
//               return result;
//             }, {
//               pickupLocation: rsl.lineServiceTO.dropLocation,
//               dropLocation: rsl.lineServiceTO.pickupLocation
//             })
//           : {},
//         // serviceTypeId: this.refDataService.getUserOptionValue('Return.ServiceType'),
//         // loadTypeId: this.refDataService.getUserOptionValue('Return.LoadType'),
//         serviceTypeId: null,
//         loadTypeId: null,
//         pickuparrivetime: null,
//         pickupdoctime: null,
//         pickupreadytime: null,
//         pickupdeparttime: null,
//         droparrivetime: null,
//         dropdoctime: null,
//         dropreadytime: null,
//         dropdeparttime: null,
//         serviceId: null,
//         // createdby: this.modelService.getUserContext().userName,
//         // tripseq: this.getTripSeqOfReturnServiceLine(rsl, runsheetLines)
//         createdby: 'dhavaltr',
//         // tripseq: this.getTripSeqOfReturnServiceLine(rsl, runsheetLines)
//       };
//     });

  
}


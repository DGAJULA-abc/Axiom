import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RunsheetLineDetailComponent } from './runsheet-line-detail.component';

describe('RunsheetLineDetailComponent', () => {
  let component: RunsheetLineDetailComponent;
  let fixture: ComponentFixture<RunsheetLineDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RunsheetLineDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RunsheetLineDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { delay, take } from 'rxjs';
import { RunsheetDetail } from '../detail2.model';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';

@Component({
  selector: 'app-runsheet-line-detail',
  templateUrl: './runsheet-line-detail.component.html',
  styleUrls: ['./runsheet-line-detail.component.scss']
})
export class RunsheetLineDetailComponent implements OnInit, OnChanges {

  tabData: any[] = [];
  runsheetRowData: any[] = [];
  tabHeaderData: any[] = [];
  @Input() runsheet: RunsheetDetail;
  @Input() formStateSubmit: boolean;
  selectedSite:any;
   
  constructor(private fb: FormBuilder, private reconsileService: ReconcileService,private navbarService:NavbarService) {

  }

  ngOnInit() {
    this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
    this.getTabRender();
    this.getMultiLegSiteLocationsBySite();
  } 

  ngOnChanges(changes: SimpleChanges) {
    console.log('runsheet Line Detail', this.runsheet);
  }

  getTabRender() {
    let uniqueData: any[] = [];
    this.reconsileService.getTabReconcileRunsheetService().subscribe((result: any) => {
      // console.log("getTabReconcileRunsheetService >> ", result);
      
      this.tabHeaderData = result;
      this.tabData = result;
      // console.log('runsheet tabs', this.tabData);
      this.tabHeaderData.sort((a: any, b: any) => a.tabOrder - b.tabOrder);

      const uniqueTabOrders = new Set();

      // Iterate through the data and add items to the uniqueData array
      for (const item of this.tabHeaderData) {
        if (!uniqueTabOrders.has(item.tabOrder)) {
          uniqueData.push(item);
          uniqueTabOrders.add(item.tabOrder);
        }
      }
      this.tabHeaderData = uniqueData;
      // console.log('Unique Data by tabOrder:', uniqueData);
    });
  }

  getMultiLegSiteLocationsBySite() {
    this.reconsileService._multiLangData.subscribe((multiData: any) => {
      console.log("Multi Data>>", multiData.siteId);
      
    })
    this.reconsileService.getMultiLegSiteLocationsBySite(this.selectedSite).subscribe((serviceData: any) => {
        console.log("serviceData >> ", serviceData);
      })
   
   }
}
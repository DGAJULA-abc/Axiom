import { Component } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { AdjustmentType } from '../../financials/finaclials.model';

@Component({
  selector: 'app-adjustment-detail',
  templateUrl: './adjustment-detail.component.html',
  styleUrls: ['./adjustment-detail.component.scss']
})
export class AdjustmentDetailComponent {

  adjustmentData: any;
  constructor(private reconcileService: ReconcileService) {}

  ngOnInit() {
       this.getMultiLegData();
  }

  getMultiLegData() {
    this.reconcileService._multiLangData.subscribe((runsheet: AdjustmentType) => {
      // console.log('customerId  Arr > ', this.loadTypeArrId);
       this.adjustmentData = runsheet;
    });
  }
}

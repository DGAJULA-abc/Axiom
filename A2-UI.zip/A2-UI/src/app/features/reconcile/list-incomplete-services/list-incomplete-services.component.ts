import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  CheckboxSelectionCallbackParams,
  ColDef,
  HeaderCheckboxSelectionCallbackParams,
  IGroupCellRendererParams,
  GridApi,
  GridReadyEvent,
} from 'ag-grid-community';

import { MatSelect } from '@angular/material/select';

import { SearchService } from '../../search/services/search.service';
import { ReconcileService } from '../services/reconcile.service';
import { ListIncompleteReconcile } from '../models/view.reconcile.model';
// import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { CellrenderComponent } from './cellrender/cellrender.component';
import { ServiceDateCycle, TripDateCycle } from '../../plan/models/plan.model';
import { SharedService } from 'src/app/shared/services/shared.service';

// import { SearchService } from '../services/search.service';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import * as moment from 'moment';
import { PlanService } from '../../plan/services/plan.service';
import { MessageService } from 'primeng/api';
import { RunsheetService } from '../services/runsheet.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
@Component({
  selector: 'app-list-incomplete-services',
  templateUrl: './list-incomplete-services.component.html',
  styleUrls: ['./list-incomplete-services.component.scss']
})
export class ListIncompleteServicesComponent {
  canDelete: boolean = false;
  gridApi!: GridApi<any>; // step
  rightTitle: string = 'Create Invoices';
  @Output() not: EventEmitter<string> = new EventEmitter<string>();
  // selectedTrip: any;
  // selectedServices: ServiceDateCycle[];
  selectedTripService: any;

  editForm: any | null;
  displayStyle = "none";
  selectedOptions: any[]; // for selection option in ag-grid menu step:1
  layoutSubscription: Subscription;
  columnApi: any;
  applicationOptions: any;
  applicationId: any;
  columnState: any;
  userName: any;
  selectedSite: any;
  selectedServiceIds: any[] =[];
  gridOptions: any;
  public colDefs: any[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'docket',
      headerName: 'Docket',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'serviceid',
      headerName: 'Service ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'serviceno',
      headerName: 'Service No.',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'servicetypeid',
      headerName: 'Service type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'servicedate',
      headerName: 'Service Date',
      type: 'DATE',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    },
    {
      field: 'customerid',
      headerName: 'Customer ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'customergroupid',
      headerName: 'Customer Group',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'truckid',
      headerName: 'Truck',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'trailerid',
      headerName: 'Trailer',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'containerid',
      headerName: 'Container',
      type: 'container',
    },
    {
      field: 'containertypeid',
      headerName: 'Container type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locationid_pickup',
      headerName: 'Location Pickup',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locationid_drop',
      headerName: 'Location Drop',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'enteredby',
      headerName: 'Entered by',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'loadid',
      headerName: 'Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtydesc',
      headerName: 'Qty Desc',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locations',
      headerName: 'Locations',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'holdcode',
      headerName: 'Hold Code',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'complete',
      headerName: 'Complete',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
        disabled: true,
      },
    },
    {
      field: 'originsite',
      headerName: 'Origin Site',
      type: 'site',
    },
    {
      field: 'destinationsite',
      headerName: 'Destination Site',
      type: 'site',
    },
    {
      field: 'originloc',
      headerName: 'Origin Loc',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'destinationloc',
      headerName: 'Destination Loc',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'invoiceid',
      headerName: 'Invoice',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'companyid',
      headerName: 'Company ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'employeefield',
      headerName: 'Employee field',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'firstfield',
      headerName: 'Firstfield',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'lastfield',
      headerName: 'Lastfield',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'runsheetid',
      headerName: 'Runsheet ID',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'customerid_load',
      headerName: 'Customer ID Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'loadno',
      headerName: 'Load No.',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'loadtypeid',
      headerName: 'Load type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'scheduleddate',
      headerName: 'Scheduled Date',
      type: 'DATE',
        cellRenderer: (milliseconds: any) => {
          return moment(milliseconds.value)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY');
        },
        filterParams: {
          filterOptions: ['contains'], // Use 'contains' filter option
          textMatcher: function (filter: any, value: any) {
            const formattedValue = moment
              .unix(filter.value / 1000)
              .tz('Australia/Melbourne')
              .format('DD/MM/YYYY')
              .toLowerCase();
            const formattedFilter = filter.filterText;

            console.log('Formatted Value:', formattedValue);
            console.log('Formatted Filter:', formattedFilter);

            return formattedValue.includes(formattedFilter);
          },
        },
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    },
    {
      field: 'holdcode_load',
      headerName: 'Holdcode Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'complete_load',
      headerName: 'Complete Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'batchno',
      headerName: 'ConNote',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'locationid',
      headerName: 'Location',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'custreference',
      headerName: 'Cust Ref.',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'customergroupid_load',
      headerName: 'Customer Group Load',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty1',
      headerName: 'Qty 1',
      type: 'DECIMAL',
    },
    {
      field: 'unit1',
      headerName: 'Unit 1',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty2',
      headerName: 'Qty 2',
      type: 'DECIMAL',
    },
    {
      field: 'unit2',
      headerName: 'Unit 2',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty3',
      headerName: 'Qty 3',
      type: 'DECIMAL',
    },
    {
      field: 'unit3',
      headerName: 'Unit 3',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty4',
      headerName: 'Qty 4',
      type: 'DECIMAL',
    },
    {
      field: 'unit4',
      headerName: 'Unit 4',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty5',
      headerName: 'Qty 5',
      type: 'DECIMAL',
    },
    {
      field: 'unit5',
      headerName: 'Unit 5',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty6',
      headerName: 'Qty 6',
      type: 'DECIMAL',
    },
    {
      field: 'unit6',
      headerName: 'Unit 6',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty7',
      headerName: 'Qty 7',
      type: 'DECIMAL',
    },
    {
      field: 'unit7',
      headerName: 'Unit 7',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qty8',
      headerName: 'Qty 8',
      type: 'DECIMAL',
    },
    {
      field: 'unit8',
      headerName: 'Unit 8',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtya',
      headerName: 'Qty A',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyb',
      headerName: 'Qty B',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyc',
      headerName: 'Qty C',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyd',
      headerName: 'Qty D',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtye',
      headerName: 'Qty E',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyf',
      headerName: 'Qty F',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyg',
      headerName: 'Qty G',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'qtyh',
      headerName: 'Qty H',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'sloadtype',
      headerName: 'S Load type',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'trailerid_tag',
      headerName: 'Trailer Tag',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'chargeamt',
      headerName: 'Charge Amount',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'rateid',
      headerName: 'Rate',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'driverrate',
      headerName: 'Driver Rate',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'driverpay',
      headerName: 'Driver Pay',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'tripid_cust',
      headerName: 'Trip Cust',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'datasourceid',
      headerName: 'Datasource',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'tripid',
      headerName: 'Trip',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'tripdate',
      headerName: 'Trip Date',
      type: 'DATE',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    },
    {
      field: 'driver',
      headerName: 'Driver',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'used',
      headerName: 'Used',
      type: 'TEXT',
      minWidth: 120,
    },
    {
      field: 'servicedesc',
      headerName: 'Service Desc',
      type: 'TEXT',
      minWidth: 120,
    },
  ];

  columnDefs: ColDef[] = this.colDefs; //step:3

  public autoGroupColumnDef: ColDef = {
    headerName: 'Group',
    minWidth: 170,
    field: 'runsheetid',
    valueGetter: (params) => {
      if (params.node!.group) {
        return params.node!.key;
      } else {
        return params.data[params.colDef.field!];
      }
    },
    headerCheckboxSelection: true,
    cellRenderer: 'agGroupCellRenderer',
    cellRendererParams: {
      checkbox: true,
    } as IGroupCellRendererParams,
  };

  public rowSelection: 'single' | 'multiple' = 'multiple';
  public rowGroupPanelShow: 'always' | 'onlyWhenGrouping' | 'never' = 'always';
  public pivotPanelShow: 'always' | 'onlyWhenPivoting' | 'never' = 'always';

  public defaultColDef: ColDef = {
    flex: 1,
    // minWidth: 180,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
  };

  showRunsheetDetail: boolean = true;
  fromSearchRunsheet: any = {
    type: 'runsheet',
    used: false
  }
  canWrite: boolean;
  public rowData: ListIncompleteReconcile[] | null;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;

  @ViewChild('mySelect') mySelect: MatSelect; //step:5

  constructor(
    public permission: PermissionsService,
    private runsheetService: RunsheetService,
    private reconcileService: ReconcileService,
    private sharedService: SharedService,
    private searchServices: SearchService,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    private planService: PlanService,
    private messageService: MessageService
  ) {
    this.gridOptions = {
      context: { Component: this },
    };
    this.reconcileService.pageTitleSubject.next('List Incomplete Services');
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          console.log('create:', data);
          this.dialogService.savaLayout(data);
        }
      }
    );
    this.getView();
  }

  // saveLayout(): any {
  //   if (this.columnApi) {
  //     this.columnState = this.columnApi.getColumnState();
  //     let columns = [];
  //     for (let column of this.columnState) {
  //       const customColumn = {
  //         name: column.colId,
  //         visible: !column.hide,
  //         width: column.width,
  //         sort: column.sort,
  //         filter: column.filter,
  //       };
  //       columns.push(customColumn);
  //     }
  //     let columnValueObj: any = { columns };
  //     columnValueObj = JSON.stringify(columnValueObj);
  //     this.navbarService.usernameSubject.subscribe((username) => {
  //       this.userName = username;
  //     });
  //     this.selectedSite = this.navbarService.selectedSiteId;
  //     console.log('site:', this.selectedSite);
  //     return {
  //       applicationOptionId: 9780,
  //       optionName: 'a2v3.setup.Search.Services.grid.layout',
  //       optionValue: columnValueObj,
  //       siteId: this.selectedSite,
  //       userId: this.userName,
  //     };
  //   }
  // }

  // getLayout() {
  //   this.navbarService.applicationOptions.subscribe(
  //     (applicationOptions: any) => {
  //       let appOptions = applicationOptions;
  //       let a = appOptions.filter((item: any) => {
  //         if (item['optionName'] === 'a2v3.setup.Search.Services.grid.layout')
  //           this.columnState = JSON.parse(item['optionValue']);
  //         if (this.columnState) {
  //           if (this.columnState.columns) {
  //             this.columnState.columns.forEach((column: any) => {
  //               if ('name' in column) {
  //                 column.colId = column.name;
  //                 delete column.name;
  //               }
  //             });
  //             this.columnState = this.columnState.columns;
  //             this.applyLayout();
  //           }
  //         }
  //       });
  //     }
  //   );
  // }

  // applyLayout() {
  //   console.log('new:', this.columnState);
  //   const applyColumnStateParams = {
  //     state: this.columnState,
  //     applyOrder: true,
  //   };
  //   this.columnApi.applyColumnState(applyColumnStateParams);
  //   this.columnState.forEach(({ colId, width }: { colId: any; width: any }) => {
  //     const column = this.columnApi.getColumn(colId);
  //     if (column) {
  //       this.columnApi.setColumnWidth(column, width);
  //     }
  //   });
  // }

  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.setup.Search.Services.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Services.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Services.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  } 


  onGridReady1(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  ngOnInit(): void {
    //this.canWrite = this.runsheetService.getCanWrite();
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
    this.selectedOptions = this.colDefs.map((coulmn) => coulmn.field); //step:2
    this.not.emit(this.rightTitle);
    this.onGridReady();
    this.planService.ServiceSearchupdate.subscribe((res)=>{
      let matchRow=this.rowData?.find((r:any)=>r.serviceid==res[0].id)
      const matchingrowindex = this.rowData?.findIndex(
        (n:any) => n.serviceid == res[0].id
      );
      if (matchingrowindex !== -1) {
        var rowNode = this.gridApi.getRowNode(String(matchingrowindex));
        let temp = {
          batchno: res[0].batchno,
          chargeamt: res[0].chargeAmt,
          companyid: res[0].companyid,
          complete: res[0].complete,
          complete_load: res[0].customergroupid_load,
          containerid: res[0].containerId,
          containertypeid: res[0].containerTypeId,
          customergroupid: res[0].customergroupid,
          customergroupid_load:res[0].customergroupid_load,
          customerid: res[0].customerId,
          customerid_load: res[0].customerid_load,
          custreference: res[0].custreference,
          datasourceid:res[0].dataSourceId,
          destinationloc: res[0].destinationLoc,
          destinationsite: res[0].destinationSite,
          docket: res[0].docket,
          driver: res[0].driver,
          driverid: res[0].driverId,
          driverpay: res[0].driverpay,
          driverrate: res[0].driverrate,
          droparrivetemp: res[0].droparrivetemp,
          dropdeparttemp: res[0].dropdeparttemp,
          dropdoctemp: res[0].dropdoctemp,
          dropreadytemp: res[0].dropreadytemp ,
          employeename: res[0].employeename,
          enteredby: res[0].enteredBy,
          firstname: res[0].firstname,
          holdcode: res[0].holdcode,
          holdcode_load: res[0].holdcode_load,
          invoiceid: res[0].invoiceid,
          lastname: res[0].lastname,
          loadid: res[0].loadId,
          loadno: res[0].loadNo,
          loadtypeid: res[0].loadTypeId,
          locationid: res[0].locationid,
          locationid_drop: res[0].locationIdDrop,
          locationid_pickup: res[0].locationIdPickup,
          locations: res[0].locations,
          originloc: res[0].originLoc,
          originsite: res[0].originSite,
          pickuparrivetemp: res[0].pickuparrivetemp,
          pickupdeparttemp: res[0].pickupdeparttemp,
          pickupdoctemp: res[0].pickupdoctemp,
          pickupreadytemp: res[0].pickupreadytemp,
          qty1: res[0].qty1,
          qty2: res[0].qty2,
          qty3: res[0].qty3,
          qty4: res[0].qty4,
          qty5: res[0].qty5,
          qty6: res[0].qty6,
          qty7: res[0].qty7,
          qty8: res[0].qty8,
          qtya:res[0].qtya,
          qtyb:res[0].qtyb,
          qtyc: res[0].qtyc,
          qtyd:res[0].qtyd,
          qtydesc: res[0].qtydesc,
          qtye: res[0].qtye,
          qtyf: res[0].qtyf,
          qtyg: res[0].qtyg,
          qtyh: res[0].qtyh,
          rateid: res[0].rateId,
          runsheetid: res[0].runsheetid,
          scheduleddate: res[0].scheduleddate,
          servicedate: res[0].serviceDate,
          servicedesc: res[0].serviceDesc,
          serviceid: res[0].id,
          serviceno: res[0].serviceNo,
          servicetypeid: res[0].serviceTypeId,
          siteid: res[0].siteId,
          sloadtype: res[0].sloadtype,
          trailerid: res[0].trailerId,
          trailerid_tag: res[0].trailerIdTag,
          tripdate: res[0].tripdate,
          tripid: res[0].tripId,
          tripid_cust: res[0].tripIdCust,
          truckid: res[0].truckId,
          unit1: res[0].unit1,
          unit2: res[0].unit2,
          unit3: res[0].unit3,
          unit4: res[0].unit4,
          unit5: res[0].unit5,
          unit6: res[0].unit6,
          unit7: res[0].unit7,
          unit8: res[0].unit8,
          used: res[0].used,
        };
        rowNode?.setData(temp);
      }
    })
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('EnterRunsheets');
      const result2 = await this.permission.canWrite('Runsheet2');
      if(result1 && result2){
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }
      console.log("Result:", this.canWrite,result1,result2); // Use the result here
      
    } catch (error) {
      console.error("Error:", error);
    }
  }

  onGridReady() {
    this.reconcileService
      .getListIncompleteService()
      .subscribe((result: any) => {
        console.log('result incompplete > ', result);

        this.rowData = result.services;
        console.log("Row data in LIS", this.rowData);
        
      });

    //  this.searchFormDetails = event;
    // this.searchServices.getRunsheetList(event).subscribe((result: any) => {
    //   this.rowData = result.runsheets;
    //   // this.pagination.pageNumber = 1;
    //   // this.totalRecords = result.pagination.totalRecords;

    // });
  }

  //step:4
  onSelectionChange(event: any) {
    this.clearFilters();
    console.log(event.value);
    this.columnDefs = this.colDefs.filter((column) =>
      event.value.includes(column.field)|| column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
  onCellClicked(e: any): void {
    console.log('cellClicked', e);
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;

    const selectedNodes = this.gridApi.getSelectedNodes();
    console.log("slected nodes:", selectedNodes);
    this.selectedServiceIds = selectedNodes.map((node) => node.data.serviceid);
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data;
      this.selectedTripANdServicesList(this.editForm?.serviceid);
      if(this.editForm.used === false){
        this.canDelete = true;
      }
    }
    //this.selectedTrip = event.api.getSelectedNodes();
    console.log("sle:", event.api.getSelectedNodes()[0].data,this.editForm, this.selectedServiceIds)
  }
  selectedServices: ServiceDateCycle;
  selectedTrip: TripDateCycle[];
  selectedTripANdServicesList(tripid: number) {
    this.sharedService.geServiceDetailsByid(tripid).subscribe((result: any) => {
      this.selectedServices = result;
      this.planService.getRunsheetServicebtnState = this.selectedServices?.used;
      // this.fromSearchRunsheet = this.selectedServices?.used;
      this.fromSearchRunsheet.used =  this.selectedServices?.used;


      // console.log("selectedServices >>", this.selectedServices?.used);
      this.selectedServices
      if (this.selectedServices.tripId) {
        this.sharedService
          .getTripDetails(this.selectedServices.tripId)
          .subscribe((result) => {
            this.selectedTrip = result.trips;
          });
      }
    });
  }
  Csvpayload = {
    pagination: {
      orderByField: 'serviceid',
      orderType: 'DESC',
      pageNumber: 1,
      recordsPerPage: 1000,
    },
    svcComplete: false,
  };

  onDelete(){
    console.log("ids are:", this.selectedServiceIds);
    this.reconcileService.deleteListIncompleteService(this.selectedServiceIds).subscribe((res:any)=>{
      this.onGridReady()
      this.closePopup();
      this.gridOptions.api.setRowData(this.rowData);
      this.editForm = false;// this.onGridReady();
      const messageDetail = `Service(s) ${this.selectedServiceIds[0]} Deleted.`
     
      this.messageService.add({
        severity: 'success',
        summary: '',
        detail: messageDetail,
      });
    },
    (err: any) => {
      this.closePopup();
    }
    )
  }

  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }

  downloadCsv() {
    this.reconcileService.postCsvDownload(this.Csvpayload).subscribe((res: any) => {
      // Assuming 'response' is the array buffer received from your HTTP request
      var arrayBuffer = res;
      var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
      var url = window.URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'report.csv'; // Set the desired file name
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }
}

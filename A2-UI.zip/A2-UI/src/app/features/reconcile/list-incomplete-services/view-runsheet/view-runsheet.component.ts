import { Component, Input } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CellrenderComponent } from '../cellrender/cellrender.component';

@Component({
  selector: 'app-view-runsheet',
  templateUrl: './view-runsheet.component.html',
  styleUrls: ['./view-runsheet.component.scss'],
})
export class ViewRunsheetComponent {
  viewListDataGrid: any;
  runSheetId: string = '';

  @Input() rowClicked: any;

  rowData: any[] = [];
  columnDefs: any[] = [
    { field: 'tripseq', headerName: 'Seq' },
    { field: 'loadTypeId', headerName: 'Load No' },
    { field: 'tripno', headerName: 'Trip' },
    { field: '', headerName: 'Service Group' },
    { field: '', headerName: 'Service Type' },
    { field: '', headerName: 'Load Type' },
    { field: 'locationPickupId', headerName: 'From' },
    { field: 'locationDropId', headerName: 'To' },
    { field: '', headerName: 'Complete' },
    { field: 'locationReturnId', headerName: 'Return To' },
    { field: '', headerName: 'Charge Amount' },
    { field: '', headerName: 'Pay Amount' },
    { field: '', headerName: 'Service No' },
    { field: 'docket', headerName: 'Docket' },
    { field: '', headerName: 'Container' },
    { field: '', headerName: 'Truck' },
    { field: '', headerName: 'Trailer' },
    { field: '', headerName: 'Trailer Tag' },
    { field: 'serviceId', headerName: 'Fleet NO.' },
    { field: 'serviceTypeId', headerName: 'Customer ID' },
    { field: 'truckId', headerName: 'Pickup Location Desc' },
    { field: 'truckId', headerName: 'Drop Location Desc' },
    { field: '', headerName: 'Truck Type' },
    { field: '', headerName: '123456743' },
    { field: '', headerName: '23456' },
    { field: '', headerName: 'Load Location ' },
    { field: '', headerName: 'Load Location Desc' },
    { field: '', headerName: 'Charge Zone Drop' },
    { field: '', headerName: 'Pay Zone Drop' },
    { field: '', headerName: 'Charge Zone Pickup' },
    { field: '', headerName: 'Pay Zone Pickup' },
    { field: '', headerName: 'Fuel Levy Charge' },
    { field: '', headerName: 'Fuek Levy Pay' },
    { field: 'qty1', headerName: 'Qty. 1' },
    { field: 'qty2', headerName: 'Qty. 2' },
    { field: 'qty3', headerName: 'Qty. 3' },
    { field: 'qty4', headerName: 'Qty. 4' },
    { field: 'qty5', headerName: 'Qty. 5' },
    { field: 'qty6', headerName: 'Qty. 6' },
    { field: 'qty7', headerName: 'Qty. 7' },
  ];

  constructor(
    private reconileService: ReconcileService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.runsheetIdData(this.rowClicked.runsheetid);
      this.runSheetId = this.rowClicked.runsheetid;
    // this.getViewCellData();
  }

  // getViewCellData() {
  //   this.reconileService.getCellSubdata.subscribe((viewListData: any) => {
  //     this.runsheetIdData(viewListData.data.runsheetid);
  //     this.runSheetId = viewListData.data.runsheetid;
  //   });
  // }

  runsheetIdData(runSheetId: any) {
    this.reconileService.getViewRunsheetId(runSheetId).subscribe((idData) => {
      console.log('idData >> ', idData);
      this.viewListDataGrid = idData.runsheet;
      if (idData.runsheet?.runsheetLines) {
        console.log('runsheetLines >>', idData.runsheet.runsheetLines);
        this.rowData = idData.runsheet.runsheetLines;
      }
    });
  }

  viewRunsheetPage() {
    // this.router.navigate(['reconcile/ViewRunsheet'], {
    //   queryParams: { runsheetId: this.runSheetId },
    //   queryParamsHandling: 'merge',
    // });
    // .then(data => this.reloadCurrentRoute())
    const baseUrl = this.router.serializeUrl(
      this.router.createUrlTree(['reconcile/ViewRunsheet'], {
        queryParams: { runsheetId: this.runSheetId },
        queryParamsHandling: 'merge',
      })
    );
    // .then(data => this.reloadCurrentRoute())

    // Open the new tab
    window.open(baseUrl, '_blank');
  }

  reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router
      .navigateByUrl('reconcile/ViewRunsheet', { skipLocationChange: true })
      .then(() => {
        this.router.navigate([currentUrl]);
      });
  }
}

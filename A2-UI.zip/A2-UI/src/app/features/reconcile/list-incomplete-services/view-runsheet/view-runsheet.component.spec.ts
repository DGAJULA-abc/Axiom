import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewRunsheetComponent } from './view-runsheet.component';

describe('ViewRunsheetComponent', () => {
  let component: ViewRunsheetComponent;
  let fixture: ComponentFixture<ViewRunsheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewRunsheetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewRunsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

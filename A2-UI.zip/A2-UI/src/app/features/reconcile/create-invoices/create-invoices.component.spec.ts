import { ComponentFixture, TestBed } from '@angular/core/testing';
import {waitForAsync} from '@angular/core/testing';
import { CreateInvoicesComponent } from './create-invoices.component';

describe('CreateInvoicesComponent', () => {
  let component: CreateInvoicesComponent;
  let fixture: ComponentFixture<CreateInvoicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateInvoicesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateInvoicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should do things onGridReady() is supposed to do', waitForAsync(() => {

    const expectedRowData = [
      { abn
      : 
      null,
      active
      : 
      true,
      allowContPickupDrop
      : 
      true,
      applyGST
      : 
      true,
      cnFormat
      : 
      1,
      cnFormatName
      : 
      "Standard Credit Note",
      customBillingName1
      : 
      "Ref 1",
      customBillingName2
      : 
      "Ref 2",
      customBillingName3
      : 
      "Ref 3",
      customBillingValue1
      : 
      "REF1",
      customBillingValue2
      : 
      "REF2",
      customBillingValue3
      : 
      "REF3",
      customerId
      : 
      "MEL001",
      customerName
      : 
      "Cement Australia - Victoria",
      debtorCode
      : 
      "MEL001",
      fuelLevyChargeRate
      : 
      null,
      fuelLevyPayRate
      : 
      null,
      glCodeBranch
      : 
      "KBKKB",
      groupId
      : 
      "MELCANN MELB OPS",
      groupName
      : 
      "aaaa Melcann Melbourne Operations",
      internalCustomer
      : 
      false,
      invFormat
      : 
      3,
      invFormatName
      : 
      "Detailed Wide Format (Service Drop)",
      invUnit1
      : 
      null,
      invUnit2
      : 
      null,
      invUnit3
      : 
      null,
      invUnit4
      : 
      null,
      invUnit5
      : 
      null,
      invUnit6
      : 
      null,
      invUnit7
      : 
      null,
      invUnit8
      : 
      null,
      invoiceRemarksMode
      : 
      3,
      invoiceRemarksModeName
      : 
      "Service Remarks",
      loadNoMaxLen
      : 
      null,
      loadNoMinLen
      : 
      null,
      numericLoadNo
      : 
      false,
      personBillingName
      : 
      "Geoff Hill",
      personContactName
      : 
      null,
      personIdBilling
      : 
      15690,
      personIdContact
      : 
      null,
      scheduleEntryForm
      : 
      "Standard Entry",
      scheduledImportFunction
      : 
      "Melcann",
      siteId
      : 
      999,
      uniqueLoadNo
      : 
      false}];

    // call ngOnInit directly
    component.ngOnInit();
    fixture.detectChanges();

    // wait for the fixture to stabilize
    fixture.whenStable().then(() => {
        console.log(' ==> stable!');
        expect(component.gridOptions.rowData).toEqual(expectedRowData);
        // whatever other tests...
    });

}));
});

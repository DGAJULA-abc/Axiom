import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

import { ReconcileRoutingModule } from './reconcile-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { ReconcileComponent } from './reconcile.component';
import { ToastModule } from 'primeng/toast';
import { ReconcileService } from './services/reconcile.service';
import { SharedModule } from 'src/app/shared/shared.module';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ListIncompleteServicesComponent } from './list-incomplete-services/list-incomplete-services.component';
import { CellrenderComponent } from './list-incomplete-services/cellrender/cellrender.component';
import { ViewRunsheetComponent } from './list-incomplete-services/view-runsheet/view-runsheet.component';
import { ListIncompleteRunsheetsComponent } from './list-incomplete-runsheets/list-incomplete-runsheets.component';
import { ListCompleteRunsheetsComponent } from './list-complete-runsheets/list-complete-runsheets.component';
import { CreateInvoicesComponent } from './create-invoices/create-invoices.component';
import { CreatePayAdvicesComponent } from './create-pay-advices/create-pay-advices.component';
import { PrintInvoicesComponent } from './print-invoices/print-invoices.component';
import { PrintPayAdvicesComponent } from './print-pay-advices/print-pay-advices.component';
import { AutomaticCompletionStatusComponent } from './automatic-completion-status/automatic-completion-status.component';
import { CreateRunSheetsComponent } from './create-run-sheets/create-run-sheets.component';
import { PrintCustomPageComponent } from './print-custom-page/print-custom-page.component';
import { RunsheetTabsComponent } from './view-runsheet-form/runsheet-tabs/runsheet-tabs.component';
import { CreateAdjustmentComponent } from './financials/create-adjustment/create-adjustment.component';
import { PeriodicChargesComponent } from './financials/periodic-charges/periodic-charges.component';
//import { LinkRendererComponent } from './link-renderer/link-renderer.component';
import { InvoiceDetailsComponent } from './invoice-details/invoice-details.component';
import { AgGridModule } from 'ag-grid-angular';
import { RouterModule } from '@angular/router';
import { FinalcialsFormComponent } from './financials/periodic-charges/finalcials-form/finalcials-form.component';
import { PeriodicPaymentsComponent } from './financials/periodic-payments/periodic-payments.component';
import { PerodicPaymentFormComponent } from './financials/periodic-payments/perodic-payment-form/perodic-payment-form.component';
import { AdjusmentAgGridComponent } from './financials/create-adjustment/adjusment-ag-grid/adjusment-ag-grid.component';
import { CloseOffLogComponent } from './close-off-log/close-off-log.component';
import { SubmitCloseOffComponent } from './submit-close-off/submit-close-off.component';
import { ViewRunsheetFormComponent } from './view-runsheet-form/view-runsheet-form.component';
import { DetailComponent } from './detail/detail.component';
import { RunsheetLineDetailComponent } from './detail/runsheet-line-detail/runsheet-line-detail.component';
import { RunsheetServiceDetailComponent } from './detail/runsheet-line-detail/runsheet-service-detail/runsheet-service-detail.component';
import { LoadDetailComponent } from './detail/runsheet-line-detail/load-detail/load-detail.component';
import { EventDetailComponent } from './detail/runsheet-line-detail/event-detail/event-detail.component';
import { RatingDetailComponent } from './detail/runsheet-line-detail/rating-detail/rating-detail.component';
import { ContaierDetailComponent } from './detail/runsheet-line-detail/contaier-detail/contaier-detail.component';
import { PlanModule } from '../plan/plan.module';
import { AddServicesByComponent } from './detail/add-services-by/add-services-by.component';
import { LoadSearchComponent } from './detail/add-services-by/load-search/load-search.component';
import { ServiceSearchComponent } from './detail/add-services-by/service-search/service-search.component';
import { TripSearchComponent } from './detail/add-services-by/trip-search/trip-search.component';
import { SearchFormComponent } from './detail/add-services-by/service-search/search-form/search-form.component';
import { SearchModule } from '../search/search.module';
import { MatAutoCompleteComponent } from '../search/mat-auto-complete/mat-auto-complete.component';
import { LoadFormComponent } from './detail/add-services-by/load-search/load-form/load-form.component';
import { TripSearchFormComponent } from './detail/add-services-by/trip-search/trip-search-form/trip-search-form.component';
import { TripDetailComponent } from './detail/trip-detail/trip-detail.component';
import { BreakDetailComponent } from './detail/break-detail/break-detail.component';
import { MessagesModule } from 'primeng/messages';
import { ProgressBarModule } from 'primeng/progressbar';
import { AdjustmentDetailComponent } from './detail/adjustment-detail/adjustment-detail.component';
import { ReasonDetailComponent } from './detail/reason-detail/reason-detail.component';
import { TimeRunsheetService } from './services/time-runsheet.service';
import { ServiceUnitsComponent } from './detail/runsheet-line-detail/service-units/service-units.component';
import { ApplypayementsComponent } from './financials/periodic-payments/applypayements/applypayements.component';
import { ApplychargesComponent } from './financials/periodic-charges/applycharges/applycharges.component';
import { TooltipModule } from 'primeng/tooltip';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';
import { ConfirmingsavedornotsaveddialogComponent } from './view-runsheet-form/confirmingsavedornotsaveddialog/confirmingsavedornotsaveddialog.component';
import { CanDeactivateGuardComponent } from './view-runsheet-form/can-deactivate-guard/can-deactivate-guard.component';
import { ConfirmNavigateComponent } from './view-runsheet-form/confirm-navigate/confirm-navigate.component';

@NgModule({
  declarations: [
    ReconcileComponent,
    LandingPageComponent,
    ListIncompleteServicesComponent,
    CellrenderComponent,
    ViewRunsheetComponent,
    ListIncompleteRunsheetsComponent,
    ListCompleteRunsheetsComponent,
    CreateInvoicesComponent,
    CreatePayAdvicesComponent,
    PrintInvoicesComponent,
    PrintPayAdvicesComponent,
    AutomaticCompletionStatusComponent,
    CreateRunSheetsComponent,
    PrintCustomPageComponent,
    RunsheetTabsComponent,
    CreateAdjustmentComponent,
    PeriodicChargesComponent,
    //  LinkRendererComponent,
    InvoiceDetailsComponent,
    FinalcialsFormComponent,
    PeriodicPaymentsComponent,
    PerodicPaymentFormComponent,
    AdjusmentAgGridComponent,
    ViewRunsheetFormComponent,
    DetailComponent,
    RunsheetLineDetailComponent,
    RunsheetServiceDetailComponent,
    CloseOffLogComponent,
    SubmitCloseOffComponent,
    ViewRunsheetFormComponent,
    LoadDetailComponent,
    EventDetailComponent,
    RatingDetailComponent,
    ContaierDetailComponent,
    AddServicesByComponent,
    LoadSearchComponent,
    ServiceSearchComponent,
    TripSearchComponent,
    ServiceSearchComponent,
    SearchFormComponent,
    LoadFormComponent,
    TripSearchFormComponent,
    TripDetailComponent,
    BreakDetailComponent,
    AdjustmentDetailComponent,
    ReasonDetailComponent,
    ApplypayementsComponent,
    ServiceUnitsComponent,
    ApplychargesComponent,
    ConfirmingsavedornotsaveddialogComponent,
    CanDeactivateGuardComponent,
    ConfirmNavigateComponent,
  ],
  imports: [
    AgGridModule,
    CommonModule,
    ConfirmDialogModule,
    HttpClientModule,
    FormsModule,
    ReconcileRoutingModule,
    SharedModule,
    PlanModule,
    ProgressBarModule,
    ToastModule,
    SearchModule,
    TooltipModule,
    DialogModule
    //RouterModule.forRoot([])
  ],
  exports: [ReconcileComponent, ListIncompleteServicesComponent],
  providers: [ReconcileService, TimeRunsheetService, MessageService,CanDeactivateGuardComponent],
})
export class ReconcileModule {}

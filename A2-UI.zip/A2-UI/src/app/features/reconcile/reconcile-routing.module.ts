import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReconcileComponent } from './reconcile.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { ListCompleteRunsheetsComponent } from './list-complete-runsheets/list-complete-runsheets.component';
import { ListIncompleteServicesComponent } from './list-incomplete-services/list-incomplete-services.component';
import { CreateRunSheetsComponent } from './create-run-sheets/create-run-sheets.component';
import { ListIncompleteRunsheetsComponent } from './list-incomplete-runsheets/list-incomplete-runsheets.component';
import { CreateInvoicesComponent } from './create-invoices/create-invoices.component';
import { CreatePayAdvicesComponent } from './create-pay-advices/create-pay-advices.component';
import { PrintInvoicesComponent } from './print-invoices/print-invoices.component';
import { PrintPayAdvicesComponent } from './print-pay-advices/print-pay-advices.component';
import { AutomaticCompletionStatusComponent } from './automatic-completion-status/automatic-completion-status.component';
import { ViewRunsheetComponent } from './list-incomplete-services/view-runsheet/view-runsheet.component';
import { CreateAdjustmentComponent } from './financials/create-adjustment/create-adjustment.component';
import { PeriodicChargesComponent } from './financials/periodic-charges/periodic-charges.component';
import { InvoiceDetailsComponent } from './invoice-details/invoice-details.component';
import { PeriodicPaymentsComponent } from './financials/periodic-payments/periodic-payments.component';
import { SubmitCloseOffComponent } from './submit-close-off/submit-close-off.component';
import { CloseOffLogComponent } from './close-off-log/close-off-log.component';
import { ViewRunsheetFormComponent } from './view-runsheet-form/view-runsheet-form.component';
import { CanDeactivateGuardComponent } from './view-runsheet-form/can-deactivate-guard/can-deactivate-guard.component';


const routes: Routes = [
  {
    path: '',
    component: ReconcileComponent,
    children: [
      {
        path: '',
        component: LandingPageComponent,
      },
      {
        path: 'CreateRunsheet',
        component: ViewRunsheetFormComponent,
      //  canDeactivate: [CanDeactivateGuardComponent]
      },
      {
        path: 'ListIncompleteRunsheets',
        component: ListIncompleteRunsheetsComponent,
      },
      {
        path: 'ListCompleteRunsheets',
        component: ListCompleteRunsheetsComponent,
      },
      {
        path: 'ListIncompleteServices',
        component: ListIncompleteServicesComponent,
      },
      {
        path: 'AutoCompleteStatus',
        component: AutomaticCompletionStatusComponent,
      },
      {
        path: 'CreateInvoices',
        component: CreateInvoicesComponent,
      },
      {
        path: 'CreatePayAdvices',
        component: CreatePayAdvicesComponent,
      },
      {
        path: 'PrintInvoices',
        component: PrintInvoicesComponent,
      },
      {
        path: 'PrintPayAdvices',
        component: PrintPayAdvicesComponent,
      },
      {
        path: 'invoiceDetails',
        component: InvoiceDetailsComponent,
      },
      {
        path: 'ViewRunsheet',
        component: ViewRunsheetFormComponent,
        // canDeactivate: [CanDeactivateGuardComponent]
      },

      {
        path: 'Financials/CreateAdjustment',
        component: CreateAdjustmentComponent,
      },
      {
        path: 'Financials/PeriodicCharges',
        component: PeriodicChargesComponent,
      },
      {
        path: 'Financials/PeriodicPayments',
        component: PeriodicPaymentsComponent,
      },

      {
        path: 'PrintInvoices/invoiceDetails/:id',
        component: InvoiceDetailsComponent,
      },
      {
        path: 'PrintPayAdvices/invoiceDetails/:id',
        component: InvoiceDetailsComponent,
      },
      {
        path: 'CloseOffLog',
        component: CloseOffLogComponent,
      },
      {
        path: 'SubmitCloseOff',
        component: SubmitCloseOffComponent,
      },
    
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReconcileRoutingModule {}

import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { ColDef, GridApi } from 'ag-grid-community';
import { Dropdown } from 'primeng/dropdown';
import { ReconcileService } from '../services/reconcile.service';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { Subscription } from 'rxjs';
import { PlanService } from '../../plan/services/plan.service';
@Component({
  selector: 'app-close-off-log',
  templateUrl: './close-off-log.component.html',
  styleUrls: ['./close-off-log.component.scss'],
})
export class CloseOffLogComponent {
  filterSites: any;
  showMissingSites: boolean = true;
  defaultIWeekEndingDate: Date;
  closeOffLogs: any[] = [];
  sites: any[] = [];
  today: any;
  // filteredSites: any;
  selectedSite: any = '';
  selectedapplicationSite: any = '';
  disableCloseOff: boolean = true;
  layoutSubscription: Subscription;
  columnApi: any;
  columnState: any;
  userName: any;
  selectedOptions: any;
  applicationOptions: any;
  applicationId: any;
  gridOptions: any;
  private gridApi!: GridApi<any>;
  colDefs: ColDef[] = [
    { field: 'site', headerName: 'Site', width: 100 },
    { field: 'weekEnding', headerName: 'Week Ending', width: 100 },
    { field: 'weekEnding1', headerName: 'Week Ending - Date', width: 100 },
    { field: 'weekEnding2', headerName: 'Week Ending - Time', width: 100, },
    { field: 'user', headerName: 'User', width: 100 },
    { field: 'status', headerName: 'Status', width: 100 },
    { field: 'submitted', headerName: 'Submitted', width: 150 },
    { field: 'submitted1', headerName: 'Submitted - Date', width: 150 },
    { field: 'submitted2', headerName: 'Submitted - Time', width: 150 },
    { field: 'started', headerName: 'Started', width: 100 },
    { field: 'started1', headerName: 'Started - Date', width: 100 },
    { field: 'started2', headerName: 'Started - Time', width: 100 },
    { field: 'exported', headerName: 'Exported', width: 100 },
    { field: 'exported1', headerName: 'Exported - Date', width: 100 },
    { field: 'exported2', headerName: 'Exported - Time', width: 100 },
    { field: 'reconciled', headerName: 'Reconciled', width: 100 },
    { field: 'reconciled1', headerName: 'Reconciled - Date', width: 100 },
    { field: 'reconciled2', headerName: 'Reconciled - Time', width: 100 },
    { field: 'reported', headerName: 'Reported', width: 100 },
    { field: 'reported1', headerName: 'Reported - Date', width: 100 },
    { field: 'reported2', headerName: 'Reported - Time', width: 100 },
    { field: 'cancelled', headerName: 'Cancelled', width: 100 },
    { field: 'cancelled1', headerName: 'Cancelled - Date', width: 100 },
    { field: 'cancelled2', headerName: 'Cancelled - Time', width: 100 },
  ];
  columnDefs: ColDef[] = this.colDefs;

  public defaultColDef: ColDef = {
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    //editable: true,
  };




  constructor(public planService: PlanService, private reconcileService: ReconcileService, public dialogService: DialogService, public navbarService: NavbarService) {
    this.gridOptions = {
      context: { Component: this }
    }
    // this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
    //   if (shouldSubscribe) {
    //     let data = this.saveLayout();
    //     console.log("create:", data)
    //     this.dialogService.savaLayout(data);
    //   }
    // })
   // this.getView();
  }

  // saveLayout(): any {
  //   if (this.columnApi) {
  //     this.columnState = this.columnApi.getColumnState();
  //     let columns = [];
  //     for (let column of this.columnState) {
  //       const customColumn = {
  //         name: column.colId,
  //         visible: !column.hide,
  //         width: column.width,
  //         sort: column.sort,
  //         filter: column.filter
  //       }
  //       columns.push(customColumn)

  //     }
  //     let columnValueObj: any = { columns };
  //     columnValueObj = JSON.stringify(columnValueObj);
  //     this.userName = sessionStorage.getItem('username');
  //     this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
  //     let paramObj :any= {}; 
  //     paramObj = {
  //       //"applicationOptionId": this.applicationId ? this.applicationId : null,
  //       "optionName": "a2v3.reconcile.closeoff.layout",
  //       "optionValue": columnValueObj,
  //       "siteId": this.selectedSite,
  //       "userId": this.userName
  //     }
  //     if(this.applicationId && (this.applicationId !== null)) {
  //       paramObj["applicationOptionId"] = this.applicationId;
  //     }
  //     return paramObj;
  //   }
  // }

  // getView() {
  //   this.planService.getView().subscribe((result: any) => {
  //     if (result) {
  //       this.applicationOptions = result.applicationOptions;
  //       console.log("applicationn optionsss:", this.applicationOptions);
  //       this.applicationOptions.filter((item: any) => {
  //         if (item["optionName"] === "a2v3.reconcile.closeoff.layout")
  //           this.applicationId = JSON.parse(item["applicationOptionId"]);
  //         console.log("id:", this.applicationId)
  //       })
  //     }
  //   })
  // }


  // getLayout() {
  //   this.planService.getView().subscribe((result: any) => {
  //     if (result) {
  //       this.applicationOptions = result.applicationOptions;
  //       console.log("applicationn optionsss:", this.applicationOptions);
  //       this.applicationOptions.filter((item: any) => {
  //         if (item["optionName"] === "a2v3.reconcile.closeoff.layout") {
  //           this.applicationId = JSON.parse(item["applicationOptionId"]);
  //           if (this.applicationId) {
  //             this.columnState = JSON.parse(item["optionValue"]);
  //             if (this.columnState) {

  //               if (this.columnState.columns) {
  //                 this.columnState.columns.forEach((column: any) => {
  //                   if ("name" in column) {
  //                     column.colId = column.name;
  //                     delete column.name
  //                   }
  //                 });
  //                 this.columnState = this.columnState.columns;
  //                 this.applyLayout();
  //               }
  //             }
  //           }
  //         }
  //       });
  //     }
  //   })


  //   //  });
  // }

  // applyLayout() {
  //   // console.log("now:", this.columnDefs, this.columnFields)
  //   const applyColumnStateParams = {
  //     state: this.columnState,
  //     applyOrder: true
  //   }
  //   this.columnApi.getColumnState().map((obj: any) => {
  //     const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
  //     if (!matchingObj) {
  //       this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
  //     }
  //   })
  //   let sample: any[] = [];
  //   this.columnApi.applyColumnState(applyColumnStateParams);
  //   this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
  //     const column = this.columnApi.getColumn(colId);
  //     if (column) {
  //       this.columnApi.setColumnWidth(column, width);
  //       this.columnApi.setColumnVisible(column, visible)
  //     }
  //   });
  //   // console.log("fields:",this.columnFields);
  //   this.selectedOptions = [];
  //   this.colDefs.filter((column: any) => {
  //     this.columnState.forEach((element: any) => {
  //       if (element.visible) {
  //         if (column.field === element.colId) {
  //           sample.push(column);
  //           this.selectedOptions.push(column.field);
  //         }
  //       }

  //     })
  //   });
  //   this.columnDefs = sample;
  //   this.gridApi.setColumnDefs(this.columnDefs);

  // }

  onGridReady(params: any) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
   // this.getLayout();
  }


  onSiteSelect(event: any) {
    console.log("selected option:", event);
    this.selectedSite = event;
    this.getRowData();
  }
  onClearCompanyId() {
    // console.log("selected site:", this.selectedSite);
    //this.payAdviceLines.get('companyId')?.setValue('');
    this.selectedSite = null;
    this.getRowData();
  }
  getSites() {
    console.log("selected site:", this.selectedSite);
  }

  filteredSites(event: any) {
    console.log("selected site:", event.query);
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.sites.length; i++) {
      let country = this.sites[i];
      if (country.name.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filterSites = filtered;
  }



  ngOnInit() {
    this.today = new Date();
    //this.columnDefs = [...this.originalColumnDefs]
    this.reconcileService.pageTitleSubject.next('Close Off Log');
    //  this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
    this.userName = sessionStorage.getItem('username');
    let today = new Date();
    today.setDate(today.getDate());
    this.defaultIWeekEndingDate = today;
    this.getRowData();
    this.selectedOptions = this.colDefs.map((coulmn) => coulmn.field);
  }

  getRowData() {
    let siteId;
    if (!this.selectedSite || this.selectedSite == undefined)
      siteId = null;
    else
      siteId = this.selectedSite.siteId;
    console.log(siteId);
    let closeOffDetails = {
      selectedSite: siteId,
      showMissingSitesForLastWeek: this.showMissingSites,
      weekEndingDate: this.defaultIWeekEndingDate.getTime()
    }
    this.reconcileService.closeOffLog(closeOffDetails)
      .subscribe(
        (result: any) => {
          console.log("result:", result);
          let i = 0;
          this.closeOffLogs = result.closeOffLogs;
          this.closeOffLogs.forEach((element) => {
            // console.log(element.site);
            this.sites.push({ "name": element.site, "siteId": element.siteId });
          });
          console.log("sites:", this.sites);
        })
  }

  displayObject(obj: any) {
    return obj ? obj.name : '';
  }
  getOptions() {
    console.log("called cross", this.selectedSite);
    //this.selectedSite = null;
    //dropdown.placeholder = '';
    //drop//down.resetFilter();
    this.getRowData();
  }

  getMissingSites(missingSites: boolean) {
    this.showMissingSites = !missingSites;
    this.getRowData();
  }

  clearFilters() {
    this.colDefs.forEach(element => {
      this.gridApi.destroyFilter(element.field!);
    });

  }
  onSelectionChange(event: any) {
    console.log(event.value);
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column) =>

      event.value.includes(column.field)

    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
}

import { ChangeDetectorRef, Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ReconcileService } from './services/reconcile.service';
import { ViewReconcile } from './models/view.reconcile.model';
import { map } from 'rxjs/operators';
import { DialogComponent } from 'src/app/shared/dialog/dialog.component';
import { routingPath } from 'src/app/config/config.model';
import { MatDialog } from '@angular/material/dialog';
import { AutoComplete } from 'primeng/autocomplete';
import { TollDialogComponent } from 'src/app/shared/toll-dialog/toll-dialog.component';
import { AutomaticCompletionStatusComponent } from './automatic-completion-status/automatic-completion-status.component';
import { ConfirmationService, MessageService, SelectItem } from 'primeng/api';

import { Subscription } from 'rxjs';
import { ErrorList, ExceptionInfo } from './view-runsheet-form/ViewRunsheetId.model';
interface City {
  name: string;
  code: string;
}

@Component({
  selector: 'app-reconcile',
  templateUrl: './reconcile.component.html',
  styleUrls: ['./reconcile.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [MessageService, ConfirmationService],
})
export class ReconcileComponent {
  cities: City[];
  selectedCity: City;
  subscription: Subscription;
  viewDetails: ViewReconcile;
  isActiveBtn: boolean = false;
  pageTitle = 'Reconcile';

  headerRunsheet: any;
  errFirst: any;
  errorId: any;
  errorDetail: any;
  errorInner: any;
  exceptionTime: any;
  errorHeader2: any;

  sortOrder = [
    "Automatic Completion",
    "Create Runsheet",
    "List complete Runsheets",
    "List Incomplete Runsheets",
    "List Incomplete Services",
    "Release Runsheets on Hold"
  ];
  // autoCompleteLayout: any = {
  //   heading: 'Complete all runsheets until',
  //   contentText: 'Are you sure you want to save this layout?'
  // }
  autoCopleteText: any = {
    heading: 'Complete all runsheets until',
    contentText: '',
  };
  constructor(
    private readonly changeDetectorRef: ChangeDetectorRef,
    private reconcileService: ReconcileService,
    public dialog: MatDialog,
    private messageService: MessageService,
    private router: Router,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit(): void {
    this.getReconcileViewDetails();
    // this.operAutoCompletePopup();
  }
  ngAfterViewChecked(): void {
    this.changeDetectorRef.detectChanges();
    this.subscription = this.reconcileService.pageTitleSubject.subscribe(
      (message) => (this.pageTitle = message)
    );
  }

  getReconcileViewDetails() {
    this.reconcileService.setReconcilePage().subscribe((result: any) => {
      this.viewDetails = result;
      console.log('Api data reconsile', this.viewDetails.actionGroupList);
    });
  }

  // sortMenuItems() {
  //   this.menuItems.sort((a, b) => {
  //     return sortOrder.indexOf(a.name) - sortOrder.indexOf(b.name);
  //   });
  // }

  openReconcile(routePath: string) {
    console.log(routePath);
    console.log('action.name >> ', routingPath);
    if (routePath === routingPath.createRunsheet) {
      this.pageTitle = 'Create Runsheet';
      this.router.navigate(['reconcile/CreateRunsheet']);
    } else if (routePath === routingPath.listIncompleteRunsheets) {
      this.pageTitle = 'List Incomplete Runsheets';
      this.router.navigate(['reconcile/ListIncompleteRunsheets']);
    } else if (routePath === routingPath.listcompleteRunsheets) {
      this.pageTitle = 'List Complete Runsheets';
      this.router.navigate(['reconcile/ListCompleteRunsheets']);
    } else if (routePath === routingPath.listIncompleteServices) {
      this.pageTitle = 'List Incomplete Services';
      this.router.navigate(['reconcile/ListIncompleteServices']);
    } else if (routePath === routingPath.autoCompleteStatusRoute) {
      this.router.navigate(['reconcile']);
      this.openDialog();
    } else if (routePath === routingPath.releaseRunsheetHold) {
      this.router.navigate(['reconcile']);
      this.getReleaseRunsheetOnHold();
    } else if (routePath === routingPath.createAdjustment) {
      this.pageTitle = 'Create Adjustment';
      this.router.navigate(['reconcile/Financials/CreateAdjustment']);
    } else if (routePath === routingPath.periodicCharges) {
      this.pageTitle = 'Periodic Charges';
      this.router.navigate(['reconcile/Financials/PeriodicCharges']);
    } else if (routePath === routingPath.periodicPayments) {
      this.pageTitle = 'Periodic Payments';
      this.router.navigate(['reconcile/Financials/PeriodicPayments']);
    }

    //////////////////////////
    else if (routePath === routingPath.CreateInvoices) {
      this.pageTitle = 'Create Invoices';
      this.router.navigate(['reconcile/CreateInvoices']);
    } else if (routePath === routingPath.CreatePayAdvices) {
      this.pageTitle = 'Create Pay Advices';
      this.router.navigate(['reconcile/CreatePayAdvices']);
    } else if (routePath === routingPath.PrintInvoices) {
      this.pageTitle = 'Print Invoices';
      this.router.navigate(['reconcile/PrintInvoices']);
    } else if (routePath === routingPath.PrintPayAdvices) {
      this.pageTitle = 'Print Pay Advices';
      this.router.navigate(['reconcile/PrintPayAdvices']);
    }
    ///////closeoff module
    else if (routePath === routingPath.CloseOffLog) {
      this.pageTitle = 'Close Off Log';
      this.router.navigate(['reconcile/CloseOffLog']);
    } else if (routePath === routingPath.SubmitCloseOff) {
      this.pageTitle = 'Submit Close Off';
      this.router.navigate(['reconcile/SubmitCloseOff']);
    }
  }
  mes: string = '';
  sum: string = '';
  showprogressbar: boolean = true;
  processwidth = 'width:';
  totalprocess: number = 0;
  totalrecord: number = 0;
  extraText: string = '';
  openDialog(): void {
    let dialogRef = this.dialog.open(TollDialogComponent, {
      width: '600px',
      position: {
        top: '100px', 
      },
      data: {
        component: AutomaticCompletionStatusComponent,
        defaultValue: this.autoCopleteText,
      },
    });
    dialogRef.afterClosed().subscribe(
      (res) => {
        if (res?.data?.Result) {
          this.mes = res.data.Result;
          // testing purpose
          // this.mes = '2 runsheets are being completed';
          this.processwidth = 'width:';
          this.extraText = '';
          this.totalprocess = res.data.number;
          this.totalrecord = res.data.number;
          // testing purpose
          // this.totalprocess = 2;
          // this.totalrecord = 2;
          if (this.mes == '0 runsheets are being completed') {
            this.sum = '';
            this.showprogressbar = false;
          } else {
            this.sum = 'Automatic Completion Progress';
            if (this.totalprocess != 0) {
              this.processwidth =
                this.processwidth +
                String((this.totalprocess / this.totalrecord) * 100) +
                '%';
            }
            this.extraText =
              String(this.totalprocess) +
              '/' +
              String(this.totalrecord) +
              ' processed';
            this.showprogressbar = true;
          }
          this.messageService.add({
            key: 'customToast',
            severity: 'success',
            summary: this.sum,
            detail: this.mes,
          });
        }
        if (res?.data?.error) {
          const lockErr: ErrorList = res?.data?.error?.errorList;
          const lockErrDetail: ExceptionInfo = lockErr.ExceptionInfos[0];
          this.errFirst = '';
          // this.errorHeader2 = lockErr.ErrorMessage;
          this.errorInner = lockErrDetail.UserErrorDescription;
          this.errorId = lockErrDetail.ErrorId;
          this.exceptionTime = lockErr.ExceptionTime;
          const lockUsername =
            lockErrDetail.UserErrorDescription.indexOf('BY ') + 3;
          // this.lockUserName =
          //   lockErrDetail.UserErrorDescription.substring(lockUsername);
          if (lockErrDetail.ContextId === 'INTERNAL') {
            this.errFirst = '500 Internal Server Error';
          }

          // console.log('Runsheet Error', lockErr);

          this.messageService.add({
            key: 'customToast',
            severity: 'error',
            life: 30000,
          });

        // this.headerRunsheet = 'Runsheet Completion';
        this.confirmationService.confirm({
          message:
            'Sorry, you can not complete runsheet because runsheet completion has been disabled.',
          header: 'Runsheet Completion',
          icon: 'pi pi-exclamation-triangle',
          accept: () => {
            // this.submitForm();
            setTimeout(() => {
              // this.reconcileFormCreateRunsheetSubmit();
            }, 200);
          },
          reject: () => {
            // If needed, handle rejection
          },
          
        });
        }
    
      },
      (err: any) => {
        console.log('err', err);
      }
    );
  }

  showConfirm() {
    this.messageService.add({
      key: 'confirm',
      sticky: true,
      severity: 'warn',
      summary: 'Are you sure?',
      detail: 'Confirm to proceed',
    });
  }
  getReleaseRunsheetOnHold() {
    this.reconcileService.getReleaseRunsheetOnHold().subscribe(
      (runSheetOnHold: any) => {
        console.log('runSheetOnHold >>', runSheetOnHold.Result);
        this.messageService.add({
          key: 'show',
          severity: 'success',
          summary: '',
          detail: runSheetOnHold.Result,
        });
      },
      (error) => {
        this.messageService.add({
          key: 'show',
          severity: 'error',
          summary: '',
          detail: 'There was an error',
        });
        alert('There was an error');
      }
    );
  }
}

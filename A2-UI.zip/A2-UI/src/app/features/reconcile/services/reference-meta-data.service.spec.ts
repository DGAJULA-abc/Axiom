import { TestBed } from '@angular/core/testing';

import { ReferenceMetaDataService } from './reference-meta-data.service';

describe('ReferenceMetaDataService', () => {
  let service: ReferenceMetaDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReferenceMetaDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

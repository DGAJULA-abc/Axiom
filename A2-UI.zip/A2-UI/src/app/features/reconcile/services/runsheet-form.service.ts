import { Injectable, OnInit } from '@angular/core';
import * as moment from 'moment';
import * as _ from 'lodash';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';


import { BehaviorSubject, Observable, Subject, map, of } from 'rxjs';
import { RunsheetLine } from '../view-runsheet-form/ViewRunsheetId.model';
import { PlanService } from '../../plan/services/plan.service';
import { ReferenceDataService } from './reference-data.service';
import { RunsheetLineDetailService } from '../detail/runsheet-line-detail/runsheet-line-detail.service';
import { HttpClient } from '@angular/common/http';
import { TimeRunsheetService } from './time-runsheet.service';
import { TimezoneServiceService } from './timezone-service.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';

@Injectable({
  providedIn: 'root',
})
export class RunsheetFormService implements OnInit {
  public griddDataSubject = new BehaviorSubject<any[]>([]);
  public runsheetLinesObj = new BehaviorSubject<any>(null);
  public runsheetLinesData = new BehaviorSubject<any>(null);
  public gridData$ = this.griddDataSubject.asObservable();
  public runSheetFormParentObject: Subject<any> = new Subject();
  public runSheetFormSubject: Subject<any> = new Subject();
  private _serviceDetailForm: any;
  private _runLoadDetailForm: any;
  private _runSheetContainerDetailForm: any;
  private _runSheetBreakForm: any;
  private _runSheetReasonForm: any;
  private _tripDetailForm: any;
  // private _dialogResultSubject:any;
  //dialog data for discard/save/cancel fn
   public dialogResultSubject = new Subject<any>();

  public _runSheetEventDetail: Subject<any> = new Subject();
  public _runSheetRatingDetail: Subject<any> = new Subject();
  public _showBreak: Subject<any> = new Subject();
  public deleteBreakRow: Subject<any> = new Subject();
  public newRunsheetLineFormReset: Subject<any> = new Subject();
  // public formStateSubmit: Subject<any> = new BehaviorSubject(false);

  public permissionFields: Subject<any> = new Subject();
  public reasonApiDataWithId: Subject<any> = new Subject();
  reasonApiDataWithId$ = this.reasonApiDataWithId.asObservable();
  private _deleteBreakId: any;

  public runseetSubsCribeData: Subject<any> = new Subject();
  runseetSubsCribeData$ = this.runseetSubsCribeData.asObservable();

  selectedSite:any;
  
  constructor(
    private planService: PlanService,
    private RefDataService: ReferenceDataService,
    private RunsheetLineService: RunsheetLineDetailService,
    private http: HttpClient,
    private navbarService:NavbarService,
    private timeService: TimeRunsheetService,
    private timezoneService: TimezoneServiceService
  ) {}
  ngOnInit(): void {
    this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
  }

  // Initialize with the form structure you expect, or use any if structure is unknown/dynamic
  private formChanges = new BehaviorSubject<any>(null);
  private formChangesbreak = new BehaviorSubject<any>(null);
  private tripFormChangesOnGrid = new BehaviorSubject<any>(null);


  private formDataSubject = new Subject<any>();
  formData$ = this.formDataSubject.asObservable();


  public deleteBreakRowId: Subject<any> = new Subject<any>();
  deleteBreakId$ = this.deleteBreakRowId.asObservable();   

  formChanges$ = this.formChanges.asObservable();

  emitFormChanges(data: any) {
    this.formChanges.next(data);
  }

  formChangesbreak$ = this.formChangesbreak.asObservable();

  emitFormChangesBreak(data: any) {
    this.formChangesbreak.next(data);
  }

  tripFormChangesOnGrid$ = this.tripFormChangesOnGrid.asObservable();

  emittripFormChangesOnGrid(data: any) {
    this.tripFormChangesOnGrid.next(data);
  }

  emitRunseetSubsCribeData(data: any) {
    this.runseetSubsCribeData.next(data);
  }
  private loadFormDataSubject = new Subject<any>();
  loadFormData$ = this.loadFormDataSubject.asObservable();

  private containerFormDataSubject = new Subject<any>();
  containerFormData$ = this.containerFormDataSubject.asObservable();

  private breeakFormDataSubject = new Subject<any>();
  breeakFormDataSubject$ = this.breeakFormDataSubject.asObservable();

  private reasonFormDataSubject = new Subject<any>();
  reasonFormDataSubject$ = this.reasonFormDataSubject.asObservable();

  private reasonApiDataSubject = new Subject<any>();
  reasonApiDataSubject$ = this.reasonApiDataSubject.asObservable();

  private tripFormDataSubject = new Subject<any>();
  tripFormDataSubject$ = this.tripFormDataSubject.asObservable();

  public unitDataSubject = new Subject<any>();
  public detailSubjectForm = new Subject<any>();
  // tripFormDataSubject$ = this.unitDataSubject.asObservable();

  sendDeleteBreakId(id: any) {
     this.deleteBreakRowId.next(id);
  }

  sendFormData(data: any) {
    this.formDataSubject.next(data);
  }

  sendLoadFormData(data: any) {
    this.loadFormDataSubject.next(data);
  }

  sendContainerFormData(data: any) {
    this.containerFormDataSubject.next(data);
  }

  sendBreakFormData(data: any) {
    this.breeakFormDataSubject.next(data);
  }

  sendReasonFormData(data: any) {
    this.reasonFormDataSubject.next(data);
  }

  sendTripFormData(data: any) {
    this.tripFormDataSubject.next(data);
  }

  updateGridData(data: any) {
    this.griddDataSubject.next(data);
  }
  sendReasonApiData(data: any) {
    this.reasonApiDataSubject.next(data);
  }
  // runsheetFormSubmitObj () {
  //   this.runSheetFormParentObject.subscribe((res: any) => {
  //     console.log("Submit runsheet res", res);

  //   })
  // }

  // Getter delete val
  get breakDeleteId(): any {
    // Add any custom logic here if needed
    return this._deleteBreakId;
  }

  // Setter
  set breakDeleteId(value: any) {
    // Here, you can include validation or transformation logic before assigning the value
    this._deleteBreakId = value;

    // Optionally, trigger other actions when the value changes
    this.onDeleteValChanged();
  }

  private onDeleteValChanged(): void {
    // Custom logic to execute when myValue changes
    console.log(`Value has been changed to: ${this._deleteBreakId}`);
  }

  //runsheet Lines Service Detail form
  get serviceDetailForm() {
    return this._serviceDetailForm;
  }
  set serviceDetailForm(value) {
    this._serviceDetailForm = value;
  }

  // runsheet Lines Service Load Form
  get serviceLoadForm() {
    return this._runLoadDetailForm;
  }
  set serviceLoadForm(value) {
    this._runLoadDetailForm = value;
  }

  // runsheet Lines Container Load Form
  get runsheetLineContainerForm() {
    return this._runSheetContainerDetailForm;
  }
  set runsheetLineContainerForm(value) {
    this._runSheetContainerDetailForm = value;
  }

  // runsheet Lines Container Load Form
  get runsheetBreakForm() {
    return this._runSheetBreakForm;
  }
  set runsheetBreakForm(value) {
    this._runSheetBreakForm = value;
  }

  // runsheet Lines Container Load Form
  get reasonDetailForm() {
    return this._runSheetReasonForm;
  }
  set reasonDetailForm(value) {
    this._runSheetReasonForm = value;
  }

  // //runsheet trip detail Service Detail form
  get tripDetailForm() {
    return this._tripDetailForm;
  }
  set tripDetailForm(value) {
    this._tripDetailForm = value;
  }

  // get dialogResult() {
  //   return this._dialogResultSubject;
  // }
  // set dialogResult(value) {
  //   this._dialogResultSubject = value;
  // }

  /**
   * Check of lookup button can be displayed
   *
   * @returns {boolean}
   */
  isReadyToShiftDetails() {
    // return  $scope.Runsheet.data.runsheet.driverId && $scope.Runsheet.deliveryDateStamp;
  }

  // , fieldObj: any
  updateLinesByTrip(runsheetLines: any, tripData: any): any {
    // if (fieldObj && fieldObj.lName === 'trailerId') {
    //   // entity.firstRunsheetLine.owntrailer = this.getOwnTrailer(runsheet, entity);
    // }
    console.log('entity values', tripData);

    _.chain(runsheetLines)
      .filter({ tripno: tripData.tripno })
      .forEach((line) => {
        // Copy properties from entity.firstRunsheetLine to line
        // ...
        line.truckId = tripData.truckId;
        // line.truck = RefDataService.get('trucks', entity.firstRunsheetLine.truckId);
        line.trailerId = tripData.trailerId;
        line.trailerTagId = tripData.trailerTagId;
        line.locationReturnId = tripData.locationReturnId;
        // we only set the tripodostart and tripodoend on the first runsheet line of the trip (tripseq=1).
        if (line.tripseq === 1) {
          line.tripodostart = tripData.tripodostart;
          line.tripodoend = tripData.tripodoend;
        } else {
          line.tripodostart = null;
          line.tripodoend = null;
        }

        line.tripstarttime = tripData.tripstarttime;
        line.tripendtime = tripData.tripendtime;
        line.hiretruck = tripData.hiretruck;
        line.owntrailer = tripData.owntrailer;
        line.offsiderused = tripData.offsiderused;
      })
      .value();
    console.log('Trip match payload', runsheetLines);

    return runsheetLines;
  }

  /**
   * Check if user options 'reqRunsheetKm' = true, then system should warn user when startkm/endkm is null or distance < 0
   * @param runsheetCopy
   */
  checkInvalidRunsheetKm(runsheetCopy: any) {
    return (
      // runsheetCopy.reqRunsheetKm &&
      !runsheetCopy.startkm || !runsheetCopy.endkm || runsheetCopy.distance < 0
    );
  }

  /**
   * Check each runsheet line, if service type requires unit then system should warn user when units are null
   * @param runsheetCopy
   */
  currentServiceType: any;

  checkInvalidServiceUnit(runsheetCopy: any, serviceType: any) {
    var invalidService = false;

    runsheetCopy.runsheetLines.forEach((runsheetLine: any) => {
      // var currentServiceType = this.RefDataService.get(
      //   'serviceTypes',
      //   runsheetLine.serviceTypeId
      // );

      serviceType.map((serviceType: any) => {
        if ((serviceType.serviceTypeId = runsheetLine.serviceTypeId)) {
          this.currentServiceType = serviceType;
        }
      });
      // let currentServiceType = runsheetLine.serviceTypeId;
      if (this.currentServiceType) {
        for (var i = 1; i <= 8; i++) {
          if (
            this.currentServiceType['reqUnit' + i] &&
            runsheetLine['qty' + i] === null
          ) {
            invalidService = true;
          }
        }
      }
    });

    return invalidService;
  }

  /**
   * Check validation of required fields
   * @param runsheet
   */
  checkInvalidResources(runsheetCopy: any, viewServiceTypes: any) {
    return (runsheetCopy.runsheetLines || []).some((runsheetLine: any) => {
      return this.RunsheetLineService.validateRunsheetLineResources(
        runsheetLine,
        viewServiceTypes
      );
    });
  }

  validateRunsheetLines(runsheetLines: any): Observable<any> {
    return this.http
      .post(`${apiEndpoint.runsheetLinesValidation}`, runsheetLines)
      .pipe(
        map((response: any) => {
          return this.generateLoadNoDuplicationMsg(response);
        })
      );
  }

  generateLoadNoDuplicationMsg(runsheetLines: any) {
    var loadNoDuplicationMsg = _(runsheetLines)
      .filter(function (runsheetLine) {
        return runsheetLine.loadNoDuplicated === true;
      })
      .map(function (runsheetLine) {
        return (
          '(Load No:' +
          runsheetLine.lineServiceTO.loadNo +
          ',Customer ID:' +
          runsheetLine.lineServiceTO.customerId +
          ')'
        );
      })
      .groupBy(function (msg) {
        return msg;
      })
      .keys()
      .join(', ');
    return loadNoDuplicationMsg === ''
      ? null
      : 'The runsheet line(s) with ' +
          loadNoDuplicationMsg +
          ' exist already. Do you want to duplicate?';
  }

  updateRunsheetPUT(runsheet: any): Observable<any> {
    return this.http.post(`${apiEndpoint.runsheetUpdate}`, runsheet);
  }

  completeRunsheetPOST(id: string): Observable<any> {
    const url = `${apiEndpoint.runsheetComplete}/${id}/complete`;
    return this.http.post(url, {});
  }

  getDriverBreaksObj(breakFormData: any) {
    return {
      deducted: false,
      siteId: this.selectedSite,
      planned: false,
      breakTypeId: breakFormData.breakTypeId || null,
      locationId: breakFormData.locationId || null,
      commentA: breakFormData.commentA || null,
    };
  }

  getRunsheetLinesObj(
    amt:any,
    tripDataObjData: any,
    loadFormReceivedData: any,
    serviceFormReceivedData: any,
    selectedRunSheetLinedata: any,
    containerFormReceivedData: any,
    unitDataServiceDetail: any
  ) {
    return {
      lineTemperature: null,
      loadNoDuplicated: false,
      locationContDropId: null,
      locationContPickupId: null,
      nextstoptime: null,
      payamt: amt,
      paydesc: null,
      payestimated: false,
      pickuparrivetime: null,
      pickupdeparttime: null,
      pickupdoctime: null,
      pickupreadytime: null,
      rateId: null,
      remarks: null,
      servicehours: null,
      tripkm: 0,
      ...unitDataServiceDetail,
      siteId: this.selectedSite,
      containerId: null,
      droparrivetime: serviceFormReceivedData
        ? this.dateTimeJone(serviceFormReceivedData.droparrivetime)
        : null,
      dropdeparttime: serviceFormReceivedData
        ? this.dateTimeJone(serviceFormReceivedData.dropdeparttime)
        : null,
      dropdoctime: serviceFormReceivedData
        ? this.dateTimeJone(serviceFormReceivedData.dropdeparttime)
        : null,
      dropreadytime: serviceFormReceivedData
        ? this.dateTimeJone(serviceFormReceivedData.dropreadytime)
        : null,
      createdby: serviceFormReceivedData?.createdby || null,
      docket: serviceFormReceivedData?.docket || null,
      groupseq: serviceFormReceivedData?.groupseq || null,
      locationDropId: serviceFormReceivedData?.locationDropId || null,
      locationPickupId: serviceFormReceivedData?.locationPickupId || null,
      serviceTypeId: serviceFormReceivedData?.serviceTypeId || null,
      deliverydate: selectedRunSheetLinedata?.deliverydate || 1701262800000,
      directfromdepot: selectedRunSheetLinedata?.directfromdepot || false,
      globaldropbonus: selectedRunSheetLinedata?.globaldropbonus || null,
      events: selectedRunSheetLinedata?.events || null,
      hiretruck: tripDataObjData?.hiretruck || false,
      locationReturnId: tripDataObjData?.locationReturnId || null,
      offsiderused: tripDataObjData?.offSiderUsed || false,
      owntrailer: tripDataObjData?.ownTrailer || false,
      trailerId: tripDataObjData?.trailerId || null,
      trailerTagId: tripDataObjData?.trailerIdTag || null,
      tripendtime: tripDataObjData?.tripendtime || null,
      tripno: tripDataObjData?.tripno || 1,
      tripodoend: tripDataObjData?.tripOdoEnd || null,
      tripodostart: tripDataObjData?.tripOdoStart || null,
      tripseq: tripDataObjData?.tripseq || 1,
      tripstarttime: tripDataObjData?.tripstarttime || null,
      truckId: tripDataObjData?.truckId || '',
      loadTypeId: loadFormReceivedData?.loadTypeId || null,
      serviceId: selectedRunSheetLinedata?.serviceId || '',
      lineServiceTO: {
        batchNo: serviceFormReceivedData.batchNo || null,
        chargeAmt: selectedRunSheetLinedata?.lineServiceTO?.chargeAmt || null,
        chargeDesc: selectedRunSheetLinedata?.lineServiceTO?.chargeDesc || null,
        clearCharge:
          selectedRunSheetLinedata?.lineServiceTO?.clearCharge || false,
        complete: selectedRunSheetLinedata?.lineServiceTO?.clearCharge || false,
        consignmentMasterCustomerId:
          selectedRunSheetLinedata?.lineServiceTO
            ?.consignmentMasterCustomerId || null,
        loadNo: selectedRunSheetLinedata?.lineServiceTO?.loadNo || null,
        customerSite: containerFormReceivedData?.customerSite || null,
        created: selectedRunSheetLinedata?.lineServiceTO?.created || null,
        customerId: serviceFormReceivedData?.customerId || null,
        custRef: serviceFormReceivedData?.custRef || null,
        dehirePark: containerFormReceivedData?.dehirePark || null,
        dataSource: selectedRunSheetLinedata?.lineServiceTO?.dataSource || null,
        dehireDeadline:
          selectedRunSheetLinedata?.lineServiceTO?.dehireDeadline || null,
        deliveryClose: containerFormReceivedData
          ? this.dateTimeJone(containerFormReceivedData.deliveryClose)
          : null,
        deliveryOpen: containerFormReceivedData
          ? this.dateTimeJone(containerFormReceivedData.deliveryOpen)
          : null,
        depot: containerFormReceivedData?.depot || null,
        despatchBy: loadFormReceivedData?.despatchBy || null,
        destinationLoc: containerFormReceivedData?.destinationLoc || null,
        destinationSite: containerFormReceivedData?.destinationSite || 0,
        originSite: containerFormReceivedData?.originSite || 0,
        dropLocation: {
          accShortCut: null,
          active: null,
          address1: null,
          address2: null,
          customerId: containerFormReceivedData?.customerId || null,
          defaultTripSeq: null,
          disableWPUpdated: null,
          externalLookUp: null,
          geofence: null,
          internalLookUp: null,
          latitude: null,
          loadTimeMins: null,
          loadTimeMinsPerUnit: null,
          loadTimeUnit: null,
          locationCode: null,
          locationDesc: null,
          locationId: containerFormReceivedData?.locationId || null,
          locationIdGroup: null,
          locationTypeId: containerFormReceivedData?.locationTypeId || null,
          longitude: null,
          mapReference: null,
          mapSourceId: null,
          permanent: null,
          personIdContact: null,
          personIdContactName: null,
          postCode: null,
          remarks: containerFormReceivedData?.remarks || null,
          routeCapacity: null,
          routeId: null,
          segExported: null,
          segManaged: null,
          siteId: this.selectedSite,
          siteTravelTime: null,
          state: null,
          suburb: null,
          truckSizeLimit: null,
          waitTimeMins: null,
          waitTimeMinsPerUnit: null,
          waitTimeUnit: null,
          window1From: null,
          window1To: null,
          window2From: null,
          window2To: null,
          window3From: null,
          window3To: null,
          zoneChargeId: null,
          zonePayId: null,
        },
        loadLocation: {
          accShortCut: null,
          active: null,
          address1: null,
          address2: null,
          customerId: null,
          defaultTripSeq: null,
          disableWPUpdated: null,
          externalLookUp: null,
          geofence: null,
          internalLookUp: null,
          latitude: null,
          loadTimeMins: null,
          loadTimeMinsPerUnit: null,
          loadTimeUnit: null,
          locationCode: null,
          locationDesc: 'ESTHER MCCLUSKEY',
          locationId: '3000166-BACCHUS MARSH',
          locationIdGroup: null,
          locationTypeId: null,
          longitude: null,
          mapReference: null,
          mapSourceId: null,
          permanent: null,
          personIdContact: null,
          personIdContactName: null,
          postCode: null,
          remarks: null,
          routeCapacity: null,
          routeId: null,
          segExported: null,
          segManaged: null,
          siteId: this.selectedSite,
          siteTravelTime: null,
          state: null,
          suburb: null,
          truckSizeLimit: null,
          waitTimeMins: null,
          waitTimeMinsPerUnit: null,
          waitTimeUnit: null,
          window1From: null,
          window1To: null,
          window2From: null,
          window2To: null,
          window3From: null,
          window3To: null,
          zoneChargeId: null,
          zonePayId: null,
        },
        lastGroupSeq: null,
        loadId: selectedRunSheetLinedata?.lineServiceTO?.loadId || null,
        originLoc: containerFormReceivedData?.originLoc || null,
        pickupLocation: {
          accShortCut: null,
          active: null,
          address1: null,
          address2: null,
          customerId: null,
          defaultTripSeq: null,
          disableWPUpdated: null,
          externalLookUp: null,
          geofence: null,
          internalLookUp: null,
          latitude: null,
          loadTimeMins: null,
          loadTimeMinsPerUnit: null,
          loadTimeUnit: null,
          locationCode: null,
          locationDesc: null,
          locationId: null,
          locationIdGroup: null,
          locationTypeId: null,
          longitude: null,
          mapReference: null,
          mapSourceId: null,
          permanent: null,
          personIdContact: null,
          personIdContactName: null,
          postCode: null,
          remarks: null,
          routeCapacity: null,
          routeId: null,
          segExported: null,
          segManaged: null,
          siteId: this.selectedSite,
          siteTravelTime: null,
          state: null,
          suburb: null,
          truckSizeLimit: null,
          waitTimeMins: null,
          waitTimeMinsPerUnit: null,
          waitTimeUnit: null,
          window1From: null,
          window1To: null,
          window2From: null,
          window2To: null,
          window3From: null,
          window3To: null,
          zoneChargeId: null,
          zonePayId: null,
        },
        priority: null,
        rateId: selectedRunSheetLinedata?.lineServiceTO?.rateId || null,
        reasonId: serviceFormReceivedData?.reasonId || null,
        returnLocationId: null,
        svcReasonLines: null,
        scheduleDate: loadFormReceivedData?.scheduleDate || 1701262800000,
        serviceDesc: null,
        serviceGroup: null,
        serviceId: 15442446,
        serviceNo: 'M0083696',
        totalChargeAmt: null,
        tripIdCust: null,
        vesselEta: containerFormReceivedData
          ? this.dateTimeJone(containerFormReceivedData.vesselEta)
          : null,
        vesselId: containerFormReceivedData?.vesselId || null,
        wharf: containerFormReceivedData?.wharf || null,
      },
    };
  }

  dateTimeJone(timeFormat: any) {
    // console.log('timeFormat > ', timeFormat);

    return this.timeService.dateTime(timeFormat);
  }

  runsheetProcessing(id: string): Observable<any> {
    const url = `${apiEndpoint.runsheetStatus}/runsheetStatus/${id}/status`;
    return this.http.get(url);
  }

  checkRunsheetTypeType(value: any) {
    if (typeof value === 'string') {
      return 'String';
    } else if (typeof value === 'number') {
      return 'Number';
    } else {
      return 'Other';
    }
  }

  /**
   * Check if ui-grids can be displayed
   * @param runsheet
   * @returns {boolean}
   */
  showGrid(runsheet: any) {
    return !!runsheet.driverId;
  }

  /**
   * Check of lookup button can be displayed
   * @param runsheet
   * @returns {boolean}
   */
  //  && runsheet.deliveryDateStamp
  isReadyToLookup(runsheet: any, deliveryDateStamp: any) {
    return runsheet && runsheet.driverId && deliveryDateStamp;
  }

  getCanWrite(): boolean {
    // Implement your logic to check if the user can write
    return true; // Placeholder for actual implementation
  }

  runsheetErrorList(runsheetId: string, shiftId: string): Observable<any> {
    if (this.getCanWrite()) {
      const url = `${apiEndpoint.runsheetErrorList}/${runsheetId}/show-errors`;
      return this.http.post<any>(url, { shiftId: shiftId });
    } else {
      // If the user cannot write, return an observable with an empty data array
      return of({ data: [] });
    }
  }

  setLookupDates(form: any, data: any): any {
    if (data.runsheet.starttime) {
      const startTime: any = moment(
        this.timezoneService.localize(data.runsheet.starttime)
      ).format('HH:mm');
      const startDate: any = moment(
        this.timezoneService.localize(data.runsheet.deliverydate)
      ).format('YYYY-MM-DD');
      form.deliveryDateStamp = this.timezoneService.unLocalize(
        new Date(`${startDate} ${startTime}`)
      );
    }

    if (data.runsheet.endtime) {
      const endTime = moment(
        this.timezoneService.localize(data.runsheet.endtime)
      ).format('HH:mm');
      const endDate = moment(
        this.timezoneService.localize(data.runsheet.enddate)
      ).format('YYYY-MM-DD');
      form.data.enddateStamp = this.timezoneService.unLocalize(
        new Date(`${endDate} ${endTime}`)
      );

      const returndepottime = moment(
        this.timezoneService.localize(data.runsheet.returndepottime)
      ).format('HH:mm');
      form.data.returndepotdateStamp = this.timezoneService.unLocalize(
        new Date(`${endDate} ${returndepottime}`)
      );
    }

    return form;
  }

  /**
   * Check if can show time
   * @param runsheet
   * @returns {boolean}
   */
  showTime(runsheet: any) {
    return !!runsheet.showLookup;
  }
}

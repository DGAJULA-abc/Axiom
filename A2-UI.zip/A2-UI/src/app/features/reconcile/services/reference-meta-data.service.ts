import { Injectable } from '@angular/core';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root',
})
export class ReferenceMetaDataService {
  _refMetadata: any;

  constructor() {}

  function(refMetadata: any) {
    this._refMetadata = refMetadata;
  }

  getIdKey(entityRef: any) {
    return (
      _.find((this.getEntityReferenceData(entityRef) || {}).fields, {
        id: true,
      }) || {}
    ).name;
  }

  getIdKeyType(entityRef: any) {
    return (
      _.find((this.getEntityReferenceData(entityRef) || {}).fields, {
        id: true,
      }) || {}
    ).type;
  };

  /**
   * Get meta data for entity
   * @param entity
   * @returns {*|{}}
   */
  getEntityReferenceData(entity: any) {
    return _.find(this.getReferenceMetadata(), { name: entity });
  }

  /**
   * get reference meta data
   * @returns {*} Array of object meta data
   */
  getReferenceMetadata() {
    return this._refMetadata;
  }
}

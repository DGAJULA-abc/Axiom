import { TestBed } from '@angular/core/testing';

import { RunsheetAutofillModalService } from './runsheet-autofill-modal.service';

describe('RunsheetAutofillModalService', () => {
  let service: RunsheetAutofillModalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RunsheetAutofillModalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

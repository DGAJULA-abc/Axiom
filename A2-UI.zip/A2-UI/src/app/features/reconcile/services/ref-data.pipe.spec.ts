// // import { RefDataPipe } from './ref-data.pipe';

// describe('RefDataPipe', () => {
//   it('create an instance', () => {
//     const pipe = new RefDataPipe();
//     expect(pipe).toBeTruthy();
//   });
// });

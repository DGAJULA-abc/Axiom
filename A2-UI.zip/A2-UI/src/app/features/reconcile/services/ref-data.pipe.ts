import { Pipe, PipeTransform } from '@angular/core';

// DayOfWeekPipe
@Pipe({ name: 'dayOfWeek' })
export class DayOfWeekPipe implements PipeTransform {
  transform(cellValue: number): string | null {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    if (!isNaN(cellValue)) {
      cellValue = (parseInt(cellValue.toString(), 10) - 1) % 7;
    }
    return days[cellValue] || null;
  }
}


// ContainerPipe
@Pipe({ name: 'container' })
export class ContainerPipe implements PipeTransform {
  // constructor(private refDataService: RefDataService) {}

  transform(containerId: string): any {
    // ...implementation using this.refDataService...
  }
}

// DriverPipe
@Pipe({ name: 'driver' })
export class DriverPipe implements PipeTransform {
  // constructor(private refDataService: RefDataService) {}

  transform(driverId: string): any {
    // ...implementation using this.refDataService...
  }
}
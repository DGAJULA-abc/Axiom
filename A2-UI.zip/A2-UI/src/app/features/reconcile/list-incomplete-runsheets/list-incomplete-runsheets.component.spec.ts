import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListIncompleteRunsheetsComponent } from './list-incomplete-runsheets.component';

describe('ListIncompleteRunsheetsComponent', () => {
  let component: ListIncompleteRunsheetsComponent;
  let fixture: ComponentFixture<ListIncompleteRunsheetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListIncompleteRunsheetsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListIncompleteRunsheetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { ReconcileService } from '../services/reconcile.service';
import { CellrenderComponent } from '../list-incomplete-services/cellrender/cellrender.component';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { ConfirmationService } from 'primeng/api';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { PlanService } from '../../plan/services/plan.service';
import { RunsheetService } from '../services/runsheet.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';

@Component({
  selector: 'app-list-incomplete-runsheets',
  templateUrl: './list-incomplete-runsheets.component.html',
  styleUrls: ['./list-incomplete-runsheets.component.scss'],
  providers: [ConfirmationService]
})
export class ListIncompleteRunsheetsComponent {
  viewListDataGrid: any;
  showPanelLeft: boolean = false;
  rowData: any[] = [];
  showRunsheetDetail: boolean = false;
  ok: boolean = false;
  sum: number = 0;
  isDivVisible: boolean = false;
  selectedRow: any = null;
  gridApi!: GridApi<any>;
  runsheetIdValue: any;
  applicationOptions: any;
  applicationId: any;
  gridOptions: any;
  runSheetId: any;
  selectedOptions: any[];
  columnApi: any;
  rowClickedData: any;
  isButtonDisabled: boolean = true;
  isLoading: boolean = false;

  qty1data: any = 0;
  unit1data: any;
  qty2data: any = 0;
  unit2data: any;
  qty3data: any = 0;
  unit3data: any;
  qty4data: any = 0;
  unit4data: any;
  qty5data: any = 0;
  unit5data: any;
  qty6data: any = 0;
  unit6data: any;
  qty7data: any = 0;
  unit7data: any;
  qty8data: any = 0;
  unit8data: any;

  public myStyles = {
    'width': '50vw',
    'z-index': 9999
  };

  colDefs: any[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'runsheetid',
      headerName: 'Runsheet Id',
      width: 100,
      floatingFilter: true,
    },
    {
      field: 'runsheettypeid',
      headerName: 'Runsheet Type Id',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    { field: 'driver', headerName: 'Driver' },
    // { field: 'driverid', headerName: 'Driver Id' },
    {
      field: 'startdatetime',
      headerName: 'Start Date Time',
      width: 100,
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
    floatingFilter: true,
    filter: 'agTextColumnFilter',
    },
    {
      field: 'enddatetime',
      headerName: 'End Date Time',
      width: 100,
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
    floatingFilter: true,
    filter: 'agTextColumnFilter',
    },
    {
      field: 'companyid',
      headerName: 'Company ID',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'companytypeid',
      headerName: 'Company Type',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'returndepottime',
      headerName: 'Return Depot Time',
      width: 100,
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
    floatingFilter: true,
    filter: 'agTextColumnFilter',
    },
    {
      field: 'totalhours',
      headerName: 'Total Hours',
      width: 100,
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'startkm',
      headerName: 'Start KM',
      width: 100,
      filter: true,
      cellDataType: 'text',
      floatingFilter: true,
    },
    {
      field: 'endkm',
      headerName: 'End KM',
      width: 100,
      filter: true,
      cellDataType: 'text',
      floatingFilter: true,
    },
    {
      field: 'totalkms',
      headerName: 'Total Kms',
      width: 100,
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'deliverydate',
      headerName: 'Delivery Date',
      width: 100,
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'sumcharge',
      headerName: 'Sum Charge',
      width: 100,
      filter: true,
      cellDataType: 'text',
      floatingFilter: true,
    },
    { field: 'payamt', headerName: 'Pay amt' },
    {
      field: 'cntservices',
      headerName: 'Count Services',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'createdby',
      headerName: 'Created By',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'holdcode',
      headerName: 'Hold Code',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'complete',
      headerName: 'Complete',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'hasbreaks',
      headerName: 'Has Breaks',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'employeename',
      headerName: 'Employee Name',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'firstname',
      headerName: 'Firstname',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'lastname',
      headerName: 'Lastname',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'vendorname',
      headerName: 'Vendor name',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'gpskm',
      headerName: 'GPS KM',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'odokm',
      headerName: 'Odo KM',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'rateid',
      headerName: 'Rate ID',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
  ];
  columnDefs: ColDef[] = this.colDefs;
  public paginationPageSize = 100;
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    // editable: true,
  };

  rihtSideRow: any[] = [];
  rihtSideDefs: any[] = [
    {
      field: 'runsheetid',
      headerName: '',
      cellRenderer: CellrenderComponent,
      filter: 'agNumberColumnFilter',
    },
    {
      field: 'serviceGroup',
      headerName: 'Service Group',
      width: 250,
      filter: true,
      floatingFilter: true,
    },
   
    { field: 'tripseq', headerName: 'Seq' },
    { field: 'loadTypeId', headerName: 'Load Type Id' },
    { field: 'serviceId', headerName: 'Service Id' },
    { field: 'serviceTypeId', headerName: 'Service Type Id' },
    { field: 'truckId', headerName: 'Truck Id' },
  ];

  // showRunsheetDetail: boolean = true;
  layoutSubscription: Subscription;
  columnState: any;
  userName: any;
  selectedSite: any;
  canWrite: boolean;
  constructor(
    public permission: PermissionsService,
    private runsheetService: RunsheetService,
    public planService: PlanService,
    private reconcileService: ReconcileService,
    private router: Router, 
    private confirmationService: ConfirmationService,
    public dialogService: DialogService,
    public navbarService: NavbarService
  ) {
    this.gridOptions = {
      context: { Component: this },
    };
    this.reconcileService.pageTitleSubject.next('List Incomplete Runsheets');
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
      if (shouldSubscribe) {
        let data = this.saveLayout();
        console.log("create:", data)
        this.dialogService.savaLayout(data);
      }
    })
    this.getView();
  }

  onPaginationChanged(event: any) {
    if (event.api && !event.api.isLastPageFound()) {
      const currentPage = event.api.paginationGetCurrentPage();
      const pageSize = event.api.paginationGetPageSize();
      this.fetchData(currentPage * pageSize, (currentPage + 1) * pageSize);
    }
  }

  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.setup.Search.Runsheets.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  fetchData(startRow: number, endRow: number) {
    // Implement your data fetching logic here
    // This example just generates dummy data
    const data = Array.from({length: endRow - startRow}, (_, index) => {
      return { id: startRow + index, value: `Value ${startRow + index}` };
    });
    this.rowData = data;
    this.gridApi.setRowData(this.rowData);
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Runsheets.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Runsheets.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  } 

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }

  ngOnInit(): void {
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
    //this.canWrite = this.runsheetService.getCanWrite();
    this.columnDefs = this.colDefs;
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.getRowData();
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('EnterRunsheets');
      const result2 = await this.permission.canWrite('Runsheet2');
      if(result1 && result2){
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }
      console.log("Result:", this.canWrite,result1,result2); // Use the result here
      
    } catch (error) {
      console.error("Error:", error);
    }
  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column: any) =>
      event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  rightSideForm(event: any) {
    this.runsheetIdData(event.data.runsheetid);
    this.runSheetId = event.data.runsheetid;
  }

  dialogdata: any[] = [];
  selectedIds: any[] = [];
  rowdatacount: any;
  onSelectionChanged(event: any) {
    var selectedNodes = event.api.getSelectedNodes();
    var rowCount = event.api.getSelectedNodes().length;
    this.rowdatacount = rowCount;
    this.showPanelLeft = false;
    this.ok = false;
    // Delete button will be disabled till row click
    if (rowCount >= 1) {
      this.isButtonDisabled = false;
    } else {
      this.isButtonDisabled = true;
    }
    if (rowCount <= 1) {
      this.rowClickedData = event.api.getSelectedNodes()[0].data;
      this.runsheetIdData(this.rowClickedData.runsheetid);
      this.runSheetId = this.rowClickedData.runsheetid;
      this.isDivVisible = true;
      this.ok = true;
      this.isButtonDisabled = false;
    } else {
      this.isDivVisible = false;
      this.ok = false;
    }
    // Clear the selectedIds array before populating it again
    this.selectedIds = [];
    // Run a loop for the selected rows and store IDs in selectedIds array
    for (let i = 0; i < rowCount; i++) {
      this.selectedIds.push(selectedNodes[i].data.runsheetid); // Assuming 'id' is the property you want to store
    }
  }
  runsheetLines: any[] = [];
  driverBreaks: any[] = [];

  runsheetLength: any;


  runsheetIdData(runSheetId: any) {
    this.reconcileService.getViewRunsheetId(runSheetId).subscribe((idData) => {
      console.log("idData?.runsheet >> ", idData?.runsheet)
      this.viewListDataGrid = idData?.runsheet;
      if (idData.runsheet?.runsheetLines) {
        this.rihtSideRow = idData.runsheet.runsheetLines;
        this.driverBreaks = idData.runsheet.driverBreaks;

        this.runsheetLength = this.rihtSideRow.length;

        this.runsheetLines.forEach((row: any) => {
          this.qty1data += row.qty1;
          if (row.qty1) {
            this.unit1data = row.unit1;
          }
          this.qty2data += row.qty2;
          if (row.qty2) {
            this.unit2data = row.unit2;
          }
          this.qty3data += row.qty3;
          if (row.qty3) {
            this.unit3data = row.unit3;
          }
          this.qty4data += row.qty4;
          if (row.qty4) {
            this.unit4data = row.unit4;
          }
          this.qty5data += row.qty5;
          if (row.qty5) {
            this.unit5data = row.unit5;
          }
          this.qty6data += row.qty6;
          if (row.qty6) {
            this.unit6data = row.unit6;
          }
          this.qty7data += row.qty7;
          if (row.qty7) {
            this.unit7data = row.unit7;
          }
          this.qty8data += row.qty8;
          if (row.qty8) {
            this.unit8data = row.unit8;
          }
        });
      }
    });
  }

  getRowData() {
    this.reconcileService
      .getListIncompleteRunsheet()
      .subscribe((result: any) => {
        this.rowData = result.runsheets;
      });
  }

  showPanel() {
    this.reconcileService.panelBehSubject.subscribe((res) => {
      this.showPanelLeft = res;
      this.showRunsheetDetail = true;
    });
  }

  viewRunsheetPage() {
    // this.router.navigate(['reconcile/ViewRunsheet'], {
    //   queryParams: { runsheetId: this.runSheetId },
    //   queryParamsHandling: 'merge',
    // });
    // Construct the URL
    const baseUrl = this.router.serializeUrl(
      this.router.createUrlTree(['reconcile/ViewRunsheet'], {
        queryParams: { runsheetId: this.runSheetId },
        queryParamsHandling: 'merge',
      })
    );
    // .then(data => this.reloadCurrentRoute())

    // Open the new tab
    window.open(baseUrl, '_blank');
  }
  DeleteData() {
    this.isLoading = true;

   const body = 'Are you sure you want to delete?';
    this.confirmationService.confirm({
      message: 'Click OK to Continue',
      header: 'Are you sure you want to delete?',
      accept: () => {
        console.log('Run Service not accept');
        this.deleteRunsheet();
        this.isLoading = false;

      },
      reject: () => {
        this.isLoading = false;
        // subscriber.next(null);
        // subscriber.complete();
      },
    });
    
  }
  
  deleteRunsheet() {
    this.reconcileService
      .deleteListInCompletedata(this.selectedIds)
      .subscribe((res: any) => {
        this.getRowData();
        this.closeDetailsPanel();
      });
  }
  closeDetailsPanel() {
    this.isDivVisible = false;
    this.ok = false;
  }

  reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router
      .navigateByUrl('reconcile/ViewRunsheet', { skipLocationChange: true })
      .then(() => {
        this.router.navigate([currentUrl]);
      });
  }
}

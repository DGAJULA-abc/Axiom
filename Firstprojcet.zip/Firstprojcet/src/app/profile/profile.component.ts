import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { User } from '../user';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profile: User | null = null;

  constructor(private auth: AuthService) {}
  
  ngOnInit() {
    const userEmail = localStorage.getItem('userEmail'); // Assuming the user's email is stored in localStorage
    if (userEmail) {
      this.auth.getUserDetails(userEmail).subscribe(
        (user: User) => {
          this.profile = user;
        },
        (error: any) => {
          console.log('Failed to fetch user profile', error);
        }
      );
    } else {
      console.log('User email is not available');
    }
  }
}

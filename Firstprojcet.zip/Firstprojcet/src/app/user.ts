// user.model.ts
export interface User {
    firstName: string;
    lastName: string;
    age: number;
    college: string;
    email: string;
    userName: string;
    password: string;
    dateOfBirth: string;
    contact: string;
    roles: string;
    addresses: string[];
    skills: string[];
    reference: string;
  }
  
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, tap, throwError } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly baseUrl = 'http://localhost:8080/api';
  private authToken: string | null = null;
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<User | null>(null);
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }
  private userEmail: string | null = null;
  private getAuthHeaders(): HttpHeaders {
    const token = this.authToken;
    let headers = new HttpHeaders();
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
    return headers;
  }

  login(data: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/login`, data).pipe(
      tap(response => {
        if (response.token && response.user && response.user.email) {
          this.authToken = response.token;
          localStorage.setItem('authToken', response.token);
          this.userEmail = response.user.email; // Store user email
          this.currentUserSubject.next(response.user);
        }
      })
    );
  }

  // Modify the getUserData method to use stored user email
  getUserDetails(email: string): Observable<any> {
    const headers = new HttpHeaders({
      Authorization: `Bearer ${this.authToken}`
    });
    return this.http.get<any>(`${this.baseUrl}?email=${email}`, { headers }).pipe(
      catchError(error => {
        return throwError(error);
      })
    );
  }
  postUser(user: User): Observable<User> {
    const headers = this.getAuthHeaders();
    return this.http.post<User>(`${this.baseUrl}/register`, user, { headers });
  }
}

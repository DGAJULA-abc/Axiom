import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit{
  zoneForm!: FormGroup;

  constructor(private fb: FormBuilder, private auth: AuthService) {}

  ngOnInit() {
    this.zoneForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      age: ['', Validators.required],
      college: ['', Validators.required],
      email: ['', Validators.required],
      userName: ['', Validators.required],
      password: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      contact: ['', Validators.required],
      roles: ['', Validators.required],
      addresses: this.fb.array([]),
      skills: this.fb.array([]),
      reference: ['', Validators.required],
      agreement: [false, Validators.requiredTrue]
    });
  }

  get addresses(): FormArray {
    return this.zoneForm.get('addresses') as FormArray;
  }

  get skills(): FormArray {
    return this.zoneForm.get('skills') as FormArray;
  }

  addAddress() {
    this.addresses.push(this.fb.control(''));
  }

  removeAddress(index: number) {
    this.addresses.removeAt(index);
  }

  addSkill() {
    this.skills.push(this.fb.control(''));
  }

  removeSkill(index: number) {
    this.skills.removeAt(index);
  }

  registe: any[] = [];

  onSubmit() {
    console.log(this.zoneForm.value);
    this.auth.postUser(this.zoneForm.value).subscribe((ele: any) => {
      if (ele) {
        console.log("registered successfully"); // Corrected typo in 'registed' to 'registered'
        this.registe = ele;
      }
    });
  }
}

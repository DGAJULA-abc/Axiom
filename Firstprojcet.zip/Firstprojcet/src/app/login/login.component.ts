import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'] // Corrected to styleUrls
})
export class LoginComponent implements OnInit {
  zoneForm!: FormGroup;

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  ngOnInit() {
    this.zoneForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]], // Added email validator
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.zoneForm.valid) {
      console.log(this.zoneForm.value);
      this.router.navigate(['/profile']);
      this.auth.login(this.zoneForm.value).subscribe(
        (response: any) => {
          console.log('Login successful', response);
          // Corrected typo
        },
        (error: any) => {
          console.log('Login failed', error);
          // Optionally handle error
        }
      );
    }
  }
}

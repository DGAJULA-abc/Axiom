function sendMessage() {
    const messageInput = document.getElementById('message-input');
    const messageText = messageInput.value.trim();

    if (messageText === '') return;

    const chatWindow = document.getElementById('chat-window');

    // Create message element
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', 'sent');
    messageElement.innerText = messageText;

    // Append message to chat window
    chatWindow.appendChild(messageElement);

    // Clear input field
    messageInput.value = '';

    // Scroll chat window to the bottom
    chatWindow.scrollTop = chatWindow.scrollHeight;

    // Simulate receiving a response (for demonstration)
    setTimeout(() => {
        const responseElement = document.createElement('div');
        responseElement.classList.add('message', 'received');
        responseElement.innerText = 'Received: ' + messageText;

        chatWindow.appendChild(responseElement);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }, 1000);
}

console.log("Hi Arya");
function clicked(){
    document.getElementById("demo").innerHTML = "Hi Dinesh";
    let num1 = 15;
let num2 = 5;

console.log(num1+num2);
console.log(num1-num2);
console.log(num1*num2);
console.log(num1/num2);
console.log(num1%num2);
}
function clicked1(){
    // document.getElementById("demo1").style.backgroundColor = 'blue';
    // document.getElementById("demo1").style.color='white';
    document.getElementById("demo1").style.display = 'none';
}

// variables

var name="dinesh";
console.log(name);
console.log(typeof name);
let age=23;
age = 37;
console.log(typeof age);
const name1 = 'dileep';
console.log(age, name1);

let name2 = 'yoga';
let age1 = 21;
let clg = 'SRIT';

let user = {
    name2 : 'yoga',
    age1: 21,
    clg: 'SRIT'
}
console.log(user);
//arrays
let user1 = ['Dinesh', 'Dileep','Yoga','Keeru'];
console.log(user1);

function showMyName(names){
    console.log("Dileep Gajula :)", names);
}
showMyName('Dillep');

function calcsSum(num1, num2){
    let sum = num1+ num2;
    return sum
}
const res = calcsSum(1,5);
console.log(res);

console.log(`My name id ${name}`);

//swap two numbers

function swapTowNums(a,b){
    let c = a;
    a=b;
    b= c;
    console.log("a is", a);
    console.log("b is",b);
}
swapTowNums(10, 15);

function staementsNums(){
    let num = 10;
    if(num > 0){
        console.log("Positive number");
    }else{
        console.log("Negative number");
    }
}
staementsNums();

//switch statement

let color = 'Black';
const rel = (color == 'Black')? 'Black color': 'not match';
console.log("-------", rel);
switch(color){
    case 'red':
        console.log("red color");
        break;

    case 'while':
        console.log("white color");
        break;
        
    case 'Black':
        console.log("Black color");
        break;
    default:
        console.log("No color match");        
}

for(let i=0;i<10;i++){
    console.log("Capgemini",i);
}

let index = 0;
while(index<10){
    console.log("Hi Capgemini---", index);
    index++;
}

let index1 = 0;
do{
    console.log("Hello Capgemini---", index1);
    index1++;
}while(index1<10)

const objs = {
    name: "Dil",
    age: 23
}
const res1 = JSON.stringify(objs);
console.log("----", res1);
for(let obj in objs){
    console.log(obj, objs[obj]);
}
let aa = [1,4,2,7,8,9,3,0,6];
   let bc = aa.sort();
   console.log("-----------", bc);
for(let a of aa){
    console.log(a);
}

for(let i=0;i<=3;i++){
    for(let j=0;j<=3;j++){
        console.log(i,j);
    }
}

let message="I am working In capgemini";

console.log(message.toLocaleLowerCase());
console.log(message.toUpperCase());
console.log(message.split(' '));

let a = 'CAT';
let b = 'TAC';
function checking(a,b){
    a = a.split(' ').sort();
    b = b.split(' ').sort();
    if( a === b){
        return true;
    }else{
        return false;
    }
}
console.log(checking('CAT', 'TAC'));

let messag='I am working In capgemini"It\'s my First company"';
console.log(messag);
//Arrow Function

const AddTwoNums = (num1, num2) => num1+ num2 ;
console.log(AddTwoNums(15,15));

function passingParams(...args){
    console.log(args);
    let mulp = 1;
    for(let num of args){
        mulp = num * mulp;
    }
    return mulp;
}
console.log(passingParams(1,4,6,89,3,9,3,5,7));


const numbs= [1,2,3,4,5,6,7,8,9];
numbs.push(10,11,12,13);
numbs.unshift(-2,-1,0);
numbs.splice(3,0,44,55);
console.log(numbs);
numbs.reverse();
console.log(numbs);
numbs.sort();
console.log(numbs);

const news = [9, 8, 7, 6, 5, 4, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(news);

const MappingArray = news.map((num) => num * 2);
console.log(MappingArray);

const filteringNums = MappingArray.filter(function (nums) {
  return nums % 2 !== 1; // Corrected to keep odd numbers
});
console.log(filteringNums);

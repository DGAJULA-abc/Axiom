import {
  Component,
  AfterViewChecked,
  OnInit,
  ChangeDetectorRef,
  Input,
  OnDestroy,
  ViewChild,
} from '@angular/core';
import { IUser } from '../../model/user.model';
import { UserService } from '../../../services/authentication/user.service';
import { NavigationStart, Router } from '@angular/router';
import { forkJoin, interval, zip } from 'rxjs';


import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';

import { Observable, Subscription } from 'rxjs';
import { map, startWith, switchMap } from 'rxjs/operators';
import { NgFor, AsyncPipe } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'src/app/shared/dialog/dialog.component';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { NavbarService } from './services/navbar.service';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { AutoComplete } from 'primeng/autocomplete';
import { RunsheetFormService } from 'src/app/features/reconcile/services/runsheet-form.service';
import { ViewSites } from '../../model/navbar.model';
import { PermissionsService } from 'src/app/shared/services/permissions.service';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit, AfterViewChecked, OnDestroy {
  //properties
  username: string = '';
  //isLoggedIn: boolean = true;
  siteCheck: boolean = false;
  selectedItem: string = 'Select a Site';
  myDialog: any;
  siteControl = new FormControl('');
  siteOptions: string[] = [];
  userName: string = '';
  filteredOptions: Observable<string[]>;
  isNavbarShow: boolean = false;
  sub: Subscription;
  isAuthenticated: boolean = false;
  isLoggedIn: boolean= false;
  selectedSiteAdvanced: any[] | any;
  filteredSites: any[];
  sites: any[];
  selectedIdPageLoad: any = 'default value';
  browserRefresh: boolean = false;
  
  saveLayout: any = {
    heading: 'Save Layout',
    contentText: 'Are you sure you want to save this layout?'
  }
  subscription: Subscription;

  @ViewChild('autoCompleteInput') autoCompleteInput: AutoComplete;
  constructor(
    private readonly changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    public dialog: MatDialog,
    public authenticationService: AuthenticationService,
    public navbarService: NavbarService,
    public runsheetFormService: RunsheetFormService,
    private permissionsService: PermissionsService
  ) { }

  ngAfterViewChecked(): void {

    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    //  this.selectedSiteAdvanced = null;
    //this.autoCompleteInput.inputEL.nativeElement.value = '';
 
  this.authenticationService.isLoggedIn.subscribe((data:any)=>{
    this.isLoggedIn = data
  })
      console.log("is log:",this.isLoggedIn)
    
    this.checkAuthNav();
    // this.getBuildVersion();
  }

  filterSite(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.sites.length; i++) {
      let sites = this.sites[i];
      if (sites.description.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(sites);
      }
    }

    this.filteredSites = filtered;
    console.log('this.filteredSites', this.filteredSites);
  }

  checkAuthNav() {
    this.authenticationService.currentUserSubject.subscribe(data => {
      if(data) {
       this.getSiteView();
      }
      this.isAuthenticated = data;
    
    });
    this.authenticationService.checkAuth().subscribe(data => {
      this.isAuthenticated = data;
      if(this.isAuthenticated || this.isLoggedIn){
        this.isNavbarShow=true;
      }
      // if(data) {
      //  this.getSiteView();
      // }
    });
  }

  getSiteView() {    
       this.authenticationService.fetchContext().subscribe((siteData: ViewSites) => {
        console.log("siteDatakkk >>", siteData);  
        let applicationOptions = siteData?.applicationOptions;
        let sitePermissions = siteData?.permissions?.sitePermissions;
        if(siteData.selectedSite === null) {
          this.navbarService.siteSelectedInDrop.next(true)
        } else {
          this.navbarService.siteSelectedInDrop.next(true)
        }

        this.sites = siteData.sites
        this.userName = siteData.userName;
        this.navbarService.usernameSubject.next(this.userName);
        sessionStorage.setItem('username', this.userName);
        this.selectedSiteAdvanced = {id: siteData.selectedSite['id'], description: siteData.selectedSite['description']};
        console.log("siteData.selectedSite['id'] > ", this.selectedSiteAdvanced);
        this.navbarService.referenceMetadataSubject.next(siteData.referenceMetadata);
        this.navbarService.refServiceData.next(siteData.ref);
        this.permissionsService.permissionFetchSub.next(siteData);
        this.navbarService.applicationOptions.next(applicationOptions);
        this.runsheetFormService.permissionFields.next(sitePermissions);
        this.authenticationService.viewAPI.next(siteData)
       }); 
  }

  logout() {
     this.isNavbarShow = false;
     this.isAuthenticated = false;
      console.log("Logout done"); 
      // Redirect to login page
      this.router.navigate(['/']).then(() => {
      this.authenticationService.logout();
      // Reload the current application. This can help reset the application state completely.
      window.location.reload();
    });
  }


  openDialog() {
   const dialogRef = this.dialog.open(DialogComponent, {
      width: '600px',
      data: { callback: this.callBack.bind(this), defaultValue: this.saveLayout }
    });

    dialogRef.componentInstance.cancelClicked.subscribe(() =>{
      dialogRef.close();
    })
  }

  callBack(name: string) {
    this.saveLayout = name;
  }

  onChangeSite(siteData: any) {
    //  console.log(" event data >>", siteData); 
    this.navbarService.siteSelectedInDrop.next(false);
    this.isNavbarShow = true;
     const  item = siteData.description ;
     
     this.navbarService.selectedSiteId=siteData.id;
     sessionStorage.setItem('selectedSiteId', this.navbarService.selectedSiteId.toString())
     console.log("Selected Site ID-->", this.navbarService.selectedSiteId)
     this.getSiteSelectedIdNumber(siteData.id);
     this.navbarService.selectedIdDataNavbar = siteData;
     
    // Call the API every 5 seconds
    // interval(5000)
    // .pipe(switchMap(async () => this.onUpadtes()))
    // .subscribe((result) => {
    //   this.data = result;
    // });
  }

  getSiteSelectedIdNumber(site: any) {

    this.navbarService.getSiteSelectedId(site).subscribe(()=>{
      this.isNavbarShow = true;
      this.onReady()
    })
  }


 getBuildVersion() {
  let versionText = this.navbarService.getVersionUI();
   let version =  this.navbarService.getVersion();
    forkJoin([versionText, version]).subscribe(version => {
        console.log("version >> ", version[0]);
        
    })
 }

 
  ngOnDestroy() {
      if(this.sub) {
        this.sub.unsubscribe()
      }
  }

  /**Working on Atmosphere api  */
  uuID :String
  jsonObject: any;

  onReady(){
    this.navbarService.onReadyforUUID().subscribe((data) =>{
      console.log(data);
      this.uuID = data
      this.onUpadtes(data)
      this.sub = interval(10000)
    .subscribe(() => { this.onUpadtes(data)
    });
      }
    );
 
  }
  onUpadtes(uuId :string){
    this.navbarService.onUpdatesforData(uuId).subscribe((data)=>{
      console.log(data);
      if(data != null){
        if (data[0].message) {
          this.jsonObject = JSON.parse(data[0].message);
          // this.navbarService.atmosphereData = this.jsonObject;
          this.navbarService.sendData(this.jsonObject)
          // console.log('Atmosphere value', this.navbarService.atmosphereData);
        } else {
          console.error('JSON string is undefined');
        }
      // this.jsonObject = JSON.parse(data.message);
      }

    })
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';
import { BehaviorSubject, Observable, Subject } from "rxjs";

// import { ViewReconcile } from '../models/view.reconcile.model';

@Injectable({
  providedIn: 'root'
})
export class NavbarService {
  public referenceMetadataSubject = new BehaviorSubject<any>(null);
  referenceMetadata$ = this.referenceMetadataSubject.asObservable();

  public usernameSubject = new BehaviorSubject<string>('');
  public applicationOptions = new BehaviorSubject<any>(null);

  public refServiceData = new BehaviorSubject<any>(null);
  refServiceData$ = this.refServiceData.asObservable();
  public siteSelectedInDrop = new BehaviorSubject<any>(null);

  private _selectedIdDataNavbar: any;

  // public selectedIdDataNavbar = new BehaviorSubject<any>(null);
  // selectedIdDataNavbar$ = this.selectedIdDataNavbar.asObservable();

  constructor(
    private http: HttpClient
  ) { }
  selectedSiteId:number=0;
  atmosphereData :any
  
  /**
   * 
   * @returns 
   */
  private dataSubject = new BehaviorSubject<any>(null);
  data$ = this.dataSubject.asObservable();
    // Function to send data to subscribers
  sendData(data: any) {
    this.dataSubject.next(data);
  }

  getSiteView() :any {
    let options :any = [];
    return this.http.get<any>(apiEndpoint.contextView, options);
    //mock json
    //  return this.http.get<any>('assets/APIs/dashboard-view.json', options);
  }

  getVersion(): any {
    let options :any = [];
    return this.http.get<any>(apiEndpoint.version.mw, options);
  }

  getVersionUI(): any {
    let options :any = [];
    return this.http.get<any>(apiEndpoint.version.ui, options);
  }

  // getSites() {
  //   let options :any = [];
  //   return this.http.get<any>(`assets/APIs/dashboard-view.json`, options)
  //   // return this.http.get<any>(`${apiEndpoint.site}`, options)
 
  //   }

  getSiteSelectedId(site: any) {
    let options :any = [];
    return this.http.get<any>(`${apiEndpoint.selectSite}/${site}`, options)
  }  

  automaticCompletionStatus() {
    let options :any = [];
    return this.http.get<any>(`${apiEndpoint.autoCompleteStatus}`, options)
  }

  /**
   * Calling api for onReay()
   * Get Method :- UUID
   */
  onReadyforUUID(): Observable<string> {
    return this.http.get(`${apiEndpoint.onReady}`, { responseType: 'text' });
  }

  onUpdatesforData(uuId :any){
    //let uuId
    return this.http.post<any>(`${apiEndpoint.onUpadtes}`,uuId);

  }

  get selectedIdDataNavbar() {
    return this._selectedIdDataNavbar;
  }

  set selectedIdDataNavbar(value: any) {
     this._selectedIdDataNavbar = value;
  }
}

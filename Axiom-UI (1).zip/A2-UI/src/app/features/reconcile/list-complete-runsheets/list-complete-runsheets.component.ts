import {
  Component,
  EventEmitter,
  Output,
  ViewChild,
  ViewContainerRef,
  ViewEncapsulation,
} from '@angular/core';

import { CellrenderComponent } from '../list-incomplete-services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';
import { FormBuilder, NgForm, Validators, FormGroup } from '@angular/forms';
import * as moment from 'moment';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { Router } from '@angular/router';
import { PlanService } from '../../plan/services/plan.service';
import { RunsheetService } from '../services/runsheet.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';

@Component({
  selector: 'app-list-complete-runsheets',
  templateUrl: './list-complete-runsheets.component.html',
  styleUrls: ['./list-complete-runsheets.component.scss'],
  // encapsulation: ViewEncapsulation.None,
})
export class ListCompleteRunsheetsComponent {
  // @ViewChild(NgForm) form: NgForm;
  val = 'Initial value';
  submitted: {};
  rightTitle: string = 'List Complete Runsheet';
  date: Date | undefined;

  viewListDataGrid: any;
  showPanelLeft: boolean = false;
  rowData: any[] = [];
  showRunsheetDetail: boolean = false;
  ok: boolean = false;
  sum: number = 0;
  isDivVisible: boolean = false;
  selectedRow: any = null;
  gridApi!: GridApi<any>;
  applicationOptions: any;
  applicationId: any;
  runsheetIdValue: any;
  gridOptions: any;
  runSheetId: any;
  selectedOptions: any[];
  columnApi: any;
  rowClickedData: any;
  isButtonDisabled: boolean = true;
  isLoading = false;

  @Output() not: EventEmitter<string> = new EventEmitter<string>();

  colDefs: any[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'runsheetid',
      headerName: 'Runsheet Id',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',
    },
    {
      field: 'runsheettypeid',
      headerName: 'Runsheet Type Id',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    { field: 'driver', headerName: 'Driver' },
    {
      field: 'driverid',
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
      headerName: 'Driver Id',
    },
    {
      field: 'startdatetime',
      headerName: 'Start Date Time',
      cellRenderer: (params: any) => {
        const timestamp = params.value;
        const date = new Date(timestamp);
        return moment(date).tz('Australia/Melbourne').format('DD/MM/YYYY HH:mm:ss');
      },
      width: 190,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'enddatetime',
      headerName: 'End Date Time',
      cellRenderer: (params: any) => {
        const timestamp = params.value;
        const date = new Date(timestamp);
        return moment(date).tz('Australia/Melbourne').format('DD/MM/YYYY HH:mm:ss');
      },
      width: 190,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'companyid',
      headerName: 'Company Id',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'companytypeid',
      headerName: 'Company Type Id',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'returndepottime',
      headerName: 'Return Depot Time',
      cellRenderer: (params: any) => {
        const timestamp = params.value;
        const date = new Date(timestamp);
        return moment(date).tz('Australia/Melbourne').format('DD/MM/YYYY HH:mm:ss');
      },
      width: 190,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'totalhours',
      headerName: 'Total hours',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'startkm',
      headerName: 'Start KM',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',
    },
    {
      field: 'endkm',
      headerName: 'End KM',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',
    },
    {
      field: 'totalkms',
      headerName: 'Total KM',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',
    },
    {
      field: 'deliverydate',
      headerName: 'Delivery Date',
      cellRenderer: (params: any) => {
        const timestamp = params.value;
        const date = new Date(timestamp);
        return moment(date).tz('Australia/Melbourne').format('DD/MM/YYYY');
      },
      width: 190,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'sumcharge',
      headerName: 'Sum Charges',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',
    },
    {
      field: 'cntservices',
      headerName: 'Count Services',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'createdby',
      headerName: 'Created By',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'holdcode',
      headerName: 'Hold Code',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'complete',
      headerName: 'Complete',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'hasbreaks',
      headerName: 'Has Break',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'employeename',
      headerName: 'Employee Name',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'firstname',
      headerName: 'FirstName',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'lastname',
      headerName: 'Last Name',
      width: 100,
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'vendorname',
      headerName: 'Vendor Name',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',
    },
    {
      field: 'odokm',
      headerName: 'Odo KM',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',

    },
    {
      field: 'gpskm',
      headerName: 'GPS KM',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',

    },
    {
      field: 'rateid',
      headerName: 'Rate Id',
      width: 100,
      filter: true,
      floatingFilter: true,
      cellDataType: 'text',

    },
  ];
  columnDefs: ColDef[] = this.colDefs;

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    // editable: true,
  };
  display: boolean = true;
  layoutSubscription: Subscription;
  columnState: any;
  userName: any;
  selectedSite: any;
  canWrite:boolean;
  public paginationPageSize = 100;
  constructor(
    public permission: PermissionsService,
    private runsheetService: RunsheetService,
    public planService: PlanService,
    private reconcileService: ReconcileService,
    private fb: FormBuilder,
    private messageService: MessageService,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    private router: Router
  ) {
    this.gridOptions = {
      context: { Component: this },
    };
    this.reconcileService.pageTitleSubject.next('List Complete Runsheets');
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          console.log('create:', data);
          this.dialogService.savaLayout(data);
        }
      }
    );
    this.getView();
  }
  appOptionPayload: any = {};

  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.setup.Search.Runsheets.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Runsheets.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Runsheets.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    // this.fetchData(0, this.paginationPageSize);
    this.getLayout();
  }

  listForm = this.fb.group({
    deliveryFrom: [new Date(), Validators.required],
    deliveryTo: [new Date(), Validators.required],
  });

  ngOnInit(): void {
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
   // this.canWrite = this.runsheetService.getCanWrite();
    
    // this.getRowData();
    this.showPanel();
    this.selectedOptions = this.colDefs.map((coulmn) => coulmn.field);
  }

  fetchData(startRow: number, endRow: number) {
    // Implement your data fetching logic here
    // This example just generates dummy data
    const data = Array.from({length: endRow - startRow}, (_, index) => {
      return { id: startRow + index, value: `Value ${startRow + index}` };
    });
    this.rowData = data;
    this.gridApi.setRowData(this.rowData);
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('EnterRunsheets');
      const result2 = await this.permission.canWrite('Runsheet2');
      if(result1 && result2){
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }
      console.log("Result:", this.canWrite,result1,result2); // Use the result here
      
    } catch (error) {
      console.error("Error:", error);
    }
  }


  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column: any) =>
      event.value.includes(column.field)|| column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  ListCompleteRunsheetSubmit() {
    this.isLoading = true;

    //  const deliveryDate = this.listForm.value.deliveryFrom;
    //   new Date(deliveryDate)
    const listFormSubmit = {
      deliveryFrom: moment(
        this.listForm.value.deliveryFrom,
        'YYYY-MM-DD HH:mm:ss'
      ).format('x'),
      deliveryTo: moment(
        this.listForm.value.deliveryTo,
        'YYYY-MM-DD HH:mm:ss'
      ).format('x'),
    };

    this.reconcileService.getListCompleteRunsheet(listFormSubmit).subscribe(
      (result: any) => {
        this.isLoading = false;

        console.log('result complete runsheet data > ', result);

        this.rowData = result.runsheets;
      },
      (err: any) => {
        console.log(err);
        this.isLoading = false;
      }
    );
  }

  columnDef: any[] = [
    { field: 'tripseq', filter: false, headerName: 'Seq' },
    { field: 'lineServiceTO.loadNo', filter: false, headerName: 'Load No' },
    { field: 'lineServiceTO.tripIdCust', filter: false, headerName: 'Trip' },
    { field: '', filter: false, headerName: 'Service Group' },
    { field: 'serviceTypeId', filter: false, headerName: 'Service Type' },
    { field: 'loadTypeId', filter: false, headerName: 'Load Type' },
    { field: 'locationPickupId', filter: false, headerName: 'From' },
    { field: 'locationDropId', filter: false, headerName: 'To' },
    { field: 'lineServiceTO.true', headerName: 'Complete', filter: false },
    { field: 'locationReturnId', headerName: 'Return To', filter: false },
    {
      field: 'lineServiceTO.chargeAmt',
      headerName: 'Charge Amount',
      filter: false,
    },
    { field: 'payamt', headerName: 'Pay Amount', filter: false },
    { field: '', headerName: 'Service No', filter: false },
    { field: 'docket', headerName: 'Docket', filter: false },
    { field: 'containerId', headerName: 'Container', filter: false },
    { field: 'truckId', headerName: 'Truck', filter: false },
    { field: 'trailerId', headerName: 'Trailer', filter: false },
    { field: 'trailerTagId', headerName: 'Trailer Tag', filter: false },
    { field: 'events[0].fleetId', headerName: 'Fleet NO.', filter: false },
    {
      field: 'lineServiceTO.customerId',
      headerName: 'Customer ID',
      filter: false,
    },
    {
      field: 'lineServiceTO.pickupLocation.locationDesc',
      headerName: 'Pickup Location Desc',
      filter: false,
    },
    {
      field: 'lineServiceTO.dropLocation.locationDesc',
      headerName: 'Drop Location Desc',
      filter: false,
    },
    { field: '', headerName: 'Truck Type', filter: false },
    { field: '', headerName: '123456743', filter: false },
    { field: '', headerName: '23456', filter: false },
    { field: '', headerName: 'Load Location ', filter: false },
    { field: '', headerName: 'Load Location Desc', filter: false },
    { field: '', headerName: 'Charge Zone Drop', filter: false },
    { field: '', headerName: 'Pay Zone Drop', filter: false },
    { field: '', headerName: 'Charge Zone Pickup', filter: false },
    { field: '', headerName: 'Pay Zone Pickup', filter: false },
    { field: '', headerName: 'Fuel Levy Charge', filter: false },
    { field: '', headerName: 'Fuek Levy Pay', filter: false },
    { field: 'qty1', headerName: 'Qty. 1', filter: false },
    { field: 'qty2', headerName: 'Qty. 2', filter: false },
    { field: 'qty3', headerName: 'Qty. 3', filter: false },
    { field: 'qty4', headerName: 'Qty. 4', filter: false },
    { field: 'qty5', headerName: 'Qty. 5', filter: false },
    { field: 'qty6', headerName: 'Qty. 6', filter: false },
    { field: 'qty7', headerName: 'Qty. 7', filter: false },
  ];
  dataSource: any;
  onPaginationChanged(event: any) {
    if (event.api && !event.api.isLastPageFound()) {
      const currentPage = event.api.paginationGetCurrentPage();
      const pageSize = event.api.paginationGetPageSize();
      this.fetchData(currentPage * pageSize, (currentPage + 1) * pageSize);
    }
  }
  runsheetLength: any;
  qty1data: any = 0;
  unit1data: any;
  qty2data: any = 0;
  unit2data: any;
  qty3data: any = 0;
  unit3data: any;
  qty4data: any = 0;
  unit4data: any;
  qty5data: any = 0;
  unit5data: any;
  qty6data: any = 0;
  unit6data: any;
  qty7data: any = 0;
  unit7data: any;
  qty8data: any = 0;
  unit8data: any;

  dataForRightSideForm(id: any) {
    this.reconcileService.getViewRunsheetId(id).subscribe((idData) => {
      // console.log('idData >> ', idData);
      this.viewListDataGrid = idData.runsheet;
      this.runSheetId = idData?.runsheet?.id;
      if (idData.runsheet?.runsheetLines) {
        // console.log('runsheetLines >>', idData.runsheet.runsheetLines);
        this.dataSource = idData.runsheet.runsheetLines;
        this.runsheetLength = this.dataSource.length;
        idData.runsheet.runsheetLines.forEach((row: any) => {
          this.qty1data += row.qty1;
          if (row.qty1) {
            this.unit1data = row.unit1;
          }
          this.qty2data += row.qty2;
          if (row.qty2) {
            this.unit2data = row.unit2;
          }
          this.qty3data += row.qty3;
          if (row.qty3) {
            this.unit3data = row.unit3;
          }
          this.qty4data += row.qty4;
          if (row.qty4) {
            this.unit4data = row.unit4;
          }
          this.qty5data += row.qty5;
          if (row.qty5) {
            this.unit5data = row.unit5;
          }
          this.qty6data += row.qty6;
          if (row.qty6) {
            this.unit6data = row.unit6;
          }
          this.qty7data += row.qty7;
          if (row.qty7) {
            this.unit7data = row.unit7;
          }
          this.qty8data += row.qty8;
          if (row.qty8) {
            this.unit8data = row.unit8;
          }
        });
      }
    });
  }

  rightSideForm(event: any) {
    // console.log('row click', event);
    var rowCount = event.api.getSelectedNodes().length;
    // console.log('checcking code in row clicked', rowCount);
    if (rowCount > 1) {
      // Get a reference to the grid API
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
      // Select the clicked row
      event.node.setSelected(true);
    }
  }

  rowdatacount: any;
  deletedIdsRow: any[] = [];
  onSelectionChanged(event: any) {
    let selectedNodes = event.api.getSelectedNodes();
    this.deletedIdsRow = []; // Clear the deletedIdsRow array before populating it again
    selectedNodes.forEach((data: any) => {
      if (data.selected) {
        if (!data.data.hasOwnProperty('runsheetid')) {
          return;
        }
        this.deletedIdsRow.push(data.data.runsheetid);
      }
    });
    console.log("deletedIdsRow", this.deletedIdsRow);
  
    var rowCount = event.api.getSelectedNodes().length;
    if (rowCount == 1) {
      this.isDivVisible = true;
      this.ok = true;
      this.dataForRightSideForm(selectedNodes[0].data.runsheetid);
    } else {
      this.isDivVisible = false;
      this.ok = false;
    }
  }
  /**
   * To close right side and unselect the selected one
   */
  closeDialog() {
    // console.log('am i hereeeee');
    this.ok = false;
    this.isDivVisible = false;
    // Get a reference to the grid API
    var gridApi = this.gridOptions.api;
    // Call deselectAll to unselect all selected rows
    gridApi.deselectAll();
  }
  showPanel() {
    this.reconcileService.panelBehSubject.subscribe((res) => {
      // console.log('show Left Panel> ', res);

      this.showPanelLeft = res;
    });
  }

  backOut() {
    console.log('Click');
    this.isLoading = true;
    this.reconcileService
      .backoutRunsheetsCompleteRun(this.deletedIdsRow)
      .subscribe(
        (res: any) => {
          this.isLoading = false;
          if (res) {
            console.log('complete runsheet', res);
            if (res?.failureMsgs && res?.failureMsgs.length > 0) {
              this.handleResponse(res);
            } else {
              this.messageService.add({
                key: 'fullWidth',
                severity: 'success',
                summary: '',
                detail: 'Backout Successfully',
                // life: 3000 // Duration in milliseconds after which the message will be closed
                closable: true,
              });
            }
          }
        },
        // (err: any) => {
        //   console.log(err);
        //   this.isLoading = false;
        // }
      );
  }

  handleResponse(response: any) {
    if (Array.isArray(response?.failureMsgs)) {
      if (response?.failureMsgs && response?.failureMsgs.length > 0) {
        response.failureMsgs.map((msg: any) => {
          // ... do something with item
          this.showMessage('error', 'Error', msg);
        });
        // Handle the undefined or null case
      }
    }
  }

  private showMessage(severity: string, summary: string, detail: string) {
    // this.messageService.add({ severity, summary, detail });
    this.messageService.add({
      key: 'fullWidth',
      severity: severity,
      summary: summary,
      detail: detail,
      // life: 3000 // Duration in milliseconds after which the message will be closed
      closable: true,
    });
  }

  viewRunsheetPage() {
    // this.router.navigate(['reconcile/ViewRunsheet'], {
    //   queryParams: { runsheetId: this.runSheetId },
    //   queryParamsHandling: 'merge',
    // });
    // .then(data => this.reloadCurrentRoute())
    const baseUrl = this.router.serializeUrl(
      this.router.createUrlTree(['reconcile/ViewRunsheet'], {
        queryParams: { runsheetId: this.runSheetId },
        queryParamsHandling: 'merge',
      })
    );
    // .then(data => this.reloadCurrentRoute())

    // Open the new tab
    window.open(baseUrl, '_blank');
  }
}

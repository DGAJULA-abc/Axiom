import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
  isFormGroup,
} from '@angular/forms';
import { MatSelect } from '@angular/material/select';
import { Router } from '@angular/router';
import { ColDef, GridApi, GridReadyEvent, SetLeftFeature } from 'ag-grid-community';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { RowToggler } from 'primeng/table';
import { Subscription } from 'rxjs';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { SearchService } from '../../search/services/search.service';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';
import { PlanService } from '../../plan/services/plan.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';

@Component({
  selector: 'app-create-invoices',
  templateUrl: './create-invoices.component.html',
  styleUrls: ['./create-invoices.component.scss'],
  // encapsulation: ViewEncapsulation.None,
})
export class CreateInvoicesComponent {
  userName: any;
  selectedSite: any;
  layoutSubscription: Subscription;
  statusCode: any;
  status: any;
  apiUrl: any;
  apiTime: any;
  statusMessage: any;
  rightTitle: string = 'Create Invoices';
  customers: any[];
  showButtons: boolean;
  prevDate: boolean = true;
  disableCreateInvoiceBtn: boolean = false;
  daysToPay: any = 7;
  checkboxValue: any;
  ok: boolean = false;
  sum: number = 0;
  isDivVisible: boolean = false;
  selectedRow: any = null;
  checkboxClicked: boolean = false;
  noInvoiceLines: boolean;
  columnState: any;
  gridOptions: any;
  saveLayoutObj: any[];
  selectedIds: any = [];
  totalRows: any;
  selectedIdCount: any;
  noDeleteBtn: boolean = true;
  public defaultIssueDate: Date;
  public defaultFromDate: Date;
  public defaultToDate: Date;
  applicationOptions: any;
  applicationId: any;
  driverNamesList: any = [];
  columnApi: any;
  private gridApi!: GridApi<any>;
  selectedOptions: any[];
  customerIds: any;
  @ViewChild('mySelect') mySelect: MatSelect; //step:5
  CurrencyCellRendererUSD(params: any) {
    var inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    });
    return inrFormat.format(params.value);
  }
  public columnDefs: any[] = [
    {
      field: 'effectiveDate',
      headerName: 'Effective date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'serviceDate',
      headerName: 'Service date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'driverId',
      headerName: 'Driver',
      cellRenderer: (data: any) => {
        let name;
        this.driverNamesList.filter((driver: any) => {
          if (driver.id === data.value) {
            name = driver.employeeName;
          }
        });
        return name;
      },
    },
    { field: 'serviceNumber', headerName: 'Service No' },
    { field: 'serviceType', headerName: 'Service Type' },
    { field: 'loadNumber', headerName: 'Load Number' },
    { field: 'loadTypeId', headerName: 'Load Type' },
    { field: 'customerId', headerName: 'Customer' },
    { field: 'qty1', headerName: 'Qty.1' },
    { field: 'qty2', headerName: 'Qty.2' },
    { field: 'qty3', headerName: 'Qty.3' },
    { field: 'qty4', headerName: 'Qty.4' },
    { field: 'holdCode', headerName: 'Hold Code' },
    { field: 'serviceComplete', headerName: 'Completed?' },
    { field: 'containerId', headerName: 'Container' },
    { field: 'enteredBy', headerName: 'Entered by' },
    { field: 'truckId', headerName: 'Truck' },
    { field: 'trailerId', headerName: 'Trailer(lead)' },
    { field: 'trailerTagId', headerName: 'Trailer(Tag)' },
    { field: 'chargeAmount', headerName: 'Charge', cellRenderer: this.CurrencyCellRendererUSD },
    { field: 'rateId', headerName: 'Rate' },
  ];
  columnFields: ColDef[] = [
    {
      headerName: 'Check Box',
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelectionFilteredOnly: true,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',

      cellRenderer: (params: any) => {
        //return params.api.selectAll();
      },
    },
    // {
    //   field: ' ', headerName: ' ', cellRenderer: CellrenderComponent, cellRendererParams: {
    //     selectedRow: null, width: 100, resizable: true
    //   }
    // },
    {
      field: 'customerId',
      headerName: 'Customer Id',
      width: 100,
      resizable: true,
    },
    { field: 'customerName', headerName: 'Name', width: 100, resizable: true },
    { field: 'groupId', headerName: 'Group', width: 100, resizable: true },
  ];

  Defs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
  };

  //selectedOptions: any[]; // for selection option in ag-grid menu step:1

  public rowData = [];

  @Output() not: EventEmitter<string> = new EventEmitter<string>();

  canWrite: boolean = true
  constructor(
    public planService: PlanService,
    private reconcileService: ReconcileService,
    private messageService: MessageService,
    private _formBuilder: FormBuilder,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    private router: Router,
    private service: SearchService,
    private authenticationService: AuthenticationService,
    public permission: PermissionsService
  ) {
    this.gridOptions = {
      context: { Component: this },
      //headerCheckboxSelection: true,
      onFirstDataRendered: this.onFirstDataRendered.bind(this),
    };

    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          console.log('create:', data);
          this.dialogService.savaLayout(data);
        }
      }
    );

    // this.layoutSubscription= this.dialogService.currentPageData$.subscribe(() =>{
    //   this.setpageLayout()
    // })
    //this.getView();
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  async permissionMethod() {
    try {
      const result = await this.permission.canWrite('CreateInvoices');
      console.log("Result:", result); // Use the result here
      this.canWrite = result
    } catch (error) {
      console.error("Error:", error);
    }
  }

  ngOnInit() {
    //this.gridApi.selectAll();
    //this.gridOptions.selectAll();
    this.reconcileService.pageTitleSubject.next('Create Invoices');
    this.selectedOptions = this.Defs.map((coulmn) => coulmn.field); //step:2
    this.not.emit(this.rightTitle);

    this.service.getDropDownData().subscribe((data: any) => {
      this.driverNamesList = data.ref.drivers;
    });
    //this.onGridReady(even);
    if (this.columnState) {
      console.log('in ngonint:', this.columnState);
    }
    let yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 4);
    let fromDate = new Date();
    fromDate.setDate(fromDate.getDate() - 7);

    this.defaultIssueDate = yesterday;
    this.defaultFromDate = fromDate;
    this.defaultToDate = yesterday;

    this.getRowData();
    this.getCustomer();
  }

  createInvoiceForm = new FormGroup({
    issuedate: new FormControl(),
    daterangefrom: new FormControl(),
    daterangeTo: new FormControl(),
  });
  /**
   *
   * @param event : from date that is selected
   */
  onFromdateSelect(event: any) {
    console.log(event);
    this.defaultFromDate = event;
    this.getRowData();
  }
  /**
   *
   * @param event : from date that is selected
   */
  onTodateSelect(event: any) {
    console.log(event);
    this.defaultToDate = event;
    this.getRowData();
  }

  onSelectionChange(event: any) {
    this.clearFilters();
    this.Defs = this.columnFields.filter(
      (column) => event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.Defs);
  }

  onFirstDataRendered(params: any) {
    console.log('call');
    params.api.selectAll();
  }

  clearFilters() {
    this.columnFields.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  onGridReady(params: any) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
    //this.getLayout();
    //params.api.selectAll();
    // this.gridOptions.selectAll();
  }

  // getLayout() {
  //   this.navbarService.applicationOptions.subscribe(
  //     (applicationOptions: any) => {
  //       let appOptions = applicationOptions;
  //       if(appOptions){
  //       let a = appOptions.filter((item: any) => {
  //         if (
  //           item['optionName'] ===
  //           'reconcile.create-customer.invoice.grid.layout'
  //         )
  //           this.columnState = JSON.parse(item['optionValue']);
  //         if (this.columnState) {
  //           if (this.columnState.columns) {
  //             this.columnState.columns.forEach((column: any) => {
  //               if ('name' in column) {
  //                 column.colId = column.name;
  //                 delete column.name;
  //               }
  //             });
  //             this.columnState = this.columnState.columns;
  //             this.applyLayout();
  //           }
  //         }
  //       });
  //     }
  //     }
  //   );
  // }

  // applyLayout() {
  //   console.log('new:', this.columnState);
  //   const applyColumnStateParams = {
  //     state: this.columnState,
  //     applyOrder: true,
  //   };
  //   this.columnApi.applyColumnState(applyColumnStateParams);
  //   this.columnState.forEach(({ colId, width }: { colId: any; width: any }) => {
  //     const column = this.columnApi.getColumn(colId);
  //     if (column) {
  //       this.columnApi.setColumnWidth(column, width);
  //     }
  //   });
  // }

  // saveLayout(): any {
  //   if (this.columnApi) {
  //     this.columnState = this.columnApi.getColumnState();
  //     let columns = [];
  //     for (let column of this.columnState) {
  //       const customColumn = {
  //         name: column.colId,
  //         visible: !column.hide,
  //         width: column.width,
  //         sort: column.sort,
  //         filter: column.filter,
  //       };
  //       columns.push(customColumn);
  //     }
  //     let columnValueObj: any = { columns };
  //     columnValueObj = JSON.stringify(columnValueObj);
  //     this.navbarService.usernameSubject.subscribe((username) => {
  //       this.userName = username;
  //     });
  //     this.selectedSite = this.navbarService.selectedSiteId;
  //     console.log('site:', this.selectedSite);
  //     return {
  //       applicationOptionId: 9683,
  //       optionName: 'reconcile.create-customer.invoice.grid.layout',
  //       optionValue: columnValueObj,
  //       siteId: 999,
  //       userId: this.userName,
  //     };
  //   }
  // }

  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.plan.service.events.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.plan.service.events.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.plan.service.events.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }

  close() {
    this.reconcileService.pageTitleSubject.next('Reconcile');
    this.router.navigate(['/reconcile']);
  }
  rightSideForm(event: any) {
    this.selectedRow = event.data;
    console.log('row click', event);
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code in row clicked', rowCount);
    if (rowCount > 1) {
      // Get a reference to the grid API
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
      // Select the clicked row
      event.node.setSelected(true);
    }
  }

  async onSelectionChanged(event: any) {
    //event.api.selectAll();
    console.log('data:', event.api);
    var rowNode = event.api.getSelectedNodes();
    if (rowNode.length > 0) {
      this.selectedIds = [];
      rowNode.forEach((element: any) => {
        this.selectedIds.push(element.data.customerId);
      });
      // if(this.selectedIds.length>0){

      // }else{

      // }
      console.log(
        event.api.getSelectedNodes(),
        event.api.getSelectedNodes()[0].data
      );
    } else {
      this.selectedIds = [];
    }
//    await this.getRowData();
    console.log('final ids:', this.selectedIds);
    // this.rowData.forEach((element:any) =>{
    //   if(!this.selectedIds.includes(element.customerId)){
    //     console.log("remove:",element);

    //   }
    // })

    //this.rowData.filter((element) => this.selectedIds.includes(element.customerId));

    //  this.rowData = this.rowData.filter((item: any) => {
    //   for (let id of this.selectedIds) {
    //     if (id == item.customerId) {
    //       return item;
    //     }
    //   }
    // })
    // setTimeout(()=>{

    // })
    await this.getRowData();
    console.log('final:', this.rowData);
  }

  setCellSubData(intvalue: any, selectedRows: any, checkboxEnabled: boolean) {
    console.log('check:', selectedRows, checkboxEnabled);
    if (intvalue == 0) {
      this.sum = 0;
    }
    this.sum += intvalue;
    console.log('selected rows', this.selectedIds, checkboxEnabled);

    if (checkboxEnabled) {
      this.selectedIds.push(selectedRows);
    } else {
      if (this.selectedIds.includes(selectedRows)) {
        this.selectedIds = this.selectedIds.filter(
          (id: any) => id !== selectedRows
        );
      }
    }
    console.log('final:', this.selectedIds);
  }

  setpageLayout() {
    console.log('create invoice');
    // const currentPageData = 'Create Invoice';
    this.dialogService.savaLayout('create invoice');
  }

  getCustomer() {
    // this.reconcileService.getCustomers()
    //   .subscribe(
    //     (result: any) => {
    //       console.log("customers > ", result);

    //       this.customers = result;
    //     });

    this.reconcileService.getCustomers().subscribe((result: any) => {
      console.log('customers > ', result);

      //this.customers = result;
      this.reconcileService.getCustomers().subscribe((result: any) => {
        console.log('customers > ', result);

        //this.customers = result;
        let customersList = result.filter((item: any) => {
          for (let id of this.customerIds) {
            if (id === item.customerId) {
              return item;
            }
          }
        });
        console.log('custoner:', customersList);
        this.customers = customersList;
      });
    });
  }

  getRowData() {
    console.log("rowdata:",this.rowData);
    const invoiceFormSubmit = {
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime(),
      includePreviousDates: true,
    };

    this.reconcileService
      .createInvoice(invoiceFormSubmit)
      .subscribe((result: any) => {
        console.log('invoice > ', result);
        this.rowData = [];
        this.rowData = result.completedUninvoicedLines;
        this.customerIds = result.customerIds;

        if(!result.completedUninvoicedLines){
          this.disableCreateInvoiceBtn = true;
        }else{
          this.disableCreateInvoiceBtn = false;
        }
        if (!this.customerIds.length) 
        this.disableCreateInvoiceBtn = true;

        let sample: any = [];
        if (this.selectedIds.length == 0 && this.selectedIds) {
          this.noInvoiceLines = true;
          this.selectedIdCount = 0;
          //  this.disableCreateInvoiceBtn = true;
        } else {
          this.noInvoiceLines = false;
          this.selectedIdCount = this.selectedIds.length;
        }
        console.log(
          'variable:',
          this.noInvoiceLines,
          this.selectedIds,
          this.selectedIds.length
        );
        if(this.selectedIds && this.rowData){
        for (let id of this.selectedIds) {
          this.rowData.forEach((element: any) => {
            if (id === element.customerId) {
              sample.push(element);
            }
          });
        }
      }
        this.rowData = sample;
        this.totalRows = this.customers?.length;

      //   this.rowData = result.completedUninvoicedLines;
      //   this.customerIds = result.customerIds;
      //   if (!this.customerIds.length) this.disableCreateInvoiceBtn = true;
        
      //   console.log(
      //     'variable:',
      //     this.noInvoiceLines,
      //     this.selectedIds,
      //     this.selectedIds.length
      //   );
      //   if (this.selectedIds.length == 0 && this.selectedIds) {
      //     this.noInvoiceLines = true;
      //     //  this.disableCreateInvoiceBtn = true;
      //   } else {
      //     this.noInvoiceLines = false;
      //   }
      //   console.log(
      //     'variable:',
      //     this.noInvoiceLines,
      //     this.selectedIds,
      //     this.selectedIds.length
      //   );
      //   for (let id of this.selectedIds) {
      //     this.rowData.forEach((element: any) => {
      //       if (id === element.customerId) {
      //         sample.push(element);
      //       }
      //     });
      //   }
      //   this.rowData = sample;
        
      });
  }

  invoices() {
    const invoiceFormSubmit = {
      effectiveDateFrom: this.defaultFromDate.getTime(),
      effectiveDateT: this.defaultToDate.getTime(),
      issueDate: this.defaultIssueDate.getTime(),
      customers: this.selectedIds,
      includePreviousDates: this.prevDate,
      daysToPay: this.daysToPay,
    };
    console.log(invoiceFormSubmit);
    this.reconcileService.invoiceWithCustomer(invoiceFormSubmit).subscribe(
      (result: any) => {
       
        const createInvoiceIssue = `Creating invoices for ${moment(this.defaultIssueDate.getTime()).format('DD/MM/YYYY')}`;

       const messageDetail  =  `Invoice creation: ${result?.invoicesCreated} documents created ($${result?.invoicesTotalAmount}), 
                              ${result?.currentInvoiceLinesProcessed + result?.oldInvoiceLinesProcessed} total invoice lines, 
                              ${result?.currentInvoiceLinesProcessed} lines within date range ($ ${result?.currentInvoiceLinesTotalAmount}), 
                              ${result?.oldInvoiceLinesProcessed} old lines ($ ${result?.oldInvoiceLinesTotalAmount})`     
        console.log('invoice > ', result, result?.status);
        this.getRowData();
        this.messageService.add({
          key: 'invoceCreate',
          detail: createInvoiceIssue,
          severity: 'success',
          life: 30000,
        });
      
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: messageDetail,
          life: 30000,
        });
      },
      (err: any) => {
        console.log('got error:', err);
        this.statusCode = err.status;
        this.status = err.statusText;
        this.apiUrl = '/api/v1/d/invoice';
        this.statusMessage = err.error.errorList.ErrorMessage;
        this.apiTime = err.error.errorList.ExceptionTime;
        const errorMessage = err?.error?.errorList?.ExceptionInfos[0]?.UserErrorDescription;

        this.messageService.add({
          key: 'customToast',
          severity: 'error',
          life: 30000,
        });

        // this.messageService.add({
        //   severity: 'error',
        //   summary: '',
        //   detail: errorMessage,
        //   life: 30000,
        // });
      }
    );
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintPayAdvicesComponent } from './print-pay-advices.component';

describe('PrintPayAdvicesComponent', () => {
  let component: PrintPayAdvicesComponent;
  let fixture: ComponentFixture<PrintPayAdvicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrintPayAdvicesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrintPayAdvicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Input, ViewEncapsulation } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import * as moment from 'moment';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';

@Component({
  selector: 'app-print-pay-advices',
  templateUrl: './print-pay-advices.component.html',
  styleUrls: ['./print-pay-advices.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class PrintPayAdvicesComponent {
  canWrite: boolean = true
  canDelete: boolean = true
  loadingPermissions: boolean = true;
  constructor(
    private reconcileService: ReconcileService,
    public permission: PermissionsService
  ) {
    this.reconcileService.pageTitleSubject.next('Print Pay Advices');
    this.getRowData();
    try {
      this.permissionMethod();
      
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  async permissionMethod() {
    try {
      const result = await this.permission.canWrite('PayAdvicePrint');
      console.log("Result:", result); // Use the result here
      this.canWrite = result
      const result2 = await this.permission.canWrite('DeletePrintedPayAdv');
      console.log("Result", result2)
      this.canDelete = result2;
      this.loadingPermissions = false;
    } catch (error) {
      console.error("Error:", error);
    }
  }
  public statusList = [
    { name: 'Ready' },
    { name: 'Hold' },
    { name: 'Printed' },
  ];
  columnFields: ColDef[] = [
    {
      field: '',
      headerName: '',
      cellRenderer: CellrenderComponent,
      cellRendererParams: {
        selectedRow: null,
      },
      // field: '',
      // minWidth: 40,
      // width: 40,
      headerCheckboxSelection: true,
      // checkboxSelection: true,
      // filter: false,
      // sortable: false,
      // pinned: 'left',
    },
    {
      field: 'id',
      headerName: 'Pay Advice No',
      cellRenderer: (id: any) =>
        `<a style="color:#00aaa6!important" href="reconcile/PrintPayAdvices/invoiceDetails/${id.value}" >${id.value}</a>`,
    },
    {
      field: 'fromDate',
      headerName: 'From',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'toDate',
      headerName: 'To',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: '',
      headerName: 'Company Code',
      cellRenderer: (data: any) => {
        return data.data.companyId;
      },
    },
    { field: 'companyId', headerName: 'Company Type' },
    { field: 'statusId', headerName: 'Status' },
    { field: 'payAdviceText', headerName: 'Description' },
    {
      field: 'issueDate',
      headerName: 'Issue Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    { field: 'baseExGst', headerName: 'Base Ex GST' },
    { field: 'totalExGst', headerName: 'Total Ex GST' },
    {
      field: 'created',
      headerName: 'Created On',
      cellRenderer: (data: any) => {
        return moment(data.value).format('MM/DD/YYYY HH:mm');
      },
    },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public printMenu = [
    { name: 'Include zero value lines', value: 'withzerolines' },
    { name: 'Print with customer format', value: 'withcustomerformat' },
    { name: 'Print creadit notes with format', value: 'creditnotesformat' },
    { name: 'Print invoices with format' },
  ];

  public rowData = [];

  getRowData() {
    this.reconcileService.getPrintPayAdvices(false).subscribe((result: any) => {
      console.log('result getPrintPayAdvices > ', result);

      this.rowData = result.payadvices;
    });
  }
}

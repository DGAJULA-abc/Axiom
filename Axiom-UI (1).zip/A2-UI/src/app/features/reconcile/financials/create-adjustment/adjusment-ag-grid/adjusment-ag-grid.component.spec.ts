import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjusmentAgGridComponent } from './adjusment-ag-grid.component';

describe('AdjusmentAgGridComponent', () => {
  let component: AdjusmentAgGridComponent;
  let fixture: ComponentFixture<AdjusmentAgGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdjusmentAgGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdjusmentAgGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

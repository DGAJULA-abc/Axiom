import { Component, ViewEncapsulation } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { ReconcileService } from '../../services/reconcile.service';
import * as moment from 'moment';
import { ServiceFormSubmit } from '../../models/financials.model';
import { AdjustmentDropdown, AdjustmentType } from '../finaclials.model';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { MessageService } from 'primeng/api';

interface MyPayload {
  runsheetId: number;
  selectFields: string[];
}

@Component({
  selector: 'app-create-adjustment',
  templateUrl: './create-adjustment.component.html',
  styleUrls: ['./create-adjustment.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CreateAdjustmentComponent {
  referenceMetaData: any[] = [];
  createAdjustFormGroup: FormGroup;
  adjustmentTypeId: any[] = [];

  sites: any[];
  selectedAdjustTypeId: any[] | any;

  selectedDriverId: any[] | any;
  rechargeCustomerId: any[] | any;

  filteredAdjusTypes: any[];

  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];
  filteredDriver: any[] = [];

  invoiceCheck: boolean = false;
  checkBoxServiceNo: boolean = false;
  checkServiceSelection: boolean = true;

  AdjustRadio: any[] = [
    { name: 'Services', key: 'service', disable: true },
    { name: 'Runsheet', key: 'runsheet', disable: true },
  ];

  adjustmentTypeValueDrop: any;
  adjustmentTabel: any[] = [];
  adjustTypeDropArr: any[] = [];
  adjustTypeSecectedData: any[] = [];
  adjustOptionSelectedVal: AdjustmentDropdown;

  driverId: any[] = [];
  driverIdRequest: any;
  invoiceLineObj: any;
  payAdviceLineObj: any;
  allDriver: any[] = [];
  serviceChecked: any = '';
  // runsheetChecked: any = 'runsheet';

  /**Seprate driver id for runsheet case */
  runsheetDriverId: any;
  runsheetPayAdviceLineObj: any;
  createAdjustForm: FormGroup;
  ViewCustomers: any[] = [];
  ViewAdjustmentTypes: any[] = [];
  ViewDrivers: any[] = [];
  constructor(
    private navbarService: NavbarService,
    private fb: FormBuilder,
    private messageService: MessageService,
    private reconcileService: ReconcileService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    this.reconcileService.pageTitleSubject.next('Create Adjustment');
  }

  ngOnInit() {
    this.createAdjustForm = this.fb.group({
      formSubmitted: new FormControl(false),
      adjustmentTypeId: ['', Validators.required],
      effectiveDate: ['', Validators.required],
      selectedAdjust: new FormControl(null),
      lineAmount: ['', Validators.required],
      customerId: ['', Validators.required],
      rechargeCustomerId: ['', Validators.required],
      fuelLevyAmount: ['', Validators.required],
      serviceNumber: ['', Validators.required],
      lineText: ['', Validators.required],

      driverId: ['', Validators.required],
      payLineAmount: ['0', Validators.required],
      payFuelLevyAmount: ['', Validators.required],
      payRechargeCustomerId: ['', Validators.required],
      payLineText: ['', Validators.required],
    });

    this.createAdjustForm.get('selectedAdjust')!.disable();
    this.createAdjustForm.get('serviceNumber')!.disable();
    // if(this.createAdjustForm.get('adjustmentTypeId')?.value){
    //   this.createAdjustForm.get('serviceNumber')!.enable();
    // }
    // this.createAdjustForm.reset();
    // this.getCustomer();
    // this.getDriver();
    // this.getReferenceMetadata();
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        // this.isLoading = false;
        // this.getServiceTypesLookup(result['ref'].serviceTypes);
        // this.getLoadType(result['ref'].loadTypes);
        //   this.selectedsite = result['selectedSite'];
        this.ViewAdjustmentTypes = result['ref'].adjustmentTypes;
        this.ViewDrivers = result['ref'].drivers;
        //   this.ViewTrucks = result['ref'].trucks;
        //   this.ViewContainers = result['ref'].containers;
        this.ViewCustomers = result['ref'].customers;
        this.adjustTypeDropArr = result['ref'].adjustmentTypes;
        // //   this.ViewTrailers = result['ref'].trailers;
        // //   this.ViewVessels = result['ref'].vessels;
        // this.ViewLocations = result['ref'].locations;
        // //   this.ViewSites = result['ref'].sites;
        //   this.getReasonCode(result['ref'].reasons);

        //   if (this.selectedService.id != 0) {
        //     if (
        //       this.selectedService.originSite == this.selectedsiteid &&
        //       this.selectedService.destinationSite == this.selectedsiteid
        //     ) {
        //       this.selectedsitedescription = this.selectedsite.description;
        //       this.sites.push(this.selectedsite.description);
        //     }
        //   } else {
        //     this.sites.push(
        //       this.ViewSites.filter(
        //         (x: { id: number }) => x.id == this.navbarService.selectedSiteId
        //       )[0].description
        //     );
        //   }
        // }
      }
    });
    // this.getAdjustmentTypes();
  }

  get adjustment() {
    return this.createAdjustForm.value;
  }

  isRunsheetChecked(): boolean {
    // Check if "Runsheet" is checked
    const runsheetItem = this.AdjustRadio.find(
      (item) => item.key === 'runsheet'
    );
    return runsheetItem ? runsheetItem.checked : false;
  }

  // saveWork(){
  //   if(this.createAdjustForm.get('effectiveDate')?.value && this.createAdjustForm.get('serviceNumber')?.value && this.createAdjustForm.get('lineText')?.value ){
  //     return true
  //   }else{
  //     return false
  //   }
  // }
  saveWork() {
    const effectiveDate = this.createAdjustForm.get('effectiveDate')?.value;
    const serviceNumber = this.createAdjustForm.get('serviceNumber')?.value;
    const lineText = this.createAdjustForm.get('lineText')?.value;
    const payAdviseLine = this.createAdjustForm.get('payLineText')?.value;

    if (effectiveDate && serviceNumber) {
        if (this.adjustOptionSelectedVal.adjustInvoice && this.adjustOptionSelectedVal.adjustPayAdvise) {
            // If both adjustInvoice and adjustPayAdvise are selected, check both lineText and payAdviseLine
            return lineText && payAdviseLine ? true : false;
        } else if (this.adjustOptionSelectedVal.adjustInvoice) {
            // If only adjustInvoice is selected, check lineText
            return lineText ? true : false;
        } else if (this.adjustOptionSelectedVal.adjustPayAdvise) {
            // If only adjustPayAdvise is selected, check payAdviseLine
            return payAdviseLine ? true : false;
        } else {
            // If neither adjustInvoice nor adjustPayAdvise is selected, return true regardless of lineText or payAdviseLine
            return true;
        }
    } else {
        return false;
    }
}


  saveForm() {
    if(this.saveWork()){
    const formValue = {
      adjustmentTypeId: 'ADDITIONAL CHARGE',
      effectiveDate: 1697115600000,
      runsheetId: null,
      serviceNumber: 'M0081169',
      invoiceLine: {
        lineAmount: 0,
        customerId: 'BULK QLD - MANUAL',
        rechargeCustomerId: null,
        lineText: 'sdsdfsdf',
        fuelLevyAmount: -1,
      },
      payAdviceLine: null,
    };

    if (this.adjustOptionSelectedVal.adjustInvoice) {
      this.invoiceLineObj = {
        lineAmount: this.createAdjustForm.value.lineAmount,
        customerId: this.createAdjustForm.value.customerId,
        // customerId: "MEL001",
        lineText: this.createAdjustForm.value.lineText,
        fuelLevyAmount: this.createAdjustForm.value.fuelLevyAmount,
      };
    } else {
      this.invoiceLineObj = null;
    }

    if (this.adjustOptionSelectedVal.adjustPayAdvise) {
      this.payAdviceLineObj = {
        driverId: this.driverIdRequest,
        payAmount: this.createAdjustForm.value.payLineAmount,
        lineText: this.createAdjustForm.value.payLineText,
        fuelLevyAmount: this.createAdjustForm.value.payFuelLevyAmount,
      };
    } else {
      this.payAdviceLineObj = null;
    }
    // rechargeCustomerId: this.createAdjustForm.value.payRechargeCustomerId,

    const formSubmitValueService = {
      adjustmentTypeId: this.createAdjustForm.value.adjustmentTypeId,
      effectiveDate: +moment(
        this.createAdjustForm.value.effectiveDate,
        'YYYY-MM-DD HH:mm:ss'
      ).format('x'),
      runsheetId: null,
      serviceNumber: this.createAdjustForm.value.serviceNumber,
      // serviceNumber: "M0081941",
      invoiceLine: this.invoiceLineObj,
      payAdviceLine: this.payAdviceLineObj,
    };

    /**
     * payAdvice line object for Runsheet since diffrent driverid
     * Based on runsheet API
     */
    if (this.adjustOptionSelectedVal.adjustPayAdvise) {
      this.runsheetPayAdviceLineObj = {
        driverId: this.runsheetDriverId,
        payAmount: this.createAdjustForm.value.payLineAmount,
        lineText: this.createAdjustForm.value.payLineText,
        fuelLevyAmount: this.createAdjustForm.value.payFuelLevyAmount,
      };
    } else {
      this.runsheetPayAdviceLineObj = null;
    }

    const formSubmitValueRunsheet = {
      adjustmentTypeId: this.createAdjustForm.value.adjustmentTypeId,
      effectiveDate: +moment(
        this.createAdjustForm.value.effectiveDate,
        'YYYY-MM-DD HH:mm:ss'
      ).format('x'),
      runsheetId: this.createAdjustForm.value.serviceNumber,
      serviceNumber: null,
      invoiceLine: this.invoiceLineObj,
      payAdviceLine: this.runsheetPayAdviceLineObj,
    };

    this.AdjustRadio.forEach((item) => {
      if (item.key === 'service' && item.disable === true) {
        this.adjustmentFormSubmit(formSubmitValueService);
      } else if (item.key === 'runsheet' && item.disable === true) {
        this.adjustmentFormSubmit(formSubmitValueRunsheet);
      }
    });
    // console.log(this.createAdjustForm.value);
    // this.adjustmentFormSubmit(formSubmitValue);
    /**
     * so the both the table should be re-load once save is done
     */
    this.showGrid = false;
    setTimeout(() => {
      this.showGrid = true;
    }, 0);
    this.messageService.add({
      severity: 'success',
      summary: '',
      detail: 'Adjustment created successfully',
    });
    this.createAdjustForm.reset();
    this.createAdjustForm.get('serviceNumber')!.disable();
    this.runsheetData = null;
    this.adjustmentTabel = [];
    console.log(this.runsheetData);
  }else{
    this.createAdjustForm.get('formSubmitted')?.setValue(true);
  }
}
  showGrid: boolean = true; // Initially true to show the grid

  /**
   *
   */
  onCleaAdjustmentType() {
    this.adjustmentTabel = [];
    this.createAdjustForm.get('serviceNumber')!.disable();
    this.selectedAdjustTypeId = '';
    this.adjustOptionSelectedVal.adjustInvoice == false;
    this.adjustOptionSelectedVal.adjustPayAdvise == false;
    this.createAdjustForm.get('selectedAdjust')!.setValue('');
    this.createAdjustForm.get('formSubmitted')?.setValue(false);

  }

  getDriver() {
    // this.reconcileService.getDriver().subscribe((drivers: any) => {
    // console.log('driversList >>', drivers);
    // this.allDriver = this.ViewDrivers;
    // this.ViewDrivers.map((driver: any) => {
    //   this.driverId.push(driver.companyId);
    // });
    // });
  }

  filteredDriverFn(event: any) {
    let driverArr: any[] = [];
    let query = event.query;
    this.allDriver = this.ViewDrivers;
    this.ViewDrivers.map((driver: any) => {
      this.driverId.push(driver.companyId);
    });
    console.log('this.customerId >', this.customerId);
    this.driverId.map((company: any) => {
      if (company.toLowerCase().includes(query.toLowerCase())) {
        driverArr.push(company);
      }
    });
    this.filteredDriver = driverArr;
    // console.log("drovers >>", this.filteredDriver );
  }

  //submit form
  adjustmentFormSubmit(adjustmentValue: any) {
    this.reconcileService
      .adjustmentFormSubmit(adjustmentValue)
      .subscribe((formData: any) => {
        console.log('formSubmitValue >> ', formData);
      });
  }

  adjustInvoice: any;
  requiredServiceId: any;

  onChangeCustomer(event: any) {}
  // serviceChecked: boolean = false;
  // runsheetChecked: boolean = false;

  onChangeAdjustType(adjustMentValue: any) {
    let adjustMentValueNew = adjustMentValue.substring(0, adjustMentValue.indexOf('(')).trim();
    this.createAdjustForm.get('serviceNumber')!.enable();
    console.log('adjustMentValue >', adjustMentValueNew);
    this.selectedAdjustTypeId = adjustMentValue;
    this.adjustmentTypeValueDrop = adjustMentValueNew;
    // console.log("filteredAdjusTypes mm> ", this.filteredAdjusTypes);
    this.adjustTypeDropArr.filter((adjustTypeSecectedData: any) => {
      if (adjustTypeSecectedData.adjustmentTypeId == adjustMentValueNew) {
        console.log('adjustTypeSecectedData', adjustTypeSecectedData);
        this.adjustOptionSelectedVal = adjustTypeSecectedData;
        this.adjustInvoice = adjustTypeSecectedData.adjustInvoice;
        this.requiredServiceId = adjustTypeSecectedData.requiredServiceId;
      }
    });
    if (this.adjustOptionSelectedVal.requiredServiceId == true) {
      this.createAdjustForm.get('selectedAdjust')!.setValue('service');
      this.AdjustRadio.forEach((item) => {
        if (item.key === 'runsheet') {
          item.disable = false;
        }
        if (item.key === 'service') {
          item.disable = true;
        }
      });
    } else if (
      this.adjustOptionSelectedVal.adjustInvoice == false &&
      this.adjustOptionSelectedVal.requiredServiceId == false
    ) {
      this.createAdjustForm.get('selectedAdjust')!.setValue('runsheet');
      this.AdjustRadio.forEach((item) => {
        if (item.key === 'service') {
          item.disable = false;
        }
        if (item.key === 'runsheet') {
          item.disable = true;
        }
      });
    }
  }
  // getAdjustmentTypes() {
  //   // this.reconcileService.getAdjustmentTypes().subscribe((adjustData: any) => {
  //   this.ViewAdjustmentTypes.map((adjustment: any) => {
  //     //  console.log("getAdjustmentTypes >>", adjustData);
  //     this.adjustTypeDropArr = adjustment;

  //     this.adjustmentTypeId.push(adjustment.adjustmentTypeId);
  //   });
  //   // });
  // }

  // Adjust Type
  filteredAdjusTypesFun(event: any) {
    let adjustmentTypeArr: any[] = [];
    this.adjustmentTypeId = [];
    let query = event.query;
    this.ViewAdjustmentTypes.map((adjustment: any) => {
      //  console.log("getAdjustmentTypes >>", adjustData);
      // this.adjustTypeDropArr = adjustment;

      this.adjustmentTypeId.push(`${adjustment.adjustmentTypeId} (${adjustment.adjustmentTypeDesc})`);
    });
    for (let i = 0; i < this.adjustmentTypeId.length; i++) {
      // console.log("adjustmentTypeId >", this.adjustmentTypeId);

      let adjustmentType = this.adjustmentTypeId[i];
      if (adjustmentType.toLowerCase().includes(query.toLowerCase())) {
        adjustmentTypeArr.push(adjustmentType);
      }
    }

    this.filteredAdjusTypes = adjustmentTypeArr;
  }

  // Customer
  // getCustomer() {
  //   // this.reconcileService.getCustomers().subscribe((customerArr: any) => {
  //   //   // console.log("Customer > ", customerArr);
  //   //   customerArr.map((customer: any) => {
  //   //     this.customerId.push(customer);
  //   //   });
  //   // });
  // }

  filteredCustomerFun(event: any) {
    let customerArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.ViewCustomers.map((customer: any) => {
      if (customer.customerId.toLowerCase().includes(query.toLowerCase())) {
        customerArr.push(customer.customerId);
      }
    });
    this.filteredCustomers = customerArr;
  }

  runsheetData: any;
  //service referenc
  searchServiceNo(event: any) {
    const selectedRadio = this.createAdjustForm.get('selectedAdjust')?.value;
    const inputVal = event.target.value;
    if (selectedRadio === this.AdjustRadio[0].key) {
      this.reconcileService
        .getServiceReference(inputVal, this.adjustmentTypeValueDrop)
        .subscribe((serviceData: any) => {
          // console.log('serviceData >>', serviceData.customerId);
          // console.log('filteredAdjusTypes >>', this.customerId);
          console.log(serviceData, ' ammm i herrrrrrrrrrrrrrrrrrrrr');
          this.adjustmentTabel = serviceData;
          this.customerId.filter((customerIdList: any) => {
            if (customerIdList.customerId === serviceData.customerId) {
              // console.log('customerIdList > ', customerIdList);

              //  return customerIdList
              this.selectedCustomerId = customerIdList.customerId;
              // this.rechargeCustomerId = customerIdList.customerId;
            }
          });
         
        });
    } else {
      const payload: MyPayload = {
        runsheetId: inputVal,
        selectFields: [
          'runsheetid',
          'deliverydate',
          'driver',
          'driverid',
          'runsheettypeid',
          'cntservices',
        ],
      };
      if (!isNaN(payload.runsheetId) || payload.runsheetId !== null) {
      } else {
        this.reconcileService
          .getRunsheetServiceNoData(payload)
          .subscribe((runsheetData: any) => {
            console.log('runsheetData >> ', runsheetData);
            this.runsheetDriverId = runsheetData.runsheets[0].driverid;
            this.runsheetData = runsheetData.runsheets[0];
          });
      }
    }
  }

  onChangeDriver(selectedDriverDrop: any) {
    //  console.log("driver selected >> ", selectedDriverDrop);
    //  console.log("all driver  >> ", this.allDriver);

    this.allDriver.filter((driverVal: any) => {
      if (driverVal.companyId === selectedDriverDrop) {
        this.driverIdRequest = driverVal.id;
        // console.log("driverIdRequest", this.driverIdRequest);
      }
    });
  }

  closeScreen() {
    this.router.navigate(['reconcile']);
  }
}

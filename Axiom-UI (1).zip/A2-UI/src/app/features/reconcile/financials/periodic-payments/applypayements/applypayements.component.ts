import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReconcileService } from '../../../services/reconcile.service';

@Component({
  selector: 'app-applypayements',
  templateUrl: './applypayements.component.html',
  styleUrls: ['./applypayements.component.scss'],
})

export class ApplypayementsComponent {
  driverId: any[] = [];
  companyId: any[] = [];
  applyPaymentForm: FormGroup;
  selectedamount: any;
  selectedCompanyId: any;
  selectedDriverId: any;
  selectedDescription: any;
  selectedEffectiveDate: Date;
  selectedId: any;

  formdata: any;
  selectedIdsdata: any = [];

  constructor(
    private reconileService: ReconcileService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<ApplypayementsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.formdata = data[0];
    this.selectedIdsdata = data[1];
  }

  ngOnInit() {
    this.applyPaymentForm = this.formBuilder.group({
      amount: '' || null,
      companyId: '' || null,
      description: '' || null,
      driverId: '' || null,
      effectiveDate: Date || null,
    });
    this.getCompany();
    this.getDriver();
    console.log(this.formdata);
    // Get current date
    const currentDate = new Date();

    // Get the day of the week (0 for Sunday, 1 for Monday, ..., 6 for Saturday)
    const currentDayOfWeek = currentDate.getDay();

    // Calculate the number of days to subtract to get to Sunday
    const daysToSubtract = currentDayOfWeek === 0 ? 0 : currentDayOfWeek;

    // Create a new date object representing the Sunday of the current week
    const sundayOfCurrentWeek = new Date(currentDate);
    sundayOfCurrentWeek.setDate(currentDate.getDate() - daysToSubtract);
    
    this.selectedamount = this.formdata.chargeAmount;
    this.selectedCompanyId = this.formdata.companyId;
    this.selectedDescription = this.formdata.serviceDesc;
    this.selectedDriverId = this.formdata.driverId;
    this.selectedEffectiveDate = sundayOfCurrentWeek;
    this.selectedId = this.formdata.id;
  }
  filterDiverID: any[];
  getDriver() {
    this.reconileService.getDriver().subscribe((drivers: any) => {
      console.log('driversList >>', drivers);
      drivers.map((driver: any) => {
        this.driverId.push(driver.id);
      });
    });
  }
  filterDriverId(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.filterDiverID = this.driverId.filter(option => option.toString().includes(query));


    // for (let i = 0; i < this.driverId.length; i++) {
    //   let country = this.driverId[i];
    //   if (country!= 0) {
    //     filtered.push(country);
    //   }
    // }
    // this.filterDiverID = filtered;
  }
  onClearDriverID(){
    this.selectedDriverId='';
  }

  filtercompanyId: any[];
  getCompany() {
    this.reconileService.getCompany().subscribe((companies: any) => {
      console.log('Company >>', companies);
      companies.map((company: any) => {
        this.companyId.push(company.companyId);
      });
    });
  }
  filterCompanyId(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.companyId.length; i++) {
      let country = this.companyId[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filtercompanyId = filtered;
  }
  onClearComapnyID(){
    this.selectedCompanyId='';
  }

  periodicIdsdata: any[] = [];
  payementdata: any;
  resultApplyPayment: any;
  applyPayment() {
    if (this.selectedIdsdata.length == 1) {
      this.periodicIdsdata = this.selectedIdsdata[0];
      const milliseconds = Date.parse(this.applyPaymentForm.controls['effectiveDate'].value);
      this.payementdata = {
        amount: this.applyPaymentForm.controls['amount'].value,
        companyId: this.applyPaymentForm.controls['companyId'].value,
        description: this.applyPaymentForm.controls['description'].value,
        driverId: this.applyPaymentForm.controls['driverId'].value,
        effectiveDate: milliseconds,
        periodicIds: [this.periodicIdsdata],
      };
    } else if (this.selectedIdsdata.length > 1) {
      this.payementdata = {
        amount: this.applyPaymentForm.controls['amount'].value,
        companyId: this.applyPaymentForm.controls['companyId'].value,
        description: this.applyPaymentForm.controls['description'].value,
        driverId: this.applyPaymentForm.controls['driverId'].value,
        effectiveDate: this.selectedEffectiveDate,
        periodicIds: this.selectedIdsdata,
      };
    }

    //console.log(this.periodicIds);
    this.reconileService.postPerdicApplyPayments(this.payementdata).subscribe(
      (res: any) => {
        console.log(res);
        this.resultApplyPayment = res.failureMsgs;
        this.dialogRef.close({ resultData: res });
      },
      (err) => {
        console.log(err);
        this.dialogRef.close({ resultData: err.statusText });
      },
    );
    console.log(this.payementdata);
  }
}

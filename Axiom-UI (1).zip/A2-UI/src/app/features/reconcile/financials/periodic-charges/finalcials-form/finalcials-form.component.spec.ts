import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinalcialsFormComponent } from './finalcials-form.component';

describe('FinalcialsFormComponent', () => {
  let component: FinalcialsFormComponent;
  let fixture: ComponentFixture<FinalcialsFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinalcialsFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FinalcialsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

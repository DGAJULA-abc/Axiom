import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReconcileService } from '../../../services/reconcile.service';

@Component({
  selector: 'app-applycharges',
  templateUrl: './applycharges.component.html',
  styleUrls: ['./applycharges.component.scss'],
})
export class ApplychargesComponent {
  applyChargesForm: FormGroup;
  selectedEffectiveDate: any;
  periodicIds: any = [];

  formdata: any;
  selectedIdsdata: any = [];

  constructor(
    private reconileService: ReconcileService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<ApplychargesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.formdata = data[0];
    this.selectedIdsdata = data[1];
  }

  ngOnInit() {
    this.applyChargesForm = this.formBuilder.group({
      effectiveDate: '',
    });
    this.selectedEffectiveDate = new Date();
  }

  periodicIdsdata: any[] = [];
  chargesdata: any;
  applyCharges() {
    if (this.selectedIdsdata.length == 1) {
      this.periodicIdsdata = this.selectedIdsdata[0];
      this.chargesdata = {
        amount: this.formdata.chargeAmount,
        description: this.formdata.serviceDesc,
        effectiveDate: this.selectedEffectiveDate,
        periodicIds: [this.periodicIdsdata],
      };
    } else if (this.selectedIdsdata.length > 1) {
      this.chargesdata = {
        amount: null,
        description: null,
        companyId: null,
        effectiveDate: this.selectedEffectiveDate,
        periodicIds: this.selectedIdsdata,
      };
    }
    this.reconileService.postapplycharges(this.chargesdata).subscribe((res) => {
      console.log(res);
      // Close the dialog after the API call is completed
      this.dialogRef.close({result:res});
    });
  }
}

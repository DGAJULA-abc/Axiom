import { Component, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridApi,
  GridOptions,
  GridReadyEvent,
  RowNode,
} from 'ag-grid-community';

import { pagination } from 'src/app/shared/model/shared.model';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Permissions } from 'src/app/shared/model/context-vew.model';
import { MatDialog } from '@angular/material/dialog';
import { Services } from 'src/app/features/search/model/search.model';
import { SearchService } from 'src/app/features/search/services/search.service';
import { DeleteInvoiceLinesComponent } from 'src/app/features/search/delete-invoice-lines/delete-invoice-lines.component';
import { ReconcileService } from '../../../services/reconcile.service';
import { ActivatedRoute } from '@angular/router';
import { RunsheetService } from '../../../services/runsheet.service';
import { AddServiceByService } from '../add-service-by.service';
import { combineLatest, map } from 'rxjs';
import { zip } from 'lodash';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
import * as moment from 'moment';

@Component({
  selector: 'app-load-search',
  templateUrl: './load-search.component.html',
  styleUrls: ['./load-search.component.scss']
})
export class LoadSearchComponent {

  public colDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable:false,
      pinned: 'left'
    },
     {
      field: 'loadNo',
      headerName: 'Load No',
      type: 'TEXT',
      filter: true,
      sortable: true,
    }, {
      field: 'scheduledDate',
      headerName: 'Date',
      type: 'DATE',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    }, {
      field: 'loadType',
      headerName: 'Load',
      type: 'TEXT',
      filter: true,
      sortable: true,
    }, {
      field: 'b',
      headerName: '1111B',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'custRef',
      headerName: '111C',
      type: 'TEXT',
      filter: true,
      sortable: true,
    }, 
     {
      field: 'enteredBy',
      headerName: 'Entered By',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },
    {
      field: 'customer',
      headerName: 'Customer',
      type: 'TEXT',
      filter: true,
      sortable: true,
    },  
    {
      field: 'location',
      headerName: 'Location',
      type: 'TEXT',
      filter: true,
      sortable: true,
    }
  ];
  runsheetId: any;
  public rowData: Services[] = [];
  selectedNodes: RowNode[];
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    suppressMenu: true,
  };
  serviceDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  editForm: Services | null;
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 100,
    orderType: "DESC",
    orderByField: "serviceid"
  }
  selectedServices: any;

  totalRecords: number = 0;
  canDelete: boolean = false;
  searchForm: any;
  setupPermission: Permissions;
  gridOptions: GridOptions;
  runsheetApiData: any = {};
  columnDefs: ColDef[] = this.colDefs;
  loadSelected:boolean =false;
  columnApi: any;
  gridApi!: GridApi<any>;
  selectedOptions: any[];
  runsheetIdLookup: any;


  constructor(
    private reconsileService: ReconcileService,
    private searchServices: SearchService,
    private sharedDervice: SharedService,
    private dialog: MatDialog,
    private runsheetFormService:RunsheetFormService,
    private activatedRoute: ActivatedRoute,
    private reconcileService: ReconcileService,
    private runsheetService: RunsheetService,
    private addServiceService: AddServiceByService,


  ) { 
    this.gridOptions = <GridOptions>{
      onRowSelected: function (event) {
        if (event.node.isSelected()) {
          event.node.setSelected(true);
        }
      }
    }
  }

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
  }

  ngOnInit(): void {
      this.getRunsheetID();  
      this.getRunsheetIDApiData(this.runsheetId);
      this.columnDefs = this.colDefs;
      this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.searchViewDetails();
    
    
    //this.getSearchLoads();
    let requestParam = {
      from: 1699534800000,
      to: 1699794000000,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 5,
        orderType: 'ASC',
        orderByField: 'scheduledDate',
      },
    };
    this.ServiceList(requestParam);
  }

  getRunsheetID() {
    this.runsheetIdLookup = this.addServiceService.runsheetIdSeriviceBy;
    console.log("runsheetIdLookup >>", this.runsheetIdLookup);
    if(this.runsheetIdLookup) {
      this.runsheetId = this.runsheetIdLookup;
    } else {
      this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
    }
    console.log("runsheetIdLookup w >>", this.runsheetId);
  }

  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.colDefs.filter((column: any) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  searchViewDetails() {
    this.searchServices.getSearchView()
      .subscribe(
        (result: any) => {
          this.setupPermission = result.permissions.sitePermissions[0].permissions;
          
          // this.rowData = result;
        }
      );
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.ServiceList(event);
  }

  ServiceList(event: any) {
    this.searchForm = event;
    this.searchServices.getSearchLoads(event).subscribe((result: any) => {
      // result.pagination.currentPage = 5;
      this.rowData = result.loads;
      this.pagination.pageNumber = result.pagination.currentPage;
      this.totalRecords = result.pagination.totalRecords;
    });
  }
/**
 * Here we have to check the no of row selected 
 * based on that we haver to call the api ..
 * like if 5 row selected then 5 time same api should call
 * @param event 
 */
loadsIDS:any[]=[];
  onSelectionChanged(event: any) {
    this.loadsIDS=[];
    if(event.api.getSelectedNodes().length >0){
      this.loadSelected = true;
    }else{
      this.loadSelected = false;
    }
    console.log("called" , event.api.getSelectedNodes())
    // this.loadId = event.api.getSelectedNodes()[0].data.loadId
    event.api.getSelectedNodes().forEach((element:any) => {
      this.loadsIDS.push(element.data.loadId)
    });

    // var rowCount = event.api.getSelectedNodes().length;
    // this.editForm = null;
    // if (rowCount == 1) {
    //   this.editForm = event.api.getSelectedNodes()[0].data;
    //   let loadNo = event.api.getSelectedNodes()[0].data.loadId;
    //   let requestParam = {
    //     id: loadNo,
    //     tripNo: 4
    //   }
    //   console.log("edit form:", this.editForm);
    //   let id = this.runsheetId;
    //   this.searchServices.postLoads(requestParam, id).subscribe((result: any) => {
    //      this.searchServices.loadSearchArray.next(result);
    //   })
    // }
    // this.selectedServices = event.api.getSelectedNodes().map((rowNode: any) => {
    //   return rowNode.data;
    // });
    // this.canDelete = this.selectedServices.filter((services: any) => services.used).length > 0 ? true : false;
  }
  runSheetLine: any;
  Result_check:any[]=[];
  addLoadsToRunsheet() {
    this.reconsileService.setSelectedItemType('detail-page');
    this.Result_check=[];
    /*Multiple Lines started*/
    this.loadsIDS.forEach(loadId=>{
      this.addServiceService.getServices(this.runsheetApiData.id,loadId,4,'load').subscribe((runsheetLine: any)=>{
        // this.Result_check.push(result);
        // this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(result);
        runsheetLine = runsheetLine.map((item: any) => ({
          ...item,
          lineTemperature: Object.keys(item.lineTemperature).some(function (key) {
            return (
              ["deliverydate", "id"].indexOf(key) > -1 &&
              item.lineTemperature[key] != null
            );
          })
            ? item.lineTemperature
            : null,
        }));
        console.log("service Line", runsheetLine);   
        this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(runsheetLine);
        this.runsheetService.updateRunsheetPUT(this.runsheetApiData).subscribe((result:any)=>{
          this.runsheetFormService.emitRunseetSubsCribeData(result);
        });

      })
    })


    // this.addServiceService.getServices(this.runsheetApiData.id, this.loadId, 4, 'load').subscribe((result: any) => {
    //     this.runSheetLine = result;
    //     console.log(this.runSheetLine);
    //     this.runsheetApiData.runsheetLines = this.runsheetApiData.runsheetLines.concat(this.runSheetLine);
    //     // Add the new runSheetLine object to the runsheetLines array
    //     this.runsheetService.updateRunsheetPUT(this.runsheetApiData).subscribe((result:any)=>{
    //     });
    // });
    /**this is for reload the Search-load data only after adding the load in runsheet-line */
    this.ServiceList(this.searchForm);
  }

  getRunsheetIDApiData(runsheetId: any) {
    this.reconcileService
      .getViewRunsheetId(runsheetId)
      .subscribe((apiData: any) => {
        this.runsheetApiData = apiData.runsheet;
  
        console.log('runsheetApiData assd Api Data', this.runsheetApiData);
      });
  }
}


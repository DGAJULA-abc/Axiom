import { Component, OnInit, Output, EventEmitter, OnChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ViewContainers } from 'src/app/features/plan/models/plan.model';
import { AddContainerDialogComponent } from 'src/app/features/plan/plan-sub/plan-details/add-container-dialog/add-container-dialog.component';
import { PlanService } from 'src/app/features/plan/services/plan.service';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss']
})
export class SearchFormComponent implements OnChanges {

  @Output() searchDetails = new EventEmitter<any>();
  serviceForm: FormGroup;
  currentTime: Date = new Date();
  previousDate: Date = new Date(new Date((new Date()).setDate((new Date()).getDate() - 14)).setHours(0, 0, 0, 0));
  drivers: { id: any, name: string }[] = [];
  companyId: { id: any, name: string }[] = [];
  routes: { id: any, name: string }[] = [];
  companyTypes: { id: any, name: string }[] = [];
  truckId: { id: any, name: string }[] = [];
  trailer: { id: any, name: string }[] = [];
  locations: { id: any, name: string }[] = [];
  siteUsers: { id: any, name: string }[] = [];
  serviceType: any[] = [];
  loadType: { id: any, name: string }[] = [];
  customer:  any[] = [];
  searchForm: any = {};
  addbutton: boolean = true;

  constructor(
      private sharedServices: SharedService,
      private planService: PlanService,
      public dialog: MatDialog,
  ) {
  }
      /**Drop down  */
      selectedServiceType: any;
      filteredServiceType: any[];
      filteredCompanie(event: any) {
        let filtered: any[] = [];
        let query = event.query;

    
        for (let i = 0; i < this.serviceType.length; i++) {
          let load = this.serviceType[i];
          if (load.toLowerCase().includes(query.toLowerCase())) {
            filtered.push(load);
          }
        }
        this.filteredServiceType = filtered;
      }

            /**Drop down  */
            selectedCustomer: any;
            filteredCustomers: any[];
            filteredCustomer(event: any) {
              let filtered: any[] = [];
              let query = event.query;

              for (let i = 0; i < this.customer.length; i++) {
                let load = this.customer[i];
                if (load.toLowerCase().includes(query.toLowerCase())) {
                  filtered.push(load);
                }
              }
              this.filteredCustomers = filtered;
            }

            ngOnChanges() {
                // this.planService.getView().subscribe((result: any) => {
                //     if (result) {
                //       this.ViewContainers = result['ref'].containers;
                //     }
                //   });
            }

  ngOnInit() {
      this.getSearchFormWithDropDown();
      this.serviceForm = new FormGroup({
          serviceNo: new FormControl(''),
          from: new FormControl(''),
          to: new FormControl(''),
          serviceType: new FormControl(''),
          docket: new FormControl(''),
          containerId: new FormControl(''),
          customerId: new FormControl(''),
      });

      this.planService.getView().subscribe((result: any) => {
        if (result) {
          this.ViewContainers = result['ref'].containers;
        }
      });
  }

  getSearchFormWithDropDown() {
      this.sharedServices.getContextView().subscribe((result: any) => {
          this.drivers = this.sharedServices.getDriverList(result.ref.drivers);
          this.truckId = this.sharedServices.getTruckList(result.ref.trucks);
          this.trailer = this.sharedServices.getTrailerList(result.ref.trailers);
          result.ref.locations.map((location: any)=> {
              if (location.active) {
                  let loactionName = [location.locationId, location.accShortCut ?  " ( " + location.accShortCut + " )" : ''].filter(function (val) {
                      return val;
                  }).join(' ');
                  this.locations.push({id: loactionName , name: loactionName});
              }
          });
          result.ref.companys.map((company: any) => {
              if (company.active)
                  this.companyId.push({ id: company.companyId, name: company.companyId });
          });
          result.ref.companyTypes.map((company: any) => {
              if (company.active)
                  this.companyTypes.push({ id: company.companyTypeId, name: company.companyTypeId });
          });

          result.ref.serviceTypes.map((serviceType: any) => {
              if (serviceType.active)
                  this.serviceType.push(serviceType.serviceTypeId);
          });

          result.ref.loadTypes.map((loaType: any) => {
              if (loaType.active)
                  this.loadType.push({ id: loaType.loadTypeId, name: loaType.loadTypeId });
          });

          result.ref.userDatas.map((userData: any) => {
              let useraName = userData.userName + " ("+ userData.userId +" )";
              this.siteUsers.push({ id: userData.userId, name: useraName});
          });

          result.ref.customers.map((customer: any) => {
              if (customer.active){
                  this.customer.push(customer.customerId);
              }
          });

          this.updateSearchFormFields();
      });
  }
  updateSearchFormFields() {
      this.searchForm = {
          displayName: 'Services',
          name: 'Search.Services',
          endpoint: '/search/service/',
          fields: [
            {
              name: 'serviceNo',
              displayName: 'Service No.',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              placeholder:"",
              type: 'TEXT'
          }, 

          {
              name: 'from',
              displayName: 'Service From',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: this.previousDate,
              placeholder:"",
              type: 'DATE'
          }, 
          {
              name: 'to',
              displayName: 'Service To',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: this.currentTime,
              placeholder:"",
              type: 'DATE'
          }, 
          {
              name: 'serviceType',
              displayName: 'Service Type',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              reference: 'serviceTypes',
              dropDownList: this.serviceType,
              placeholder:"",
              type: 'REFERENCE'
          },
          {
            name: 'docket',
            displayName: 'Docket',
            required: false,
            readonly: false,
            hidden: false,
            updatable: true,
            defaultValue: 'docket',
            placeholder:"",
            type: 'TEXT'
        }, 
          // {
          //     name: 'containerId',
          //     displayName: 'container',
          //     required: false,
          //     readonly: false,
          //     hidden: false,
          //     updatable: true,
          //     defaultValue: null,
          //     placeholder:"find a container...",
          //     type: 'TEXT'
          // }, 
          {
              name: 'customerId',
              displayName: 'customer',
              required: false,
              readonly: false,
              hidden: false,
              updatable: true,
              defaultValue: null,
              reference: 'customerId',
              dropDownList: this.customer,
              placeholder:"",
              type: 'REFERENCE2'
          },
          ],
      };
  }

  updateValue(controlName: string, newValue: any) {
      this.serviceForm.get(controlName)?.setValue(newValue);
  }
  onSubmit() {
      let formValues = this.serviceForm.value;
      if (formValues.from instanceof Date) {
        formValues.from = formValues.from.getTime();
    }
    if (formValues.to instanceof Date) {
        formValues.to = formValues.to.getTime();
    }
      this.searchDetails.emit(formValues);
  }

    //autocomplete for containers
    containers: any[] = [];
    selectedContainer: any;
    filteredContainers: any[];
    container_arr: any[] = [];
    ViewContainers: ViewContainers[] = [];
    getContainers() {
      this.containers=[];
      this.ViewContainers.forEach((element) => {
        this.containers.push(element.containerId);
      });
    }
 
   filterContainer(event: any) {
     this.getContainers();
     let filtered: any[] = [];
     let query = event.query;

 
     for (let i = 0; i < this.containers.length; i++) {
       let country = this.containers[i];
       if (country.toLowerCase().includes(query.toLowerCase())) {
         filtered.push(country);
       }
     }
 
     this.filteredContainers = filtered;
   }

     //Popup for Adding Container
  openDialog() {
    const dialogRef = this.dialog.open(AddContainerDialogComponent);
    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      if (res.data[0] != null) {
        // this.serviceform.controls['container'].setValue(res.data[0].label);
      }
    });
  }

}

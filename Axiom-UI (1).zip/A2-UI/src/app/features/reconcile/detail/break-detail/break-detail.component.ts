import {
  Component,
  Input,
  OnChanges,
  SimpleChange,
  SimpleChanges,
} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ReconcileService } from '../../services/reconcile.service';
import { BreakType, Location } from '../detail.model';
import { RunsheetFormService } from '../../services/runsheet-form.service';
import { BreaktypeResponse, breakType, breakypeIdData } from '../detail2.model';
import { location } from 'src/app/features/setup/models/setup.model';
import { DetailService } from '../detail.service';
import * as moment from 'moment';

@Component({
  selector: 'app-break-detail',
  templateUrl: './break-detail.component.html',
  styleUrls: ['./break-detail.component.scss'],
})
export class BreakDetailComponent implements OnChanges {
  isNew: boolean = true;

  // Truck
  breakTypeId: any[] = [];
  filteredBreakType: any[] = [];
  selectedBreakType: any;

  //autocomplete for locationIds
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  location_arr: any[] = [];
  allLocations: any[] = [];
  // datefor tooltip:
  @Input() breakTimeValidationForm: any;

  showTooltipStart: boolean = false;
  showTooltipEnd: boolean = false;

  constructor(
    private fb: FormBuilder,
    private reconcileService: ReconcileService,
    private runsheetFormService: RunsheetFormService,
    private detailService: DetailService
  ) {
    this.startdate = this.detailService.startandenddate?.fromdate;
    this.endtodate = this.detailService.startandenddate?.todate;
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('breakTimeValidationForm >>', this.breakTimeValidationForm);

    this.breakStartTimeValid = moment(
      this.detailService.runsheetBreakTime?.breakStartTime
    ).format('DD/MM/YY HH:mm:ss');
    this.breakEndTimeValid = moment(
      this.detailService.runsheetBreakTime?.breakEndTime
    ).format('MM/DD/YYYY HH:mm:ss');
    console.log(
      'Break Compnet date',
      this.breakStartTimeValid,
      this.breakEndTimeValid
    );

    this.startdate = this.detailService.startandenddate?.fromdate;
    this.endtodate = this.detailService.startandenddate?.todate;
  }

  viewrunsheetstartandenddate: any;
  startdate: any;
  endtodate: any;

  ngOnInit() {
    this.getMultiLegData();
    this.getBreaks();
    this.getLocationIds();
    this.getLoadDetailForm();
    this.showBreak();
  }

  editBreak = {
    id: null,
    breakTypeId: '',
    deducted: false,
    siteId: null,
    locationId: '',
    breakstarttime: '',
    breakendtime: '',
    commentA: '',
    planned: false,
  };

  breakStartTimeValid: any;
  breakEndTimeValid: any;

  tooltipStatwarning: any;
  tooltipEndwarning: any;
  startcheck:boolean=false;
  starttime:any;
  endcheck:boolean=false;
  endtime:any;

  onChangeStartDate(date: any) {
    this.startcheck=false;
    console.log('start Date', date);
    const breakFormDate = moment(date);
    const formDate = moment(
      this.detailService.runsheetBreakTime?.breakStartTime
    );
    console.log('startFormDate >>', breakFormDate);
    if (breakFormDate.isBefore(formDate)) {
      this.showTooltipStart = true;
      console.log('view form date > breakFormDate');
      this.tooltipStatwarning = `Input Should be equal to or before  ${this.breakStartTimeValid}`;
      this.startcheck=false;
    } else {
      this.showTooltipStart = false;
      this.startcheck=true;
      var date_int = moment.tz(date, 'Australia/Melbourne');
      var india = date_int.clone().tz('Asia/Kolkata');
      this.starttime = moment(india).valueOf();
      this.runsheetFormService.emitFormChangesBreak({
        lName: 'breakstarttime',
        lValue: this.starttime
      });
      if(this.endcheck){
        let duration='';
        let b = this.endtime-this.starttime
      duration = this.getActivityTime(b);
        this.runsheetFormService.emitFormChangesBreak({
          lName: 'serviceTypeId',
          lValue: duration
        });
      }
    }
  }

  getTooltipMessagestarttime(breakStartTime: Date, breakendTime: Date): string {
    if (breakStartTime) {
      if (breakStartTime < this.startdate) {
        return (
          'Input Should be equal to or after ' + this.formatDate(this.startdate)
        );
      } else if (breakStartTime > this.endtodate) {
        return (
          'Input Should be equal to or before ' +
          this.formatDate(this.endtodate)
        );
      } 
      else if(breakendTime){
        if (breakStartTime > breakendTime) {
          return (
            'Input Should be equal to or before ' + this.formatDate(breakendTime)
          );
        }
      }
    }
    return '';
  }

  getTooltipMessageendtime(breakStartTime: Date, breakendTime: Date): string {
    if (breakendTime) {
      if (breakendTime < this.startdate) {
        return (
          'Input Should be equal to or after ' + this.formatDate(this.startdate)
        );
      } else if (breakendTime > this.endtodate) {
        return (
          'Input Should be equal to or before ' +
          this.formatDate(this.endtodate)
        );
      } else if (breakStartTime > breakendTime) {
        return (
          'Input Should be equal to or after ' + this.formatDate(breakStartTime)
        );
      }
    }
    return '';
  }

  formatDate(date: Date): string {
    const formattedDate = date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
    });
    const formattedTime =
      date.getHours().toString().padStart(2, '0') +
      ':' +
      date.getMinutes().toString().padStart(2, '0');
    return formattedDate + ' ' + formattedTime;
  }

  isValidBreakstartTime(breakStartTime: Date, breakendtime: Date): boolean {
    if (breakStartTime) {
      if (breakStartTime < this.startdate) {
        return true;
      } else if (breakStartTime > this.endtodate) {
        return true;
      } else if (breakStartTime > breakendtime) {
        return true;
      }
    }
    return false;
  }

  isValidBreakendTime(breakStartTime: Date, breakendtime: Date): boolean {
    if (breakendtime) {
      if (breakendtime < this.startdate) {
        return true;
      } else if (breakendtime > this.endtodate) {
        return true;
      } else if (breakStartTime > breakendtime) {
        return true;
      }
    }
    return false;
  }

  onChangeEndDate(date: any) {
    this.endcheck=false;
    console.log('End Date', date);
    //  const breakFormDate =  moment(date).format('DD/MM/YY HH:mm:ss');
    const breakFormDate = moment(date);
    const formDate = moment(this.detailService.runsheetBreakTime?.breakEndTime);
    console.log('endFormDate >>', breakFormDate);
    if (breakFormDate.isBefore(formDate)) {
      this.showTooltipEnd = true;
      console.log('view form date > breakFormDate');
      //  this.tooltipEndwarning = `Input Should be equal to or before  ${this.breakEndTimeValid}`;
      this.tooltipEndwarning = `Input Should be equal to of after ${this.breakEndTimeValid}`;
      this.endcheck=false;

      var date_int = moment.tz(date, 'Australia/Melbourne');
      var india = date_int.clone().tz('Asia/Kolkata');
      this.endtime= moment(india).valueOf();
      this.runsheetFormService.emitFormChangesBreak({
        lName: 'breakendtime',
        lValue: this.endtime
      });
      this.endcheck=true;
      //check if start is there and then send duration
      if(this.startcheck){
        let duration='';
        let b = this.endtime-this.starttime
      duration = this.getActivityTime(b);
        this.runsheetFormService.emitFormChangesBreak({
          lName: 'serviceTypeId',
          lValue: duration
        });

      }
  ;
    } else {
      this.showTooltipEnd = false;
      var date_int = moment.tz(date, 'Australia/Melbourne');
      var india = date_int.clone().tz('Asia/Kolkata');
      this.endtime= moment(india).valueOf();
      this.runsheetFormService.emitFormChangesBreak({
        lName: 'breakendtime',
        lValue: this.endtime
      });
      this.endcheck=true;
      //check if start is there and then send duration
      if(this.startcheck){
        let duration='';
        let b = this.endtime-this.starttime
      duration = this.getActivityTime(b);
        this.runsheetFormService.emitFormChangesBreak({
          lName: 'serviceTypeId',
          lValue: duration
        });

      }
  ;
      
    }
  }
  getActivityTime(time: number): string {
    let hours = Math.floor(time / 3600000);
    var minutes = Math.floor((time % 3600000) / 60000);
    // var minutes = Math.round((32.7666666 - hours) * 60);
    return String(hours) + 'h ' + String(minutes) + 'm';
  }
  getTooltipClass() {
    return 'custom-tooltip-class';
  }

  breakDetailForm = this.fb.group({
    breakTypeId: '',
    locationId: '',
    breakstarttime: ['', Validators.required],
    breakendtime: ['', Validators.required],
    commentA: '',
  });

  showBreak() {
    this.runsheetFormService._showBreak.subscribe((res) => {
      this.isNew = res;
      if (this.isNew) {
        this.breakDetailForm.reset();
      }
    });
  }

  getLoadDetailForm() {
    this.breakDetailForm.valueChanges.subscribe((res) => {
      console.log(this.breakDetailForm.getRawValue());
      this.runsheetFormService.runsheetBreakForm =
        this.breakDetailForm.getRawValue();
    });
  }

  sendData() {
    this.runsheetFormService.sendBreakFormData(this.breakDetailForm);
    return null;
  }

  // Truck Type
  getBreaks() {
    this.reconcileService.getBreakType().subscribe((breakType: any) => {
      breakType.map((breakType: BreakType) => {
        this.breakTypeId.push(breakType);
      });
    });
  }

  filteredBreakFun(event: any) {
    let breakArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.breakTypeId.map((breakType: BreakType) => {
      if (breakType.typeId.toLowerCase().includes(query.toLowerCase())) {
        // const truckName = `${truck.truckId} , (${truck.routeCapacity} , ${truck.companyId})`;
        breakArr.push(breakType.typeId);
      }
    });
    this.filteredBreakType = breakArr;
  }

  onChangeBreak(event: any) {
    this.runsheetFormService.emitFormChangesBreak({
      lName: 'breakTypeId',
      lValue: event
    });
  }
  onChangeCommentsInput(event:any){
    const comments = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChangesBreak({
      lName: 'commentA',
      lValue: comments?.value,
    });
  }
  onChangeLocation(event: any) {
    const location = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChangesBreak({
      lName: 'locationId',
      lValue: event
    });
  }
 

  // location
  getLocationIds() {
    this.reconcileService.getLocation().subscribe((locations: any) => {
      this.allLocations = locations;
      locations.map((location: Location) => {
        if (location.locationId !== null) {
          this.location_arr.push(location.locationId);
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    });
  }
  filteredLoactionFun(event: any) {
    let locationIdArr: any[] = [];
    let query = event.query;

    this.location_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        locationIdArr.push(location);
      }
    });
    this.filteredLocations = locationIdArr;
  }



  selectedbreakstarttime: any;
  selectedbreakendtime: any;
  getMultiLegData() {
    this.reconcileService._multiLangData.subscribe(
      (runsheet: BreaktypeResponse) => {
        console.log('Runsheet Break details >> ', runsheet);
        this.runsheetFormService.deleteBreakRow.next(runsheet.id);
        // console.log('customerId  Arr > ', this.loadTypeArrId);

        this.breakTypeId.filter((breakype: breakypeIdData) => {
          if (runsheet.breakTypeId === breakype.typeId) {
            this.selectedBreakType = breakype.typeId;
          }
        });

        this.allLocations.map((loadtype: Location) => {
          if (runsheet.locationId === loadtype.locationId) {
            this.selectedLocation = loadtype.locationId;
          }
        });

        this.editBreak.breakTypeId = runsheet.breakTypeId;
        this.editBreak.locationId = runsheet.locationId;
        this.selectedbreakstarttime = new Date(runsheet.breakstarttime);
        this.selectedbreakendtime = new Date(runsheet.breakendtime);
        this.editBreak.commentA = runsheet.commentA;
      }
    );
  }
  /**
   * 
   */
  close(){
    this.reconcileService.selectedItemType.next('deleteBreak'); 
  }
}

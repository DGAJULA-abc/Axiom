import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { ReconcileService } from '../services/reconcile.service';
import { RunsheetDetail } from './detail2.model';
import { RunsheetFormService } from '../services/runsheet-form.service';
import { ActivatedRoute } from '@angular/router';
import { Runsheet, ViewRunsheetRunsheetId } from '../view-runsheet-form/ViewRunsheetId.model';
import { DetailService } from './detail.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss'],
})
export class DetailComponent implements OnInit, OnChanges {
  selectedItemType: any;
  isDetailShow: boolean = true; 
  runsheetLineData: RunsheetDetail;
  runsheetLineServiceDetailData: any;
  runsheetId: any;
  runsheetLineDataApi: RunsheetDetail[];
  @Input() formStateSubmit: boolean;
  @Input() breakTimeValidationForm: any;
  runsheetLookApidata: any[] = [];
  runsheetAPiParent: any[] = [];

  constructor(private activatedRoute: ActivatedRoute,
           private reconcileService: ReconcileService,
            private runsheetFormService: RunsheetFormService,
            private detailService: DetailService) {}

  ngOnChanges() {
  
   this.runsheetAPiParent = this.detailService?.runsheetStateConf; 
   console.log("ngon change call", this.runsheetAPiParent);
   
   this.runsheetLookApidata = this.detailService?.runseetLookupApidata?.runsheet?.runsheetLines;
   console.log("lookup api Response",this.runsheetLookApidata);
   
  }

  ngOnInit() {
    this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
  if(this.runsheetId) {
    this.getRunsheetIDApiData(this.runsheetId);
  } else {
    this.runsheetLineDataApi = this.runsheetLookApidata;
  }
    this._setDetailScreen();
    this.getMultiLegData();
    // this.getApiData();
    // this.reconcileService.selectedItemType.next('');  

  }

  _setDetailScreen() {
    this.reconcileService.selectedItemType$.subscribe((res) => {
      this.selectedItemType = res;
    });
  }

  getRunsheetIDApiData(runsheetId: any) {
    if(runsheetId !== null) {
      // this.reconcileService
      // .getViewRunsheetId(runsheetId)
      // .subscribe((apiData: ViewRunsheetRunsheetId) => {
      //   this.runsheetLineDataApi = apiData.runsheet.runsheetLines;
      this.runsheetLineDataApi =  this.runsheetAPiParent;
      console.log("api runsheet", this.runsheetAPiParent);
      
          // this.getMultiLegData();
        if(this.runsheetLineDataApi.length === 0) {
          this.selectedItemType = "ClosePanel";
          this.isDetailShow = false;
        }
  
        console.log('detail assd Api Data', this.runsheetLineDataApi);
      // });
     }
  }
  runsheetObj: any = {}
  getMultiLegData() {
    this.reconcileService._multiLangData.subscribe((runsheet: any) => {
      if(runsheet) {
        // this._setDetailScreen();
        console.log("runsheetLineData detail", this.runsheetLineDataApi);
        console.log("runsheet detail >>>", runsheet);
        const runsheetData = runsheet;
      // this.bulkeditIdsData = 
          this.runsheetObj = runsheetData[runsheetData.length -1]
        // this.runsheetLineDataApi.
        if(this.runsheetLineDataApi.length > 0) {
          this.runsheetLineDataApi.map(
            (runsheetLineAll: any) => {
             if(runsheetLineAll.id === this.runsheetObj.id) {
                this.runsheetLineData = runsheetLineAll;
                console.log("runsheetLineAll.id", this.runsheetLineData);
  
             }
            }
          );
          setTimeout(() => {
            this.runsheetLineData = this.runsheetObj;   
          }, 500);
        } else {
          // setTimeout(() => {       
            this.runsheetLineData = runsheetData[0]; 
          // }, 500);
        } 
               // this.selectedItemType = "runsheet-line";
      }
        
    })
  }

  onCloseDetail() {
    // this.isDetailShow = false;
     this.selectedItemType = "ClosePanel";
    // this.reconcileService.selectedItemType.next('');

  }
}

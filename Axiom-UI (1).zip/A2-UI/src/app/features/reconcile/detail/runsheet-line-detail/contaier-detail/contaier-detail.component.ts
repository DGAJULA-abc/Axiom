import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AddContainerDialogComponent } from 'src/app/features/plan/plan-sub/plan-details/add-container-dialog/add-container-dialog.component';
import { ReconcileService } from '../../../services/reconcile.service';
import { MatDialog } from '@angular/material/dialog';
import { ServiceType } from '../runsheet-service-detail/runsheet-service-detail.model';
import { Location, Site, Vessel } from '../../detail.model';
import { OriginLoc, RunsheetDetail } from '../../detail2.model';
import { customers } from 'src/app/features/setup/models/setup.model';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
import { TimeRunsheetService } from '../../../services/time-runsheet.service';
import { PlanService } from 'src/app/features/plan/services/plan.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { MultiLegSiteLocation, ViewContainers } from 'src/app/features/plan/models/plan.model';
import { DetailService } from '../../detail.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-contaier-detail',
  templateUrl: './contaier-detail.component.html',
  styleUrls: ['./contaier-detail.component.scss'],
})
export class ContaierDetailComponent implements OnInit, OnChanges {
  @Input() formStateSubmit: boolean;

  // service type
  serviceTypeId: any[] = [];
  filteredServiceType: any[] = [];
  selectedserviceTypeId: any;

  // customer
  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];

  // customer name
  selectedCustomerName: any[] | any;
  customerName: any[] = [];
  filteredCustomersName: any[] = [];

  // Load Type
  selectedLoadType: any[] | any;
  loadTypeId: any[] = [];
  filteredLoadType: any[] = [];

  batchNo: any;

  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];
  addbutton = true;

  //vessel
  vesselId: any[] = [];
  filteredVessel: any[] = [];
  vessel: any[] = [];
  selectedVesselId: any[] | any;
  //  allReasonCode: any[] = [];
  //  reasonCodeUnique: any[] = [];
  //  addbutton=true;

  // autocomplete for  customer Site
  selectedCustomerSite: any[] | any;
  customerSite: any[] = [];
  filteredCustomerSite: any[] = [];

  //autocomplete for locationIds
  locationIds: any[] = [];
  selectedLocation: any[] | any;
  filteredLocations: any[];
  location_arr: any[] = [];

  //autocomplete for Wharf
  selectedWharf: any;
  filteredWharf: any[];
  wharf_arr: any[] = [];
  wharf: any[] = [];

  //autocomplete for Depot
  selectedDepot: any;
  filteredDepot: any[];
  depot_arr: any[] = [];
  depot: any[] = [];

  //autocomplete for Dehire Park
  selectedDehire: any;
  filteredDehire: any[];
  dehire_arr: any[] = [];
  dehire: any[] = [];

  //autocomplete for Dehire Park
  selectedPrimaryOrigin: any;
  filteredPrimaryOrigin: any[];
  primaryOrigin_arr: any[] = [];
  primaryOrigin: any[] = [];

  selectedDestinationLocation: any[] | any;
  selectedOriginLocation: any[] | any;
  
  // Date
  selectedVesselEtaDate:  any = new Date();
  selectedDeliveryOpen: any = new Date();
  selectedDeliveryClose: any = new Date();
  selectedDeadline: any = new Date();

  loadDetailFormObj: any = {};

  selectedDestinationSite: any[] | any;
  resetFormState = false;
  @Input() runsheet: RunsheetDetail;
  vesselWholeArr: any[];

  editContainetForm = {
    vesselId: null,
    wharf: null,
    depot: null,
    customerSite: null,
    originSite: null,
    dehirePark: null,
    destinationSite: null,
    destinationLoc: null,
    vesselEta: new Date(),
    deliveryOpen: new Date(),
    deliveryClose: new Date(),
    dehireDeadline: new Date(),
    originLoc: null,
  };

  ViewVessels: Vessel[] = [];
  ViewLocations: MultiLegSiteLocation[] = [];
  runsheetState: any;
  isLoading: boolean =false;

  selectedsiteid: any;
  containerFormObj: any = {};
  selectedSiteIdNavbar: any;
  selectedsite: any;
  //autocomplete for containers
  containers: any[] = [];
  selectedContainer: any;
  filteredContainers: any[];
  container_arr: any[] = [];
  ViewContainers: ViewContainers[] = [];
  constructor(
    private fb: FormBuilder,
    public navbarService: NavbarService,
    public planService: PlanService,
    private reconcileService: ReconcileService,
    public dialog: MatDialog,
    private runsheetFormService: RunsheetFormService,
    private timeRunsheetService: TimeRunsheetService,
    private detailService: DetailService,
    private authenticationService: AuthenticationService,
  ) {}

  ngOnInit() {
    this.selectedSiteIdNavbar =  this.navbarService.selectedIdDataNavbar;
    console.log("OnInit selected", this.selectedSiteIdNavbar);
    this.getRefData();
    // this.getVesselLookup();
    
    // this.getCustomer();
    // this.getLoadType();
    // this.getReasonCode();
    this.getPrimaryOriginSite();
    // this.getRunsheetLineContainerForm();
    // this.planService.getView().subscribe((result: any) => {
    //   if (result) {
    //     // this.ViewVessels = result['ref'].vessels;
    //     // this.ViewLocations = result['ref'].locations;
    //     // this.getLocationIds();
    //   }
    // });
    this.runsheetState = this.detailService.runsheetStateConf;

    //  this.resetContainerDetailForm();
  }

  ngOnChanges() {
    console.log('Container NgOnChanges');
    this.selectedSiteIdNavbar =  this.navbarService.selectedIdDataNavbar;
    console.log("this.selectedSiteIdNavbar", this.selectedSiteIdNavbar);
    this.selectedsiteid = this.navbarService.selectedSiteId;
   

    this.sendData();
    setTimeout(() => {
      this.getMultiLegData(this.runsheet);
      this.getRunsheetState();
    }, 200);
  }

getRefData() {
   // this.selectedSiteIdNavbar = this.navbarService.selectedSiteId;
   this.authenticationService.viewAPI.subscribe((result) => {
    if (result) {
      this.isLoading = false;
      // this.getServiceTypesLookup(result['ref'].serviceTypes);
      // this.getLoadType(result['ref'].loadTypes);
      this.selectedsite = result['selectedSite'];
    //   this.ViewServiceTypes = result['ref'].serviceTypes;
    //   this.ViewDrivers = result['ref'].drivers;
    //   this.ViewTrucks = result['ref'].trucks;
      this.ViewContainers = result['ref'].containers;
      // this.ViewCustomers = result['ref'].customers;
    // //   this.ViewTrailers = result['ref'].trailers;
      this.ViewVessels = result['ref'].vessels;
      this.ViewLocations = result['ref'].locations;
      this.getLocationIds();
      this.selectedPrimaryOrigin = this.selectedsite?.description;
      this.selectedDestinationSite = this.selectedsite?.description;

      
    // //   this.ViewSites = result['ref'].sites;
    //   this.getReasonCode(result['ref'].reasons);

    //   if (this.selectedService.id != 0) {
    //     if (
    //       this.selectedService.originSite == this.selectedsiteid &&
    //       this.selectedService.destinationSite == this.selectedsiteid
    //     ) {
          // this.selectedsitedescription = this.selectedsite.description;
    //       this.sites.push(this.selectedsite.description);
    //     }
    //   } else {
    //     this.sites.push(
    //       this.ViewSites.filter(
    //         (x: { id: number }) => x.id == this.navbarService.selectedSiteId
    //       )[0].description
    //     );
    //   }
    // }
    
    }
  });
}

  getRunsheetLineContainerForm() {
    this.runsheetLineContainerForm.valueChanges.subscribe((res) => {
      console.log(this.runsheetLineContainerForm.getRawValue(), res);
      this.runsheetFormService.runsheetLineContainerForm =
        this.runsheetLineContainerForm.getRawValue();
      this.checkFormForNull();
    });
  }


  runsheetLineContainerForm = this.fb.group({
    vesselId: ['', Validators.required],
    wharf: ['', Validators.required],
    depot: ['', Validators.required],
    customerSite: ['', Validators.required],
    originSite: ['', Validators.required],
    dehirePark: ['', Validators.required],
    destinationSite: ['', Validators.required],
    destinationLoc: ['', Validators.required],
    vesselEta: ['', Validators.required],
    deliveryOpen: ['', Validators.required],
    deliveryClose: ['', Validators.required],
    dehireDeadline: ['', Validators.required],
    originLoc: ['', Validators.required],
    containerId: ['', Validators.required],
  });

  getContainers() {
    this.containers=[];
    this.ViewContainers.forEach((element) => {
      this.containers.push(element.containerId);
    });
  }
  
  filterContainer(event: any) {
    this.getContainers();
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.containers.length; i++) {
      let country = this.containers[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredContainers = filtered;
  }

  
     //Popup for Adding Container
     openDialogContainer() {
      const dialogRef = this.dialog.open(AddContainerDialogComponent);
      dialogRef.afterClosed().subscribe((res) => {
        // received data from dialog-component
        if (res.data[0] != null) {
          // this.serviceform.controls['container'].setValue(res.data[0].label);
        }
      });
    }
  
  resetContainerDetailForm() {
    this.runsheetFormService.newRunsheetLineFormReset.subscribe((res: any) => {
      this.resetFormState = res;
      console.log('reset for  Container >>', this.resetFormState);
      if (this.resetFormState) {
        this.runsheetLineContainerForm.reset();
      }
    });
  }

  sendData() {
    this.runsheetFormService.sendContainerFormData(
      this.runsheetLineContainerForm.value
    );
    // return null;
  }

  checkFormForNull() {
    Object.keys(this.runsheetLineContainerForm.controls).forEach((key: any) => {
      // First, check if the form control exists
      const control = this.runsheetLineContainerForm.get(key);

      // Then check if the control is not null and has a value
      if (
        control &&
        (control.value === null ||
          control.value === '' ||
          control.value === undefined)
      ) {
        // console.log(key + ' is null or empty');
      } else if (control) {
        // console.log(key + ' has a value:', control.value);
        this.containerFormObj[key] = control.value;
        // console.log('this.serviceDetailFormObj', this.serviceDetailFormObj);
      }
    });
  }

  // Vessel
  // getVesselLookup() {
  //   this.reconcileService.getVesselLookup().subscribe((vesselArr: any) => {
  //     // console.log(' vessels> ', vesselArr);
  //     vesselArr.map((vessels: Vessel) => {
  //       this.vesselId.push(vessels.id);
  //     });
  //   });
  // }
  vessel_arr: string[] = [];
  getVessels(viewvessels: Vessel[]) {
    // this.vesselWholeArr.push(viewvessels);
    this.vesselWholeArr = viewvessels;
    viewvessels.forEach((element) => {
      this.vessel_arr.push(element.vessel);
    });
    this.vesselId = this.vessel_arr.filter(
      (item, index) => this.vessel_arr.indexOf(item) === index
    );
  }

  filteredVesselFun(event: any) {
    this.getVessels(this.ViewVessels);

    let vesselArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.vesselId.map((vessel: any) => {
      if (vessel.toLowerCase().includes(query.toLowerCase())) {
        vesselArr.push(vessel);
      }
    });
    this.filteredServiceType = vesselArr;
  }

  onChangeVessel(vesselId: any) {
    let vesselIDPayload = '';; 
    this.vesselWholeArr.map((vessel: any) => {
      if(vessel.vessel === vesselId) {
        vesselIDPayload = vessel.id;
        this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.vesselId','lValue': vesselIDPayload});
      }
    })
  }

  
  onChangeContainer(containerId: any) {
    // let vesselIDPayload = '';; 
    // this.ViewContainers.map((vessel: any) => {
      // if(vessel.vessel === vesselId) {
      //   vesselIDPayload = vessel.id;
        this.runsheetFormService.emitFormChanges({'lName':'containerId','lValue': containerId});
      // }
    // })
  }
  //location

  getLocationIds() {
    this.locationIds=[]
    this.ViewLocations.forEach((element) => {
      this.locationIds.push(element.locationId);
    });
    // this.reconcileService.getLocation().subscribe((locations: any) => {
      this.ViewLocations.map((location: Location) => {
        if (location.locationId) {
          if (location.locationId !== null &&
            location.locationTypeId==='CUSTOMER') {
            this.customerSite.push(location.locationId);
          }
          if (
            location.locationId !== null &&
            location.locationTypeId === 'originLoc'
          ) {
            this.location_arr.push(location.locationId);
          }
          if (
            location.locationId !== null &&
            location.locationTypeId === 'WHARF'
          ) {
            this.wharf_arr.push(location.locationId);
          } else if (
            location.locationId !== null &&
            location.locationTypeId === 'DEPOT'
          ) {
            this.depot_arr.push(location.locationId);
          } else if (
            location.locationId !== null &&
            location.locationTypeId === 'PARK'
          ) {
            this.dehire_arr.push(location.locationId);
          }
        }
      });
      // console.log('location_arr >>', this.dehire_arr);
    // });
  }
  custsite_arr: string[] = [];
  custSites: any[] = [];
  filteredLoactionFun(event: any) {
    let wharfIdArr: any[] = [];
    let depotIdArr: any[] = [];
    let dehireArr: any[] = [];
    let locationArr: any[] = [];
    let check:any[]=[];

    let query = event.query;

    this.wharf_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        wharfIdArr.push(location);
      }
    });

    this.depot_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        depotIdArr.push(location);
      }
    });

    this.dehire_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        dehireArr.push(location);
      }
    });

    this.location_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        locationArr.push(location);
      }
    });
    this.locationIds.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        check.push(location);
      }
    });
    this.filteredWharf = wharfIdArr;
    this.filteredDepot = depotIdArr;
    this.filteredDehire = dehireArr;
    this.filteredLocations = locationArr;
    this.filteredCustomerSite = this.customerSite;
    this.filteredLocations=check;
  }

  filteredLoactionCustomerSiteFun(event: any) {
    let locationArr: any[] = [];
    this.customerSite = [];
    let check:any[]=[];

    let query = event.query;

    this.ViewLocations.map((location: Location) => {
      if (location.locationId) {
        if (location.locationId !== null &&
          location.locationTypeId==='CUSTOMER') {
          this.customerSite.push(location.locationId);
        }
      }
    });

    this.customerSite.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        locationArr.push(location);
      }
    });
   
  
    this.filteredCustomerSite = locationArr;
    // this.filteredLocations=check;
  }

  onChangeLocationWharf(wharf: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.wharf','lValue': wharf});
  }

  onChangeLocationDepot(depot: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.depot','lValue': depot});
  }

  // Customer
  getCustomer() {
    this.reconcileService.getCustomers().subscribe((customerArr: any) => {
      // console.log('Customer > ', customerArr);
      customerArr.map((customer: any) => {
        this.customerName.push(customer);
      });
    });
  }

  filteredCustomerFun(event: any) {
    let customerNameArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    this.filteredCustomers = this.customerName.filter(option => option.customerName.toLowerCase().includes(query.toLowerCase()));

    // this.customerName.map((customer: any) => {
    //   if (customer.customerName) {
    //     if (
    //       customer.customerName.toLowerCase().indexOf(query.toLowerCase()) == 0
    //     ) {
    //       customerNameArr.push(customer.customerName);
    //     }
    //   }
    // });
    // this.filteredCustomers = customerNameArr;
  }

  onChangeCustomerSite(customer: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.customerSite','lValue': customer});
  }

  onChangeLocationDehire(dhire: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.dehirePark','lValue': dhire});
  }



  getPrimaryOriginSite() {
   let siteId = this.selectedSiteIdNavbar ? this.selectedSiteIdNavbar.id : '999';
    this.reconcileService
      .getMultiLegSiteLocations(siteId)
      .subscribe((originSite: any) => {
        console.log('originSite > ', originSite);
        originSite.map((origin: OriginLoc) => {
          if(siteId === originSite?.id) {
            this.primaryOrigin.push(origin.siteDesc);
          }
          
        });
      });
  }
  filteredPrimaryOriginSite: any[] = [];
  filteredOriginFun(event: any) {
    let primaryOriginArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);
    // this.primaryOrigin.map((originSite: Site) => {
    //   if (originSite) {
    //     // if (
    //     //   originSite.siteDesc.toLowerCase().indexOf(query.toLowerCase()) == 0
    //     // ) {
    //     primaryOriginArr.push(originSite.siteId);
    //     // }
    //   }
    // });
    if(this.selectedsite) {
      this.selectedPrimaryOrigin = this.selectedsite?.description;
      // this.filteredPrimaryOriginSite.push(this.selectedsite?.description);
    }
  }

  onChangeOrigin(originSite: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.originSite','lValue': originSite});
  }

  onChangeOriginLoc(originLoc: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.originLoc','lValue': originLoc});
  }

  onChangeDestinationSite(destinationSite: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.destinationSite','lValue': destinationSite});
  }

  onChangeDestinationLoc(destinationLoc: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.destinationLoc','lValue': destinationLoc});
  }

  onChangeDespatchBy(vesselEta: any) {
    const vesselEtaDateConvert = this.detailService.convertAusTimeZone(vesselEta);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.vesselEta','lValue': vesselEtaDateConvert}); 
  }

  onChangeDeliveryOpen(deliveryOpen: any) {
    const deliveryOpenDateConvert = this.detailService.convertAusTimeZone(deliveryOpen);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.deliveryOpen','lValue': deliveryOpenDateConvert}); 
  }
  
  onChangeDeliveryClosed(deliveryClose: any) {
    const deliveryCloseDateConvert = this.detailService.convertAusTimeZone(deliveryClose);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.deliveryClose','lValue': deliveryCloseDateConvert}); 
  }
  
  onChangeDehireDeadline(dehireDeadline: any) {
    const dehireDeadlineDateConvert = this.detailService.convertAusTimeZone(dehireDeadline);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.dehireDeadline','lValue': dehireDeadlineDateConvert}); 
  }
  // Loadtype
  getLoadType() {
    this.reconcileService.getLoadType().subscribe((loadTypeArr: any) => {
      // console.log("Customer > ", customerArr);
      loadTypeArr.map((loadType: any) => {
        this.loadTypeId.push(loadType.loadTypeId);
      });
    });
  }
  filteredLoadtypeFun(event: any) {
    let loadTypeArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.loadTypeId.map((loadType: any) => {
      if (loadType.toLowerCase().includes(query.toLowerCase())) {
        loadTypeArr.push(loadType);
      }
    });
    this.filteredCustomers = loadTypeArr;
  }

  onChangeLoadType(event: any) {}

  //Reason Code

  //reason code
  getReasonCode() {
    this.reconcileService.getReasonCode().subscribe((reasonCodes: any) => {
      // console.log('getReasonCode >> ', reasonCodes);
      reasonCodes.map((reasonDrop: any) => {
        if (reasonDrop.reasonDescription !== null) {
          this.reasonCode.push(
            `${reasonDrop.reasonId}__${reasonDrop.reasonDescription}`
          );
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;

    this.reasonCode.map((company: any) => {
      if (company.toLowerCase().includes(query.toLowerCase())) {
        reasonArr.push(company);
      }
    });
    this.filteredReasons = reasonArr;
  }

  onChangeReason(selectedReasonCode: any) {
    // console.log("selectedReasonCode >", selectedReasonCode);
    let extractReasonCode = selectedReasonCode.split('_')[0];
    console.log('strLen >> ', extractReasonCode);
    this.reasonCodeUnique = extractReasonCode;

    // this.reasonCode.filter((reasonVal: any) => {
    //   let fileterResonStr = reasonVal.split('_')[0];

    //   console.log("reasonVal >>", fileterResonStr);

    //   if (fileterResonStr === extractReasonCode) {
    //      this.reasonCodeUnique =
    //     // this.drivrIdRequest = this.allReasonCode;
    //   }
    // });
  }

  //Popup for Adding Container
  openDialog() {
    const dialogRef = this.dialog.open(AddContainerDialogComponent);
  }

  getMultiLegData(runsheet: RunsheetDetail) {
    console.log("containet ViewLocations", this.ViewLocations);
    
    // this.reconcileService._multiLangData.subscribe(
    //   (runsheet: RunsheetDetail) => {
    // console.log('Container  details >> ', runsheet);
    // console.log("customerId  Arr > ", this.loadTypeArrId);
    if (runsheet != undefined && runsheet) {
      this.ViewLocations.filter((location: Location) => {
        // console.log("customerSite >>", this.customerSite);

        if (runsheet.lineServiceTO.customerSite === location.locationId) {
          this.selectedCustomerSite = location.locationId;
        }
      });

      this.wharf_arr.filter((loadtype: any) => {
        if (runsheet.lineServiceTO.wharf === loadtype) {
          this.selectedLocation = loadtype;
        }
      });

      this.customerId.filter((customer: customers) => {
        if (runsheet.lineServiceTO.customerId === customer.customerId) {
          this.selectedCustomerId = customer.customerId;
        }
      });

      // this.loadTypeId.map((loadtype: any) => {
      //   if (runsheet.loadTypeId === loadtype) {
      //     this.selectedLoadType = loadtype;
      //   }
      // });

      //vesselId
      this.vesselId.map((vessel: any) => {
        if (vessel === runsheet.lineServiceTO.vesselId)
          this.selectedVesselId = vessel;
      });

      //depot
      this.depot_arr.map((depot: any) => {
        if (depot === runsheet.lineServiceTO.depot) {
          this.selectedDepot = depot;
        }
      });

      //dehire
      this.dehire_arr.map((dehire: any) => {
        if (dehire === runsheet.lineServiceTO?.dehirePark) {
          this.selectedDehire = dehire;
        }
      });

      //primaryOrigin
      this.primaryOrigin.map((pOrigin: OriginLoc) => {
        if (pOrigin.siteId) {
          if (pOrigin.siteId === runsheet.lineServiceTO.originSite) {
            this.selectedPrimaryOrigin = pOrigin.siteId;
          }
          if (pOrigin.siteId === runsheet.lineServiceTO.destinationSite) {
            this.selectedDestinationLocation = pOrigin.siteId;
          }
        }
      });

      //Primary Loocation
      this.primaryOrigin.map((prOriginLoc: OriginLoc) => {
        if (prOriginLoc.siteId) {
          if (prOriginLoc.siteId === runsheet.siteId) {
            this.selectedDestinationLocation = prOriginLoc.siteId;
          }
        }
      });

      this.ViewLocations.map((location: Location) => {
        if (location.locationId) {
          if (location.locationId === runsheet.lineServiceTO.originLoc) {
            this.selectedOriginLocation = location.locationId;
          }

          if (
            location.locationId === runsheet.lineServiceTO.destinationLoc
          ) {
            this.selectedDestinationLocation = location.locationId;
          }
        }
      });

      this.selectedVesselEtaDate=
        this.timeRunsheetService.convertMillisecondsToDate(
          runsheet.lineServiceTO.vesselEta
        );
        this.selectedDeliveryOpen =
        this.timeRunsheetService.convertMillisecondsToDate(
          runsheet.lineServiceTO.deliveryOpen
        );
        this.selectedDeliveryClose=
        this.timeRunsheetService.convertMillisecondsToDate(
          runsheet.lineServiceTO.deliveryClose
        );
      this.selectedDeadline =
        this.timeRunsheetService.convertMillisecondsToDate(
          runsheet.lineServiceTO.dehireDeadline
        );
      // });
    }
  }

  getRunsheetState() {
    if (this.runsheetState?.complete) {
      this.runsheetLineContainerForm.controls['vesselId'].disable();
      this.runsheetLineContainerForm.controls['wharf'].disable();
      this.runsheetLineContainerForm.controls['depot'].disable();
      this.runsheetLineContainerForm.controls['customerSite'].disable();
      this.runsheetLineContainerForm.controls['originSite'].disable();
      this.runsheetLineContainerForm.controls['dehirePark'].disable();
      this.runsheetLineContainerForm.controls['destinationSite'].disable();
      this.runsheetLineContainerForm.controls['destinationLoc'].disable();
      this.runsheetLineContainerForm.controls['vesselEta'].disable();
      this.runsheetLineContainerForm.controls['deliveryOpen'].disable();
      this.runsheetLineContainerForm.controls['deliveryClose'].disable();
      this.runsheetLineContainerForm.controls['dehireDeadline'].disable();
      this.runsheetLineContainerForm.controls['originLoc'].disable();

    }
  }
 
}

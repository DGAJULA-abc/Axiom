import {
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { RunsheetDetail, ServiceUnitKeys } from '../../detail2.model';

@Component({
  selector: 'app-service-units',
  templateUrl: './service-units.component.html',
  styleUrls: ['./service-units.component.scss'],
})
export class ServiceUnitsComponent implements OnChanges {
  @Input() selectedServiceTypeId: any;
  @Input() runsheetLine: any;
  serviceUnitsForm: FormGroup;
  serviceUnits: any;
  unitKeyValuePairs: any[] = [];
  serviceControls: any[] = [];

  keys: any = {
    qty: ['qty1', 'qty2', 'qty3', 'qty4', 'qty5', 'qty6', 'qty7', 'qty8'],
    unit: [
      'unit1',
      'unit2',
      'unit3',
      'unit4',
      'unit5',
      'unit6',
      'unit7',
      'unit8',
    ],
    maxQty: [
      'maxQty1',
      'maxQty2',
      'maxQty3',
      'maxQty4',
      'maxQty5',
      'maxQty6',
      'maxQty7',
      'maxQty8',
    ],
    defaultQty: [
      'defaultQty1',
      'defaultQty2',
      'defaultQty3',
      'defaultQty4',
      'defaultQty5',
      'defaultQty6',
      'defaultQty7',
      'defaultQty8',
    ],
    reqUnit: [
      'reqUnit1',
      'reqUnit2',
      'reqUnit3',
      'reqUnit4',
      'reqUnit5',
      'reqUnit6',
      'reqUnit7',
      'reqUnit8',
    ],
  };

  constructor(private navbarService: NavbarService) {}

  ngOnChanges(changes: SimpleChanges): void {
    this.getUnitAndQty();
    if (changes['selectedServiceTypeId']) {
      console.log('selectedServiceTypeId >>', this.selectedServiceTypeId);
      console.log('this.serviceUnits ng change', this.serviceUnits);
      console.log('runsheetLine service>>', this.runsheetLine);

      // for (const key in this.selectedServiceTypeId) {
      //   if (this.runsheetLine.hasOwnProperty(key) && key.startsWith('unit')) {
      //     const value = this.runsheetLine[key];
      //     if (value !== null) {
      //       this.serviceUnits.forEach((serviceUnit: any) => {
      //         if (serviceUnit.unitId === value) {
      //           console.log('serviceUnit onChange,>>', serviceUnit);
      //           this.unitKeyValuePairs.push({
      //             key,
      //             value: value,
      //           });
      //         }
      //       });
      //       // const controls: any = {};

      //       // this.unitKeyValuePairs.forEach((res: any) => {
      //       //   controls[res.value] = new FormControl('', []);
      //       // });
      //       // this.serviceUnitsForm = new FormGroup(controls);
      //     }

      //     // console.log(`${key}: ${value}`);
      //   }
      // }
    }
    console.log('this.unitKeyValuePairs >>', this.unitKeyValuePairs);

    this.serviceUnitsForm.valueChanges.subscribe((res) => {
      console.log('service units >> ', this.serviceUnitsForm.getRawValue());
      // this.runsheetFormService.serviceDetailForm =
      //   this.serviceDetailForm.getRawValue();
    });
  }

  ngOnInit() {
    this.serviceUnitsForm.valueChanges.subscribe((res) => {
      console.log('service units >> ', this.serviceUnitsForm.getRawValue());
      // this.runsheetFormService.serviceDetailForm =
      //   this.serviceDetailForm.getRawValue();
    });
    this.getRefData();
    // this.formInitiate();
   

    // this.getQtyForUnit();
  }

  getUnitAndQty() {
    // this.runsheetLine.map
    const unitKey: any = [];
    const qtyKey: any[] = [];
    const unitAndQtyKeVal: any[] = [];
    this.unitKeyValuePairs  = []
    for (const key in this.runsheetLine) {
      if (this.runsheetLine.hasOwnProperty(key) && key.startsWith('unit')) {
        // const value = this.runsheetLine[key];
        unitKey.push(this.runsheetLine[key]);
      }
      if (this.runsheetLine.hasOwnProperty(key) && key.startsWith('qty')) {
        // const value = this.runsheetLine[key];
        qtyKey.push(this.runsheetLine[key]);
      }
    }

    // Merge mergedQtyWithApi with key json
    const mergedQtyWithApi: any = {};
    this.keys.qty.forEach((key: any, index: any) => {
      mergedQtyWithApi[key] = qtyKey[index];
    });
    console.log('mergedQtyWithApi >>', mergedQtyWithApi);

    // Merge mergedQtyWithApi with key json
    const mergedUnitWithApi: any = {};
    this.keys.unit.forEach((key: any, index: any) => {
      mergedUnitWithApi[key] = unitKey[index];
    });
    const qtyArray = [];
    for (const qtyApiKey in mergedQtyWithApi) {
      if (mergedQtyWithApi[qtyApiKey]) {
        qtyArray.push(mergedQtyWithApi[qtyApiKey]);
      }
    }
    console.log('qtyArray >>> ', qtyArray);
    let key = 0;
    for (const unitApiKey in mergedUnitWithApi) {
      console.log('unitApiKey >', mergedUnitWithApi[unitApiKey]);
     
      if (mergedUnitWithApi[unitApiKey]) {
        this.unitKeyValuePairs.push({
          name: mergedUnitWithApi[unitApiKey],
          value: qtyArray[key],
        });
        key++;

        this.unitKeyValuePairs.forEach((res: any) => {
          this.serviceControls[res.name] = new FormControl('', []);
        });
        this.serviceUnitsForm = new FormGroup(this.serviceControls);
        // this.serviceControls[unitApiKey] = new FormControl(mergedQtyWithApi[qtyApiKey], []);
        // this.serviceUnitsForm.addControl(unitApiKey, new FormControl(mergedQtyWithApi[qtyApiKey], Validators.required))
      }
    }

    // this.serviceUnitsForm = new FormGroup(this.serviceControls);

    console.log('this.unitKeyValuePairs >>', this.unitKeyValuePairs);

    console.log('serviceControls >>', this.serviceControls);

    // Merge arrays into an object
    // const controls: any = {};
    // unitKey.forEach((key: any, index: any) => {
    //   controls[key] = qtyKey[index];
    //   controls[key] = new FormControl(qtyKey[index], []);
    // });
    // this.serviceUnitsForm = new FormGroup(controls);
  }

  formInitiate() {
    const controls: any = {};
    console.log('this.serviceUnits', this.serviceUnits);

    this.serviceUnits.forEach((res: any) => {
      controls[res.unitId] = new FormControl('', []);
    });
    this.serviceUnitsForm = new FormGroup(controls);
  }

  getRefData() {
    this.navbarService.refServiceData$.subscribe((refData: any) => {
      console.log('refData >>', refData);
      this.serviceUnits = refData.units;
    });
  }

  getMultiLegData(runsheet: RunsheetDetail) {
    // this.editServiceDetail.lineServiceTO.batchNo =
    //   runsheet.lineServiceTO.batchNo;
    // this.editServiceDetail.lineServiceTO.custRef =
    //   runsheet.lineServiceTO.custRef;
    // this.editServiceDetail.lineServiceTO.serviceNo =
    //   runsheet.lineServiceTO.serviceNo;
    // this.editServiceDetail.lineServiceTO.loadNo =
    //   runsheet.lineServiceTO.loadNo;
    // this.editServiceDetail.docket = runsheet.docket;
  }

  /**
   * @ngdoc function
   * @description return the quantity key for a given unit on a given service
   * @param {Object} service service
   * @param  {string} unit  unit (e.g. 'TONNES')
   * @return {string}         key (e.g. 'qty1')
   */

  getQtyKeyForUnit = (unit: any) => {
    // return this.keys.qty[this.getUnitsForService(service).indexOf(unit)];
    // var serviceType = RefDataService.get('serviceTypes', (service || {}).serviceTypeId) || {};
    let serviceType: any = this.selectedServiceTypeId;
    return this.keys.unit.reduce((result: any, key: any, i: any) => {
      return (serviceType || {})[key] === (unit || {}).unitId
        ? this.keys.qty[i]
        : result;
    }, null);
  };

  /**
   * @ngdoc function
   * @description return the quantity for a given unit on a given service
   * @param {Object} service service
   * @param  {string} unit  unit (e.g. 'TONNES')
   * @return {number}         quantity
   */
  getQtyForUnit = (unit: any): number => {
    return parseFloat(
      this.selectedServiceTypeId[this.getQtyKeyForUnit(unit)] || 0
    );
  };

  getEnhancedUnitsForService = (service: any) => {
    return this.enhanceUnits(this.getUnitsForService(service), service);
  };

  /**
   * @ngdoc function
   * @description add properties to copy of unit objects
   * @param {Object} service service
   * @param  {string} unit  unit (e.g. 'TONNES')
   * @return {number}         default quantity
   */
  enhanceUnits = (units: any, service: any) => {
    function _getRexForDecimal(decimalPlaces: any) {
      if (decimalPlaces === 0 || decimalPlaces === null) {
        return '-?\\d*';
      }
      return '-?\\d*\\.{0,1}\\d{1,' + decimalPlaces + '}';
      // return '[-0-9]?(\\.[0-9]{1,'+(decimalPlaces || 100)+'})?';
    }
    // var serviceType = RefDataService.get('serviceTypes', (service || {}).serviceTypeId) || {};
    var serviceType = this.selectedServiceTypeId;

    return (units || [])
      .map((unit: any, i: any) => {
        return !unit
          ? undefined
          : Object.assign(
              ['defaultQty', 'maxQty', 'reqUnit'].reduce(
                (enhancedUnit: any, key: any) => {
                  enhancedUnit[key] = serviceType[this.keys[key][i]];
                  return enhancedUnit;
                },
                {
                  minQty: !unit.allowNegative ? 0 : null,
                  formatPattern: _getRexForDecimal(unit.decimalPlaces),
                  decimalPlaces: unit.decimalPlaces,
                }
              ),
              unit
            );
      })
      .filter((unit: any) => {
        return !!unit;
      });
  };

  /**
   * @ngdoc function
   * @description return units for a given service, with reference to its service type
   * @param {Object} service service
   * @return {Array}         unit types
   */
  getUnitsForService = (service: any) => {
    let serviceType = this.selectedServiceTypeId;
    // RefDataService.get('serviceTypes', (service || {}).serviceTypeId) || {};
    return this.keys.unit.map((unitKey: any) => {
      // return RefDataService.get('units', serviceType[unitKey]);
      return this.serviceUnits;
    });
  };
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceUnitsComponent } from './service-units.component';

describe('ServiceUnitsComponent', () => {
  let component: ServiceUnitsComponent;
  let fixture: ComponentFixture<ServiceUnitsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServiceUnitsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceUnitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import { LoadType, ServiceType } from './runsheet-service-detail.model';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  FormGroupDirective,
  Validators,
} from '@angular/forms';
import * as _ from 'lodash';
import { MatDialog } from '@angular/material/dialog';
import { AddContainerDialogComponent } from 'src/app/features/plan/plan-sub/plan-details/add-container-dialog/add-container-dialog.component';
import { RunsheetDetail } from '../../detail2.model';
import { customers } from 'src/app/features/setup/models/setup.model';
import { Subject, Subscription } from 'rxjs';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
import { Location } from '../../detail.model';
import { TimeRunsheetService } from '../../../services/time-runsheet.service';
import { ServiceTypes, ViewContainers } from 'src/app/features/plan/models/plan.model';
import { Reason } from '../../../models/reference-model';
import { DetailService } from '../../detail.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
// import { reasonsCode } from '../../runsheet-line-detail/runsheet-service-detail/runsheet-service-detail.model';

@Component({
  selector: 'app-runsheet-service-detail',
  templateUrl: './runsheet-service-detail.component.html',
  styleUrls: ['./runsheet-service-detail.component.scss'],
})
export class RunsheetServiceDetailComponent implements OnInit, OnChanges {
  @Input() formStateSubmit: boolean;
  //autocomplete for locationIds
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  location_arr: any[] = [];

  // autocomplete for  From location
  selectedPickLocationId: any[] | any;
  customerSite: any[] = [];
  filteredCustomerSite: any[] = [];
  filteredFrom: any[] = [];
  filteredToSiteLoc: any[] = [];

  // drop location
  selectedDropLocation: any[] | any;

  // service type
  serviceTypeId: any[] = [];
  filteredServiceType: any[] = [];
  selectedserviceTypeId: any[] | any;
  serviceTypeArray: any[] | any;
  currentServiceType: any[] | any;

  // customer
  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];

  // Load Type
  selectedLoadType: any[] | any;
  loadTypeId: any[] = [];
  filteredLoadType: any[] = [];
  loadTypeArrId: any[] = [];

  batchNo: any;

  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];
  addbutton = true;
  serviceDetailForm: FormGroup;
  selectedReasonId: Reason = {
    reasonId: '',
    siteId: 0,
    reasonDescription: '',
    driver: false,
    active: false,
  };

   //autocomplete for containers
   containers: any[] = [];
   selectedContainer: any;
   filteredContainers: any[];
   container_arr: any[] = [];
   ViewContainers: ViewContainers[] = [];

  runsheetState: any;

  runsheetLines: any;
  resetFormState = false;

  editServiceDetail = {
    id: null,
    locationContDropId: null,
    locationContPickupId: null,
    locationDropId: '',
    locationPickupId: '',
    locationReturnId: null,
    serviceId: null,
    trailerId: null,
    containerId: null,
    loadTypeId: '',
    trailerTagId: null,
    serviceTypeId: '',
    rateId: '',
    truckId: null,
    siteId: 999,
    qty1: null,
    unit1: '',
    qty2: null,
    unit2: '',
    qty3: null,
    unit3: null,
    qty4: null,
    unit4: null,
    qty5: null,
    unit5: null,
    qty6: null,
    unit6: null,
    qty7: null,
    unit7: null,
    qty8: null,
    unit8: null,
    owntrailer: false,
    offsiderused: false,
    pickuparrivetime: new Date(),
    pickupdeparttime: new Date(),
    droparrivetime: new Date(),
    dropreadytime: new Date(),
    dropdeparttime: new Date(),
    docket: null,
    payamt: null,
    payestimated: false,
    directfromdepot: false,
    remarks: '',
    nextstoptime: null,
    tripkm: 0,
    paydesc: '',
    pickupreadytime: null,
    dropdoctime: new Date(),
    pickupdoctime: new Date(),
    createdby: '',
    tripno: 1,
    tripseq: 1,
    servicehours: null,
    hiretruck: false,
    globaldropbonus: null,
    deliverydate: new Date(),
    tripodostart: null,
    tripodoend: null,
    groupseq: null,
    tripstarttime: null,
    tripendtime: null,
    lineTemperature: null,
    lineServiceTO: {
      serviceId: null,
      dataSource: 'A2',
      created: new Date(),
      tripIdCust: null,
      serviceGroup: null,
      serviceDesc: null,
      customerId: null,
      consignmentMasterCustomerId: null,
      loadId: null,
      serviceNo: '',
      reasonId: '',
      chargeAmt: null,
      chargeDesc: null,
      rateId: null,
      complete: false,
      loadNo: '',
      batchNo: '123',
      custRef: '',
      scheduleDate: new Date(),
      despatchBy: null,
      deliveryOpen: new Date(),
      deliveryClose: null,
      returnLocationId: null,
      pickupLocation: {
        locationId: null,
        siteId: 999,
        locationTypeId: null,
        locationDesc: '',
        zonePayId: '',
        zoneChargeId: '',
        suburb: null,
        active: null,
        loadTimeMins: null,
        address1: null,
        address2: null,
        state: null,
        postCode: null,
        window1From: null,
        window1To: null,
        window2From: null,
        window2To: null,
        window3From: null,
        window3To: null,
        personIdContact: null,
        personIdContactName: null,
        customerId: null,
        locationCode: null,
        latitude: null,
        longitude: null,
        geofence: null,
        mapSourceId: null,
        mapReference: null,
        remarks: null,
        truckSizeLimit: null,
        defaultTripSeq: null,
        routeId: null,
        permanent: null,
        loadTimeMinsPerUnit: null,
        loadTimeUnit: null,
        waitTimeMins: null,
        waitTimeMinsPerUnit: null,
        waitTimeUnit: null,
        accShortCut: null,
        locationIdGroup: null,
        siteTravelTime: null,
        disableWPUpdated: null,
        externalLookUp: null,
        internalLookUp: null,
        segManaged: null,
        segExported: null,
        routeCapacity: null,
      },
      dropLocation: {
        locationId: null,
        siteId: 999,
        locationTypeId: null,
        locationDesc: '',
        zonePayId: '',
        zoneChargeId: '',
        suburb: null,
        active: null,
        loadTimeMins: null,
        address1: null,
        address2: null,
        state: null,
        postCode: null,
        window1From: null,
        window1To: null,
        window2From: null,
        window2To: null,
        window3From: null,
        window3To: null,
        personIdContact: null,
        personIdContactName: null,
        customerId: null,
        locationCode: null,
        latitude: null,
        longitude: null,
        geofence: null,
        mapSourceId: null,
        mapReference: null,
        remarks: null,
        truckSizeLimit: null,
        defaultTripSeq: null,
        routeId: null,
        permanent: null,
        loadTimeMinsPerUnit: null,
        loadTimeUnit: null,
        waitTimeMins: null,
        waitTimeMinsPerUnit: null,
        waitTimeUnit: null,
        accShortCut: null,
        locationIdGroup: null,
        siteTravelTime: null,
        disableWPUpdated: null,
        externalLookUp: null,
        internalLookUp: null,
        segManaged: null,
        segExported: null,
        routeCapacity: null,
      },
      loadLocation: {
        locationId: '',
        siteId: 999,
        locationTypeId: null,
        locationDesc: '',
        zonePayId: null,
        zoneChargeId: null,
        suburb: null,
        active: null,
        loadTimeMins: null,
        address1: null,
        address2: null,
        state: null,
        postCode: null,
        window1From: null,
        window1To: null,
        window2From: null,
        window2To: null,
        window3From: null,
        window3To: null,
        personIdContact: null,
        personIdContactName: null,
        customerId: null,
        locationCode: null,
        latitude: null,
        longitude: null,
        geofence: null,
        mapSourceId: null,
        mapReference: null,
        remarks: null,
        truckSizeLimit: null,
        defaultTripSeq: null,
        routeId: null,
        permanent: null,
        loadTimeMinsPerUnit: null,
        loadTimeUnit: null,
        waitTimeMins: null,
        waitTimeMinsPerUnit: null,
        waitTimeUnit: null,
        accShortCut: null,
        locationIdGroup: null,
        siteTravelTime: null,
        disableWPUpdated: null,
        externalLookUp: null,
        internalLookUp: null,
        segManaged: null,
        segExported: null,
        routeCapacity: null,
      },
      lastGroupSeq: null,
      clearCharge: false,
      totalChargeAmt: null,
      svcReasonLines: [],
      dehireDeadline: null,
      vesselEta: 1699362000000,
      vesselId: 1801,
      priority: null,
      wharf: '',
      depot: '',
      customerSite: '',
      dehirePark: '',
      originSite: 999,
      originLoc: '',
      destinationSite: 999,
      destinationLoc: '',
    },
    events: [],
    loadNoDuplicated: null,
  };

  //pickup time
  selectedPickuparrivetime: any = new Date();
  selectedPickupdoctime: any = new Date();
  selectedPickupReadytime: any = new Date();
  selectedPickupdeparttime: any = new Date();

  //drop time
  selectedDroparrivetime: any = new Date();
  selectedDropreadytime: any = new Date();
  selectedDropDocTime: any = new Date();
  selectedDropDeparttime: any = new Date();

  canWrite: any;
  @Input() runsheet: any;

  serviceSelectedUnits: any;

  unitdata: any;
  create: boolean = false;
  automatice: any = 'Automatic';
  isservicetypeSelected: boolean = false;
  unit1: boolean = false;
  unit2: boolean = false;
  unit3: boolean = false;
  unit4: boolean = false;
  unit5: boolean = false;
  unit6: boolean = false;
  unit7: boolean = false;
  unit8: boolean = false;

  showdrop: boolean = false;
  showpickup: boolean = false;
  showextraunit1: boolean = false;
  showextraunit4: boolean = false;
  showextraunit5: boolean = false;

  uni1merge: any;
  uni2merge: any;
  uni3merge: any;
  uni4merge: any;
  uni5merge: any;
  uni6merge: any;
  uni7merge: any;
  uni8merge: any;

  unitFormServiceObj: any;
  unitQtysObjs: any;
  serviceDetailFormObj: any = {};
  initialServiceDetailFormValue: any = {};

  changesFormField = {};
  ViewServiceTypes: ServiceTypes[] = [];
  formSubscription: Subscription;
  defaultDate = new Date();
  isLoading: boolean = false;
  ViewCustomers: any[] = [];
  ViewLocations: any[] = [];

  constructor(
    private fb: FormBuilder,
    private reconcileService: ReconcileService,
    public dialog: MatDialog,
    private runsheetFormService: RunsheetFormService,
    private runsheetTime: TimeRunsheetService,
    private detailService: DetailService,
    private authenticationService: AuthenticationService
  ) // private timeService: TimeRunsheetService
  {
    this.createServiceLineForm();
    this.formSubscription = this.serviceDetailForm.valueChanges.subscribe(
      (data) => {
        console.log('formSubscription >>', data);

        this.runsheetFormService.emitFormChanges(data);
      }
    );
  }

  ngOnInit() {
    console.log('selectedPickuparrivetime >>', this.selectedPickuparrivetime);
    console.log('select doc Time', this.selectedPickupdoctime);

    // // this.getServiceTypesLookup();
    // this.getLocationIds();
    // this.getCustomer();
    // // this.getLoadType();
    // this.getReasonCode();
    // this.getMultiLegData();
    this.createServiceLineForm();
    this.fetchPermissions();
    this.initialServiceDetailFormValue = _.cloneDeep(
      this.serviceDetailForm.value
    );
    this.serviceDetailForm.valueChanges.subscribe((currentFormValue) => {
      // console.log(this.serviceDetailForm.getRawValue());
      this.runsheetFormService.serviceDetailForm =
        this.serviceDetailForm.getRawValue();
      this.changesFormField = this.getChanges(
        this.initialServiceDetailFormValue,
        currentFormValue
      );
      // console.log('Changed fields:', this.changesFormField);

      // Update the previous values for the next comparison
      this.initialServiceDetailFormValue = { ...currentFormValue };

      // this.checkFormForNull();
    });
    this.runsheetState = this.detailService.runsheetStateConf;
    this.resetServiceDetailForm();
  }

  ngOnChanges() {
    console.log('ngOnChanges service runsheet', this.runsheet);
    this.isLoading = true;
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        this.isLoading = false;
        this.getServiceTypesLookup(result['ref'].serviceTypes);
        this.getLoadType(result['ref'].loadTypes);
        //   this.selectedsite = result['selectedSite'];
        //   this.ViewServiceTypes = result['ref'].serviceTypes;
        //   this.ViewDrivers = result['ref'].drivers;
        //   this.ViewTrucks = result['ref'].trucks;
          this.ViewContainers = result['ref'].containers;
        this.ViewCustomers = result['ref'].customers;
        //   this.ViewTrailers = result['ref'].trailers;
        //   this.ViewVessels = result['ref'].vessels;
        this.ViewLocations = result['ref'].locations;
        //   this.ViewSites = result['ref'].sites;
        this.getReasonCode(result['ref'].reasons);

        //   if (this.selectedService.id != 0) {
        //     if (
        //       this.selectedService.originSite == this.selectedsiteid &&
        //       this.selectedService.destinationSite == this.selectedsiteid
        //     ) {
        //       this.selectedsitedescription = this.selectedsite.description;
        //       this.sites.push(this.selectedsite.description);
        //     }
        //   } else {
        //     this.sites.push(
        //       this.ViewSites.filter(
        //         (x: { id: number }) => x.id == this.navbarService.selectedSiteId
        //       )[0].description
        //     );
        //   }
        // }
      }
    });

    this.sendData();
    setTimeout(() => {
      this.getMultiLegData(this.runsheet);
      this.getRunsheetState();
    }, 100);
  }

  getChanges(previous: any, current: any): any {
    const changes: any = {};
    Object.keys(current).forEach((key) => {
      if (current[key] !== previous[key]) {
        changes[key] = current[key];
      }
    });
    return changes;
  }
  resetServiceDetailForm() {
    this.runsheetFormService.newRunsheetLineFormReset.subscribe((res: any) => {
      this.resetFormState = res;
      console.log('reset for >>', this.resetFormState);
      if (this.resetFormState) {
        this.serviceDetailForm.reset('');
      }
    });
  }

  createServiceLineForm() {
    this.serviceDetailForm = this.fb.group({
      serviceTypeId: ['', Validators.required],
      customerId: ['', Validators.required],
      loadTypeId: ['', Validators.required],
      batchNo: ['', Validators.required],
      custRef: ['', Validators.required],
      serviceNo: ['', Validators.required],
      loadNo: ['', Validators.required],
      docket: ['', Validators.required],
      pallets: ['', Validators.required],
      dollars: ['', Validators.required],
      // tonnes: ['', Validators.required],
      hours: ['', Validators.required],
      containers: ['', Validators.required],
      kilograms: ['', Validators.required],
      kilometers: ['', Validators.required],
      reels: ['', Validators.required],
      enteredBy: ['', Validators.required],
      reasonId: ['', Validators.required],
      pickupdeparttime: ['', Validators.required],
      container: ['', Validators.required],

      locationPickupId: ['', Validators.required],
      pickuparrivetime: ['', Validators.required],
      pickupdoctime: ['', Validators.required],
      depart: ['', Validators.required],
      remarks: ['', Validators.required],
      reqDropLocation: ['', Validators.required],
      droparrivetime: ['', Validators.required],
      dropdoctime: ['', Validators.required],
      dropreadytime: ['', Validators.required],
      dropdeparttime: ['', Validators.required],
      locationDropId: ['', Validators.required],
      containerId: ['', Validators.required],


    });
  }

  sendData() {
    this.runsheetFormService.sendFormData(this.serviceDetailForm.value);
    // this.runsheetFormService.detailSubjectForm.next(this.serviceDetailFormObj);

    this.runsheetFormService.unitDataSubject.next(this.unitQtysObjs);
    // return null;
  }

  getContainers() {
    this.containers=[];
    this.ViewContainers.forEach((element) => {
      this.containers.push(element.containerId);
    });
  }
  
  filterContainer(event: any) {
    this.getContainers();
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.containers.length; i++) {
      let country = this.containers[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredContainers = filtered;
  }

  
     //Popup for Adding Container
     openDialogContainer() {
      const dialogRef = this.dialog.open(AddContainerDialogComponent);
      dialogRef.afterClosed().subscribe((res) => {
        // received data from dialog-component
        if (res.data[0] != null) {
          // this.serviceform.controls['container'].setValue(res.data[0].label);
        }
      });
    }

  checkFormForNull() {
    Object.keys(this.serviceDetailForm.controls).forEach((key: any) => {
      // First, check if the form control exists
      const control = this.serviceDetailForm.get(key);

      // Then check if the control is not null and has a value
      if (
        control &&
        (control.value === null ||
          control.value === '' ||
          control.value === undefined)
      ) {
        // console.log(key + ' is null or empty');
      } else if (control) {
        // console.log(key + ' has a value:', control.value);
        this.serviceDetailFormObj[key] = control.value;
        // console.log('this.serviceDetailFormObj', this.serviceDetailFormObj);
      }
    });
    // this.serviceDetailForm.valueChanges.subscribe((form: any) => {
    //   console.log("form changes", form);

    // })
  }

  saveServiceLineForm() {}

  //location

  getLocationIds() {
    // this.reconcileService.getLocation().subscribe((locations: any) => {
    this.ViewLocations.map((location: Location) => {
      if (location.locationId) {
        if (location.locationId !== null) {
          this.customerSite.push(location.locationId);
          this.location_arr.push(location.locationId);
        }
      }
    });
    // console.log('location_arr >>', this.dehire_arr);
    // });
  }
  filteredLoactionFun(event: any) {
    this.location_arr = [];
    let locationArr: any[] = [];

    let query = event.query;
    this.ViewLocations.map((location: Location) => {
      if (location.locationId) {
        if (location.locationId !== null) {
          this.location_arr.push(location.locationId);
        }
      }
    });

    this.location_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        locationArr.push(location);
      }
    });

    // this.filteredLocations = locationArr;
    // this.filteredCustomerSite = this.customerSite;
    // this.filteredFrom = this.customerSite;
    this.filteredFrom = locationArr;

    // this.filteredToSiteLoc = this.customerSite;
  }


  location_arrSite: any[] = []
  filteredLoactionToLoc(event: any) {
    let location_arrToLoc: any[] = [];
    this.location_arr = [];
    let query = event.query;
    this.ViewLocations.map((location: Location) => {
      if (location.locationId) {
        if (location.locationId !== null) {
          this.location_arr.push(location.locationId);
        }
      }
    });

    this.location_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        location_arrToLoc.push(location);
      }
    });

    // this.filteredLocations = location_arrToLoc;
    // this.filteredCustomerSite = this.customerSite;
    // this.filteredFrom = this.customerSite;
    this.filteredToSiteLoc = location_arrToLoc;
  }

  onBatchChange(event: any) {
    const batch = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'lineServiceTO.batchNo',
      lValue: batch?.value,
    });
  }

  onCustRefChange(event: any) {
    const custRef = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'lineServiceTO.custRef',
      lValue: custRef?.value,
    });
  }

  onServiceNoChange(event: any) {
    const serviceNo = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'lineServiceTO.serviceNo',
      lValue: serviceNo?.value,
    });
  }

  onChangeUnit1(event: any, unit1: any) {
    const qty1 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty1',
      lValue: `${Number(qty1?.value)} ${unit1}`,
    });
  }

  onChangeUnit2(event: any, unit2: any) {
    const qty2 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty2',
      lValue: `${Number(qty2?.value)} ${unit2}`,
    });
  }

  onChangeUnit3(event: any, unit3: any) {
    const qty3 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty3',
      lValue: `${Number(qty3?.value)} ${unit3}`,
    });
  }

  onChangeUnit4(event: any, unit4: any) {
    const qty4 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty4',
      lValue: `${Number(qty4?.value)} ${unit4}`,
    });
  }

  onChangeUnit5(event: any, unit5: any) {
    const qty5 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty5',
      lValue: `${Number(qty5?.value)} ${unit5}`,
    });
  }

  onChangeUnit6(event: any, unit6: any) {
    const qty6 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty6',
      lValue: `${Number(qty6?.value)} ${unit6}`,
    });
  }

  onChangeUnit7(event: any, unit7: any) {
    const qty7 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty7',
      lValue: `${Number(qty7?.value)} ${unit7}`,
    });
  }

  onChangeUnit8(event: any, unit8: any) {
    const qty8 = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'qty8',
      lValue: `${Number(qty8?.value)} ${unit8}`,
    });
  }

  onChangeLoadNo(event: any) {
    const loadNo = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'lineServiceTO.loadNo',
      lValue: loadNo?.value,
    });
  }

  onChangeDocket(event: any) {
    const docket = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'docket',
      lValue: docket?.value,
    });
  }

  onChangeContainerId(event: any) {
    const containerId = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'containerId',
      lValue: containerId?.value,
    });
  }

  onChangeRemarkInput(event: any) {
    const remarks = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({
      lName: 'remarks',
      lValue: remarks?.value,
    });
  }

  onChangePickuparrivetime(pickuparrivetime: any) {
    const pickuparrivetimeConvert =
      this.detailService.convertAusTimeZone(pickuparrivetime);
    this.runsheetFormService.emitFormChanges({
      lName: 'pickuparrivetime',
      lValue: pickuparrivetimeConvert,
    });
  }

  onChangePickupDeparttime(pickupDeparttime: any) {
    const pickupDeparttimetimeConvert =
      this.detailService.convertAusTimeZone(pickupDeparttime);
    this.runsheetFormService.emitFormChanges({
      lName: 'pickupdeparttime',
      lValue: pickupDeparttimetimeConvert,
    });
  }

  onChangePickupdoctime(pickupdoctime: any) {
    const pickupdoctimeConvert =
      this.detailService.convertAusTimeZone(pickupdoctime);
      console.log("-------------------------",pickupdoctimeConvert);
    this.runsheetFormService.emitFormChanges({
      lName: 'pickupdoctime',
      lValue: pickupdoctimeConvert,
    });
  }

  onChangeDropArrivetime(droparrivetime: any) {
    const droparrivetimeConvert =
      this.detailService.convertAusTimeZone(droparrivetime);
    this.runsheetFormService.emitFormChanges({
      lName: 'droparrivetime',
      lValue: droparrivetimeConvert,
    });
  }

  onChangeDropDocTime(dropdoctime: any) {
    const dropdoctimeConvert =
      this.detailService.convertAusTimeZone(dropdoctime);
    this.runsheetFormService.emitFormChanges({
      lName: 'dropdoctime',
      lValue: dropdoctimeConvert,
    });
  }

  onChangeDropreadytime(dropreadytime: any) {
    const dropreadytimeConvert =
      this.detailService.convertAusTimeZone(dropreadytime);
    this.runsheetFormService.emitFormChanges({
      lName: 'dropreadytime',
      lValue: dropreadytimeConvert,
    });
  }

  onChangeDropDeparttime(dropDeparttime: any) {
    const dropDeparttimetimeConvert =
      this.detailService.convertAusTimeZone(dropDeparttime);
    this.runsheetFormService.emitFormChanges({
      lName: 'dropdeparttime',
      lValue: dropDeparttimetimeConvert,
    });
  }

  onChangePickupreadytime(pickupreadytime: any) {
    const pickupreadytimeConvert =
      this.detailService.convertAusTimeZone(pickupreadytime);
    this.runsheetFormService.emitFormChanges({
      lName: 'pickupreadytime',
      lValue: pickupreadytimeConvert,
    });
  }
  dropLocationFull = '';
  onChangeDropLocation(locationDropId: any) {
    let matchLocation = this.ViewLocations.find(
      (location: Location) => location.locationId === locationDropId
    );
    console.log('matchLocation >>', matchLocation);
    this.dropLocationFull = this.detailService.getFullLocationDescription(matchLocation);
    this.dropLocationFull = this.dropLocationFull ? this.dropLocationFull : locationDropId;
  
    this.runsheetFormService.emitFormChanges({
      lName: 'locationDropId',
      lValue: locationDropId,
    });
    if (this.selectedDropLocation) {
      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.dropLocation.locationDesc',
        lValue: this.selectedDropLocation,
      });
      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.dropLocation.zoneChargeId',
        lValue: matchLocation.zoneChargeId,
      });
      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.dropLocation.locationDropId',
        lValue: matchLocation.locationId,
      });

      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.dropLocation.zonePayId',
        lValue: matchLocation.zonePayId,
      });
    }
  }
  pickupDescription: any;
  onChangeLocation(locationPickupId: any) {
    this.pickupDescription = '';
    console.log('Event loc >> ', locationPickupId);
    console.log('ViewLocations >>', this.ViewLocations);
    let matchLocation = this.ViewLocations.find(
      (location: Location) => location.locationId === locationPickupId
    );
    this.pickupDescription = this.detailService.getFullLocationDescription(matchLocation);
    this.pickupDescription = this.pickupDescription ? this.pickupDescription : locationPickupId;
    
    if (this.selectedPickLocationId) {
      this.runsheetFormService.emitFormChanges({
        lName: 'locationPickupId',
        lValue: this.selectedPickLocationId,
      });
      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.pickupLocation.locationDesc',
        lValue: this.selectedPickLocationId,
      });
      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.pickupLocation.locationId',
        lValue: matchLocation.locationId,
      });
      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.pickupLocation.zoneChargeId',
        lValue: matchLocation.zoneChargeId,
      });
      this.runsheetFormService.emitFormChanges({
        lName: 'lineServiceTO.pickupLocation.zonePayId',
        lValue: matchLocation.zonePayId,
      });
    }
    // else if(this.selectedDropLocation) {
    //   this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.dropLocation.locationDesc','lValue': this.selectedDropLocation});
    //   this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.dropLocation.zoneChargeId','lValue': matchLocation.zoneChargeId});
    //   this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.dropLocation.locationDropId','lValue': matchLocation.locationDropId});

    //   this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.dropLocation.zonePayId','lValue': matchLocation.zonePayId});
    // }
  }

  // Service Type
  getServiceTypesLookup(serviceTypeArray: any) {
    this.serviceTypeId = [];
    this.serviceTypeArray = serviceTypeArray;
    serviceTypeArray.map((serviceTypeIdUniqye: ServiceType) => {
      this.serviceTypeId.push(serviceTypeIdUniqye);      
    });
  //   const selectedServiceTypeData = serviceTypeArray[4];
  //   this.serviceDetailForm.get('serviceTypeId')?.setValue(selectedServiceTypeData.serviceTypeId);        
  //   this.currentServiceType = selectedServiceTypeData;
  //  this.selectionUnitData(this.currentServiceType);
  }

  filteredServiceFun(event: any) {
    let serviceTypeArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.serviceTypeId.map((serviceType: ServiceType) => {
      if (
        serviceType.serviceTypeId.toLowerCase().includes(query.toLowerCase())
      ) {
        serviceTypeArr.push(serviceType.serviceTypeId);
      }
    });
    this.filteredServiceType = serviceTypeArr;
  }
  clearService(){
    this.onChangeServiceType('JUICE')
    console.log("donee");
  }

  onChangeServiceType(selectServiceId: any) {
    this.runsheetFormService.emitFormChanges({
      lName: 'serviceTypeId',
      lValue: selectServiceId,
    });

    // this.runsheetFormService.emitFormChanges({serviceTypeId: selectServiceId});
    // console.log("service Type service detail",selectServiceId);
    this.serviceTypeArray.map((serviceIdData: ServiceType) => {
      if (selectServiceId === serviceIdData.serviceTypeId) {
        this.currentServiceType = serviceIdData;
        // this.ViewServiceTypes.push(serviceIdData)
        console.log('this.currentServiceType >>', this.currentServiceType);
        if (this.currentServiceType) {
          this.selectionUnitData(this.currentServiceType);
        }
      }
    });
  }

  selectionUnitData(matchedServiceType: any) {
    this.serviceDetailForm.reset;
    this.unit1 = false;
    this.unit2 = false;
    this.unit3 = false;
    this.unit4 = false;
    this.unit5 = false;
    this.unit6 = false;
    this.unit7 = false;
    this.unit8 = false;
    this.showdrop = false;
    this.showpickup = false;
    this.showextraunit1 = false;
    this.showextraunit4 = false;
    this.showextraunit5 = false;
    if (this.create == false) {
      // const matchedServiceType =  this.serviceTypeArray.find(
      //   (element: any) => element.serviceTypeId == element.serviceTypeId
      // );
      // const matchedServiceType =   this.currentServiceType
      if (matchedServiceType) {
        this.isservicetypeSelected = true;
        this.unitdata = matchedServiceType;
        if (this.unitdata.unit1) {
          this.unit1 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit1,
            new FormControl('')
          );
        }
        if (this.unitdata.unit2) {
          this.unit2 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit2,
            new FormControl('')
          );
        }
        if (this.unitdata.unit3) {
          this.unit3 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit3,
            new FormControl('')
          );
        }
        if (this.unitdata.unit4) {
          this.unit4 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit4,
            new FormControl('')
          );
        }
        if (this.unitdata.unit5) {
          this.unit5 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit5,
            new FormControl('')
          );
        }
        if (this.unitdata.unit6) {
          this.unit6 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit6,
            new FormControl('')
          );
        }
        if (this.unitdata.unit7) {
          this.unit7 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit7,
            new FormControl('')
          );
        }
        if (this.unitdata.unit8) {
          this.unit8 = true;
          this.serviceDetailForm.addControl(
            this.unitdata.unit8,
            new FormControl('')
          );
        }
      }
    }
  }

  // Customer
  getCustomer() {
    // this.reconcileService.getCustomers().subscribe((customerArr: any) => {
    // console.log("Customer > ", customerArr);
    this.ViewCustomers.map((customer: any) => {
      this.customerId.push(customer);
      // });
    });
  }

  filteredCustomerFun(event: any) {
    let customerArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.ViewCustomers.map((customer: any) => {
      this.customerId.push(customer);
      // });
    });
    this.customerId.map((customer: any) => {
      if (customer.customerId.toLowerCase().includes(query.toLowerCase())) {
        customerArr.push(customer.customerId);
        customerArr.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
      }
    });
    this.filteredCustomers = customerArr;
  }

  onChangeCustomer(customerId: any) {
    this.runsheetFormService.emitFormChanges({
      lName: 'lineServiceTO.customerId',
      lValue: customerId,
    });
  }

  // Loadtype
  getLoadType(loadTypeArr: any) {
    this.loadTypeId = [];
    loadTypeArr.map((loadType: any) => {
      this.loadTypeId.push(loadType.loadTypeId);
    });
  }

  filteredLoadtypeFun(event: any) {
    let loadTypeArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.loadTypeId.map((loadType: any) => {
      if (loadType.toLowerCase().includes(query.toLowerCase())) {
        loadTypeArr.push(loadType);
      }
    });
    this.filteredCustomers = loadTypeArr;
  }

  onChangeLoadType(loadTypeId: any) {
    this.runsheetFormService.emitFormChanges({
      lName: 'loadTypeId',
      lValue: loadTypeId,
    });
  }

  //Reason Code

  //reason code
  getReasonCode(reasonCodes: any) {
    // this.reconcileService.getReasonCode().subscribe((reasonCodes: any) => {
    // console.log('getReasonCode >> ', reasonCodes);
    this.reasonCode = [];
    reasonCodes.map((reasonDrop: any) => {
      if (reasonDrop.reasonDescription !== null) {
        // this.reasonCode.push(
        //   `${reasonDrop.reasonId}__${reasonDrop.reasonDescription}`
        // );
        this.reasonCode.push(reasonDrop);
      }
    });
    // console.log('reasonCode >>', this.reasonCode);
    // });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;

    this.reasonCode.map((company: any) => {
      if (
        company.reasonDescription.toLowerCase().includes(query.toLowerCase())
      ) {
        reasonArr.push(company);
      }
    });
    this.filteredReasons = reasonArr;
  }
  showReason: Reason = {
    reasonId: '',
    siteId: 0,
    reasonDescription: '',
    driver: false,
    active: false,
  };
  onChangeReason(selectedReasonCode: any) {
    this.showReason = selectedReasonCode;
    this.selectedReasonId = selectedReasonCode;
    let extractReasonCode = selectedReasonCode.reasonId;
    this.reasonCodeUnique = extractReasonCode;
    this.runsheetFormService.emitFormChanges({
      lName: 'lineServiceTO.reasonId',
      lValue: selectedReasonCode.reasonId,
    });

    // this.reasonCode.filter((reasonVal: any) => {
    //   let fileterResonStr = reasonVal.split('_')[0];

    //   console.log("reasonVal >>", fileterResonStr);

    //   if (fileterResonStr === extractReasonCode) {
    //      this.reasonCodeUnique =
    //     // this.drivrIdRequest = this.allReasonCode;
    //   }
    // });
  }

  //Popup for Adding Container
  openDialog() {
    const dialogRef = this.dialog.open(AddContainerDialogComponent);
  }

  getMultiLegData(runsheet: RunsheetDetail) {
    this.selectedPickLocationId = '';
    this.selectedDropLocation= '';
    if (runsheet != undefined) {
      this.serviceTypeId.filter((serviceTypeId: ServiceType) => {
        if (runsheet.serviceTypeId === serviceTypeId.serviceTypeId) {
          // this.selectedserviceTypeId = serviceTypeId.serviceTypeId;
          this.serviceDetailForm.controls['serviceTypeId'].setValue(
            serviceTypeId.serviceTypeId
          );
        }
      });

      //  console.log("Runseet unit key ,",         this.getformcontrolname(runsheet.unit1));

      this.serviceTypeId.filter((serviceTypeId: ServiceType) => {
        if (runsheet.serviceTypeId === serviceTypeId.serviceTypeId) {
          this.selectedserviceTypeId = serviceTypeId.serviceTypeId;
          // this.currentServiceType = 
          this.serviceTypeArray.map((serviceIdData: ServiceType) => {
            if (runsheet.serviceTypeId === serviceIdData.serviceTypeId) {
              this.currentServiceType = serviceIdData;
              // this.ViewServiceTypes.push(serviceIdData)
              console.log('this.currentServiceType >>', this.currentServiceType);
              if (this.currentServiceType) {
                // this.selectionUnitData(this.currentServiceType);
                // this.serviceDetailForm.patchValue({
                //   this.unitdata.unit1: ''
                // })
              }
            }
          });
        }
      });
      if (runsheet.qty1 == null) {
        this.serviceDetailForm.reset;
        this.unit1 = false;
        this.unit2 = false;
        this.unit3 = false;
        this.unit4 = false;
        this.unit5 = false;
        this.unit6 = false;
        this.unit7 = false;
        this.unit8 = false;
      }

      this.runsheetLines = runsheet;

      this.unitdata = runsheet;
      if (this.unitdata.unit1) {
        this.unit1 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit1,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit1].setValue(
          runsheet.qty1
        );
      }
      if (this.unitdata.unit2) {
        this.unit2 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit2,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit2].setValue(
          runsheet.qty2
        );
      }
      if (this.unitdata.unit3) {
        this.unit3 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit3,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit3].setValue(
          runsheet.qty3
        );
      }
      if (this.unitdata.unit4) {
        this.unit4 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit4,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit4].setValue(
          runsheet.qty4
        );
      }
      if (this.unitdata.unit5) {
        this.unit5 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit5,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit5].setValue(
          runsheet.qty5
        );
      }
      if (this.unitdata.unit6) {
        this.unit6 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit6,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit6].setValue(
          runsheet.qty6
        );
      }
      if (this.unitdata.unit7) {
        this.unit7 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit7,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit7].setValue(
          runsheet.qty7
        );
      }
      if (this.unitdata.unit8) {
        this.unit8 = true;
        this.serviceDetailForm.addControl(
          this.unitdata.unit8,
          new FormControl('')
        );
        this.serviceDetailForm.controls[this.unitdata.unit8].setValue(
          runsheet.qty8
        );
      }

      

      // this.ViewLocations.filter((location: Location) => {
      //   // console.log("customerSite >>", this.customerSite);

      //   if (runsheet.lineServiceTO.pickupLocation.locationDesc === location.locationId) {
      //     this.selectedPickLocationId = location.locationId;
      //   }
      // });
      this.selectedPickLocationId = runsheet?.locationPickupId;
      this.selectedDropLocation = runsheet?.locationDropId;

      // this.serviceDetailForm.patchValue({
      //   locationPickupId: runsheet.lineServiceTO.pickupLocation.locationDesc,
      //   locationDropId: runsheet.lineServiceTO.dropLocation.locationId,

      // });
      this.selectedCustomerId = runsheet?.lineServiceTO?.customerId;

      // this.customerId.filter((customer: customers) => {
      //   if (runsheet.lineServiceTO.customerId === customer.customerId) {
      //     this.selectedCustomerId = customer.customerId;
      //   }
      // });

      this.loadTypeId.map((loadtype: any) => {
        if (runsheet.loadTypeId === loadtype) {
          this.selectedLoadType = loadtype;
        }
      });

      this.editServiceDetail.lineServiceTO.batchNo =
        runsheet.lineServiceTO.batchNo;
      this.editServiceDetail.lineServiceTO.custRef =
        runsheet.lineServiceTO.custRef;
      // this.editServiceDetail.lineServiceTO.serviceNo =
      //   runsheet.lineServiceTO.serviceNo;
      // this.editServiceDetail.lineServiceTO.loadNo = runsheet.lineServiceTO.loadNo;
      this.serviceDetailForm.patchValue({
        serviceNo: runsheet.lineServiceTO.serviceNo,
      });

      this.serviceDetailForm.patchValue({
        loadNo: runsheet.lineServiceTO.loadNo,
      });
      this.serviceDetailForm.patchValue({ docket: runsheet.docket });

      // this.editServiceDetail.docket = runsheet.docket;
      // this.editServiceDetail.containerId = runsheet.containerId;
      this.serviceDetailForm.patchValue({ containerId: runsheet?.containerId });

      this.editServiceDetail.locationContPickupId =
        runsheet.locationContPickupId;
      // this.editServiceDetail.pickuparrivetime =
      //   this.runsheetTime.timeStamptToDateTime(runsheet.pickuparrivetime);

      this.selectedPickuparrivetime =
        this.runsheetTime.convertMillisecondsToDateTimeS(
          runsheet.pickuparrivetime
        );
        // this.serviceDetailForm.controls['pickuparrivetime'].setValue(this.selectedPickuparrivetime);
      this.selectedPickupReadytime =
        this.runsheetTime.convertMillisecondsToDateTimeS(
          runsheet.pickupreadytime
        );

      // this.timeService.convertMillisecondsToDate(
      //   this.selectedService.loadScheduledDate
      // );
      this.selectedPickupdoctime =
        this.runsheetTime.convertMillisecondsToDateTimeS(
          runsheet.pickupdoctime
        );
      this.selectedPickupdeparttime =
        this.runsheetTime.convertMillisecondsToDateTimeS(
          runsheet.pickupdeparttime
        );
      this.editServiceDetail.remarks = runsheet.remarks;
      //droptime
      this.selectedDroparrivetime =
        this.runsheetTime.convertMillisecondsToDateTimeS(
          runsheet.droparrivetime
        );

      this.selectedDropDocTime =
        this.runsheetTime.convertMillisecondsToDateTimeS(runsheet.dropdoctime);
      this.selectedDropreadytime =
        this.runsheetTime.convertMillisecondsToDateTimeS(
          runsheet.dropreadytime
        );

      this.selectedDropDeparttime =
        this.runsheetTime.convertMillisecondsToDateTimeS(
          runsheet.dropdeparttime
        );
      this.editServiceDetail.dropdeparttime =
        this.runsheetTime.timeStamptToDateTime(runsheet.dropdeparttime);
      this.selectedReasonId = this.getSelectedReason(
        runsheet.lineServiceTO.reasonId
      );
      this.showReason = this.selectedReasonId;
      // });
    }
  }
  reason: Reason;
  getSelectedReason(Id: any): Reason {
    let a = '';
    this.reasonCode.forEach((reason) => {
      if (reason.reasonId == Id) {
        this.reason = reason;
      }
    });
    if (this.reason != undefined || this.reason != null) {
      return this.reason;
    }
    return {
      active: false,
      driver: false,
      reasonDescription: '',
      reasonId: '',
      siteId: 0,
    };
  }
  fetchPermissions() {
    this.runsheetFormService.permissionFields.subscribe((permissions: any) => {
      console.log('Permisions Service line detail>> ', permissions);
      const permisionMatch = permissions.map((per: any) =>
        per.permissions.find((perm: any) => perm.id === 'Runsheet2')
      );

      this.canWrite = permisionMatch[0].write;
      if (!this.canWrite) {
        this.serviceDetailForm.controls['runsheetTypeId'].disable();
        this.serviceDetailForm.controls['driverId'].disable();
        this.serviceDetailForm.controls['starttime'].disable();
        this.serviceDetailForm.controls['endtime'].disable();
        this.serviceDetailForm.controls['returndepottime'].disable();
        this.serviceDetailForm.controls['runsheetTypeId'].disable();

        //  this.showLookup = !this.canWrite;
      } else {
        this.serviceDetailForm.controls['runsheetTypeId'].enable();
        this.serviceDetailForm.controls['driverId'].enable();
        this.serviceDetailForm.controls['starttime'].enable();
        this.serviceDetailForm.controls['endtime'].enable();
        this.serviceDetailForm.controls['returndepottime'].enable();
        this.serviceDetailForm.controls['runsheetTypeId'].enable();
      }
      console.log('permisionMatch >>', this.canWrite);
    });
  }

  getRunsheetState() {
    if (this.runsheetState?.complete) {
      this.serviceDetailForm.controls['serviceTypeId'].disable();
      this.serviceDetailForm.controls['customerId'].disable();
      this.serviceDetailForm.controls['loadTypeId'].disable();
      this.serviceDetailForm.controls['batchNo'].disable();
      this.serviceDetailForm.controls['custRef'].disable();
      this.serviceDetailForm.controls['serviceNo'].disable();
      this.serviceDetailForm.controls['loadNo'].disable();
      this.serviceDetailForm.controls['docket'].disable();
      this.serviceDetailForm.controls['pallets'].disable();
      this.serviceDetailForm.controls['dollars'].disable();
      this.serviceDetailForm.controls['hours'].disable();
      this.serviceDetailForm.controls['containers'].disable();
      this.serviceDetailForm.controls['kilograms'].disable();
      this.serviceDetailForm.controls['kilometers'].disable();
      this.serviceDetailForm.controls['reels'].disable();
      this.serviceDetailForm.controls['enteredBy'].disable();
      this.serviceDetailForm.controls['reasonId'].disable();
      this.serviceDetailForm.controls['remarks'].disable();
      this.serviceDetailForm.controls['pickupdeparttime'].disable();
      this.serviceDetailForm.controls['locationPickupId'].disable();
      this.serviceDetailForm.controls['pickuparrivetime'].disable();
      this.serviceDetailForm.controls['pickupdoctime'].disable();
      this.serviceDetailForm.controls['depart'].disable();
      this.serviceDetailForm.controls['reqDropLocation'].disable();
      this.serviceDetailForm.controls['droparrivetime'].disable();
      this.serviceDetailForm.controls['dropdoctime'].disable();
      this.serviceDetailForm.controls['dropreadytime'].disable();
      this.serviceDetailForm.controls['dropdeparttime'].disable();
      this.serviceDetailForm.controls['pickupdeparttime'].disable();
      this.serviceDetailForm.controls['container'].disable();

      if (this.unitdata.unit1) {
        this.serviceDetailForm.controls[this.unitdata.unit1].disable();
      }
      if (this.unitdata.unit2) {
        this.serviceDetailForm.controls[this.unitdata.unit2].disable();
      }
      if (this.unitdata.unit3) {
        this.serviceDetailForm.controls[this.unitdata.unit3].disable();
      }

      if (this.unitdata.unit4) {
        this.serviceDetailForm.controls[this.unitdata.unit4].disable();
      }

      if (this.unitdata.unit5) {
        this.serviceDetailForm.controls[this.unitdata.unit5].disable();
      }

      if (this.unitdata.unit6) {
        this.serviceDetailForm.controls[this.unitdata.unit6].disable();
      }

      if (this.unitdata.unit7) {
        this.serviceDetailForm.controls[this.unitdata.unit7].disable();
      }

      if (this.unitdata.unit8) {
        this.serviceDetailForm.controls[this.unitdata.unit8].disable();
      }

    }
  }

  ngOnDestroy() {
    // Unsubscribe to ensure no memory leaks
    this.formSubscription.unsubscribe();
  }

  
  onChangeContainer(containerId: any) {
    // let vesselIDPayload = '';; 
    // this.ViewContainers.map((vessel: any) => {
      // if(vessel.vessel === vesselId) {
      //   vesselIDPayload = vessel.id;
        this.runsheetFormService.emitFormChanges({'lName':'containerId','lValue': containerId});
      // }
    // })
  }

  //get formcontrolname based on detail form for create
  getformcontrolname(key: any): string {
    var a = '';
    for (const field in this.serviceDetailForm.controls) {
      if (field == key) {
        a = field;
      }
    }
    return this.serviceDetailForm.controls[a].value;
  }

  onServiceSubmit() {
    if (this.unitdata.unit1) {
      const Obj = {
        unit1: this.unitdata.unit1 ? this.unitdata.unit1 : 'unit1',
        qty1: this.getformcontrolname(this.unitdata.unit1)
          ? this.getformcontrolname(this.unitdata.unit1)
          : null,
      };
      this.uni1merge = { ...this.uni1merge, ...Obj };
    }
    if (this.unitdata.unit2) {
      const Obj = {
        unit2: this.unitdata.unit2 ? this.unitdata.unit2 : 'unit2',
        qty2: this.getformcontrolname(this.unitdata.unit2)
          ? this.getformcontrolname(this.unitdata.unit2)
          : null,
      };
      this.uni2merge = { ...this.uni2merge, ...Obj };
    }
    if (this.unitdata.unit3) {
      const Obj = {
        unit3: this.unitdata.unit3 ? this.unitdata.unit3 : 'unit3',
        qty3: this.getformcontrolname(this.unitdata.unit3)
          ? this.getformcontrolname(this.unitdata.unit3)
          : null,
      };
      this.uni3merge = { ...this.uni2merge, ...Obj };
    }
    if (this.unitdata.unit4) {
      const Obj = {
        unit4: this.unitdata.unit4 ? this.unitdata.unit4 : 'unit4',
        qty4: this.getformcontrolname(this.unitdata.unit4)
          ? this.getformcontrolname(this.unitdata.unit4)
          : null,
      };
      this.uni4merge = { ...this.uni3merge, ...Obj };
    }
    if (this.unitdata.unit5) {
      const Obj = {
        unit5: this.unitdata.unit5 ? this.unitdata.unit5 : 'unit5',
        qty5: this.getformcontrolname(this.unitdata.unit5)
          ? this.getformcontrolname(this.unitdata.unit5)
          : null,
      };
      this.uni5merge = { ...this.uni4merge, ...Obj };
    }
    if (this.unitdata.unit6) {
      const Obj = {
        unit6: this.unitdata.unit6 ? this.unitdata.unit6 : 'unit6',
        qty6: this.getformcontrolname(this.unitdata.unit6)
          ? this.getformcontrolname(this.unitdata.unit6)
          : null,
      };
      this.uni6merge = { ...this.uni5merge, ...Obj };
    }
    if (this.unitdata.unit7) {
      const Obj = {
        unit7: this.unitdata.unit7 ? this.unitdata.unit7 : 'unit7',
        qty7: this.getformcontrolname(this.unitdata.unit7)
          ? this.getformcontrolname(this.unitdata.unit7)
          : null,
      };
      this.uni7merge = { ...this.uni6merge, ...Obj };
    }
    if (this.unitdata.unit8) {
      const Obj = {
        unit8: this.unitdata.unit8 ? this.unitdata.unit8 : 'unit8',
        qty8: this.getformcontrolname(this.unitdata.unit8)
          ? this.getformcontrolname(this.unitdata.unit8)
          : null,
      };
      this.uni8merge = { ...this.uni7merge, ...Obj };
    }

    this.unitFormServiceObj = {
      ...this.uni1merge,
      ...this.uni2merge,
      ...this.uni3merge,
      ...this.uni4merge,
      ...this.uni5merge,
      ...this.uni6merge,
      ...this.uni7merge,
      ...this.uni8merge,
    };

    console.log('Service form submit', this.unitFormServiceObj);

    const units: any = {
      unit1: null,
      unit2: null,
      unit3: null,
      unit4: null,
      unit5: null,
      unit6: null,
      unit7: null,
      unit8: null,
    };

    const qtys: any = {
      qty1: null,
      qty2: null,
      qty3: null,
      qty4: null,
      qty5: null,
      qty6: null,
      qty7: null,
      qty8: null,
    };

    for (let key in units) {
      if (this.unitFormServiceObj[key]) {
        units[key] = this.unitFormServiceObj[key];
      }
    }

    for (let key in qtys) {
      if (this.unitFormServiceObj[key]) {
        qtys[key] = this.unitFormServiceObj[key];
      }
    }

    this.unitQtysObjs = { ...units, ...qtys };
    console.log('Units seperate > ', units);
    console.log('Qtys seperate kwy', qtys);
    console.log('Qtys Units ', this.unitQtysObjs);
  }
}

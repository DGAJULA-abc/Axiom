import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ReconcileService } from '../../../services/reconcile.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ServiceType } from '../runsheet-service-detail/runsheet-service-detail.model';
import {
  Details,
  LineServiceTo,
  LoadLocation,
  LoadTableData,
  LoadTableResponse,
  Location,
} from '../../detail.model';
import { CellrenderComponent } from '../../../list-incomplete-services/cellrender/cellrender.component';
import { customers } from 'src/app/features/setup/models/setup.model';
import { RunsheetDetail } from '../../detail2.model';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
import { PlanService } from 'src/app/features/plan/services/plan.service';
import { MultiLegSiteLocation } from 'src/app/features/plan/models/plan.model';
import { DetailService } from '../../detail.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { TimeRunsheetService } from '../../../services/time-runsheet.service';

@Component({
  selector: 'app-load-detail',
  templateUrl: './load-detail.component.html',
  styleUrls: ['./load-detail.component.scss'],
})
export class LoadDetailComponent implements OnInit, OnChanges {
  @Input() formStateSubmit: boolean;
  // service type
  serviceTypeId: any[] = [];
  filteredServiceType: any[] = [];
  selectedserviceTypeId: any;

  // customer
  selectedCustomerId: any[] | any;
  customerId: any[] = [];
  filteredCustomers: any[] = [];

  // Load Type
  selectedLoadType: any[] | any;
  loadTypeId: any[] = [];
  filteredLoadType: any[] = [];
  //reasonCode
  reasonCodeArr: any[] = [];
  filteredReasons: any[] = [];
  reasonCode: any[] = [];
  allReasonCode: any[] = [];
  reasonCodeUnique: any[] = [];

  //autocomplete for locationIds
  locationIds: any[] = [];
  selectedloadTypeId: any;
  filteredLocations: any[];
  location_arr: any[] = [];
  ViewCustomers: any[] = [];
  // Date
  editScheduleDate:  any = new Date();
  selectedDeliveryOpen: any = new Date();
  selectedDeliveryClose: any = new Date();
  selectedDispachDate: any = new Date();

  loadDetailFormObj: any = {};
  selectedLocationDest: any;

  @Input() runsheet: RunsheetDetail; 
  runsheetState: any;

  loadRow: any[] = [];
  loadColumnDefs: any[] = [
    {
      field: 'used',
      headerName: 'Used',
      filter: 'agNumberColumnFilter',
    },
    { field: 'enteredby', headerName: 'Entered By', minWidth: 120 },
    { field: 'serviceno', headerName: 'Service No.', minWidth: 120 },
    { field: 'loadtypeid', headerName: 'Load Type Id', minWidth: 150 },
    { field: 'servicetypeid', headerName: 'Service Type Id', minWidth: 120 },
    { field: 'servicedesc', headerName: 'Service desc', minWidth: 80 },
  ];

  isLoading: boolean = false;

  constructor(
    private fb: FormBuilder,
    private planService:PlanService,
    private reconcileService: ReconcileService,
    private runsheetFormService: RunsheetFormService,
    private detailService: DetailService,
    private authenticationService: AuthenticationService,
    private runsheetTime: TimeRunsheetService
  ) {}

  editLoadDetail =  {
    id: 14008010,
    locationContDropId: null,
    locationContPickupId: 123,
   locationDropId: "3000166-BACCHUS MARSH",
    locationPickupId: "1246 THOMASTOWN",
    locationReturnId: null,
    serviceId: 15441966,
    trailerId: null,
    containerId: null,
    loadTypeId: "DELIVERY",
    trailerTagId: null,
    serviceTypeId: "EXPORT",
    rateId: "P500PERTRIP",
    truckId: null,
    siteId: 999,
    qty1: 44,
    unit1: "TONNES",
    qty2: 45,
    unit2: "HOURS",
    qty3: null,
    unit3: null,
    qty4: null,
    unit4: null,
    qty5: null,
    unit5: null,
    qty6: null,
    unit6: null,
    qty7: null,
    unit7: null,
    qty8: null,
    unit8: null,
    owntrailer: false,
    offsiderused: false,
    pickuparrivetime: 1700053200000,
    pickupdeparttime: 1700744400000,
    droparrivetime: 1699448400000,
    dropreadytime: null,
    dropdeparttime: 1700139600000,
    docket: null,
    payamt: 500,
    payestimated: false,
    directfromdepot: false,
    remarks: "rating component",
    nextstoptime: null,
    tripkm: 0,
    paydesc: "$500.00 (Trip $500.00)",
    pickupreadytime: null,
    dropdoctime: null,
    pickupdoctime: null,
    createdby: "dhavaltr",
    tripno: 1,
    tripseq: 1,
    servicehours: null,
    hiretruck: false,
    globaldropbonus: null,
    deliverydate: 1699448400000,
    tripodostart: null,
    tripodoend: null,
    groupseq: null,
    tripstarttime: null,
    tripendtime: null,
    lineTemperature: null,
    lineServiceTO: {
        serviceId: 15441966,
        dataSource: "A2",
        created: 1699376153000,
        tripIdCust: null,
        serviceGroup: null,
        serviceDesc: null,
        customerId: "1052601",
        consignmentMasterCustomerId: "1052601",
        loadId: 13791515,
        serviceNo: "M0083289",
        reasonId: "105",
        chargeAmt: null,
        chargeDesc: null,
        rateId: null,
        complete: false,
        loadNo: "L0097771",
        batchNo: "3443",
        custRef: "r45",
        scheduleDate: 1699448400000,
        despatchBy: null,
        deliveryOpen: 1698843600000,
        deliveryClose: null,
        returnLocationId: null,
        pickupLocation: {
            locationId: null,
            siteId: 999,
            locationTypeId: null,
            locationDesc: "COD ROBERT JARVIS CASH SALE",
            zonePayId: "METRO",
            zoneChargeId: "METRO",
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null
        },
        dropLocation: {
            locationId: null,
            siteId: 999,
            locationTypeId: null,
            locationDesc: "ESTHER MCCLUSKEY",
            zonePayId: "PZONEOUT3",
            zoneChargeId: "CZONEOUT3",
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null
        },
        loadLocation: {
            locationId: "3000166-BACCHUS MARSH",
            siteId: 999,
            locationTypeId: null,
            locationDesc: "ESTHER MCCLUSKEY",
            zonePayId: null,
            zoneChargeId: null,
            suburb: null,
            active: null,
            loadTimeMins: null,
            address1: null,
            address2: null,
            state: null,
            postCode: null,
            window1From: null,
            window1To: null,
            window2From: null,
            window2To: null,
            window3From: null,
            window3To: null,
            personIdContact: null,
            personIdContactName: null,
            customerId: null,
            locationCode: null,
            latitude: null,
            longitude: null,
            geofence: null,
            mapSourceId: null,
            mapReference: null,
            remarks: null,
            truckSizeLimit: null,
            defaultTripSeq: null,
            routeId: null,
            permanent: null,
            loadTimeMinsPerUnit: null,
            loadTimeUnit: null,
            waitTimeMins: null,
            waitTimeMinsPerUnit: null,
            waitTimeUnit: null,
            accShortCut: null,
            locationIdGroup: null,
            siteTravelTime: null,
            disableWPUpdated: null,
            externalLookUp: null,
            internalLookUp: null,
            segManaged: null,
            segExported: null,
            routeCapacity: null
        },
        lastGroupSeq: null,
        clearCharge: false,
        totalChargeAmt: null,
        svcReasonLines: [],
        dehireDeadline: null,
        vesselEta: 1699362000000,
        vesselId: 1801,
        priority: null,
        wharf: "1246- CRAIGIEBURN",
        depot: "ASAHI ARCHERFIELD DC",
        customerSite: "3BUNNALTO-ALTONA",
        dehirePark: "1250 - ALTONA NORTH",
        originSite: 999,
        originLoc: "1246- CRAIGIEBURN",
        destinationSite: 999,
        destinationLoc: "1246 THOMASTOWN"
    },
    events: [],
    loadNoDuplicated: null
}

resetFormState = false;

  ngOnInit() {
    // this.getServiceTypesLookup();
    // this.getCustomer();
    // this.getLoadType();
    // this.getReasonCode();
   
    this.getServicesOfLoad();
    // // this.getMultiLegData();
    // this.getLoadDetailForm();
    this.runsheetState = this.detailService.runsheetStateConf;

  //   this.planService.getView().subscribe((result: any) => {
  //     if (result) {
  //   this.ViewLocations = result['ref'].locations;
  //   // this.getLocationIds();
  //   this.runsheetState = this.detailService.runsheetStateConf;

  // }});
    // this.resetLoadDetailForm();
  }
  ViewLocations: MultiLegSiteLocation[] = [];
  ngOnChanges(changes: SimpleChanges){

    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        this.isLoading = false;
        this.getServiceTypesLookup(result['ref'].serviceTypes);
        this.getLoadType(result['ref'].loadTypes);
      //   this.selectedsite = result['selectedSite'];
      //   this.ViewServiceTypes = result['ref'].serviceTypes;
      //   this.ViewDrivers = result['ref'].drivers;
      //   this.ViewTrucks = result['ref'].trucks;
      //   this.ViewContainers = result['ref'].containers;
        this.ViewCustomers = result['ref'].customers;
      // //   this.ViewTrailers = result['ref'].trailers;
      // //   this.ViewVessels = result['ref'].vessels;
        this.ViewLocations = result['ref'].locations;
      // //   this.ViewSites = result['ref'].sites;
      //   this.getReasonCode(result['ref'].reasons);
  
      //   if (this.selectedService.id != 0) {
      //     if (
      //       this.selectedService.originSite == this.selectedsiteid &&
      //       this.selectedService.destinationSite == this.selectedsiteid
      //     ) {
      //       this.selectedsitedescription = this.selectedsite.description;
      //       this.sites.push(this.selectedsite.description);
      //     }
      //   } else {
      //     this.sites.push(
      //       this.ViewSites.filter(
      //         (x: { id: number }) => x.id == this.navbarService.selectedSiteId
      //       )[0].description
      //     );
      //   }
      // }
      }
    });
    
  //   this.authecationService.getView().subscribe((result: any) => {
  //     if (result) {
  //   this.ViewLocations = result['ref'].locations;
  //   // this.getLocationIds();
  //   this.runsheetState = this.detailService.runsheetStateConf;

  // }});
    // console.log("LOad ngONchangex called on submit");
    this.sendData();
    setTimeout(() => {
      this.getMultiLegData(this.runsheet); 
      this.getRunsheetState();
 
    }, 100);
    
  }

  resetLoadDetailForm() {
    this.runsheetFormService.newRunsheetLineFormReset.subscribe((res: any) => {
      this.resetFormState = res;
      console.log('reset for  load >>', this.resetFormState);
      if (this.resetFormState) {
        this.serviceLoadForm.reset();
      }
    });
  }

  serviceLoadForm = this.fb.group({
    serviceTypeId: ['', Validators.required],
    customerId: ['', Validators.required],
    loadTypeId: ['', Validators.required],
    scheduleDate: ['', Validators.required],
    despatchBy: ['', Validators.required],
    deliveryOpen: ['', Validators.required],
    loadNo: ['', Validators.required],
    deliveryClose: ['', Validators.required],
    locationId: ['', Validators.required]
  });
  saveLoadForm() {}

  sendData() {
   this.runsheetFormService.sendLoadFormData(this.serviceLoadForm.value);
    // return null;
  }
  getLoadDetailForm() {
    this.serviceLoadForm.valueChanges.subscribe(res => {
      console.log(this.serviceLoadForm.getRawValue());
      this.runsheetFormService.serviceLoadForm = this.serviceLoadForm.getRawValue();
      this.checkFormForNull();
    })
  }

  checkFormForNull() {
    Object.keys(this.serviceLoadForm.controls).forEach((key: any) => {
      // First, check if the form control exists
      const control = this.serviceLoadForm.get(key);
  
      // Then check if the control is not null and has a value
      if (control && (control.value === null || control.value === '' || control.value === undefined)) {
        // console.log(key + ' is null or empty');
      } else if (control) {
        // console.log(key + ' has a value:', control.value);  
        this.loadDetailFormObj[key] = control.value;
          console.log('this.loadDetailFormObj', this.loadDetailFormObj);  
      }
    });
  }

  // Service Type
  getServiceTypesLookup(serviceTypeArr: any) {
    this.reconcileService
      .getServiceTypesLookup()
      // .subscribe((serviceTypeArr: any) => {
        // console.log('getServiceTypesLookup line> ', serviceTypeArr);
        serviceTypeArr.map((serviceTypeIdUniqye: ServiceType) => {
          this.serviceTypeId.push(serviceTypeIdUniqye);
        });
      // });
  }

  filteredServiceFun(event: any) {
    let serviceTypeArr: any[] = [];
    let query = event.query;

    // console.log("this.customerId >", this.customerId);
    this.serviceTypeId.map((serviceType: ServiceType) => {
      if (
        serviceType.serviceTypeId.toLowerCase().includes(query.toLowerCase())) {
        serviceTypeArr.push(serviceType.serviceTypeId);
      }
    });
    this.filteredServiceType = serviceTypeArr;
  }

  onChangeServiceType(selectServiceId: any) {
    this.runsheetFormService.emitFormChanges({'lName':'serviceTypeId','lValue': selectServiceId});

  }

  // Customer
  // getCustomer() {
  //   // this.reconcileService.getCustomers().subscribe((customerArr: any) => {
  //     // console.log("Customer > ", customerArr);
  //     this.ViewCustomers.map((customer: any) => {
  //       this.customerId.push(customer);
  //     });
  //   // });
  // }

  filteredCustomerFun(event: any) {
    let customerArr: any[] = [];
    let query = event.query;
    this.ViewCustomers.map((customer: any) => {
            this.customerId.push(customer);
          });
    // console.log("this.customerId >", this.customerId);
    this.customerId.map((customer: any) => {
      if (customer.customerId.toLowerCase().includes(query.toLowerCase())) {
        customerArr.push(customer.customerId);
      }
    });
    this.filteredCustomers = customerArr;
  }

  onChangeLoadNo(event: any) {
    const loadNo = event.target as HTMLInputElement;
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.loadNo','lValue':loadNo?.value}); 
  }


  onChangeCustomer(customerId: any) {
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.customerId','lValue':customerId}); 
  }

  onChangeScheduleDate(scheduleDate: any) {
    const scheduleDateConvert = this.detailService.convertAusTimeZone(scheduleDate);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.scheduleDate','lValue': scheduleDateConvert}); 
  }

  
  onChangeDespatchBy(despatchBy: any) {
    const despatchByConvert = this.detailService.convertAusTimeZone(despatchBy);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.despatchBy','lValue': despatchByConvert}); 
  }

  onChangeDeliveryOpen(deliveryOpen: any) {
    const deliveryOpenConvert = this.detailService.convertAusTimeZone(deliveryOpen);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.deliveryOpen','lValue': deliveryOpenConvert}); 
  }

  onDeliveryClose(deliveryClose: any) {
    const deliveryCloseConvert = this.detailService.convertAusTimeZone(deliveryClose);
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.deliveryClose','lValue': deliveryCloseConvert}); 
  }

  // Loadtype
  getLoadType(loadTypeArr: any) {
    // this.reconcileService.getLoadType().subscribe((loadTypeArr: any) => {
      // console.log("Customer > ", customerArr);
      loadTypeArr.map((loadType: any) => {
        this.loadTypeId.push(loadType.loadTypeId);
      });
    // });
  }

  filteredLoadtypeFun(event: any) {
    let loadTypeArr: any[] = [];
    let query = event.query;
    // console.log("this.customerId >", this.customerId);

    this.loadTypeId.map((loadType: any) => {
      if (loadType.toLowerCase().includes(query.toLowerCase())) {
        loadTypeArr.push(loadType);
      }
    });
    this.filteredLoadType = loadTypeArr;
  }

  onChangeLoadType(loadTypeId: any) {
    this.runsheetFormService.emitFormChanges({'lName':'loadTypeId','lValue': loadTypeId});
  }

  //Reason Code

  //reason code
  getReasonCode() {
    this.reconcileService.getReasonCode().subscribe((reasonCodes: any) => {
      // console.log('getReasonCode >> ', reasonCodes);
      reasonCodes.map((reasonDrop: any) => {
        if (reasonDrop.reasonDescription !== null) {
          this.reasonCode.push(
            `${reasonDrop.reasonId}__${reasonDrop.reasonDescription}`
          );
        }
      });
      // console.log('reasonCode >>', this.reasonCode);
    });
  }

  filteredReasonFn(event: any) {
    let reasonArr: any[] = [];
    let query = event.query;

    this.reasonCode.map((company: any) => {
      if (company.toLowerCase().includes(query.toLowerCase())) {
        reasonArr.push(company);
      }
    });
    this.filteredReasons = reasonArr;
  }

  onChangeReason(selectedReasonCode: any) {
    // console.log("selectedReasonCode >", selectedReasonCode);
    let extractReasonCode = selectedReasonCode.split('_')[0];
    console.log('strLen >> ', extractReasonCode);
    this.reasonCodeUnique = extractReasonCode;
  }

  getLocationIds() {
    this.ViewLocations.forEach((element) => {
      
      this.location_arr.push(element.locationId);
    });
    // this.reconcileService.getLocation().subscribe((locations: any) => {
    //   // console.log('getReasonCode >> ', reasonCodes);
    //   locations.map((location: Location) => {
    //     if (location.locationId !== null) {
    //       this.location_arr.push(location.locationId);
    //     }
    //   });
    //   // console.log('reasonCode >>', this.reasonCode);
    // });
  }
  filteredLoactionFun(event: any) {
    this.ViewLocations.forEach((element) => {
      
      this.location_arr.push(element.locationId);
    });
    let locationIdArr: any[] = [];
    let query = event.query;
    this.location_arr.map((location: any) => {
      if (location.toLowerCase().includes(query.toLowerCase())) {
        locationIdArr.push(location);
      }
    });
    this.filteredLocations = locationIdArr;
  }

  onChangeLocation(locationId: any) {
   let loadLocation = this.ViewLocations.find((loadLocation: any) => loadLocation.locationId === locationId)
   console.log("loadLocation >", loadLocation);
    
   this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.loadLocation.locationId','lValue':locationId}); 
    this.runsheetFormService.emitFormChanges({'lName':'lineServiceTO.loadLocation.locationDesc','lValue':loadLocation?.locationDesc});      
     
  }

  getServicesOfLoad() {
    this.reconcileService._multiLangData.subscribe((fetchLoad: any) => {
      if (fetchLoad[0]?.lineServiceTO?.loadId) {
        this.reconcileService
          .getServicesOfLoad(fetchLoad[0].lineServiceTO.loadId)
          .subscribe((loadData: LoadTableResponse) => {
            this.loadRow = loadData.map((rowLoad: LoadTableData) => {
              return rowLoad;
            });
          });
      }
    });
  }


  getMultiLegData(runsheet: RunsheetDetail) {
     if(runsheet != undefined && runsheet) {

     
      // console.log("customerId  Arr > ", this.loadTypeArrId);
      this.serviceTypeId.filter((serviceTypeId: ServiceType) => {
           if(runsheet.serviceTypeId === serviceTypeId.serviceTypeId) {
            this.selectedserviceTypeId = serviceTypeId.serviceTypeId;
           }
      })

      // this.customerId.filter((customer: customers) => {
      //      if(runsheet.lineServiceTO.customerId === customer.customerId) {
      //       this.selectedCustomerId = customer.customerId;
      //      }
      // })

      this.selectedCustomerId = runsheet.lineServiceTO.customerId;

      this.loadTypeId.map((loadtype: any) => {
        if(runsheet.loadTypeId === loadtype) {
          this.selectedloadTypeId = loadtype;
        }
      })


      // this.editLoadDetail.lineServiceTO.loadLocation.locationId = runsheet?.lineServiceTO?.loadLocation?.locationId;
      this.selectedLocationDest = runsheet?.lineServiceTO?.loadLocation?.locationId;
      // this.editLoadDetail.lineServiceTO.custRef = runsheet.lineServiceTO.loadLocation;
      this.editLoadDetail.lineServiceTO.serviceNo = runsheet.lineServiceTO.serviceNo;
      this.editLoadDetail.lineServiceTO.loadNo = runsheet.lineServiceTO.loadNo;
      this.editLoadDetail.docket = runsheet.docket;
      this.editLoadDetail.containerId = runsheet.containerId;

      this.editScheduleDate  = this.runsheetTime.convertMillisecondsToDate(runsheet.lineServiceTO.scheduleDate);
      this.selectedDeliveryOpen = this.runsheetTime.convertMillisecondsToDate(runsheet.lineServiceTO.deliveryOpen);
      this.selectedDeliveryClose  = this.runsheetTime.convertMillisecondsToDate(runsheet.lineServiceTO.deliveryClose);
       this.selectedDispachDate = this.runsheetTime.convertMillisecondsToDate(runsheet.lineServiceTO.deliveryClose);
  }
}

getRunsheetState() {

  if (this.runsheetState?.complete) {
    this.serviceLoadForm.controls['serviceTypeId'].disable();
    this.serviceLoadForm.controls['customerId'].disable();
    this.serviceLoadForm.controls['loadTypeId'].disable();
    this.serviceLoadForm.controls['scheduleDate'].disable();
    this.serviceLoadForm.controls['despatchBy'].disable();
    this.serviceLoadForm.controls['deliveryOpen'].disable();
    this.serviceLoadForm.controls['deliveryClose'].disable();
    this.serviceLoadForm.controls['loadNo'].disable();
    this.serviceLoadForm.controls['locationId'].disable();


    
    
  }
}
}

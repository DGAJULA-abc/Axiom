import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContaierDetailComponent } from './contaier-detail.component';

describe('ContaierDetailComponent', () => {
  let component: ContaierDetailComponent;
  let fixture: ComponentFixture<ContaierDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContaierDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ContaierDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

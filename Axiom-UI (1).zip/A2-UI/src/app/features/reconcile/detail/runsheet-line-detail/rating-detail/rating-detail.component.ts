import { Component, Input, OnInit,OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import { ReconcileService } from '../../../services/reconcile.service';
import { Details } from '../../detail.model';
import { RunsheetFormService } from '../../../services/runsheet-form.service';
import { DetailService } from '../../detail.service';
import { RunsheetDetail } from '../../detail2.model';

@Component({
  selector: 'app-rating-detail',
  templateUrl: './rating-detail.component.html',
  styleUrls: ['./rating-detail.component.scss']
})
export class RatingDetailComponent implements OnInit, OnChanges {
  
     ratingData: any[] = [];
     rateId: any;
     line: any;
     servicehours: any;
     tripkm: any;
     totalChargeAmt: any;
     paydesc: any;
     fuelLevyPay: any;
     chargeAmt: any;
     chargeDesc: any;
     fuelLevyCharge: any;
     remarks: any;

     rateChargeId: any;
     runsheetState: any;


    constructor(private reconcileService: ReconcileService, 
      private detailService: DetailService,
      private runsheetFormService: RunsheetFormService, private fb: FormBuilder){}

    // Define your form group
  ratingForm = this.fb.group({
    remarks:  ['', Validators.required] // Initialize your textarea with empty string or any default value
  });

    ngOnInit(){
    //  this.getRateDataLoad();
     this.getEventDetailForm();
     this.getRemarksValue();
     this.runsheetState = this.detailService.runsheetStateConf;
     setTimeout(() => {
      this.getRunsheetState();
 
    }, 100);
    }

    getEventDetailForm() {
      this.ratingForm.valueChanges.subscribe(res => {
        console.log(this.ratingForm.getRawValue());
        // this.runsheetFormService.serviceLoadForm = this.ratingForm.getRawValue();
        // this.checkFormForNull();
      })
    }

    // Method to access the value
  getRemarksValue() {
    // Access the value of the textarea using the formControlName 'remarks'
    const remarksValue = this.ratingForm?.get('remarks')?.value;
    if (remarksValue != null) {
      console.log(remarksValue);
    } else {
      console.error('remarksValue is null');
    }
  }
  getRunsheetState() {

    if (this.runsheetState?.complete) {
      this.ratingForm.controls['remarks'].disable();
  
      
    }
  }
  @Input() runsheet: RunsheetDetail; 
  ngOnChanges(changes: SimpleChanges){
    setTimeout(() => {
      this.getRateDataLoad(this.runsheet); 
    }, 100);
  }

    getRateDataLoad(runsheet:any) {
      // this.reconcileService._multiLangData.subscribe((fetchRate: Details) => {
       this.runsheetFormService._runSheetRatingDetail.next(runsheet);
      //   console.log("fetchLoad >>", fetchRate);
        let fetchRate = runsheet;

         this.rateId =  fetchRate?.rateId;
         this.line = fetchRate?.payamt;
         this.servicehours = fetchRate?.servicehours;
         this.tripkm = fetchRate?.tripkm;
         this.totalChargeAmt = fetchRate?.lineServiceTO?.totalChargeAmt;
         this.paydesc = fetchRate?.paydesc;
        //  this.fuelLevyPay = fetchRate?.fuelLevyInfo.fuelLevyPay;
       

        //Charge;
        this.rateChargeId = fetchRate?.lineServiceTO?.rateId;
        this.chargeAmt = fetchRate?.lineServiceTO?.chargeAmt;
        this.chargeDesc = fetchRate?.lineServiceTO?.chargeDesc;
        this.remarks = fetchRate?.remarks;

        
        // this.fuelLevyCharge = fetchRate.fuelLevyInfo.fuelLevyCharge;
        
        // this.reconcileService
        //   .getRatingDetails(fetchLoad.lineServiceTO.rateId)
        //   .subscribe((rateData: any) => {
        //     console.log("rateData >>", rateData);
            
        //     this.ratingData = rateData.map((ratesData: any) => {
        //       return ratesData;
        //     });
        //   });
      // });
    }
}

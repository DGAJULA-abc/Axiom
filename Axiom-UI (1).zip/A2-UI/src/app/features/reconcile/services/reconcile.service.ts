import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  Driver,
  ListIncompleteReconcile,
  ViewReconcile,
} from '../models/view.reconcile.model';
import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';

import { BehaviorSubject, Observable, Subject, catchError, of } from 'rxjs';
import { RunsheetFormRequest } from '../view-runsheet-form/ViewRunsheetId.model';
import { MultiLegSiteLocation } from '../../plan/models/plan.model';
import { OriginLoc } from '../detail/detail2.model';
import { trailers } from '../../setup/models/setup.model';
import { MessageService } from 'primeng/api';
import { map } from 'lodash';

@Injectable({
  providedIn: 'root',
})
export class ReconcileService {
  public pageTitleSubject = new Subject<string>;
  private _cellSubdata: Subject<any> = new Subject();
  public _onDetailChangeSubdata: Subject<any> = new Subject();

  public panelBehSubject = new BehaviorSubject<any>(false);
  public reloadGrid = new BehaviorSubject<any>(false);
  public selectedItemType = new Subject();
  selectedItemType$ = this.selectedItemType.asObservable();
  public setRowData: any = [];
  public selectedServiceId: any = [];

  public _multiLangData: Subject<any> = new Subject();
  public _gridEventData: Subject<any> = new Subject();
  public _multicheckeddata: Subject<any> = new Subject();

  constructor(private http: HttpClient, private messageService: MessageService) {}
  getReconcileView(): any {
    // let options :any = [];
    let options: any = { referenceDataActiveStates: { drivers: 'ANY' } };

    return this.http.get<ViewReconcile>(
      'assets/APIs/reconcile-view.json',
      options
    );
  }

  setSelectedItemType(val: any) {
    this.selectedItemType.next(val);
  }

  getListIncompleteService(): any {
    let searchQuery = {
     // svcDateFrom: 1698172200000,
     // svcDateTo: 1699429961759,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 10000,
        orderType: 'DESC',
        orderByField: 'serviceid',
      },
      svcComplete: false
    };
    let options: any = [];
    return this.http.post<any>(`${apiEndpoint.searchService}`, searchQuery);
  }

  lookUp(requestParam: any): any {
    return this.http.post<any>(`${apiEndpoint.runsheetLookup}`, requestParam);
  }

  getListIncompleteRunsheet(): any {
    let searchQuery = {
      completed: false,

      pagination: {
        pageNumber: 1,
        recordsPerPage: 10000,
        orderType: 'DESC',
        orderByField: 'runsheetid',
      },
    };
    // return this.http.get<any>(`${localEndpoint.ListIncompleteRunsteet}`, options)
    return this.http.post<any>(`${apiEndpoint.searchRunsheet}`, searchQuery);
  }

  getListCompleteRunsheet(listFormSubmit: any): any {
    let searchQuery = {
      completed: true,
      deliveryFrom: +listFormSubmit.deliveryFrom,
      deliveryTo: +listFormSubmit.deliveryTo,
      exported: false,
      pagination: {
        pageNumber: 1,
        recordsPerPage: 10000,
        orderType: 'DESC',
        orderByField: 'runsheetid',
      },
    };
    // return this.http.get<any>(`${localEndpoint.ListIncompleteRunsteet}`, options)
    return this.http.post<any>(`${apiEndpoint.searchRunsheet}`, searchQuery);
  }

  public get getCellSubdata(): Observable<any> {
    return this._cellSubdata.asObservable();
  }
  runsheetIdGet: any;
  setCellSubData(cellData: any, isChecked?: boolean) {
    if(cellData?.data?.runsheetid) {
       this.runsheetIdGet = cellData?.data?.runsheetid;
    } else {
       this.runsheetIdGet = cellData?.data?.id;
    }
    if (isChecked) {
      this.setRowData.push(this.runsheetIdGet);
      // console.log('cellData >> ', this.setRowData);
    } else {
      const index = this.setRowData.indexOf(this.runsheetIdGet);
      if (index > -1) {
        // only splice array when item is found
        this.setRowData.splice(index, 1); // 2nd parameter means remove one item only
      }
      // console.log('cellData >> ', this.setRowData);
    }

    this._cellSubdata.next(cellData);
  }

  deleteInvoiceApi(id: any) {
    let options: any = [];
    return this.http.delete<any>(`${apiEndpoint.adjustmentUndocumentedInvoiceLine}`, {
      body: id,
    });
  }

  deletePayAdjustMentApi(id: any) {
    let options: any = [];
    return this.http.delete<any>(`${apiEndpoint.adjustmentUndocumentedPayAdviceLine}`, {
      body: id,
    });
  }

  setReconcilePage() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.reconcileView}`, options);
  }

  autoCompletionStatus() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.autoCompleteStatus}`, options);
  }

  deleteRunsheetId() {
    return this.http.delete<any>(`${apiEndpoint.runsheets}`, {
      body: this.setRowData,
    });
  }

  getViewRunsheetId(runsheetId: any) {
    return this.http.get<any>(`${apiEndpoint.runsheet}/${runsheetId}`);
  }

  getPeriodicCharges() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.periodics.charge}`);
  }

  postPeriodicCharges(chargeForm: any) {
    let options: any = [];
    return this.http.post<any>(`${apiEndpoint.periodic.charge}`, chargeForm);
  }

  putPeriodicCharges(chargeForm: any) {
    let options: any = [];
    return this.http.put<any>(`${apiEndpoint.periodic.charge}`, chargeForm);
  }

  deletePerdicCharges(ids: any) {
    return this.http.delete<any>(`${apiEndpoint.periodics.charge}`, {
      body: ids,
    });
  }
  deletePerdicPays(ids: any) {
    return this.http.delete<any>(`${apiEndpoint.periodics.payment}`, {
      body: ids,
    });
  }

  postapplycharges(data:any){
    return this.http.post<any>(`${apiEndpoint.periodics.apply}`,data);
  }

  deleteListInCompletedata(ids:any){
    return this.http.delete<any>(`${apiEndpoint.runsheets}`, {
      body: ids,
    });
  }

  getCustomers() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.customerLookup}`, options);
  }

  getServiceType() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.serviceTypesLookup}`, options);
  }

  getAllRunsheetStatus(completiondate: any) {
    let options = completiondate;
    return this.http.post<any>(`${apiEndpoint.autoComplete}`, options);

    // return this.http.get<any>('assets/APIs/auto-complete.json');
  }

  getReleaseRunsheetOnHold() {
    let options: any = {};
    return this.http.post<any>(`${apiEndpoint.releaseRunsheetOnHold}`, options);
  }
  
  postRunsheetLinesValidation(runsheetLines: any) {
    let options: any = {};
    return this.http.post<any>(`${apiEndpoint.runsheetLinesValidation}`, runsheetLines);
  }
  getPrintInvoices(printed: boolean): any {
    let searchQuery;
    if (printed === true) {
      searchQuery = {
        exported: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    } else {
      searchQuery = {
        printed: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    }
    return this.http.post<any>(`${apiEndpoint.searchInvoice}`, searchQuery);
  }

  getPrintPayAdvices(printed: boolean): any {
    let searchQuery;
    if (printed === true) {
      searchQuery = {
        exported: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    } else {
      searchQuery = {
        printed: false,

        pagination: {
          pageNumber: 1,
          recordsPerPage: 100,
          orderType: 'DESC',
          orderByField: 'id',
        },
      };
    }

    return this.http.post<any>(`${apiEndpoint.searchPayAdvice}`, searchQuery);
  }

  createPayAdvices(payAdviceForm: any): any {
    let searchQuery = {
      issueDate: payAdviceForm.issueDate,
      effectiveDateFrom: payAdviceForm.effectiveDateFrom,
      effectiveDateTo: payAdviceForm.effectiveDateT,

      pagination: {
        orderType: 'ASC',
        pageNumber: 1,
        recordsPerPage: 100,
      },
    };
    // return this.http.get<any>(`${localEndpoint.ListIncompleteRunsteet}`, options)
    return this.http.post<any>(
      `${apiEndpoint.payAdviceSimulationCreation}`,
      searchQuery
    );
  }

  createInvoice(invoiceFormSubmit: any): any {
    let searchQuery = {
      invoiceCreationParameters: {
        effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
        effectiveDateTo: invoiceFormSubmit.effectiveDateT,
        includePreviousDates: invoiceFormSubmit.includePreviousDates,
      },
      pagination: {
        pageNumber: 1,
        recordsPerPage: 100,
        orderType: 'DESC',
        orderByField: 'id',
      },
    };

    return this.http.post<any>(
      `${apiEndpoint.invoiceSimulateCreation}`,
      searchQuery
    );
  }

  invoiceWithCustomer(invoiceFormSubmit: any): any {
    let searchQuery = {
      effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
      effectiveDateTo: invoiceFormSubmit.effectiveDateT,
      issueDate: invoiceFormSubmit.issueDate,
      includePreviousDates: invoiceFormSubmit.includePreviousDates,
      customers: invoiceFormSubmit.customers,
      daysToPay: invoiceFormSubmit.daysToPay,
    };

    return this.http.put<any>(`${apiEndpoint.invoice}`, searchQuery);
  }

  closeOffLog(LogsDetails: any) {
    let searchQuery = {
      selectedSite: LogsDetails.selectedSite,
      showMissingSitesForLastWeek: LogsDetails.showMissingSitesForLastWeek,
      weekEndingDate: LogsDetails.weekEndingDate,
    };

    return this.http.post<any>(`${apiEndpoint.closeOff.logs}`, searchQuery);
  }

  closeOffSummary(weekEndingDate: any) {
    let searchQuery = {"weekEndingDate" : weekEndingDate};
    return this.http.post<any>(`${apiEndpoint.closeOff.summary}`, searchQuery);
  }

  closeOff(reqParam: any, closeOffImmediate:boolean) {
    let searchQuery = reqParam;
    let url;
    if (closeOffImmediate === true){
      url = `${apiEndpoint.closeOff.submitNow}`;
    }else{
      url = `${apiEndpoint.closeOff.submit}`
    }
    return this.http.post<any>(url, searchQuery);
  }
  //viewreconcilre tab data;
  getTabsDada(): any {
    let options: any = [];
    return this.http.get<any>('assets/APIs/reconcileTab.json', options);
  }

  //viewreconcilre tab data;
  getTabReconcileRunsheetService(): any {
    let options: any = [];
    return this.http.get<any>(
      'assets/APIs/runsheet_Lines_Tab_Data.json',
      options
    );
  }

  getMetaDataJson() {
    let options: any = [];
    return this.http.get<any>('assets/APIs/metadata.json', options);
  }

  getInvoiceDeatails(invoiceId: any) {
    return this.http.get<any>(`${apiEndpoint.invoice}/${invoiceId}`);
  }

  getPayAdviceDetails(invoiceId: any) {
    return this.http.get<any>(`${apiEndpoint.payAdviceCreation}/${invoiceId}`);
  }

  getPeriodic() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.periodic}`, options);
  }

  getPeriodicPayments() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.periodics.payment}`, options);
  }

  postPerdicApplyPayments(data: any) {
    let option = data;
    return this.http.post(`${apiEndpoint.periodic.applyPayments}`, option);
  }

  getDriver() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.drivers}`, options);
  }

  getCompany() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.companies}`, options);
  }

  // getGLCode() {
  //   let options :any = [];
  //   return this.http.get<any>(`${apiEndpoint.glCode}`, options);
  // }

  perdiocPaymentFormApi(paymentValue: any) {
    let options: any = [];
    return this.http.post<any>(`${apiEndpoint.periodic.payment}`, paymentValue);
  }

  putPeriodicPayment(paymentValue: any){
    return this.http.put<any>(`${apiEndpoint.periodic.payment}`, paymentValue);
  }

  payAdvice(invoiceFormSubmit: any) {
    let searchQuery = {
      issueDate: invoiceFormSubmit.issueDate,
      effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
      effectiveDateTo: invoiceFormSubmit.effectiveDateT,
    };

    return this.http.put<any>(`${apiEndpoint.payAdviceCreation}`, searchQuery);
  }

  invoice(invoiceFormSubmit: any) {
    let searchQuery = {
      effectiveDateFrom: invoiceFormSubmit.effectiveDateFrom,
      effectiveDateTo: invoiceFormSubmit.effectiveDateT,
      includePreviousDates: true,
    };

    return this.http.put<any>(`${apiEndpoint.invoice}`, searchQuery);
  }

  getAdjustmentTypes() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.adjustmentTypes}`);
  }

  getRunsheetTypes() {
    let options: any = [];
    return this.http.get<any>(`${apiEndpoint.runsheetTypes}`);
  }

  getEffectiveDate() {
    let options: any = [];
    // return this.http.get<any>(`${apiEndpoint.adjus}`);
  }

  getundocumentedAdjustment() {
    return this.http.get<any>(`${apiEndpoint.adjustmentUndocumented}`);
  }

  getRunsheetServiceNoData(runsheetNo: any) {
    return this.http.post<any>(`${apiEndpoint.searchRunsheet}`, runsheetNo);
  }
  getServiceReference(serviceNumber: any, adjustType: any) {
    let options: any = [];
    // const url = http://axiapauu04/api/v1/d/adjustment/service-reference/M0081941/type/CREDIT%20CHARGE
    return this.http.get<any>(
      `${apiEndpoint.adjustmentServiceRef}/${serviceNumber}/type/${adjustType}`
    );
  }

  adjustmentFormSubmit(formValue: any) {
    return this.http.put<any>(`${apiEndpoint.adjustment}`, formValue);
  }

  updateInvoiceStatus(invoiceIds: any, invoiceStatus: any) {
    let searchQuery = {
      ids: invoiceIds,
      status: invoiceStatus,
    };

    return this.http.post<any>(
      `${apiEndpoint.updateInvoiceStatus}`,
      searchQuery
    );
  }

  updatePayAdviceStatus(payAdviceIds: any, payAdviceStatus: any) {
    let searchQuery = {
      status: payAdviceStatus,
      ids: payAdviceIds,
    };

    return this.http.post<any>(
      `${apiEndpoint.updatePayAdviceStatus}`,
      searchQuery
    );
  }

  deleteInvoices(selectedIds: any) {
    let searchQuery = selectedIds;

    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: searchQuery,
    };

    return this.http.delete<any>(`${apiEndpoint.deleteInvoice}`, options);
  }

  deletePayAdvices(selectedIds: any) {
    let searchQuery = selectedIds;

    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: searchQuery,
    };
    return this.http.post<any>(`${apiEndpoint.deletePayAdvice}`, searchQuery);
  }

  //viewRunsheet id

  getReasonCode() {
    return this.http.get<any>(`${apiEndpoint.reasonsCode}`);
  }

  //viewRunsheet id

  viewRunsheetSubmit(runsheetForm: any) {
    return this.http.post<any>(`${apiEndpoint.runsheet}`, runsheetForm);
  }

  lockRunsheet(id: any) {
    let data = {};
    return this.http.post<any>(`${apiEndpoint.runsheet}/${id}/lock`, data);
  }

  showErrors(id: any, shiftId: any) {
    let shiftId_ = 123;
    const httpOptions = {
      Headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    //return this.http.post(`${apiEndpoint.despatchDecision.endpoint}`, requestParam, {headers: headers});
    return this.http.post<any>(
      `${apiEndpoint.runsheet}/${id}/show-errors`,
      shiftId_,
      { headers: httpOptions.Headers }
    );
  }

  unlockRunsheet(id: any) {
    let data = {};
    return this.http.post<any>(`${apiEndpoint.runsheet}/${id}/unlock`, data);
  }

  renewLocks(id: any) {
    let data: any = {};
    return this.http.post<any>(`${apiEndpoint.renewLocks}/${id}/lock`, data);
  }

  renew() {
    let data = {};
    // return this.http.post(`${apiEndpoint.renewLocks}`);
    return this.http.post<any>(`${apiEndpoint.renewLocks}`, data);
  }

  getMultiLegSiteLocationsBySite(sideId: any) {
    return this.http.get<any>(
      `${apiEndpoint.locationMultiLegSiteLocations}/${sideId}`
    );
  }

  getLocation() {
    return this.http.get<any>(`${apiEndpoint.locations}`);
  }

  getServiceTypesLookup() {
    return this.http.get<any>(`${apiEndpoint.serviceTypesLookup}`);
  }

  getLoadType() {
    return this.http.get<any>(`${apiEndpoint.loadTypes}`);
  }

  getServicesOfLoad(loadId: any) {
    return this.http.get<any>(
      `${apiEndpoint.runsheetGetServicesOfLoad}/${loadId}`
    );
  }

  getEventData(loadId: any) {
    return this.http.get<any>(`${apiEndpoint.events}}`);
  }

  getRatingDetails(rateId: any) {
    return this.http.get<any>(`${apiEndpoint.runsheetRate}}/${rateId}`);
  }

  getContainerLookup(rateId: any) {
    return this.http.get<any>(`${apiEndpoint.containerLookup}}`);
  }

  getVesselLookup() {
    return this.http.get<any>(`${apiEndpoint.vessels}`);
  }
  getWharfLookup() {
    // return this.http.get<any>(`${apiEndpoint.locations}`);
  }

  getDepot() {
    return this.http.get<any>(`${apiEndpoint.locations}`);
  }

  getCustomerSite() {
    return this.http.get<any>(`${apiEndpoint.customerLookup}`);
  }

  getPrimaryOriginSite() {
    return this.http.get<OriginLoc>(
      `${apiEndpoint.maxxToAxiomTranslation.originSites}`
    );
  }
  getMultiLegSiteLocations(siteId: string): Observable<any> {
    if (!siteId) {
      return of([]); // Immediately return an empty array if no siteId is provided
    }

    const url = `${apiEndpoint.multiLegSiteLocations}/${siteId}`;
    return this.http.get(url);
  }


  getTruck() {
    return this.http.get<any>(`${apiEndpoint.truckLookup}`);
  }

  getTrailer() {
    return this.http.get<any>(`${apiEndpoint.trailerLookup}`);
  }

  getBreakType() {
    return this.http.get<any>(`${apiEndpoint.breakTypes}`);
  }

  getShiftDetails(request: any) {
    return this.http.post<any>(`${apiEndpoint.shiftDetails}`, request);
  }

  postLookupRunsheet(request: any) {
    return this.http.post<any>(`${apiEndpoint.runsheetLookup}`, request);
  }

  deleteRunsheet(runsheetId: any) {
    return this.http.delete<any>(`${apiEndpoint.deleteRunsheet}/${runsheetId}`);
  }

  completeRunsheet(runsheetId: any) {
    let data: any = {};
    return this.http.post<any>(
      `${apiEndpoint.runsheetComplete}/${runsheetId}/complete`,
      data
    );
  }

  rateRunsheet(runsheetId: any) {
    let data: any = {};
    return this.http.post<any>(
      `${apiEndpoint.runsheetRate}/${runsheetId}/rate`,
      data
    );
  }

  backoutRunsheet(runsheetId: any) {
    let data: any = {};
    return this.http.post<any>(
      `${apiEndpoint.backoutRunsheet}/${runsheetId}/backout`,
      data
    );
  }

  backoutRunsheetsCompleteRun(runsheetArray: number[]): Observable<any> {
    // Assuming 'your_endpoint' is the URL to which you post the data
    return this.http.post(`${apiEndpoint.bulkBackout}`, runsheetArray);
  }

  
  handleResponse(response: any) {
    if(Array.isArray(response?.failureMsgs)) {
      if (response?.failureMsgs && response?.failureMsgs.length > 0) {
        response.failureMsgs.map((msg: any) => {
          // ... do something with item
          this.showMessage('error', 'Error', msg);
        });
        // Handle the undefined or null case
      
    }
    }
   
  }

  private showMessage(severity: string, summary: string, detail: string) {
    // this.messageService.add({ severity, summary, detail });
    this.messageService.add({
      key: 'fullWidth',
      severity: severity,
      summary: summary,
      detail: detail,
      // life: 3000 // Duration in milliseconds after which the message will be closed
      closable: true 
    });
  }
    

  _resetServices(runsheetId: any, serviceId: any, isChecked: any) {
    let data: any = {};
    if (isChecked) {
      this.selectedServiceId.push(serviceId);
      // console.log('cellData >> ', this.setRowData);
    } else {
      const index = this.selectedServiceId.indexOf(runsheetId);
      if (index > -1) {
        // only splice array when item is found
        this.selectedServiceId.splice(index, 1); // 2nd parameter means remove one item only
      }
      // console.log('cellData >> ', this.setRowData);
    }
    return this.http.post<any>(
      `${apiEndpoint.runsheet}/${runsheetId}/reset-services/`,
      this.selectedServiceId
    );
  }

  checkDemurrage(runsheetLines: any) {
    let data: any = {};
    return this.http.post<any>(
      `${apiEndpoint.runsheetCheckDemurrage}`,
      runsheetLines
    );
  }

  validateRunsheetLines(runsheetLines: any) {
    let data: any = {};
    return this.http.post<any>(
      `${apiEndpoint.runsheetLinesValidation}`,
      runsheetLines
    );
  }

  generateLoadNoDuplicationMsg(runsheetLines: any) {
    return runsheetLines
      .filter((runsheetLine: any) => {
        return runsheetLine.loadNoDuplicated === true;
      })
      .map(function (runsheetLine: any) {
        return (
          '(Load No:' +
          runsheetLine.lineServiceTO.loadNo +
          ',Customer ID:' +
          runsheetLine.lineServiceTO.customerId +
          ')'
        );
      })
      .groupBy(function (msg: any) {
        return msg;
      })
      .keys()
      .join(', ');
  }

  runsheetProcessing(runsheetId: any) {
    return this.http.get<any>(
      `${apiEndpoint.runsheetStatus}/${runsheetId}/status`
    );
  }

  getDriverDropProperVal(driver: Driver) {
    const driverName = `${driver.employeeName} - ${driver.surname} (${driver.companyId})`;
    return driverName;
  }
  getDriverDropProperVal2(driver: Driver) {
    const driverName = `${driver.firstName} - ${driver.surname} (${driver.companyId})`;
    return driverName;
  }

  getReasonIdVal(reasonDrop: any) {
    const reasonId = `${reasonDrop.reasonId}__${reasonDrop.reasonDescription}`;
    return reasonId;
  }

  geTrailerName(trailer: trailers) {
    const trailerName = `${trailer.trailerId} , (${trailer.trailerTypeId} , ${trailer.companyId})`;

    return trailerName;
  }

  findDriverId(allDriver: any, selectedDriver: any) {
     return allDriver.find((driver: Driver) => selectedDriver.indexOf(driver.employeeName) > -1)
  }

  searchByTrips(searchObject: any) {
    return this.http.post(apiEndpoint.searchTrips, searchObject);
  }
  postCsvDownload(payload: any) {
    return this.http.post(apiEndpoint.setupCsvDownload.services, payload, {
      responseType: 'arraybuffer',
    });
  }

  deleteListIncompleteService(id: any) {
    return this.http.delete<any>(`${apiEndpoint.service}`, {
      body: id,
    });
  }
}

import { Injectable } from '@angular/core';
import { RunsheetService } from './runsheet.service';
import { ConfirmationService } from 'primeng/api';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RunsheetAutofillModalService {
  constructor(
    private confirmationService: ConfirmationService,
    private runsheetService: RunsheetService
  ) {}

  /**
   * [show description]
   * @param {Object} driverSummary
   * @param {Object} runsheet      runsheet to autofill
   * @return {Object}               promise
   */
  show(driverSummary: any, runsheet: any): Observable<any> {
    const resultSubject = new Subject<any>();

    this.confirmationService.confirm({
      header: 'Automatically Fill Runsheet',
      message: 'Jobs have been completed for this driver',
      accept: () => {
        // Here you can call autoFillSome or autoFillAll
        // For example, if you choose to fill all:
        this.runsheetService
          .autoFillAll(runsheet)
          .subscribe((autoFillResult: any) => {
            resultSubject.next(autoFillResult);
            resultSubject.complete();
          });
      },
      reject: () => {
        resultSubject.next({ filled: false });
        resultSubject.complete();
      },
    });

    return resultSubject.asObservable();
  }
}

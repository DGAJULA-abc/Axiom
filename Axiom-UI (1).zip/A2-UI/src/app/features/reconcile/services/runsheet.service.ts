import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map, of } from 'rxjs';

import { apiEndpoint, localEndpoint } from 'src/app/config/config.model';
import { RunsheetLineDetailService } from '../detail/runsheet-line-detail/runsheet-line-detail.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';


@Injectable({
  providedIn: 'root',
})
export class RunsheetService {
  constructor(
    private http: HttpClient,
    private runsheetLineService: RunsheetLineDetailService,
    private permissionsService: PermissionsService
  ) {}

  unlockRunsheet(id: number): Observable<any> {
    // if (this.getCanWrite()) {
    return this.http.post(`${apiEndpoint.runsheetLock}/${id}/unlock`, {});
    // } else {
    // return of({ data: {} });
    // }
  }

  getRunsheetLookup(json: any): Observable<any> {
    if (this.getCanWrite()) {
      console.log("this.getCanWrite() >", this.getCanWrite());
      
    return this.http.post(apiEndpoint.runsheetLookup, json);
    } else {
    return of({}); // of() creates an Observable from a static value
    }
  }

  lockRunsheet(id: number) {
    // if (this.getCanWrite()) {
    return this.http.post(`${apiEndpoint.runsheetLock}/${id}/lock`, {});
    // } else {
    // If getCanWrite() is false, return an observable with an empty object.
    // return of({ data: {} });
  }

  checkAutofill(runsheet: any): Observable<any> {
    const url = `${apiEndpoint}/${runsheet.id}/autofill-services-of-driver`;
    const body = {
      deliveredServicesOnly: false,
      deliveryDate: 
      runsheet.deliverydate,
      driverId: runsheet.driverId,
      tripNo: runsheet.runsheetLines.reduce(
        (result: any, rsl: any) => Math.max(rsl.tripno, result + 1),
        0
      ),
    };
   console.log("URL:", url);
   console.log("body:", body);
    return this.http.post(`${apiEndpoint.runsheetUpdate}/${runsheet.id}/autofill-services-of-driver`, body);
  }

  autoFillSome(runsheet: any): any {
    return this.autoFill(runsheet, true);
  }

  autoFillAll(runsheet: any): any {
    return this.autoFill(runsheet, false);
  }

  autoFill(runsheet: any, deliveredServicesOnly: boolean): Observable<any> {
    const tripNo = runsheet.runsheetLines.reduce(
      (result: any, rsl: any) => Math.max(rsl.tripno + 1, result),
      1
    );
    const requestPayload = {
      deliveredServicesOnly: deliveredServicesOnly,
      deliveryDate: runsheet.deliverydate, //1710853200000,
      driverId: runsheet.driverId,
      driverShiftId: runsheet.shiftId,
      tripNo: tripNo,
    };

    const url = [apiEndpoint.runsheet, runsheet.id, 'autofill'].join('/');

    return this.http.post<any>(url, requestPayload);
    // .pipe(
    //   map((response: any) => {
    //     // response.runsheetLines.forEach((line: any) => {
    //     //   line.owntrailer = this.getOwnTrailer(runsheet, line); // Assuming getOwnTrailer is a method within this service
    //     // });
    //     const isTrip = false;
    //     this.runsheetLineService.refreshRunsheetLines(
    //       this.runsheetLineService.updateRunsheetLines(
    //         response.runsheetLines,
    //         runsheet,
    //         isTrip
    //       )
    //     );
    //     // this.breakService.updateDriverBreaks(response.driverBreaks, runsheet);

    //     return {
    //       filled: !!(
    //         response.runsheetLines.length > 0 ||
    //         response.driverBreaks.length > 0
    //       ),
    //     };
    //   })
    //);
  }

  getOwnTrailer(runsheet: any, entity: any): any {
    // const driver = this.refDataService.get('drivers', runsheet.driverId);
    const trailerId = entity.firstRunsheetLine
      ? entity.firstRunsheetLine.trailerId
      : entity.trailerId;
    // const trailer = this.refDataService.get('trailers', trailerId);
    //  const  driver = {
    //   driver: {
    //     companyId: '12349'
    //   }
    //  }
    //  const trailer = {
    //   trailer: {
    //     companyId: 1234
    //   }
    //  }
    //   if (driver && trailer) {
    //     return driver.companyId === trailer.companyId;
    //   }

    // If driver or trailer is not found, the function returns undefined implicitly
  }

  isSelectionBulk(selections: any[]): boolean {
    return (
      selections && selections.length > 1 && !this.isSelectionMixed(selections)
    );
  }

  isSelectionMixed(selections: any[]): boolean {
    return (
      this.selectionHasTrip(selections) &&
      this._selectionNotAllTrips(selections)
    );
  }

  selectionHasTrip(selections: any[]): boolean {
    return selections.some((row) => row.isTrip);
  }

  _selectionNotAllTrips(selections: any) {
    return selections.some((row: any) => {
      return !row.isTrip;
    });
  }

  bulkUpdateField(runsheet: any, selections: any[], fieldObj: any): any {
    const tripSelection = selections.every(
      (selection) => selection.isTrip === true
    );
    if (tripSelection) {
      return this.bulkUpdateByTrip(runsheet, selections, fieldObj);
    } else {
      return this.bulkUpdateByService(runsheet, selections, fieldObj);
    }
  }

  private bulkUpdateByService(
    runsheetLines: any,
    selections: any[],
    fieldObj: any
  ): any {
    const selectionIdList = selections.map((selection) => selection.id);
    let updatedSelectionArr: any[] = [];
    updatedSelectionArr = selections.map((item: any) => ({
      ...item,
      ...fieldObj,
    }));
    for (let i = 0; i < runsheetLines.length; i++) {
      for (let j = 0; j < updatedSelectionArr.length; j++) {
        if (runsheetLines[i].id === updatedSelectionArr[j].id) {
          runsheetLines.splice(i, 1, updatedSelectionArr[j]);
        }
      }
    }
    // runsheetLines.forEach((line: any) => {
    //   if (selectionIdList.includes(line.id) && fieldObj) {
    //     // line[fieldObj] = fieldObj.lValue;
    //     for (let key in line) {
    //       line[key] = fieldObj[key];
    //     }

    //   }
    // });
    console.log('bulkUpdateByUpdatedSelectionArr >>', updatedSelectionArr);

    console.log('bulkUpdateByServiceRunsheetLines >>', runsheetLines);

    return runsheetLines;
  }

  private bulkUpdateByTrip(
    runsheet: any,
    selections: any[],
    fieldObj: any
  ): any {
    const selectionIdList = selections.map((selection) => selection.tripno);
    runsheet.runsheetLines.forEach((line: any) => {
      if (selectionIdList.includes(line.tripno)) {
        line[fieldObj.lName] = fieldObj.lValue;
      }
    });
    return runsheet;
  }

  getCanWrite() {
    return (
      this.permissionsService.canWrite2('EnterRunsheets') &&
      this.permissionsService.canWrite2('Runsheet2')
    );
  }

  updateRunsheetPUT(json: any): Observable<any> {
    // Assuming `paths.runsheetUpdate` is the URL to which you're making the request
    return this.http.post<any>(apiEndpoint.runsheetUpdate, json).pipe(
      map(data => data)
    );
  }
}

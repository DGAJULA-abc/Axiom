import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { Subject } from 'rxjs';
import { TimezoneServiceService } from './timezone-service.service';

@Injectable({
  providedIn: 'root',
})
export class TimeRunsheetService {
  constructor(private timezoneService: TimezoneServiceService) {}

  dateTime(runsheetTime: any) {
    const dateTime = +moment(runsheetTime, 'YYYY-MM-DD[T]HH:mm:ss')
      .format('x')
      .valueOf();
    return dateTime;
  }

  timeStamptToDateTime(time: any) {
    //  const dateTime = moment(
    //     time,
    //     'YYYY-MM-DD[T]HH:mm:ss'
    //   ).format('x');
    const dateTime = new Date(time);

    return dateTime;
  }

  adjustWithNextDayPolicy(
    baseDate: any,
    comparedDate: any,
    onlyTimeEntered: boolean
  ): any {
    if (!comparedDate) {
      return null;
    }

    if (!baseDate) {
      return comparedDate;
    }

    if (onlyTimeEntered) {
      let baseDateMoment = this.timezoneService.localizeMoment(baseDate);
      let comparedDateMoment =
        this.timezoneService.localizeMoment(comparedDate);
      if (comparedDateMoment.isBefore(baseDateMoment)) {
        comparedDateMoment = comparedDateMoment.add(1, 'day');
      }
      return this.timezoneService.unLocalize(comparedDateMoment.valueOf());
    } else {
      return comparedDate;
    }
  }

 adjustWith8HoursPolicy(baseDate: any, comparedDate: any, onlyTimeEntered: boolean): Date | null {
    if (baseDate) {
      const baseDateMoment: any = this.timezoneService.localizeMoment(baseDate);
      if (comparedDate) {
        let comparedDateMoment = this.timezoneService.localizeMoment(comparedDate);
        const extraHours = 8;
        const adjusted = this.timezoneService.unLocalize(this.addHours(baseDateMoment, extraHours));

        if (!comparedDateMoment.isValid()) {
          return adjusted;
        }

        if (onlyTimeEntered) {
          comparedDateMoment.year(baseDateMoment.year());
          comparedDateMoment.month(baseDateMoment.month());
          comparedDateMoment.date(baseDateMoment.date());
        }

        if (comparedDateMoment < baseDateMoment) {
          return new Date(adjusted.valueOf());
        } else {
          return new Date(this.timezoneService.unLocalize(comparedDateMoment.valueOf()).valueOf());
        }
      } else {
        return null;
      }
    } else {
      return comparedDate;
    }
  }

  private addHours(date: Date, hours: number): Date {
    const result = new Date(date);
    result.setHours(result.getHours() + hours);
    return result;
  }

  convertMillisecondsToDate(milliseconds: number) {
    return moment(milliseconds).tz('Australia/Melbourne').format('DD/MM/YYYY');
  }
  convertMillisecondsToDateTimeS(milliseconds: number) {
    return moment(milliseconds)
      .tz('Australia/Melbourne')
      .format('DD/MM/YYYY HH:mm:ss');
  }
  convertMillisecondsToDateTimeM(milliseconds: number) {
    return moment(milliseconds)
      .tz('Australia/Melbourne')
      .format('DD/MM/YY HH:mm');
  }
  convertMillisecondsToDateTimeMS(milliseconds: number) {
    return moment(milliseconds)
      .tz('Australia/Melbourne')
      .format('DD/MM/YY HH:mm:ss');
  }

  convertMillisecondsToDateTimeF(milliseconds: number) {
    return moment(milliseconds)
      .tz('Australia/Melbourne')
      .format('YYYY-MM-DD HH:mm');
  }
  convertMillisecondsToDateTimeSF(milliseconds: number) {
    return moment(milliseconds)
      .tz('Australia/Melbourne')
      .format('YYYY-MM-DD HH:mm:ss');
  }
  convertMillisecondsToDateTime2(milliseconds: number) {
    return moment(milliseconds)
      .tz('Australia/Melbourne')
      .format('MM/DD/YYYY HH:mm:ss');
  }

  convertDatetoMilliseconds(date: any) {
    return moment(
      moment
        .tz(moment(date).format('YYYY-MM-DD HH:mm:ss'), 'Australia/Melbourne')
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
  }
  convertDatetoMilliseconds2(date: any) {
    return moment(
      moment
        .tz(moment(date).set({
          hour: 14,
          minute: 0,
          second: 0,
        }).format('MM/DD/YYYY HH:mm:ss'), 'Australia/Melbourne')
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
  }
  convertDatetoMilliseconds3(date: any) {
    return moment(
      moment
        .tz(moment(date).set({
          hour: 0,
          minute: 0,
          second: 0,
        }).format('MM/DD/YYYY HH:mm:ss'), 'Australia/Melbourne')
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
  }
  getmomentfromdate(sentdate: any): number {
    var newYork = moment.tz(sentdate, 'Australia/Melbourne');
    var india = newYork.clone().tz('Asia/Kolkata');
    let moment_num = moment(india).valueOf();
    return moment_num;
  }
}

import { Component} from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { ReconcileService } from 'src/app/features/reconcile/services/reconcile.service';

@Component({
  selector: 'app-cellrender',
  templateUrl: './cellrender.component.html',
  styleUrls: ['./cellrender.component.scss']
})
export class CellrenderComponent implements ICellRendererAngularComp {
  receivedData: boolean;
  rowCheckData: any = "";
  params: any;
  checkboxEnabled = false;
  selectedRows: any[] = [];
  isChecked: boolean = false;
  totalCount: number = 0;
  parentComponent: any;

  constructor(private reconsileService: ReconcileService) {

  }

  agInit(params: ICellRendererParams<any, any, any>): void {
    this.params = params;
    this.parentComponent = this.params.context.Component;
  }

  refresh(params: ICellRendererParams<any, any, any>): boolean {
    return false;
  }

  ngOninit(): void {

  }

  getRowIdData(event: any) {
    console.log("parent component:", this.parentComponent);
    event.stopPropagation();
    let id;
    if (this.parentComponent.rightTitle === 'Create Invoices') {
      id = this.params.data.customerId;
    } else if (this.parentComponent.rightTitle === 'Print Custom Page') {
      id = this.params.data.id;
    }
  console.log("id:", id, this.parentComponent.rightTitle);
    if (this.params.data.isChecked === true && event.target.checked === false) {
      this.params.data.isChecked = false
      this.totalCount = 0;
      if(this.parentComponent)
      this.parentComponent.setCellSubData(this.totalCount, id, event.target.checked);
    } else {

      this.totalCount = event.target.checked ? 1 : -1;
      this.reconsileService.panelBehSubject.next(true);
      if(this.parentComponent)
      this.parentComponent.setCellSubData(this.totalCount, id, event.target.checked);
    }

  }

}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RunsheetDetail } from '../detail/detail2.model';
import {
  Runsheet,
  RunsheetInterface,
} from '../view-runsheet-form/ViewRunsheetResponse.model';

@Injectable({
  providedIn: 'root',
})
export class RunsheetObjCreation {
  constructor() {}
  // RunsheetInterface

  runsheetObjCompare(serviceData: any, formData: any) {
    const result: any = {};
    const runsheet = {}.hasOwnProperty;
    for (let serviceDataKey in serviceData) {
      if (runsheet.call(formData, serviceDataKey)) {
        //  runsheeet start
        if (
          serviceDataKey === 'runsheetLines' &&
          formData[serviceDataKey].length > 0 &&
          formData[serviceDataKey][0].id !== null
        ) {
          console.log('Yes runsheetLines');
          result[serviceDataKey] = formData[serviceDataKey];
        } else if (
          serviceDataKey === 'runsheetLines' &&
          formData[serviceDataKey].length === 0 &&
          serviceData[serviceDataKey].length > 0 &&
          serviceData[serviceDataKey][0].id !== null
        ) {
          console.log('service api data runsheetLines');
          result[serviceDataKey] = serviceData[serviceDataKey];
        } else if (
          serviceDataKey === 'runsheetLines' &&
          formData[serviceDataKey].length > 0 &&
          formData[serviceDataKey][0].id === null
        ) {
          if (
            result[serviceDataKey] &&
            Array.isArray(result[serviceDataKey]) &&
            result[serviceDataKey].length === 0
          ) {
            result[serviceDataKey].push(formData[serviceDataKey][0]);
          }
          result[serviceDataKey] = formData[serviceDataKey];
        } else {
          result[serviceDataKey] = formData[serviceDataKey];
        }
        // runsheeet ENd

        // driver break
        if (
          serviceDataKey === 'driverBreaks' &&
          formData[serviceDataKey].length > 0 &&
          formData[serviceDataKey][0].id !== null
        ) {
          console.log('Yes Break');
          result[serviceDataKey] = formData[serviceDataKey];
        } else if (
          serviceDataKey === 'driverBreaks' &&
          formData[serviceDataKey].length > 0 &&
          formData[serviceDataKey][0].id === null
        ) {
          console.log('New Break');
          result[serviceDataKey] = formData[serviceDataKey];
        }
                // driver End
      } else if (runsheet.call(serviceData, serviceDataKey)) {
        result[serviceDataKey] = serviceData[serviceDataKey];
      }
    }
    return result;
  }
}

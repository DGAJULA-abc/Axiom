import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import { ReferenceMetaDataService } from './reference-meta-data.service';

@Injectable({
  providedIn: 'root',
})
export class ReferenceDataService {
  private _userOptions: any = {};
  private _refData: any = {};
  private _unusedCustomerMasters = [];
  private _unusedHomeLocations = [];

  // The paths object should be provided as well, perhaps through Angular's environment files
  private paths: { [key: string]: string };

  constructor(private http: HttpClient, private referenceMetadataService: ReferenceMetaDataService) {}

  getRefData(): any {
    return this._refData;
  }

  _getDriverFullName(driver: any) {
    if (!driver.firstName && !driver.surname) {
      return null;
    }
    if ('Last First' === this.getUserOptionValue('DriverNameFormat')) {
      return [driver.surname, driver.firstName].join(' ');
    }
    return [driver.firstName, driver.surname].join(' ');
  }

  getUserOptionValue(optionName: any): any {
    return this._userOptions[optionName];
  }

  getAsyncRefDataByPath(pathName: string): Observable<any> {
    return this.http.get(this.paths[pathName]);
  }

  getUserOptions() {
    return this._userOptions;
  }

  get(entityRef: string, id: string | number, filters: Array<Function> = []): any {
    // get id key from metadata
    const idKey = this.referenceMetadataService.getIdKey(entityRef) || 'id';
    const idKeyType = this.referenceMetadataService.getIdKeyType(entityRef);
    
    // If idKeyType is 'INTEGER', ensure id is a number
    const entityId = idKeyType === 'INTEGER' ? parseInt(id as string, 10) : id;

    // Prepare the filter functions
    const entityFilters = [
      ...filters,
      (entity: any) => entity[idKey] === entityId
    ];

    // Call the getAll method with the entity reference and the filters
    return this.getAll(entityRef, entityFilters)[0];
  }

  // The getAll method should be implemented to filter the _refData based on the entityRef and filters.
  private getAll(entityRef: string, filters: Array<Function>): any[] {
    // This is a simplified version. You'll need to implement actual filtering logic.
    return (this._refData[entityRef] || []).filter((entity: any) => filters.every(filterFn => filterFn(entity)));
  }
}

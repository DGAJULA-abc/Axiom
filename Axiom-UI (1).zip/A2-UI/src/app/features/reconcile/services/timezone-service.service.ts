import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class TimezoneServiceService {

  private units = ['hour', 'day', 'week', 'month', 'year'];

  constructor() {}

  private _getTimezoneId(): string {
    const defaultTimezoneId = 'utc';
    // Replace with the actual logic to get the timezone ID from your application context
    // this.modelService.getUserContext().siteTimeZoneId || 
    return (defaultTimezoneId).toLowerCase();
  }

  localize(timestamp: number): number | null {
    return timestamp !== null ? this.localizeMoment(timestamp).toDate().getTime() : null;
  }

  localizeMoment(timestamp: number): moment.Moment {
    return moment(timestamp).add(this._getOffsetMinutes(timestamp), 'minute');
  }

  unLocalize(timestamp: any): any | null {
    return timestamp !== null ? moment(timestamp).subtract(this._getOffsetMinutes(timestamp), 'minute').toDate().getTime() : null;
  }

  localStartOf(timestamp: number, unit: string): number | null {
    return moment(timestamp).isValid() && this.units.indexOf(unit) !== -1
      ? this.unLocalize(moment(this.localize(timestamp)).startOf(unit as moment.unitOfTime.StartOf).valueOf())
      : null;
  }

  // Other methods...

  private _getOffsetMinutes(timestamp: number): number {
    const timezoneId = this._getTimezoneId();
    return moment(timestamp).isValid() && timezoneId
      ? moment(timestamp).tz(timezoneId).utcOffset() - moment(timestamp).utcOffset()
      : 0;
  }


  localStartOfLastFinancialWeek(): number {
    const today = moment().tz(this._getTimezoneId()).startOf('day');
    let currentWeekStart = today.clone().isoWeekday(this._getFirstDayOfWeekInISO());
    if (currentWeekStart.isAfter(today)) {
      currentWeekStart = currentWeekStart.subtract(1, 'weeks');
    }
    const previousWeekStart = currentWeekStart.clone().subtract(1, 'weeks');
    return previousWeekStart.valueOf();
  }

  localEndOfLastFinancialWeek(): number {
    return moment(this.localStartOfLastFinancialWeek()).tz(this._getTimezoneId())
      .add(6, 'days')
      .endOf('day')
      .valueOf();
  }

  localEndOfLastFinancialWeekAtMidnight(): number {
    return moment(this.localStartOfLastFinancialWeek()).tz(this._getTimezoneId())
      .add(6, 'days')
      .startOf('day')
      .valueOf();
  }

  isSameFinancialWeek(subjectDate: any, effectiveDate: any): boolean {
    const weekStartDay = this._getFirstDayOfWeek();
    // Localize dates
    subjectDate = this.localize(subjectDate);
    effectiveDate = this.localize(effectiveDate);
    // Get service/runsheet financial week
    const subjectWeekStartDate = moment(subjectDate).weekday(weekStartDay - 1).unix() * 1000;
    const subjectWeekEndDate = moment(subjectDate).weekday(weekStartDay + 5).unix() * 1000;
    return effectiveDate >= subjectWeekStartDate && effectiveDate <= subjectWeekEndDate;
  }

  localDayOfWeek(input: number): number {
    return moment().tz(this._getTimezoneId()).day(input).valueOf();
  }

  private _getFirstDayOfWeekInISO(): number {
    // Implement this method based on how you determine the first day of the week
    let isoWeekDay = this._getFirstDayOfWeek() - 1;
    if (isoWeekDay === 0) {
      isoWeekDay = 7;
    }
    return isoWeekDay;
  }

  private _getFirstDayOfWeek(): any {
    // Replace with your logic to get the first day of the week
    // For example:
    // return parseInt(this.refDataService.getUserOptionValue('FirstDayOfWeek'), 10);
  }
}

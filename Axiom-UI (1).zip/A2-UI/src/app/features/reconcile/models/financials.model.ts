export interface UndocumentedAdjustments {
    adjustmentInvoiceLineUndocumentedTOs: [],
    adjustmentPayAdviceLineUndocumentedTOs: []
}

export interface ServiceNo {
    id: number
    siteId: number
    serviceDate: number
    serviceNumber: string
    customerId: string
    chargeAmount: number
    fuelLevyAmount: number
    loadNumber: string
    serviceTypeId: string
    driverId: number
    dataSourceId: string
    fuelLevyPercent: number
  }

// 
  export interface ServiceFormSubmit {
    adjustmentTypeId: string
    effectiveDate: number
    runsheetId: any
    serviceNumber: string
    invoiceLine: InvoiceLine
    payAdviceLine: any
  }
  
  export interface InvoiceLine {
    lineAmount: number
    customerId: string
    rechargeCustomerId: any
    lineText: string
    fuelLevyAmount: number
  }
  
  
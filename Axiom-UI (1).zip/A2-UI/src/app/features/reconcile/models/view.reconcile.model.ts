import { ActionGroupList, CloseOffSites } from "src/app/shared/model/shared.model";

export interface ViewReconcile {
    actionGroupList: ActionGroupList,
    closeOffSites: CloseOffSites[],
    weekEndingDay: number
}


export interface ListIncompleteReconcile  {
            runsheetid: number,
            siteid: number,
            deliverydate: number,
            publicholidayapplies: boolean,
            driverid: number,
            driver: string,
}

export interface Driver {
    id: number
    siteId: number
    personId: number
    firstName: string
    surname: string
    employeeName: string
    mdtCode: string
    groupDriver: boolean
    companyId: string
    vendorName: string
    truckId: any
    trailerId: any
    payBasisId: any
    homeLocationId: any
    active: boolean
    mobile: string
    invalidationDate: any
    entityDriver: boolean
}
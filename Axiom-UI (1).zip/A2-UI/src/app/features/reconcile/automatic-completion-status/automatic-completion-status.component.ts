import { Component, Inject } from '@angular/core';
import { ReconcileService } from '../services/reconcile.service';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

import { MAT_DIALOG_DATA, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import {
  DialogComponent,
  DialogDataSubmitCallback,
} from 'src/app/shared/dialog/dialog.component';
import * as moment from 'moment';
import { ConfirmationService, MessageService, SelectItem } from 'primeng/api';
import { ErrorList, ExceptionInfo } from '../view-runsheet-form/ViewRunsheetId.model';


@Component({
  selector: 'app-automatic-completion-status',
  templateUrl: './automatic-completion-status.component.html',
  styleUrls: ['./automatic-completion-status.component.scss'],
  providers: [MessageService, ConfirmationService]
  // providers: [
  //   DatePipe,
  //   TimeRunsheetService,
  //   ConfirmationService,
  //   RunsheetAutofillModalService,
  // ],
})
export class AutomaticCompletionStatusComponent {
  input: FormControl = new FormControl('');
  heading: string = 'Complete all runsheets until';
  contentText: string = '';
  dateCompletion: any;
  headerRunsheet: any;
  errFirst: any;
  errorId: any;
  errorDetail: any;
  errorInner: any;
  exceptionTime: any;
  errorHeader2: any;

//   automaticCompletionDate: 
  autoCompleteForm = this.autoFb.group({
     automaticCompletionDate: [new Date(), Validators.required]
  })
   dialogConfig = new MatDialogConfig();


  constructor(
    private reconsileService: ReconcileService,private autoFb: FormBuilder, private messageService: MessageService,
    private confirmationService: ConfirmationService,

    @Inject(MAT_DIALOG_DATA)
    public data: { callback: DialogDataSubmitCallback<any>; defaultValue: any },
    private dialogRef: MatDialogRef<DialogComponent>
  ) {}

  
  ngOnInit() {
    this.operReconcilePopup()
  }

  autoCompleteFormSubmit() {
    let _date;
    _date = moment(this.autoCompleteForm.value.automaticCompletionDate);
    _date = _date
      .set({
        hour: 0,
        minute: 0,
        second: 0,
      })
      .format('YYYY-MM-DD HH:mm:ss');
    var s_australia_time = moment.tz(_date, 'Australia/Melbourne');
    var s_india = s_australia_time.clone().tz('Asia/Kolkata');
    this.dateCompletion = moment(s_india).valueOf();

    //  this.dateCompletion = moment(this.autoCompleteForm.value.automaticCompletionDate, "YYYY-MM-DD").format("x");
     this.reconsileService.getAllRunsheetStatus(this.dateCompletion).subscribe((res: any) => {
      if(res){
        this.dialogRef.close({data:res})
      }
     }, 
     (err: any) => {
      console.log("Error in autocomplete", err);
      this.dialogRef.close({data: err})
  
    })
     
  }  

  operReconcilePopup() {
    this.dialogConfig.position = { top: '0' };

    this.reconsileService.autoCompletionStatus().subscribe((runsheet: any) => {
      console.log('autoCompletionStatus data comp>> ', runsheet);
    });
  }

  checkRunsheetStatus() {
    this.operReconcilePopup();
  }
}

import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { ColDef } from 'ag-grid-community';
import * as moment from 'moment';
import { LinkRendererComponent } from '../link-renderer/link-renderer.component';
import { CellrenderComponent } from '../services/cellrender/cellrender.component';
import { ReconcileService } from '../services/reconcile.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';

@Component({
  selector: 'app-print-invoices',
  templateUrl: './print-invoices.component.html',
  styleUrls: ['./print-invoices.component.scss'],
  encapsulation: ViewEncapsulation.None,
})

export class PrintInvoicesComponent {
  canWrite: boolean = true
  canDelete: boolean = true
  loadingPermissions: boolean = true;
  constructor(
    private reconcileService: ReconcileService,
    public permission: PermissionsService
  ) {
    this.reconcileService.pageTitleSubject.next('Print Invoices');
    this.getRowData();
    try {
      this.permissionMethod();
      
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  async permissionMethod() {
    try {
      const result = await this.permission.canWrite('InvoicePrint');
      console.log("Result:", result); // Use the result here
      this.canWrite = result
      const result2 = await this.permission.canWrite('DeletePrintedInvoices');
      this.canDelete = result2;
      this.loadingPermissions = false;
    } catch (error) {
      console.error("Error:", error);
    }
  }
  columnFields: ColDef[] = [
    {
      field: '',
      headerName: '',
      cellRenderer: CellrenderComponent,
      cellRendererParams: {
        selectedRow: null,
      },
      // field: '',
      // minWidth: 40,
      // width: 40,
      headerCheckboxSelection: true,
      // checkboxSelection: true,
      // filter: false,
      // sortable: false,
      // pinned: 'left',
    },
    {
      field: 'id',
      headerName: 'Invoice No',
      cellRenderer: (id: any) =>
        `<a style="color:#00aaa6!important" href="reconcile/PrintInvoices/invoiceDetails/${id.value}" >${id.value}</a>`,
    },
    { field: 'customerid', headerName: 'Customer' },
    { field: 'customergroupid', headerName: 'Customer Group' },
    {
      field: 'todate',
      headerName: 'To Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      field: 'issuedate',
      headerName: 'Issue Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    { field: 'baseexgst', headerName: 'Base Ex GST' },
    { field: 'fuellevy', headerName: 'Fuel Levy' },

    { field: 'discountamt', headerName: 'Discount' },

    { field: 'totalexgst', headerName: 'Total Ex GST' },
    { field: 'invoicestatusid', headerName: 'Invoice Status' },

    { field: 'documenttype', headerName: 'Type' },
    {
      field: 'created',
      headerName: 'Created On',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },

      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
  ];
  columnDefs: ColDef[] = this.columnFields;

  public statusList = [
    { name: 'Ready' },
    { name: 'Hold' },
    { name: 'Printed' },
  ];
  public printMenu = [
    { name: 'Include zero value lines', value: 'withzerolines' },
    { name: 'Print with customer format', value: 'withcustomerformat' },
    { name: 'Print creadit notes with format', value: 'creditnotesformat' },
    { name: 'Print invoices with format', value: 'printInvoiceFormat' },
  ];

  public rowData: any[];

  getRowData() {
    this.reconcileService.getPrintInvoices(false).subscribe((result: any) => {
      console.log('result getPrintInvoices > ', result);

      this.rowData = result.invoices;
      console.log('rowdata:', this.rowData);
    });
  }

  getdata() {
    console.log('call');
  }
}

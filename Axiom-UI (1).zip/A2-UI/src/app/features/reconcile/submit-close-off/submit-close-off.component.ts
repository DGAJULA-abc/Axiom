import { Component, ViewEncapsulation } from '@angular/core';
import { ColDef, GridApi } from 'ag-grid-community';
import { ReconcileService } from '../services/reconcile.service';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { GridReadyEvent } from 'ag-grid-community';
import { MessageService } from 'primeng/api';
import * as moment from 'moment';
import { PlanService } from '../../plan/services/plan.service';

@Component({
  selector: 'app-submit-close-off',
  templateUrl: './submit-close-off.component.html',
  styleUrls: ['./submit-close-off.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SubmitCloseOffComponent {
  defaultIWeekEndingDate: Date = new Date();
  closeOffSummary: any[] = [];
  layoutSubscription: Subscription;
  columnApi: any;
  columnState: any;
  applicationOptions: any;
  applicationId: any;
  userName: any;
  selectedSite: any;
  gridOptions: any;
  displayStyle = "none";
  errors: any;
  displayErrors: boolean = false;
  closeOffImmediate: boolean = false;
  private gridApi!: GridApi<any>;
  selectedOptions: any[];
  today: any;
  columnFields: ColDef[] = [
    { field: 'recordCount', headerName: 'Records', width: 100 },
    { field: 'recordType', headerName: 'Type', width: 100 },
    { field: 'totalAmount', headerName: 'Total Amount', width: 100,cellRenderer: this.CurrencyCellRendererUSD }


  ];
  CurrencyCellRendererUSD(params: any) {
    var inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    });
    return inrFormat.format(params.value);
  }
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };

  constructor(public planService: PlanService, private reconsileService: ReconcileService, private messageService: MessageService, public dialogService: DialogService, public navbarService: NavbarService) {
    this.gridOptions = {
      context: { Component: this }
    }
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
      if (shouldSubscribe) {
        let data = this.saveLayout();
        this.dialogService.savaLayout(data);
      }
    });
   // this.getView();
  }

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi
    //this.gridApi = params.api;
   // this.getView();
    this.getLayout();
  }
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.userName = sessionStorage.getItem('username');
      this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
      console.log("site:", this.selectedSite);
      let paramObj :any= {}; 
      paramObj = {
        //"applicationOptionId": this.applicationId ? this.applicationId : null,
        "optionName": "a2v3.reconcile.submit-closeoff.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
      if(this.applicationId && (this.applicationId !== null)) {
        paramObj["applicationOptionId"] = this.applicationId;
      }
      return paramObj;
    }
  }

  getData() {
    console.log("get:", this.defaultIWeekEndingDate);
    const previousMonday = new Date(this.defaultIWeekEndingDate); previousMonday.setDate(this.defaultIWeekEndingDate.getDate() - (this.defaultIWeekEndingDate.getDay() + 6) % 7);
    this.defaultIWeekEndingDate = previousMonday;
    console.log("got:", previousMonday);

    //let today = new Date();
    previousMonday.setHours(0, 0, 0, 0);
    this.reconsileService.closeOffSummary(previousMonday.getTime())
      .subscribe(
        (result: any) => {
          this.closeOffSummary = result.closeOffSummary;
        });
  }
  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.submit-closeoff.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
        })
      }
    })
  }


  getLayout() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.submit-closeoff.layout") {
            this.applicationId = JSON.parse(item["applicationOptionId"]);
            if (this.applicationId) {
              this.columnState = JSON.parse(item["optionValue"]);
              if (this.columnState) {

                if (this.columnState.columns) {
                  this.columnState.columns.forEach((column: any) => {
                    if ("name" in column) {
                      column.colId = column.name;
                      delete column.name
                    }
                  });
                  this.columnState = this.columnState.columns;
                  this.applyLayout();
                }
              }
            }
          }
        });

      }
    })

    // this.applicationOptions.filter((item: any) => {
    //   if (item["optionName"] === "a2v3.plan.service.events.grid.layout")
    //     this.columnState = JSON.parse(item["optionValue"]);
    //   if (this.columnState) {

    //     if (this.columnState.columns) {
    //       this.columnState.columns.forEach((column: any) => {
    //         if ("name" in column) {
    //           column.colId = column.name;
    //           delete column.name
    //         }
    //       });
    //       this.columnState = this.columnState.columns;
    //       this.applyLayout();
    //     }
    //   }
    // })
    //  });
  }

  applyLayout() {
    console.log("now:", this.columnDefs, this.columnFields)
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })
    let sample: any[] = [];
    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    });
    // console.log("fields:",this.columnFields);
    this.selectedOptions = [];
    this.columnFields.filter((column: any) => {
      this.columnState.forEach((element: any) => {
        if (element.visible) {
          if (column.field === element.colId) {
            sample.push(column);
            this.selectedOptions.push(column.field);
          }
        }

      })
    });
    this.columnDefs = sample;
    this.gridApi.setColumnDefs(this.columnDefs);

  }

  ngOnInit() {
    this.today = new Date()
    this.navbarService.usernameSubject.subscribe((username) => {
      this.userName = username;
    });

    this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
    this.userName = sessionStorage.getItem('username');
    console.log("user name:", this.userName, this.selectedSite)
    this.reconsileService.pageTitleSubject.next('Submit Close Off');
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    var now = new Date();
    var daysBack = -6 + (6 - now.getDay());
    this.defaultIWeekEndingDate = new Date(now.getTime() + ((daysBack || -7) * 1000 * 60 * 60 * 24));

    this.getRowData();
  }

  convertDatetoMilliseconds(date: any) {
    return moment(
      moment
        .tz(moment(date).format('YYYY-MM-DD HH:mm:ss'), 'Australia/Melbourne')
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
  }
  convertDatetoMilliseconds2(date: any) {
    return moment(
      moment
        .tz(moment(date).set({
          hour: 14,
          minute: 0,
          second: 0,
        }).format('MM/DD/YYYY HH:mm:ss'), 'Australia/Melbourne')
        .clone()
        .tz('Asia/Kolkata')
    ).valueOf();
  }

  getRowData() {
    let today = new Date();
    today.setHours(0, 0, 0, 0);
    this.reconsileService.closeOffSummary(today.getTime())
      .subscribe(
        (result: any) => {
          this.closeOffSummary = result.closeOffSummary;
        });


  }

  closeOff() {
    this.closeOffImmediate = false;
    this.displayStyle = "block";
  }

  closeOffImmediateClick() {
    this.closeOffImmediate = true;
    this.displayStyle = 'block';
  }

  submitCloseoff() {
    const reqParam = {
      cutOffDate: this.defaultIWeekEndingDate.getTime(),
      weekEndingDate: this.defaultIWeekEndingDate.getTime()
    }
    this.reconsileService.closeOff(reqParam, this.closeOffImmediate)
      .subscribe(
        (result: any) => {
          this.errors = result.errors;
          this.displayErrors = result.displayErrors;
          this.displayStyle = "none";
          if (this.displayErrors === true) {
            this.messageService.add({
              severity: 'error',
              summary: '',
              detail: this.closeOffImmediate ? 'Immediate close off falied.' : 'Close off failed.',
            });
          }
        });
  }

  cancel() {
    this.displayStyle = "none";
  }

  clearFilters() {
    this.columnFields.forEach(element => {
      this.gridApi.destroyFilter(element.field!);
    });

  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.columnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
}

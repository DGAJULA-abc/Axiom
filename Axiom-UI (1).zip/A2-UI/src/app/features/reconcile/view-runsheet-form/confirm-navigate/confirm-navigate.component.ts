import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-confirm-navigate',
  templateUrl: './confirm-navigate.component.html',
  styleUrls: ['./confirm-navigate.component.scss']
})
export class ConfirmNavigateComponent {
  constructor(public dialogRef: MatDialogRef<ConfirmNavigateComponent>) {}
  onDiscard(): void {
    this.dialogRef.close('discard');
  }

  onSave(): void {
    this.dialogRef.close('save');
  }

  onCancel(): void {
    this.dialogRef.close('cancel');
  }
}

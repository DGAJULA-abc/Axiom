import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmNavigateComponent } from './confirm-navigate.component';

describe('ConfirmNavigateComponent', () => {
  let component: ConfirmNavigateComponent;
  let fixture: ComponentFixture<ConfirmNavigateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmNavigateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConfirmNavigateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

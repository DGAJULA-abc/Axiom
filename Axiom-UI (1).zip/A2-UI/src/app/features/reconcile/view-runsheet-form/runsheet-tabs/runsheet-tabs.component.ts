import { ChangeDetectorRef, Component, Input ,OnChanges,OnDestroy, SimpleChanges } from '@angular/core';
import { ReconcileService } from '../../services/reconcile.service';
import { ActivatedRoute } from '@angular/router';
import { CellrenderComponent } from '../../list-incomplete-services/cellrender/cellrender.component';
import { FormGroup, FormGroupDirective } from '@angular/forms';
import { ColDef , GridApi, GridOptions} from 'ag-grid-community';
import { Observable, Subscription } from 'rxjs';
import { RunsheetFormService } from '../../services/runsheet-form.service';
import {
  ErrorList,
  ExceptionInfo,
  Runsheet,
  RunsheetConfig,
  RunsheetLine,
} from '../ViewRunsheetId.model';
import * as _ from 'lodash';
import { MessageService } from 'primeng/api';
import { add } from 'ngx-bootstrap/chronos';
import { BehaviorSubject } from 'rxjs';
import * as moment from 'moment';
import { tripRow } from '../runsheet-form.model';
import { RunsheetLineDetailService } from '../../detail/runsheet-line-detail/runsheet-line-detail.service';
import { RunsheetService } from '../../services/runsheet.service';
import { AnyKindOfDictionary } from 'lodash';
import { AddServiceByService } from '../../detail/add-services-by/add-service-by.service';
import { PlanService } from 'src/app/features/plan/services/plan.service';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { DetailService } from '../../detail/detail.service';

@Component({
  selector: 'app-runsheet-tabs',
  templateUrl: './runsheet-tabs.component.html',
  styleUrls: ['./runsheet-tabs.component.scss'],
})
export class RunsheetTabsComponent implements OnDestroy, OnChanges {
  tabData: any[] = [];
  runsheetRowData: any[] = [];
  tabHeaderData: any[] = [];
  runsheetLinesRow: any[] = [];
  driverBreaks: any[] = [];
  documentInvoiceLines: any[] = [];
  documentPayAdviceLines: any[] = [];
  adjistmentRow: any[] = [];
  private gridApi!: GridApi<any>;
  gridOptions: any;
  subscription: Subscription;
  form: FormGroup;
  serviceFormReceivedData: any = {};

  runsheetLength: any;
  driverBreaksLength: any;
  payAdviceLength: any;
  documentInvoiceLinesLength: any;
  adjistmentRowLength: any;

  enableForm: boolean = false;
  runsheetIdRemove: any;
  runsheetLineServiceId: any;

  selectedRow: any;
  public gridDataSubject = new BehaviorSubject<any[]>(this.runsheetLinesRow);
  gridData$ = this.gridDataSubject.asObservable();
  disabledAction: boolean = false;
  tripLength: any;
  multipleRowSelecetedMoretwo: any;

  runsheetId: any = '';
  runsheetLineIdUnique: any = null;
  breakIdUnique:any=null;

  runsheetState: RunsheetConfig = {
    runsheetTypeId: null,
    displayLookupButton: false,
    displayNextRunsheetButton: false,
    deliveryDateStamp: null,
    enddateStamp: null,
    shiftId: null,
    showLookup: false,
    showGrid: false,
    showTime: false,
    StartEndKMSwappedCondition: false,
    completed: false,
    formEnabled: false,
    locked: false,
  };

  columnDefs: any[] = [
    {
      field: 'id',
      headerName: 'CheckBox',
      // cellRenderer: CellrenderComponent,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: 'agNumberColumnFilter',
      maxWidth: 50,
      floatingFilter: false,
      cellRenderer: (params: any) => {
        return ''
      },
    },
    // // {
    // //   field: 'id',
    // //   headerName: 'Runsheet Id',
    // //   // cellRenderer: CellrenderComponent,
    // //   headerCheckboxSelection: true,
    // //   checkboxSelection: true,
    // //   filter: 'agNumberColumnFilter',
    // //   minWidth: 150,
    // // },
    // { field: 'tripseq', headerName: 'Seq', minWidth: 150 },
    { field: 'seqDisplay', headerName: 'Seq', minWidth: 150 },

    
    {
      field: 'lineServiceTO.serviceGroup',
      headerName: 'Service Group',
      minWidth: 150,
    },
    // { field: 'tripname', headerName: 'Seq', minWidth: 150 },
    { field: 'lineServiceTO.loadNo', headerName: 'Load No', minWidth: 150 },
    { field: 'loadTypeId', headerName: 'Load Type', minWidth: 150 },
    { field: 'lineServiceTO.tripIdCust', headerName: 'Trip', minWidth: 150 },
    { field: 'serviceTypeId', headerName: 'Service Type', minWidth: 150 },
    { field: 'locationPickupId', headerName: 'From', minWidth: 150 },
    { field: 'locationDropId', headerName: 'To', minWidth: 150 },
    { field: 'lineServiceTO.complete', headerName: 'Complete', minWidth: 150 },
    { field: 'locationReturnId', headerName: 'Return To', minWidth: 150 },
    {
      field: 'lineServiceTO.chargeAmt',
      headerName: 'Charge Amount',
      minWidth: 150,
    },
    { field: 'payamt', headerName: 'Pay Amount', minWidth: 150 },
    {
      field: 'lineServiceTO.serviceNo',
      headerName: 'Service No.',
      minWidth: 150,
    },
    { field: 'docket', headerName: 'Docket', minWidth: 150 },
    { field: 'containerId', headerName: 'Container', minWidth: 150 },
    { field: 'truckId', headerName: 'Truck', minWidth: 150 },
    { field: 'trailerId', headerName: 'Trailer', minWidth: 150 },
    { field: 'trailerTagId', headerName: 'Trailer Tag', minWidth: 150 },
    { field: 'truck.fleetNumber', headerName: 'Fleet No.', minWidth: 150 },
   {
      field: 'lineServiceTO.customerId',
      headerName: 'Customer Id',
      minWidth: 150,
    },
    {
      field: 'lineServiceTO.customerSite',
      headerName: 'Customer Site',
      minWidth: 150,
    },
    {
      field: 'lineServiceTO.pickupLocation.locationDesc',
      headerName: 'Pickup Location Desc',
      minWidth: 300,
    },
    {
      field: 'lineServiceTO.dropLocation.locationDesc',
      headerName: 'Drop Loaction Desc',
      minWidth: 300,
    },
    { field: 'truck.truckTypeId', headerName: 'Truck Type', minWidth: 150 },
    { field: 'lineServiceTO.batchNo', headerName: 'Batch No.', minWidth: 150 },
    { field: 'lineServiceTO.custRef', headerName: 'Cust Ref.', minWidth: 150 },
    {
      field: 'lineServiceTO.loadLocation.locationId',
      headerName: 'Load Location ',
      minWidth: 200,
    },
    {
      field: 'lineServiceTO.loadLocation.locationDesc',
      headerName: 'Load Location Desc',
      minWidth: 300,
    },
    {
      field: 'lineServiceTO.dropLocation.zoneChargeId',
      headerName: 'Charge zone Drop',
      minWidth: 150,
    },
    {
      field: 'lineServiceTO.dropLocation.zonePayId',
      headerName: 'Pay Zone Drop',
      minWidth: 150,
    },
    {
      field: 'lineServiceTO.pickupLocation.zoneChargeId',
      headerName: 'Charge zone Pickup',
      minWidth: 150,
    },
    {
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      minWidth: 150,
    },
    {
      field: 'lineServiceTO.vesselId',
      headerName: 'Vessel No.',
      minWidth: 150,
    },
    { field: 'createdby', headerName: 'Created by', minWidth: 150 },
    {
      field: 'fuelLevyInfo.fuelLevyCharge',
      headerName: 'Fule Levy Charge',
      minWidth: 150,
    },
    {
      field: 'fuelLevyInfo.fuelLevyPay',
      headerName: 'Fule Levy Pay',
      minWidth: 150,
    },

    { field: 'qty1', headerName: 'Qty.1', minWidth: 150 },
    { field: 'qty2', headerName: 'Qty.2', minWidth: 150 },
    { field: 'qty3', headerName: 'Qty.3', minWidth: 150 },
    { field: 'qty4', headerName: 'Qty.4', minWidth: 150 },
    { field: 'qty5', headerName: 'Qty.5', minWidth: 150 },
    { field: 'qty6', headerName: 'Qty.6', minWidth: 150 },
    { field: 'qty7', headerName: 'Qty.7', minWidth: 150 },
    { field: 'qty8', headerName: 'Qty.8', minWidth: 150 },
  ];

  bulkEditMode: any = false;

  columnTrips: any[] = [
    {
      field: 'id',
      headerName: 'Runsheet Id',
      cellRenderer: CellrenderComponent,
      filter: 'agNumberColumnFilter',
      minWidth: 150,
    },
    // {
    //   field: 'id',
    //   headerName: 'Runsheet Id',
    //   // cellRenderer: CellrenderComponent,
    //   headerCheckboxSelection: true,
    //   checkboxSelection: true,
    //   filter: 'agNumberColumnFilter',
    //   minWidth: 150,
    // },
    { field: 'tripseq', headerName: 'Seq', minWidth: 150 },
    { field: 'tripno', headerName: 'Trip', minWidth: 150 },
    { field: 'truckId', headerName: 'Truck', minWidth: 150 },
    { field: 'trailerId', headerName: 'Trailer', minWidth: 150 },
    { field: 'locationReturnId', headerName: 'Return To', minWidth: 150 },
    { field: 'tripstarttime', headerName: 'Trip start time', minWidth: 150 },
    { field: 'tripendtime', headerName: 'Trip end time', minWidth: 150 },

    { field: 'trailerTagId', headerName: 'Trailer Tag', minWidth: 150 },
    { field: 'hiretruck', headerName: 'Truck Hire', minWidth: 150 },
    { field: 'owntrailer', headerName: 'Own Trailer', minWidth: 150 },
    { field: 'offsiderused', headerName: 'Off sider used', minWidth: 50 },
    { field: 'tripOdoEnd', headerName: 'Trip Odo End', minWidth: 150 },
    { field: 'tripOdoStart', headerName: 'Trip Odo Start', minWidth: 150 },
  ];

  transformRunsheetGlobal: any = [];
  totalTrips = 0;
  /**
   * modify rsl data for display and manipulation
   * - extra elements are added to represent trips
   * @param  {Array} originalRunsheetLinesArray original rsl array. Assume it to have been 'refreshed' (refreshRunsheetLines)
   * @return {Array}               transformed runsheetLines
   */
  arrayOfObjects: any[] = [];
  private transformRunsheetLines(originalRunsheetLinesArray: any[]): any[] {
    // let totalTrips = 0;
    originalRunsheetLinesArray
      .sort(function (a, b) {
        return (
          a.tripno - b.tripno ||
          a.tripseq - b.tripseq ||
          a.groupseq - b.groupseq
        );
      })
      .reduce((transformRunsheet, runsheetLine, index, array) => {
        var previousTripno = index ? array[index - 1].tripno : 0; // look back to previous item, if any, and get trip no
        if (runsheetLine.tripno > previousTripno) {
          // has the trip number incremented?
          let tripRow: any = {
            // if so, we insert add a trip before the next rsl
            isTrip: true,
            tripno: runsheetLine.tripno,
            tripseq: 0, //runsheetLine.tripno + '.' + runsheetLine.tripseq,
            //tripname: 'Trip' + runsheetLine.tripno,
            id: 'trip' + runsheetLine.tripno, 
            firstRunsheetLine: runsheetLine, // stash a reference to the first runsheetline fo the trip, this will come in handy for the trip detail
          };
          // tripRow.seqDisplay = RunsheetLineService.getDisplaySeq(tripRow);
          // let tripRunsheetLIne = {...tripRow, ...runsheetLine}
          tripRow.seqDisplay = this.getDisplaySeq(tripRow);
          runsheetLine.seqDisplay = this.getDisplaySeq(runsheetLine);
          // tripRow.tripseq = this.getDisplaySeq(tripRow);
          // runsheetLine.tripseq = runsheetLine.tripno + '.' + runsheetLine.tripseq
          transformRunsheet.push(tripRow);
          this.totalTrips++;
        } 
        // else {
        //   runsheetLine.tripseq = runsheetLine.tripno + '.' + runsheetLine.tripseq
        // }
         else {
          runsheetLine.seqDisplay = this.getDisplaySeq(runsheetLine);
        }
        // runsheetLine.truck = RefDataService.get('trucks', runsheetLine.truckId);
        runsheetLine.truckId = runsheetLine.truckId;
      transformRunsheet.push(runsheetLine);
        this.transformRunsheetGlobal = transformRunsheet;
        return this.transformRunsheetGlobal;
      }, []);
    console.log(
      'this.transformRunsheetGlobal >> ',
      this.transformRunsheetGlobal
    );

    return this.transformRunsheetGlobal;
  }

  canConsolidateSelection: any;
  canDeconsolidateSelection: any;

  updateButtonStates() {
    this.canConsolidateSelection = this.canConsolidate(this.selectedRow);
    this.canDeconsolidateSelection = this.canDeconsolidate(this.selectedRow);
  }

  refresh() {
    //https://github.com/angular-ui/ui-grid/issues/1302
    //for grid not displayed properly
    setTimeout(() => {
      const data = this.transformRunsheetLines(this.transformRunsheetGlobal);
      const totalServices = data.length - this.totalTrips;
      this.updateButtonStates();
      // if selectedItem is a trip, update the selectedItem to the newly generated trip that matches
      if ((this.selectedRow || {}).isTrip) {
        var selectedTrip = this.transformRunsheetGlobal.reduce(
          (result: any, item: any) => {
            return item.isTrip &&
              item.firstRunsheetLine === this.selectedRow.firstRunsheetLine
              ? item
              : result;
          },
          null
        );
        // scope.$emit('a2v3.reconcile.runsheet.select', selectedTrip, 'trip');
      }
    }, 200);
  }

  consolidateSelection() {
   const consoldateData = this.consolidateRunsheetLines(this.multipleRowSeleceted, this.runsheetLinesRow);
    // this.refresh();
  this.transformRunsheetGlobal = this.updateConsolidatedRows(this.transformRunsheetGlobal, consoldateData);
  console.log("transform >>", this.transformRunsheetGlobal)
  this.gridOptions.api!.applyTransaction({ update: consoldateData });
  this.runsheetLineService.gridDataArrayServiceDetail = this.gridOptions.rowData;  
  }

  deconsolidateSelection() {
    const deConsoldateData = this.deconsolidateRunsheetLines(this.multipleRowSeleceted, this.runsheetLinesRow);
    // this.refresh();
    this.transformRunsheetGlobal = this.updateConsolidatedRows(this.transformRunsheetGlobal, deConsoldateData);
    console.log("transform >>", this.transformRunsheetGlobal)
    this.gridOptions.api!.applyTransaction({ update: deConsoldateData });
    this.runsheetLineService.gridDataArrayServiceDetail = this.gridOptions.rowData; 
  }

   updateConsolidatedRows(allRows: any, modifiedRows: any) {
    for (let i = 0; i < allRows.length; i++) {
      for (let j = 0; j < modifiedRows.length; j++) {
        if (allRows[i].id === modifiedRows[j].id) {
          allRows.splice(i, 1, modifiedRows[j]);
        }
      }
    }
    return allRows;
  }

  /**
   * Fro Breaks we need an different columnDefs
   */
  columnDefsBreaks: any[] = [
    {
      field: 'id',
      headerName: '#',
      filter: 'agNumberColumnFilter',
      minWidth: 150,
    },
    // {
    //   field: 'id',
    //   headerName: 'Runsheet Id',
    //   // cellRenderer: CellrenderComponent,
    //   headerCheckboxSelection: true,
    //   checkboxSelection: true,
    //   filter: 'agNumberColumnFilter',
    //   minWidth: 150,
    // },
    { field: 'locationId', headerName: 'Location', minWidth: 150 },
    { field: 'breakTypeId', headerName: 'Type', minWidth: 150 },
    {
      field: 'breakstarttime',
      headerName: 'Start date/time',
      minWidth: 150,
      cellRenderer: (data: any) => {
        if (data.value) {
          return moment(data.value).format('DD/MM/YYYY HH:mm:ss');
        } else {
          return '';
        }
      },
    },
    {
      field: 'breakendtime',
      headerName: 'End date/time',
      minWidth: 150,
      cellRenderer: (data: any) => {
        if (data.value) {
          return moment(data.value).format('DD/MM/YYYY HH:mm:ss');
        } else {
          return '';
        }
      },
    },
    { field: 'serviceTypeId', headerName: 'Break duration', minWidth: 150 },
    { field: 'commentA', headerName: 'Comments', minWidth: 150 },
  ];
  /**
   * Here field name of headerType = '#' should be check 
   * Not sure about it
   */
  columnAdjustment: any[] = [
    {
      field: '#',
      headerName: '#',
      filter: 'agNumberColumnFilter',
      minWidth: 150,
      cellRenderer: CellrenderComponent,
      cellRendererParams: {
        selectedRow: null,
      },
    },
    { field: 'adjustmentTypeId', headerName: 'Adjustment Type', minWidth: 150 },
    {
      field: 'effectivedate',
      headerName: 'Effective Date',
      minWidth: 150,
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
    },
    { field: 'serviceno', headerName: 'Service', minWidth: 150 },
    { field: 'payamt', headerName: 'Amount', minWidth: 150 },
    { field: 'fuellevyamt', headerName: 'Fuel Levy', minWidth: 150 },
    { field: 'linetext', headerName: 'Remarks', minWidth: 150 },
  ];

  payAdviceLinesColumnDefs: any[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'id',
      headerName: 'Pay Advice Id',
      filter: 'agNumberColumnFilter',
      minWidth: 150,
      cellRenderer: (id: any) =>
        `<a style="color:#00aaa6!important" href="reconcile/PrintPayAdvices/invoiceDetails/${id.value}" >${id.value}</a>`,
    },
    { field: 'companyId', headerName: 'Company Id', minWidth: 150 },
    {
      field: 'issueDate',
      headerName: 'Issue Date',
      minWidth: 150,
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
    },

    { field: 'exported', headerName: 'Exported', minWidth: 150 },
    {
      field: 'paFormat',
      headerName: 'Print',
      filter: 'agNumberColumnFilter',
      minWidth: 150,
    },
  ];

  invoiceLinesColumnDefs: any[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'id',
      headerName: 'Invoice ID',
      filter: 'agNumberColumnFilter',
      minWidth: 150,
      cellRenderer: (id: any) =>
        `<a style="color:#00aaa6!important" href="reconcile/PrintInvoices/invoiceDetails/${id.value}" >${id.value}</a>`,
    },
    { field: 'customerid', headerName: 'Customer Id', minWidth: 150 },
    {
      field: 'issuedate',
      headerName: 'Issue Date',
      minWidth: 150,
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
    },
    {
      field: 'exported',
      headerName: 'Exported',
      filter: 'agNumberColumnFilter',
      minWidth: 150,
    },
    {
      field: 'paFormat',
      headerName: 'Print',
      filter: 'agNumberColumnFilter',
      minWidth: 150,
    },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 150,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  newText: any;
  obsServiceDetail$: Observable<any>;
  formChangesSubscription: Subscription;
  formChangesTripSubscription: Subscription;
  runsheetLookApidata: any[] = [];

  constructor(
    public planService: PlanService,
    private reconsileService: ReconcileService,
    private runsheetFormService: RunsheetFormService,
    private activatedRoute: ActivatedRoute,
    private rootFormGroup: FormGroupDirective,
    public navbarService: NavbarService,
    private messageService: MessageService,
    private runsheetLineService: RunsheetLineDetailService,
    private runsheetService: RunsheetService,
    private addServiceByService: AddServiceByService,
    public dialogService: DialogService,
    private detailService: DetailService,

  ) {
    this.gridOptions = {
      context: { Component: this }
    }    
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
      if (shouldSubscribe) {
        let data = this.saveLayout();
        console.log("create:", data)
        this.dialogService.savaLayout(data);
      }
    })
    //this.getView();
  }
  selectedsite:any;
  runsheetAPiParent: any;

  ngOnChanges() {
    
   }

  ngOnInit() {
    this.selectedsite = parseInt(sessionStorage.getItem('selectedSiteId')!);

    this.formChangesSubscription =
      this.runsheetFormService.formChanges$.subscribe((data) => {
        // Use the form changes data as needed
        console.log("multipleRowSeleceted >>", this.multipleRowSeleceted );
        
        console.log('service tab data', data);
        if (this.runsheetLineIdUnique) {
          if(this.multipleRowSeleceted.length > 1) {
             this.updateMultipleRunsheeTLineOnChange(data);
          } else {
            this.updateRunsheeTLineOnChangeServiceType(data);
          }
        } else {
          this.addRunsheeTLineOnChangeServiceType(data);
        }
      });
      //adding for Break - Palak
      this.runsheetFormService.formChangesbreak$.subscribe((data) => {
        if (this.breakIdUnique) {
        
            this.updateBreakOnChange(data);
        } else {
          this.addBreakOnChange(data);
        }
      });

      this.formChangesTripSubscription = 
      this.runsheetFormService.tripFormChangesOnGrid$.subscribe((row) => {
        console.log("trip form change", row);
        console.log("all rows data",this.gridOptions.rowData);
      //  const tripComnined = this.gridOptions.rowData.map((item: any) => {
      //     if (item.hasOwnProperty("truckId")) {
      //       return { ...item, truckId: 3 };
      //     }
      //     return item;
      //   });
        const itemsToUpdate: any[] = [];
        let selectedNode: any = null;
        this.gridOptions.api!.forEachNodeAfterFilterAndSort(
          (rowNode: any, index: any) => {
            // const selectedNodeTripNo = this.gridOptions.rowData.filter((item: any) => item.tripno === rowNode.selected && rowNode.tripno);
            if (rowNode.selected) {
              selectedNode = rowNode.data.tripno;
            }
            console.log(selectedNode, rowNode.data.tripno)
            if(selectedNode && selectedNode === rowNode.data.tripno) {
              if (!rowNode.data.hasOwnProperty(row.lName)) {
                return;
              }
              let data = rowNode.data;
              // data[row.lName] = row[row.lValue];
              // data.loadTypeId = row.loadTypeId;
              data = this.lineObjMapping(data, row);
              itemsToUpdate.push(data);
             }
            
          }
        );
        console.log("tripComnined >>", itemsToUpdate);
        this.gridOptions.api!.applyTransaction({ update: itemsToUpdate });
        this.runsheetLineService.gridDataArrayServiceDetail = this.gridOptions.rowData;
        console.log("gridDataArrayServiceDetail 1", this.runsheetLineService.gridDataArrayServiceDetail);

        // Use the form changes data as needed
        // console.log('service tab data', data);
        // if (this.runsheetLineIdUnique) {
        //   this.updateRunsheeTLineOnChangeServiceType(data);
        // } else {
        //   this.addRunsheeTLineOnChangeServiceType(data);
        // }
      });
      
      
      this.runsheetFormService.runseetSubsCribeData$.subscribe((runsheetSubscribe: any) => {
        console.log("getRowReconcileData", runsheetSubscribe);
        // this.getRowReconcileData(this.runs);
        // this.gridOptions
        this.runsheetLinesRow = runsheetSubscribe?.runsheetLines;
        this.transformRunsheetLines(
          runsheetSubscribe?.runsheetLines
        );
        this.bulkEditMode = false;

        this.driverBreaks = runsheetSubscribe?.driverBreaks;
        if( this.driverBreaks!=undefined){

          this.breakIdUnique = this.driverBreaks[this.driverBreaks.length-1].id
        }
        else{
          this.driverBreaks=[];
        }
      })
      // this.runsheetAPiParent = this.detailService?.runseetReasonApidata; 
      // this.transformRunsheetLines(this.runsheetAPiParent);
      // this.bulkEditMode=false;
      // this.driverBreaks = this.runsheetAPiParent?.driverBreaks;
      // if( this.driverBreaks!=undefined){

      //   this.breakIdUnique = this.driverBreaks[this.driverBreaks.length-1].id
      // }
      // else{
      //   this.driverBreaks=[];
      // }
      
    // console.log("data:",this.transformRunsheetGlobal,this.transformRunsheetLines)
    // this.subscription = this.runsheetFormService.runsheetLinesObj.subscribe(obj=>{
    //   let runsheetObj = obj;
    //   this.transformRunsheetGlobal.push(obj[0]);
    //   //this.cdr.markForCheck();
    //   console.log("runshheet obj:", runsheetObj)
    //   console.log("already data:", this.transformRunsheetGlobal)
    //   this.runsheetFormService.runsheetLinesData.next(this.transformRunsheetGlobal);
    // })

    this.obsServiceDetail$ = this.runsheetFormService.formData$;
    console.log('Runsheet tab line form', this.obsServiceDetail$);
    this.runsheetFormService.formData$.subscribe((data: any) => {
      console.log('Form tab data', data);
    });

    this.gridOptions = {
      context: { Component: this },
    };
    this.runsheetId =
      this.activatedRoute.snapshot.queryParamMap.get('runsheetId');
    this.getTabRender();
    this.getRowDataReconsileSheet(this.runsheetId);

    // update ROw data though form

    //  this.subscription = this.runsheetFormService.formData$.subscribe((data) => {
    //   this.serviceFormReceivedData = data.value;
    //   const tempObj = {
    //     "id" : 111,
    //     "tripseq": 5
    //   }
    //   console.log("service data, serviceFormReceivedData:", this.serviceFormReceivedData)
    //   this.runsheetLinesRow.push(tempObj);
    //  });
    this.getMultiLegData();
  }
  //adding for break - Palak
  gridOptionsBreak: GridOptions = {
    columnDefs: this.columnDefsBreaks
  };
  count:number=-1
  addBreakOnChange(data:any){
    let lastRow = null;
    const createNewRL = this.runsheetLineService.createTempId();
    this.count+=1;
    lastRow = this.count;
   
    
    const newBreakNode = {
      id: lastRow,
      locationId: data.lName === 'locationId' ? data.lValue : null,
      breakTypeId: data.lName === 'breakTypeId' ? data.lValue : null,
      breakstarttime: data.lName === 'breakstarttime' ? data.lValue : null,
      breakendtime: data.lName === 'breakendtime' ? data.lValue : null,
      serviceTypeId: data.lName === 'serviceTypeId' ? data.lValue : null,
      commentA: data.lName === 'commentA' ? data.lValue : null
  };
  if(this.count!=0){

    this.driverBreaks.push(newBreakNode)
    this.gridOptionsBreak.api!.applyTransaction({
      add: [newBreakNode],
    });
  }
  this.breakIdUnique=newBreakNode.id
  console.log(this.gridOptionsBreak.rowData)
  //for saving - Palak
  if (this.gridOptionsBreak.rowData!.length > 0) {
    this.runsheetLineService.gridDataArrayBreakDetail = this.gridOptionsBreak.rowData;

  }

    
  }
  updateBreakOnChange(row:any){
    const itemsToUpdate: any[] = [];
    this.gridOptionsBreak.api!.forEachNodeAfterFilterAndSort(
      (rowNode: any, index: any) => {
        if (rowNode?.data?.id !== this.breakIdUnique) {
          return;
        }
        let data = rowNode.data;
        // data[row.lName] = row[row.lValue];
        // data.loadTypeId = row.loadTypeId;
        data = this.lineObjMappingBreak(data, row);
        itemsToUpdate.push(data);
      }
    );
    this.gridOptionsBreak.api!.applyTransaction({ update: itemsToUpdate });
    
  }

   addRunsheeTLineOnChangeServiceType(data: any) {
    // console.log("add trip data in grid >>", this.transformRunsheetGlobal);
    
    console.log('lastTripRow > ',this.gridOptions.rowData, this.transformRunsheetGlobal, this.gridOptions.api.getDisplayedRowCount());
    let lastRow = null;
    let lastRowLength = null;
    const tripNo = this.transformRunsheetGlobal.filter((item: any) => item.isTrip).length || 1;
    const lastTripRow = this.gridOptions.rowData.length > 0 ? this.gridOptions.rowData[this.gridOptions.rowData.length - 1]: this.gridOptions.rowData[this.gridOptions.rowData.length];
    const lastTripNoRowsCount = this.gridOptions.rowData.length > 0 ? this.gridOptions.rowData.filter((item: any) => item.tripno === lastTripRow.tripno && !item.isTrip).length + 1: 1;
    const createNewRL = this.runsheetLineService.createTempId();
    console.log("trip Check >>",tripNo, lastTripNoRowsCount, lastTripRow)
    if (this.gridOptions.rowData?.length === 1) {
      lastRow = this.gridOptions.rowData[0];
    }
    if (this.gridOptions.rowData?.length > 1) {
      lastRow = this.gridOptions.rowData[this.gridOptions.rowData.length - 1];
    }

    const newNode = 
    {
      id: createNewRL,
      lineServiceTO: {
          svcReasonLines: [],
          loadNo: null,
          loadId: null,
          loadTypeId: data.loadTypeId,
          locationPickupId: data.locationPickupId,
          locationDropId: data.locationDropId,
          locationReturnId: data.locationReturnId,
          // originSite: this.navbarService.selectedSiteId,
          originSite: this.selectedsite,

          // destinationSite: this.navbarService.selectedSiteId,
          destinationSite:this.selectedsite,

          customerId: null,
          pickupLocation: {
            locationDesc: null,
            zoneChargeId: null,
            zonePayId: null
        },          // pickupLocation: data?.lValue?.pickupLocation || {
          //     locationDesc: null,
          //     zoneChargeId: null,
          //     zonePayId: null
          // },
          dropLocation: {
              locationDesc: null,
              zoneChargeId: null,
              zonePayId: null
          },
          loadLocation: {
              locationId: null,
              locationDesc: null
          }
      },
      trailerId: null,
      tripno: tripNo, // lastRow?.tripno || 1,
     // tripname: `${lastRow?.tripno || 1}.${this.gridOptions.rowData.length + 1}`,
      truckId: null,
      serviceTypeId: data.lValue,
      qty1: null,
      qty2: null,
      qty3: null,
      qty4: null,
      qty5: null,
      qty6: null,
      qty7: null,
      qty8: null,
      events: [],
      unit1: null,
      unit2: null,
      unit3: null,
      unit4: null,
      unit5: null,
      unit6: null,
      unit7: null,
      unit8: null,
      docket: null,
      dropdoctime: null,
      dropreadytime: null,
      pickupdoctime: null,
      pickupreadytime: null,
      lineTemperature: null,
      hiretruck: false,
      owntrailer: false,
      offsiderused: false,
      seqDisplay: `${tripNo}.${lastTripNoRowsCount}`,
      tripseq: parseInt(lastTripNoRowsCount), //    `${tripNo}.${lastTripNoRowsCount}`,// lastRow?.tripseq + 1 || 1,
      deliverydate: 1690812000000,
      // siteId: this.navbarService.selectedSiteId,
      siteId: this.selectedsite,
      directfromdepot: false,
      payestimated: false,
  }
    if (this.gridOptions.rowData.length > 0) {
      this.transformRunsheetGlobal.push(newNode);
      this.gridOptions.api!.applyTransaction({
        add: [newNode],
      });
      console.log('add', add)
      // this.gridOptions
      //   .api!.getDisplayedRowAtIndex(this.gridOptions.api.getDisplayedRowCount() - 1)
      //   .setSelected(true);
      console.log("this.gridOptions.rowData new", this.gridOptions.rowData);
      this.runsheetLineService.gridDataArrayServiceDetail = this.gridOptions.rowData;
      console.log("gridDataArrayServiceDetail 2", this.runsheetLineService.gridDataArrayServiceDetail);
    } else {
      this.transformRunsheetGlobal.push(newNode);
      this.gridOptions.api!.applyTransaction({
        add: [{seqDisplay: `Trip ${lastRow?.tripno || 1}`, isTrip: true}, newNode],
      });
      // this.gridOptions
      // .api!.getDisplayedRowAtIndex(this.gridOptions.api.getDisplayedRowCount() - 1)
      // .setSelected(true);
    }
    this.gridOptions
    .api!.getDisplayedRowAtIndex(this.gridOptions.api.getDisplayedRowCount() - 1)
    .setSelected(true);
  }

  updatedrowdata:any[]=[];

  updateRunsheeTLineOnChangeServiceType(row: any) {
    const itemsToUpdate: any[] = [];
    this.gridOptions.api!.forEachNodeAfterFilterAndSort(
      (rowNode: any, index: any) => {
        if (rowNode?.data?.id !== this.runsheetLineIdUnique) {
          return;
        }
        let data = rowNode.data;
        // data[row.lName] = row[row.lValue];
        // data.loadTypeId = row.loadTypeId;
        data = this.lineObjMapping(data, row);
        itemsToUpdate.push(data);
      }
    );
    this.gridOptions.api!.applyTransaction({ update: itemsToUpdate });

    this.runsheetLineService.gridDataArrayServiceDetail = this.gridOptions.rowData;
    console.log("gridDataArrayServiceDetail 3", this.runsheetLineService.gridDataArrayServiceDetail);

    console.log("this.gridOptions.rowData Updatae", this.gridOptions.rowData);
    this.updatedrowdata=this.gridOptions.rowData;
    if(this.updatedrowdata.length>0){
      this.runsheetLength=this.updatedrowdata.length;
    }
    
    this.updatedrowdata.forEach((data:any)=>{
      if (data.qty1 !=null) {
        const qty1Parts = data.qty1.split(' ');
        // if (r.qty1.length >= 2) {
          this.qty1data = parseFloat(qty1Parts[0]); 
          this.unit1data = qty1Parts.slice(1).join(' '); 
      }
      if (data.qty2 !=null) {
        const qty2Parts = data.qty2.split(' ');
          this.qty2data = parseFloat(qty2Parts[0]); 
          this.unit2data = qty2Parts.slice(1).join(' '); 
      }
      if (data.qty3 !=null) {
        const qty3Parts = data.qty3.split(' ');
          this.qty3data = parseFloat(qty3Parts[0]); 
          this.unit3data = qty3Parts.slice(1).join(' '); 
      }
      if (data.qty4 !=null) {
        const qty4Parts = data.qty4.split(' ');
          this.qty4data = parseFloat(qty4Parts[0]); 
          this.unit4data = qty4Parts.slice(1).join(' '); 
      }
      if (data.qty5 !=null) {
        const qty5Parts = data.qty5.split(' ');
          this.qty5data = parseFloat(qty5Parts[0]); 
          this.unit5data = qty5Parts.slice(1).join(' '); 
      }
      if (data.qty6 !=null) {
        const qty6Parts = data.qty6.split(' ');
          this.qty6data = parseFloat(qty6Parts[0]); 
          this.unit6data = qty6Parts.slice(1).join(' '); 
      }
      if (data.qty7 !=null) {
        const qty7Parts = data.qty7.split(' ');
          this.qty7data = parseFloat(qty7Parts[0]); 
          this.unit7data = qty7Parts.slice(1).join(' '); 
      }
      if (data.qty8 !=null) {
        const qty8Parts = data.qty8.split(' ');
          this.qty8data = parseFloat(qty8Parts[0]); 
          this.unit8data = qty8Parts.slice(1).join(' '); 
      }
    })
  }


  updateMultipleRunsheeTLineOnChange(row: any) {
    const itemsToUpdate: any[] = [];
    console.log("multipleRowSeleceted sdf",  this.multipleRowSeleceted);
    this.gridOptions.api!.forEachNodeAfterFilterAndSort(
      (rowNode: any, index: any) => {
        if(rowNode.selected) {
          if (!rowNode.data.hasOwnProperty(row.lName)) {
            return;
          }
          let data = rowNode.data;
          // data[row.lName] = row[row.lValue];
          // data.loadTypeId = row.loadTypeId;
          data = this.lineObjMapping(data, row);
          itemsToUpdate.push(data);
        }
       
      }
    );
    console.log("tripComnined >>", itemsToUpdate);
    this.gridOptions.api!.applyTransaction({ update: itemsToUpdate });
    this.runsheetLineService.gridDataArrayServiceDetail = this.gridOptions.rowData;
    console.log("gridDataArrayServiceDetail 4", this.runsheetLineService.gridDataArrayServiceDetail);
  }

  // updateGridData(selectedDropdown: any) {
  //   console.log("this.gridOptions >> ", this.gridOptions);
  //   let itemsToUpdate: any = [];
  //   this.gridOptions.api!.forEachNodeAfterFilterAndSort((item:any) =>{
  //     itemsToUpdate.push(item.data)
  //   })
  //   let selectedRows = this.gridOptions.api!.getSelectedNodes();
  //   for (let i = 1; i < itemsToUpdate.length; i++) {
  //     for (let j = 0; j < selectedRows.length; j++) {
  //       if (itemsToUpdate[i]?.data.id === selectedRows[j]?.data?.id) {
  //         itemsToUpdate.splice(i, 1, {
  //           ...selectedRows[j],
  //           data: {
  //             ...selectedRows[j].data,
  //             [selectedDropdown.lName]: selectedDropdown.lValue,
  //           },
  //         });
  //       }
  //     }
  //   }
  
  //   // this.gridOptions.api!.forEachNode(
  //   //   (rowNode: any, index: any) => {
  //   //     for (let j = 0; j < selectedRows.length; j++) {
  //   //       if (rowNode.data.id === selectedRows[j].data.id) {
  //   //         rowNode.splice(index, 1, {
  //   //           ...selectedRows[j],
  //   //           data: {
  //   //             ...selectedRows[j].data,
  //   //             [selectedDropdown.lName]: selectedDropdown.lValue,
  //   //           },
  //   //         });
  //   //       }
  //   //     }
  //   //   }
  //   // );
  //   this.gridOptions.api!.applyTransaction({ update: itemsToUpdate });
  // }

  lineObjMapping(obj: any, updates: any) {
    // Loop over the updates object
    // Object.keys(updates).forEach((key) => {
      let split = updates.lName.split('.');
      if (split.length === 2) {
        obj[split[0]][split[1]] = updates['lValue']; // Update the property if it exists
      } else if (split.length === 3) {
        obj[split[0]][split[1]][split[2]] = updates['lValue']; // Update the property if it exists
      } else {
        obj[updates['lName']] = updates['lValue']; // Update the property if it exists
      }
    // });
    return obj;
  }
//adding for break - Palak
lineObjMappingBreak(obj: any, updates: any) {

    let split = updates.lName.split('.');
    obj[updates['lName']] = updates['lValue']; // Update the property if it exists
    
  return obj;
}

  onInputChange(event: any): void {
    // This method will be called when the input changes
    const value = event;
    if (value) {
      const newItem = this.createNewRowData(value);
      this.gridOptions.api!.applyTransaction({ add: [newItem] });
      this.newText = ''; // Clear the input if you need to
    }
  }

  createNewRowData(text: string) {
    console.log('newText ', text);

    // Create a new row object based on the input
    return {
      // ... your new item's properties
      yourTextField: text,
    };
  }

  getTabRender() {
    let uniqueData: any[] = [];
    this.reconsileService.getTabsDada().subscribe((result: any) => {
      this.tabHeaderData = result;
      this.tabData = result;
      // console.log('runsheet tabs', this.tabData);
      this.tabHeaderData.sort((a: any, b: any) => a.tabOrder - b.tabOrder);

      const uniqueTabOrders = new Set();

      // Iterate through the data and add items to the uniqueData array
      for (const item of this.tabHeaderData) {
        if (!uniqueTabOrders.has(item.tabOrder)) {
          uniqueData.push(item);
          uniqueTabOrders.add(item.tabOrder);
        }
      }
      this.tabHeaderData = uniqueData;
      // console.log('Unique Data by tabOrder:', uniqueData);
    });
  }

  getRowDataReconsileSheet(runsheetId: any) {
    if(runsheetId !== null) {
      this.reconsileService.reloadGrid.subscribe((res) => {
        console.log('reload Data> ', res);
        this.getRowReconcileData(runsheetId);
      });
    }
  }

  qty1data: any = 0;
  unit1data: any;
  qty2data: any = 0;
  unit2data: any;
  qty3data: any = 0;
  unit3data: any;
  qty4data: any = 0;
  unit4data: any;
  qty5data: any = 0;
  unit5data: any;
  qty6data: any = 0;
  unit6data: any;
  qty7data: any = 0;
  unit7data: any;
  qty8data: any = 0;
  unit8data: any;

  getRowReconcileData(runsheetId: any) {
    this.reconsileService
      .getViewRunsheetId(runsheetId)
      .subscribe((result: any) => {
        this.runsheetRowData.push(result.runsheet);
        this.runsheetState.completed = result?.runsheet?.complete;
        this.addServiceByService._allRunsheetSubject.next(result.runsheet);
        this.runsheetRowData.map((runsheetRow: any) => {
          this.runsheetLinesRow = runsheetRow.runsheetLines
          // .map((item: any) => ({...item, 
          //   qty1: `${item.qty1} ${item.unit1}`,
          //   qty2: `${item.qty2} ${item.unit2}`,
          //   qty3: `${item.qty3} ${item.unit3}`,
          //   qty4: `${item.qty4} ${item.unit4}`,
          //   qty5: `${item.qty5} ${item.unit5}`,
          //   qty6: `${item.qty6} ${item.unit6}`,
          //   qty7: `${item.qty7} ${item.unit7}`,
          //   qty8: `${item.qty8} ${item.unit8}`,

          // }))
           || [];
          
           /**
           * Calling method to chnage array of object design
           * so we can get Output as per requriment
           */
          this.arrayOfObjects = this.transformRunsheetLines(
            this.runsheetLinesRow
          );
         // this.gridOptions.api!.getDisplayedRowAtIndex(this.gridOptions.rowData.length - 1).setSelected(true);

          this.gridDataSubject.next([...this.runsheetLinesRow]);
          this.runsheetFormService.griddDataSubject.next(this.runsheetLinesRow);
          this.driverBreaks = runsheetRow.driverBreaks
            ? runsheetRow.driverBreaks
            : [];
          this.adjistmentRow = runsheetRow.payAdviceLines
            ? runsheetRow.payAdviceLines
            : [];
          this.adjistmentRowLength = runsheetRow.payAdviceLines.length;
          this.runsheetLength = this.runsheetLinesRow.length;

          //console.log(this.runsheetLength);

          this.runsheetLinesRow.forEach((row) => {
            this.qty1data += row.qty1;
            if (row.qty1) {
              this.unit1data = row.unit1;
            }
            this.qty2data += row.qty2;
            if (row.qty2) {
              this.unit2data = row.unit2;
            }
            this.qty3data += row.qty3;
            if (row.qty3) {
              this.unit3data = row.unit3;
            }
            this.qty4data += row.qty4;
            if (row.qty4) {
              this.unit4data = row.unit4;
            }
            this.qty5data += row.qty5;
            if (row.qty5) {
              this.unit5data = row.unit5;
            }
            this.qty6data += row.qty6;
            if (row.qty6) {
              this.unit6data = row.unit6;
            }
            this.qty7data += row.qty7;
            if (row.qty7) {
              this.unit7data = row.unit7;
            }
            this.qty8data += row.qty8;
            if (row.qty8) {
              this.unit8data = row.unit8;
            }
          });

          this.driverBreaksLength = this.driverBreaks.length;
          if (this.driverBreaks.length === 0) {
            this.runsheetFormService._showBreak.next(true);
          }
          this.runsheetFormService._showBreak.next(false);
          this.documentPayAdviceLines = result.payAdvices
            ? result.payAdvices
            : [];
          this.payAdviceLength = this.documentPayAdviceLines.length
            ? this.documentPayAdviceLines.length
            : null;
          this.documentInvoiceLines = result.invoices ? result.invoices : [];
          this.documentInvoiceLinesLength = this.documentInvoiceLines.length
            ? this.documentInvoiceLines.length
            : null;

          console.log('driverBreaks >>', this.adjistmentRow);
        });
      });
  }

  selectedTab(e: any) {
    console.log('selected tab >>,', e.tab.textLabel);

    switch (e.tab.textLabel) {
      case 'Trips':
        this.addTrips();
        break;
      case 'Runsheet Lines':
        // this.addEntity();
        break;
      case 'Breaks':
       // this.break();
        break;

      case 'Adjustments':
        this.adjustmentDiv();
        break;

      case 'Documents':
        break;

      default:
        break;
    }
  }

  addServiceBy() {
    console.log('Hi addServiceBy');
    this.reconsileService.setSelectedItemType('add-by-service');
  }

  duplicateRow() {
    console.log('duplicate row:', this.selectedRow);
    let newRow = this.selectedRow;
    newRow.id = null;
    newRow.lineServiceTO.loadNo = null;
    newRow.lineServiceTO.serviceId = null;
    this.runsheetLinesRow.push(newRow);
    console.log(this.runsheetLinesRow);
    this.runsheetLength=this.runsheetLinesRow.length;
    this.gridDataSubject.next([...this.runsheetLinesRow]);
    this.runsheetFormService.griddDataSubject.next(this.runsheetLinesRow);
    this.runsheetFormService.griddDataSubject.next(this.runsheetLength);
  }
  noOfCopies:number=0
  duplicateRunsheetLines() {
    // console.log('runsheetLinesRowc >>',this.gridOptions.rowData,this.selectedRow,this.runsheetLinesRow,this.noOfCopies);
    // const tripNo = this.transformRunsheetGlobal.filter((item: any) => item.isTrip).length || 1;
    // const lastTripRow = this.gridOptions.rowData.length > 0 ? this.gridOptions.rowData[this.gridOptions.rowData.length - 1]: this.gridOptions.rowData[this.gridOptions.rowData.length];
    // const lastTripNoRowsCount = this.gridOptions.rowData.length > 0 ? this.gridOptions.rowData.filter((item: any) => item.tripno === lastTripRow.tripno && !item.isTrip).length + 1: 1;
    // const addNode = {...this.gridOptions.rowData[this.gridOptions.rowData.length - 1], tripseq: `${tripNo}.${lastTripNoRowsCount}`}
    // this.transformRunsheetGlobal.push(addNode);
    //   this.gridOptions.api!.applyTransaction({
    //     add: [addNode],
    //   });
    //   this.gridOptions
    //     .api!.getDisplayedRowAtIndex(this.gridOptions.api.getDisplayedRowCount() - 1)
    //     .setSelected(true);
    //   this.runsheetLineService.gridDataArrayServiceDetail = this.gridOptions.rowData;


    const duplicateRow: any = this.runsheetLineService.duplicateRunsheetLines(
      this.selectedRow,
      this.runsheetLinesRow,
      this.noOfCopies
    )
    console.log('duplicate row >>', duplicateRow);

    this.runsheetLineService.gridDataArrayServiceDetail = duplicateRow;
    this.transformRunsheetLines(duplicateRow);
  }

   rslReturnData:any = []
  addReturnService() {
    const allRowData = this.gridOptions.rowData;
    const itemsToAdd: any = [];
    this.gridOptions.api!.forEachNodeAfterFilterAndSort(
      (rowNode: any, index: any) => {
        if (rowNode.selected) {
          console.log('rowNode >>', rowNode);
          this.rslReturnData = rowNode.data;
          const tempId =
            this.runsheetLineService.createTempId() + Math.random() * 100;
          const lineServiceTO = this.rslReturnData.lineServiceTO
            ? Object.keys(this.rslReturnData.lineServiceTO).reduce(
                (result: any, key: any) => {
                  if (
                    ![
                      'serviceNo',
                      'tripIdCust',
                      'pickupLocation',
                      'dropLocation',
                    ].includes(key)
                  ) {
                    result[key] = this.rslReturnData.lineServiceTO[key];
                  }
                  return result;
                },
                {
                  pickupLocation: this.rslReturnData.lineServiceTO.dropLocation,
                  dropLocation: this.rslReturnData.lineServiceTO.pickupLocation,
                }
              )
            : {};

            itemsToAdd.push({
              ...this.rslReturnData,
              id: tempId,
              locationDropId: this.rslReturnData.locationPickupId,
              locationPickupId: this.rslReturnData.locationDropId,
              lineServiceTO,
              serviceTypeId: null,
              loadTypeId: null,
              createdby: this.rslReturnData.createdby,
              tripseq: this.getTripSeqOfReturnServiceLine(
                this.rslReturnData,
                allRowData
              ),
              // Other properties as necessary
            });

          // if (!rowNode.data.hasOwnProperty(row.lName)) {
          //   return;
          // }
          // let data = rowNode.data;
          // // data[row.lName] = row[row.lValue];
          // // data.loadTypeId = row.loadTypeId;
          // data = this.lineObjMapping(data, row);
          // itemsToUpdate.push(data);
        }
      }
    );

    this.gridOptions.api!.applyTransaction({
      add: itemsToAdd,
    });
    
    this.runsheetLineService.gridDataArrayServiceDetail = [...this.gridOptions.rowData, ...itemsToAdd];
    console.log("gridDataArrayServiceDetail 6", this.runsheetLineService.gridDataArrayServiceDetail);
    // const returnServiceLines = (this.runsheetLinesRow || []).map(rsl => {
    //   const tempId = this.runsheetLineService.createTempId() + (Math.random() * 100); 
    //   const lineServiceTO = rsl.lineServiceTO ?
    //     Object.keys(rsl.lineServiceTO).reduce((result: any, key: any) => {
    //       if (!['serviceNo', 'tripIdCust', 'pickupLocation', 'dropLocation'].includes(key)) {
    //         result[key] = rsl.lineServiceTO[key];
    //       }
    //       return result;
    //     }, { pickupLocation: rsl.lineServiceTO.dropLocation, dropLocation: rsl.lineServiceTO.pickupLocation }) : {};

    //   return {
    //     ...rsl,
    //     id: tempId,
    //     locationDropId: rsl.locationPickupId,
    //     locationPickupId: rsl.locationDropId,
    //     lineServiceTO,
    //     serviceTypeId: null,
    //     loadTypeId: null,
    //     createdby: "dhavaltr",
    //     tripseq: this.getTripSeqOfReturnServiceLine(rsl, allRowData)  
    //     // Other properties as necessary
    //   };
    // });

    // console.log("all return service >>", [...(this.runsheetLinesRow || []), ...returnServiceLines]);

    // this.transformRunsheetLines([...(this.runsheetLinesRow || []), ...returnServiceLines])
    
    // return [...(this.runsheetLinesRow || []), ...returnServiceLines];
    // let addReturnRow = this.selectedRow;
    // addReturnRow.id = null;
    // addReturnRow.loadTypeId = 'LIMEL';
    // addReturnRow.serviceTypeId = 'FINISH';
    // this.runsheetLinesRow.push(addReturnRow);
    // this.gridDataSubject.next([...this.runsheetLinesRow]);
    // this.runsheetFormService.griddDataSubject.next(this.runsheetLinesRow);
  }

  getTripSeqOfReturnServiceLine(returnServiceLine: any, runsheetLines: any[]): number {
    // Check if 'RSL.ReturnsAfterLines' option is true
    // if (this.refDataService.getUserOptionValue('RSL.ReturnsAfterLines')) {
    //   // Return the tripseq from the returnServiceLine
    //   return returnServiceLine.tripseq;
    // } else {
      // Otherwise, calculate a new trip sequence
      return 1 + this.getMaxTripSeqInRunsheetLines(
        this.filterrunsheetLinesByTripArray(runsheetLines, returnServiceLine.tripno)
      );
    // }
  }

  
   getMaxTripSeqInRunsheetLines(runSheetLines: any) {
    return runSheetLines.reduce(function (maxTripSeq: any, runsheetLine: any) {
        return Math.max(maxTripSeq, parseInt(runsheetLine.tripseq));
    }, 0);
}

   
   filterrunsheetLinesByTripArray(runsheetLines: any, tripno: any) {
    return runsheetLines.filter( (line: any) => line.tripno === tripno);
      //  return _.filter(runsheetLines, function (line) {
      // return line.tripno === tripno;
    // });
   }

  addEntity() {

    console.log('click runsheet-line');
    this.reconsileService.setSelectedItemType('runsheet-line');
    this.runsheetFormService.newRunsheetLineFormReset.next(true);
    if (this.gridOptions.rowData.length > 0) {
      this.gridOptions.api.deselectAll();
      this.bulkEditMode =false;
    }
    this.runsheetLineIdUnique = null;
  }

  addEntitySelected() {
    console.log('click runsheet-line');
    this.reconsileService.setSelectedItemType('runsheet-line');
    this.runsheetFormService.newRunsheetLineFormReset.next(true);

    // this.gridOptions.api.deselectAll();
  }

  addTrips() {
    console.log('click Trips');
    this.reconsileService.setSelectedItemType('trips');
    //this.runsheetFormService.newRunsheetLineFormReset.next(true);
  }

  break() {
    this.reconsileService.setSelectedItemType('break');
    if(this.rowSelected){
      this.runsheetFormService._showBreak.next(false);
    }else{
      this.runsheetFormService._showBreak.next(true);
    }
    this.breakIdUnique=null;
  }

  deletebreak() {
    console.log('Delete Break', this.driverBreaks ,this.rowSelected);
    this.reconsileService.selectedItemType.next('deleteBreak'); 
    this.runsheetFormService.sendDeleteBreakId(this.selectedRow.id);
    this.driverBreaks = this.driverBreaks.filter(item => item.id !== this.rowSelected.id);
    console.log(this.driverBreaks)
    this.runsheetFormService.breakDeleteId = this.selectedRow.id;
  }

  adjustmentDiv() {
    this.reconsileService.selectedItemType.next('adjustment');
  }
  /**on click on break row we need to pass that data to break form
   * For Edit Sistuation
   */
  breakForm() {
    this.reconsileService.selectedItemType.next('break');
  }

  deleteEntities() {
    let nodeToRemove = this.gridOptions.rowData.find((item: any) => item.id === this.runsheetLineIdUnique)
    if (nodeToRemove) {
      this.gridOptions.api.applyTransaction({ remove: [nodeToRemove] });
    }

    this.reconsileService
      ._resetServices(this.runsheetId, this.runsheetLineIdUnique, true)
      .subscribe(
        (serviceData: any) => {
          console.log('serviceData >> ', serviceData);
          this.messageService.add({
            detail: 'Service Deleted',
            severity: 'success',
            life: 30000,
          });
        },
        (err) => {
          let errMsg = '';
          const lockErrDetail: ExceptionInfo =
            err.error.errorList.ExceptionInfos[0];
          errMsg = lockErrDetail.UserErrorDescription;
          this.messageService.add({
            detail: errMsg,
            severity: 'error',
            life: 30000,
          });
        }
      );
  }
  bulkeditIdsData: any[] = [];
  isSelectedRow: any;
  runsheetObj: any = {};
  multipleRowSeleceted: any[] = []
  rowSelected: any
  getMultiLegData() {
    // this.reconsileService._onDetailChangeSubdata.subscribe((runsheetCheckedObj: any) => {
    //     console.log("runsheetCheckedObj >>", runsheetCheckedObj);
    //     this.selectedRow = runsheetCheckedObj;
    //     if (this.selectedRow?.data.isTrip) {
    //       this.addTrips();
    //     } else if (this.selectedRow?.hasOwnProperty('breakTypeId')) {
    //       this.breakForm();
    //     } else {
    //       this.addEntity();
    //     }
    // })
    this.reconsileService._multiLangData.subscribe((runsheet: any) => {
      console.log('Runsheet Tab line details >> ', runsheet);
      this.multipleRowSeleceted = runsheet;
      this.rowSelected = runsheet;
      if(this.multipleRowSeleceted.length >= 1) {
        this.multipleRowSelecetedMoretwo = true;
        this.disabledAction = true;
        this.bulkEditMode = true;
      } else {
        this.bulkEditMode = false;
        this.disabledAction = false;
      }
      const runsheetData = runsheet;
      this.runsheetLineIdUnique = runsheet[0]?.id; 
      
      if (Array.isArray(runsheetData)) {
        this.selectedRow = runsheetData[runsheetData.length - 1];
        if (this.selectedRow?.isTrip) {
          this.addTrips();
        } else if (this.selectedRow) {
          this.addEntitySelected();
        }
      } else {
        this.selectedRow = runsheetData;
        if (
          typeof this.selectedRow === 'object' &&
          !Array.isArray(this.selectedRow) &&
          this.selectedRow !== null
        ) {
          if (this.selectedRow?.hasOwnProperty('breakTypeId')) {
            this.breakForm();
          }
        }
      }

      console.log('multiArray detail >>', this.runsheetObj, runsheetData);

      //this.disabledAction = !this.disabledAction;
      // this.selectedRow = this.runsheetObj;

      //   this.bulkeditIdsData.push(runsheet);
      //   console.log("this.bulkeditIds >> ",this.bulkeditIdsData);

      //  this.isSelectedRow = this.runsheetService.isSelectionBulk(this.bulkeditIdsData);
      //  if(this.isSelectedRow && runsheetData.length > 1)
      //  {
      //   this.bulkEditMode = true
      //  }
      //  console.log("this.bulkeditIds Data Check>>",this.isSelectedRow);

      // if(this.bulkeditIds.length > 0) {
      //   this.bulkEditMode = true;

      // }

      // this.runsheetFormService.deleteBreakRow.next(this.selectedRow.id);
      this.runsheetIdRemove = this.selectedRow.id;
      this.runsheetLineServiceId = this.selectedRow?.lineServiceTO?.serviceId;
    });
  }

  getDisplaySeq(rsl: tripRow) {
    // return rsl.isTrip
    //   ? 'Trip ' + rsl.tripno
    //   : rsl.tripno + '.' +  rsl.tripseq;

        //[, rsl.tripseq, rsl.groupseq]
        // .filter(function (element) {
        //   return !!element;
        // })
        // .join('.');

        return rsl.isTrip ?
              'Trip ' + rsl.tripno :
               [rsl.tripno, rsl.tripseq, rsl.groupseq].filter(function (element) {
                return !!element;
              }).join('.');
  }

  /**
   * @ngdoc function
   * @description
   * Consolidate the supplied runsheet lines:
   * assign the same tripseq to all (whichever is lowest)
   * assign groupseq sequentially
   * @param  {Array} runsheetLinesToConsolidate runsheetLines to consolidate
   * @param  {Array} runsheetLines              all runsheetlines
   * @return {Array}                            updated runsheet lines
   */
  consolidateRunsheetLines(
    runsheetLinesToConsolidate: any,
    runsheetLines: any
  ) {
    if (this.canConsolidate(runsheetLinesToConsolidate)) {
      runsheetLinesToConsolidate
        .sort(function (a: any, b: any) {
          // sort by tripseq, so we know the first item has the lowest tripseq
          return a.tripseq - b.tripseq;
        })
        .forEach(function (rsl: any, index: any, array: any) {
          rsl.tripseq = array[0].tripseq; // set all to the first(lowest) tripseq
          rsl.lineServiceTO.serviceGroup = array[0].lineServiceTO.serviceNo; //The service group for each service is set to the service number of the first service in the group
          rsl.groupseq = index + 1; // assign groupseq in sequence (1 based)
        });
    }
    return this.refreshRunsheetLines(runsheetLinesToConsolidate);
  }

  /**
   * @ngdoc function
   * @description return true if the supplied runsheet lines can be consolidated:
   * runsheet lines must be an array of more than 1, have the same tripno, and be not already consolidated (ie none have a groupseq, and they do not all have the same tripseq)
   * @param  {Array} runsheetLinesToConsolidate runsheetLines to consolidate
   * @return {boolean}                            true if consolidation permitted
   */
  canConsolidate(runsheetLinesToConsolidate: any) {
    return (
      Array.isArray(runsheetLinesToConsolidate) &&
      runsheetLinesToConsolidate.length > 1 &&
      runsheetLinesToConsolidate.every(function (rsl, index, array) {
        return !rsl.groupseq && rsl.tripno === array[0].tripno;
      }) &&
      runsheetLinesToConsolidate.some(function (rsl, index, array) {
        return rsl.tripseq !== array[0].tripseq;
      })
    );
  }

  /**
   * @ngdoc function
   * @description
   * Refresh tripno, tripseq (TODO and groupseq) of an array of runsheetLines
   * New items go to the end
   * update tripno and tripseq (TODO groupseq) to ensure contiguity
   * nb output is not sorted
   * @param {Array} runsheetLines runsheetLines to process
   * @return {Array} updated runsheetLines
   */
  refreshRunsheetLines(runsheetLines: any) {
    // create hash of runsheet lines grouped by tripno...
    var runsheetLinesByTripObject = (runsheetLines || []).reduce(function (
      result: any,
      runsheetLine: any
    ) {
      var tripno = runsheetLine.tripno || 0;
      result[tripno] = result[tripno] || [];
      result[tripno].push(runsheetLine);
      return result;
    },
    {});
    // ...convert to array...
    Object.keys(runsheetLinesByTripObject)
      .map(function (key) {
        return runsheetLinesByTripObject[key];
      })
      // ...sort by tripno. RunsheetLines with falsy tripno (e.g. new ones) go to the end
      .sort(function (a, b) {
        return a.length && b.length
          ? (a[0].tripno || 99999) - (b[0].tripno || 99999)
          : 0;
      })
      .forEach((runsheetLinesByTripArray, i) => {
        runsheetLinesByTripArray
          .sort(function (a: any, b: any) {
            // sort by tripseq (runsheetLines with falsey tripseq (e.g. new ones) go to the end) and by groupseq
            return (
              (a.tripseq || 99999) - (b.tripseq || 99999) ||
              (a.groupseq || 99999) - (b.groupseq || 99999)
            );
          })
          .reduce(
            (
              currentTripseq: any,
              runsheetLine: any,
              index: any,
              runsheetLinesByTripArray: any
            ) => {
              // ensure tripseq and tripno values are contiguous
              currentTripseq =
                runsheetLine.groupseq > 1 ? currentTripseq : currentTripseq + 1;
              // runsheetLine.tripno = i + 1;
              //runsheetLine.tripseq = currentTripseq;
               runsheetLine.seqDisplay = this.getDisplaySeq(runsheetLine);

              // runsheetLine.seqDisplay = getDisplaySeq(runsheetLine);
              runsheetLine.lineServiceTO = runsheetLine.lineServiceTO || {};
              runsheetLine.lineServiceTO.serviceGroup = this.getServiceGroup(
                runsheetLine,
                runsheetLinesByTripArray
              );
              return currentTripseq;
            },
            0
          );
      });
    runsheetLines.sort(function (a: any, b: any) {
      return (
        a.tripno - b.tripno || a.tripseq - b.tripseq || a.groupseq - b.groupseq
      );
    });
    return runsheetLines;
  }

  /*
   * @ngdoc function
   * @description
   * set servicegroup for runsheetline
   * Only applies to consolidated rsls (ie !!runsheetLine.groupseq)
   * Find the rsl with matching tripno and tripseq and groupseq === 1
   * Return the last 4 chars of its service number
   *
   * @param {Object} targetRunsheetLine  runsheet line to get service group for
   * @param {Object} runsheetLines runsheet lines to search in
   * @return {string}               service group
   */
  getServiceGroup(targetRunsheetLine: any, runsheetLines: any) {
    return (runsheetLines || []).reduce(function (
      serviceGroup: any,
      runsheetLine: any
    ) {
      return runsheetLine.tripno === targetRunsheetLine.tripno &&
        runsheetLine.tripseq === targetRunsheetLine.tripseq &&
        runsheetLine.groupseq === 1 &&
        !!runsheetLine.lineServiceTO
        ? (runsheetLine.lineServiceTO.serviceNo || '').substr(-4)
        : serviceGroup;
    },
    null);
  }

  /**
   * @ngdoc function
   * @description return true if the supplied runsheet lines can be deconsolidated:
   * Supplied runsheet lines must be an array with non-zero length, and are already consolidated (all have the same tripno and tripseq, and have a (truthy) groupseq)
   * @param  {Array} runsheetLinesToDeconsolidate runsheetLines to deconsolidate
   * @return {boolean}                            true if deconsolidation permitted
   */
  canDeconsolidate(runsheetLinesToDeconsolidate: any) {
    return (
      Array.isArray(runsheetLinesToDeconsolidate) &&
      runsheetLinesToDeconsolidate.length &&
      runsheetLinesToDeconsolidate.every(function (rsl, index, array) {
        return (
          rsl.tripno === array[0].tripno &&
          rsl.tripseq === array[0].tripseq &&
          rsl.groupseq
        );
      })
    );
  }

  /**
   * @ngdoc function
   * @description
   * Deconsolidate the supplied runsheet lines:
   * reverse consolidation operation:
   * - remove groupseq
   * - assign a unique tripseq
   * - clean up other runsheet lines with the same tripseq (ensure groupseq is contiguous, remove groupseq if only on remaining)
   * @param  {Array} runsheetLinesToDeconsolidate runsheetLines to deconsolidate
   * @param  {Array} runsheetLines              all runsheetlines
   * @return {Array}                            updated runsheet lines
   */
  deconsolidateRunsheetLines(
    runsheetLinesToDeconsolidate: any,
    runsheetLines: any
  ) {
    if (this.canDeconsolidate(runsheetLinesToDeconsolidate)) {
      var consolidationTripseq = runsheetLinesToDeconsolidate[0].tripseq;
      var consolidationTripno = runsheetLinesToDeconsolidate[0].tripno;
      runsheetLinesToDeconsolidate.forEach(function (
        rsl: any,
        index: any,
        array: any
      ) {
        rsl.tripseq = consolidationTripseq + index; // * 0.001;
        rsl.groupseq = null;
      });
      runsheetLines
        .filter(function (rsl: any) {
          return (
            rsl.tripno === consolidationTripno &&
            Math.floor(rsl.tripseq) === consolidationTripseq &&
            rsl.groupseq
          );
        })
        .forEach(function (rsl: any, index: any, array: any) {
          rsl.groupseq = array.length === 1 ? null : index + 1;
        });
    }
    return this.refreshRunsheetLines(runsheetLines);
  }


  onGridReady(params: any) {
    this.gridApi = params.api;
    this.columnApi = params.columnApi;
    this.getLayout();
  }

  // Save Layout functinality
  selectedSite: any ='';
  disableCloseOff: boolean = true;
  layoutSubscription: Subscription;
  columnApi: any;
  columnState: any;
  userName: any;
  selectedOptions: any;
  applicationOptions: any;
  applicationId: any;
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.selectedsite;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.reconcile.create-runsheet.breaks.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.create-runsheet.breaks.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.create-runsheet.breaks.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }

  ngOnDestroy() {
   // Unsubscribe from all subscriptions to prevent memory leaks
  //  this.subscription.unsubscribe();
  }

  onValueSelected(event:any){
    this.runsheetFormService._showBreak.next(false);
  }

}

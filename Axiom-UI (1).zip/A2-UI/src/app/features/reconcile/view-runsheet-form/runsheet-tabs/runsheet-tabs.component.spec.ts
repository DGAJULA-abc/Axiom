import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RunsheetTabsComponent } from './runsheet-tabs.component';

describe('RunsheetTabsComponent', () => {
  let component: RunsheetTabsComponent;
  let fixture: ComponentFixture<RunsheetTabsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RunsheetTabsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RunsheetTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-confirmingsavedornotsaveddialog',
  templateUrl: './confirmingsavedornotsaveddialog.component.html',
  styleUrls: ['./confirmingsavedornotsaveddialog.component.scss'],
})
export class ConfirmingsavedornotsaveddialogComponent {
  constructor(public dialogRef: MatDialogRef<ConfirmingsavedornotsaveddialogComponent>) {}

  onDiscard(): void {
    this.dialogRef.close('discard');
  }

  onSave(): void {
    this.dialogRef.close('save');
  }

  onCancel(): void {
    this.dialogRef.close('cancel');
  }
}

import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { map, Observable } from 'rxjs';
import { RunsheetFormService } from '../../services/runsheet-form.service';
import { ConfirmNavigateComponent } from '../confirm-navigate/confirm-navigate.component';

@Component({
  selector: 'app-can-deactivate-guard',
  templateUrl: './can-deactivate-guard.component.html',
  styleUrls: ['./can-deactivate-guard.component.scss']
})
export class CanDeactivateGuardComponent implements CanDeactivate<any> {
  constructor(private dialog: MatDialog,private runsheetService:RunsheetFormService) {}
  check:boolean=false;
   canDeactivate(component: any): Observable<boolean> | boolean {
    // if (component.hasUnsavedChanges()) {
    //   const dialogRef = this.dialog.open(ConfirmNavigateComponent);
    //   return dialogRef.afterClosed().pipe(
    //     map(result => {
    //       if (result === 'discard') {
    //         // this.runsheetService.dialogResultSubject.next('discard')
    //         return true; // Allow navigation
    //       } else if (result === 'save') {
    //         // this.runsheetService.dialogResultSubject.next('save')
    //         component.onFormSubmit()
    //        this.runsheetService.dialogResultSubject.subscribe((res)=>{
    //            if(res){
    //              this.check = true;
    //            }
    //            else{
    //              this.check = false;
    //            }

    //          })
    //           // this.runsheetService.dialogResult=null

    //         return this.check; // Allow navigation
    //       } else {
    //         // this.runsheetService.dialogResultSubject.next('cancel')
    //         return false; // Prevent navigation
    //       }
    //     })
    //   );
    // }
    return true;
  }
}

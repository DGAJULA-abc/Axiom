import { Component, ViewChild } from '@angular/core';
import { ColDef, GridApi, GridReadyEvent, RowNode } from 'ag-grid-community';
import { SearchService } from '../services/search.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { FormGroup } from '@angular/forms';
import { AgGridAngular } from 'ag-grid-angular';
import { pagination } from 'src/app/shared/model/shared.model';
import { Runsheet, RunsheetDetails } from '../model/search.model';
import { MatDialog } from '@angular/material/dialog';
import { DeleteInvoiceLinesComponent } from '../delete-invoice-lines/delete-invoice-lines.component';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { Router } from '@angular/router';
import { PlanService } from '../../plan/services/plan.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
import * as moment from 'moment';
@Component({
  selector: 'app-runsheet',
  templateUrl: './runsheet.component.html',
  styleUrls: ['./runsheet.component.scss'],
})
export class RunsheetComponent {
  selectedOptions: any[];
  columnDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'runsheetid',
      headerName: 'Runsheet Id',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'runsheettypeid',
      headerName: 'Runsheet Type',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'driver',
      headerName: 'Driver',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'startdatetime',
      headerName: 'Start Date Time',
      type: 'DATETIME',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    },
    {
      field: 'enddatetime',
      headerName: 'End Date Time',
      type: 'DATETIME',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
    },
    {
      field: 'companyid',
      headerName: 'Company ID',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'companytypeid',
      headerName: 'Company Type',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'returndepottime',
      headerName: 'Return Depot Time',
      type: 'DATETIME',
      cellRenderer: (params: any) => {
        if (!params.value) {
          return ''; // Return an empty string or another placeholder
        }
        return moment(params.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'totalhours',
      headerName: 'Total Hours',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'startkm',
      headerName: 'Start KM',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'endkm',
      headerName: 'End KM',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'totalkms',
      headerName: 'Total Kms',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'deliverydate',
      headerName: 'Delivery Date',
      type: 'DATE',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          return formattedValue.includes(formattedFilter);
        },
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'sumcharge',
      headerName: 'Sum Charge',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'payamt',
      headerName: 'Pay amt',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'cntservices',
      headerName: 'Count Services',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'createdby',
      headerName: 'Created By',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'holdcode',
      headerName: 'Hold Code',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'complete',
      headerName: 'Complete',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
        disabled: true,
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'hasbreaks',
      headerName: 'Has Breaks',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
        disabled: true,
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'employeename',
      headerName: 'Employee Name',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'firstname',
      headerName: 'Firstname',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'lastname',
      headerName: 'Lastname',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'vendorname',
      headerName: 'Vendor name',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'gpskm',
      headerName: 'GPS KM',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'odokm',
      headerName: 'Odo KM',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'rateid',
      headerName: 'Rate ID',
      type: 'text',
      filter: true,
      floatingFilter: true,
    },
  ];

  columnDefsRunsheetLines: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      type: 'default',
      field: 'seqDisplay',
      headerName: 'Seq',
      width: 80,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.loadNo',
      headerName: 'Load No',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.tripIdCust',
      headerName: 'Trip',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.serviceGroup',
      headerName: 'Service Group',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'serviceTypeId',
      headerName: 'Service Type',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'loadTypeId',
      headerName: 'Load Type',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'locationPickupId',
      headerName: 'From',
      width: 200,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'locationDropId',
      headerName: 'To',
      width: 200,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'yesOrNo',
      field: 'lineServiceTO.complete',
      headerName: 'Complete',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'locationReturnId',
      headerName: 'Return To',
      width: 200,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.chargeAmt',
      headerName: 'Charge Amount',
      // cellFilter: 'currency'
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'currency',
      field: 'payamt',
      headerName: 'Pay Amount',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.serviceNo',
      headerName: 'Service No.',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'docket',
      headerName: 'Docket',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'container',
      field: 'containerId',
      headerName: 'Container',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'truckId',
      headerName: 'Truck',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'trailerId',
      headerName: 'Trailer',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'trailerTagId',
      headerName: 'Trailer Tag',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'truck.fleetNumber',
      headerName: 'Fleet No.',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.customerId',
      headerName: 'Customer Id',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.locationDesc',
      headerName: 'Pickup Location Desc',
      filter: true,
      floatingFilter: true,
      width: 300,
    },
    {
      type: 'default',
      field: 'lineServiceTO.dropLocation.locationDesc',
      headerName: 'Drop Location Desc',
      filter: true,
      floatingFilter: true,
      width: 300,
    },
    {
      type: 'default',
      field: 'truck.truckTypeId',
      headerName: 'Truck Type',
      width: 150,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.batchNo',
      headerName: 'ConNote',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.custRef',
      headerName: 'CustRef',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.loadLocation.locationId',
      headerName: 'Load Location',
      width: 200,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.loadLocation.locationDesc',
      headerName: 'Load Location Desc',
      width: 300,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.dropLocation.zoneChargeId',
      headerName: 'Charge Zone Drop',
      width: 150,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.dropLocation.zonePayId',
      headerName: 'Pay Zone Drop',
      width: 150,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zoneChargeId',
      headerName: 'Charge Zone Pickup',
      width: 150,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      width: 150,
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'vessel',
      field: 'lineServiceTO.vesselId',
      headerName: 'Vessel No.',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'createdby',
      headerName: 'Created by',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'fuelLevyInfo.fuelLevyCharge',
      headerName: 'Fuel Levy Charge',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'fuelLevyInfo.fuelLevyPay',
      headerName: 'Fuel Levy Pay',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'fuelLevyInfo.fuelLevyPay',
      headerName: 'Fuel Levy Pay',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Qty. 1',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      filter: true,
      floatingFilter: true,
    },
    {
      type: 'default',
      field: 'lineServiceTO.pickupLocation.zonePayId',
      headerName: 'Pay Zone Pickup',
      filter: true,
      floatingFilter: true,
      width: 150,
    },
  ];

  columnDefBreaks = [
    { type: 'autoId' },
    { type: 'default', field: 'locationId', displayName: 'Location' },
    { type: 'default', field: 'breakTypeId', displayName: 'Type' },
    {
      type: 'dateAndTime',
      field: 'breakstarttime',
      displayName: 'Start date/time',
    },
    {
      type: 'dateAndTime',
      field: 'breakendtime',
      displayName: 'End date/time',
    },
    {
      type: 'default',
      field: 'getDuration()',
      displayName: 'Break duration',
      cellFilter: "duration:'ms':'m[m]'",
    },
    { type: 'default', field: 'commentA', displayName: 'Comments', width: 300 },
  ];
  summary: { label: string; value: number }[];
  public rowData: Runsheet[] = [];
  selectedNodes: RowNode[];
  defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: false,
    sortable: true,
    resizable: true,
    suppressMenu: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
  };
  runsheetDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  editForm: Runsheet | null;
  runsheetDetails: RunsheetDetails;
  rowNodeRunsheetLines: RowNode[];
  rowNodeDriverBreak: RowNode[];
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 10000,
    orderType: 'DESC',
    orderByField: 'runsheetid',
  };
  selectedSRunsheets: any;
  canDelete: boolean = false;
  totalRecords: number = 0;
  searchFormDetails: any;
  applicationOptions: any;
  applicationId: any;
  userName: any;
  selectedSite: any;
  columnApi: any;
  columnState: any;
  gridOptions: any;
  layoutSubscription: Subscription;
  constructor(
    public planService: PlanService,
    private searchServices: SearchService,
    private sharedDervice: SharedService,
    private dialog: MatDialog,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    private router: Router,
    public permission: PermissionsService

  ) {
    this.gridOptions = {
      context: { Component: this },
    };
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          console.log('create:', data);
          this.dialogService.savaLayout(data);
        }
      }
    );
    this.getView();
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  canWrite: boolean = true
  async permissionMethod() {
    try {
      const permission1 = await this.permission.canWrite('EnterRunsheets');
      const permission2 = await this.permission.canWrite('Runsheet2');
      const canWriteBoth = permission1 && permission2;
      console.log("Can write both permissions:", canWriteBoth);
      this.canWrite = canWriteBoth;
    } catch (error) {
      console.error("Error:", error);
    }
  }

  viewRunsheetPage(runsheetId: any) {
    const baseUrl = this.router.serializeUrl(
      this.router.createUrlTree(['reconcile/ViewRunsheet'], {
        queryParams: { runsheetId:  runsheetId },
        queryParamsHandling: 'merge',
      })
    );
    // .then(data => this.reloadCurrentRoute())

    // Open the new tab
    window.open(baseUrl, '_blank');
  }

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  // saveLayout(): any {
  //   if (this.columnApi) {
  //     this.columnState = this.columnApi.getColumnState();
  //     let columns = [];
  //     for (let column of this.columnState) {
  //       const customColumn = {
  //         name: column.colId,
  //         visible: !column.hide,
  //         width: column.width,
  //         sort: column.sort,
  //         filter: column.filter,
  //       };
  //       columns.push(customColumn);
  //     }
  //     let columnValueObj: any = { columns };
  //     columnValueObj = JSON.stringify(columnValueObj);
  //     this.navbarService.usernameSubject.subscribe((username) => {
  //       this.userName = username;
  //     });
  //     this.selectedSite = this.navbarService.selectedSiteId;
  //     console.log('site:', this.selectedSite);
  //     return {
  //       applicationOptionId: 9711,
  //       optionName: 'a2v3.setup.Search.Runsheets.grid.layout',
  //       optionValue: columnValueObj,
  //       siteId: this.selectedSite,
  //       userId: this.userName,
  //     };
  //   }
  // }

  // getLayout() {
  //   this.navbarService.applicationOptions.subscribe(
  //     (applicationOptions: any) => {
  //       let appOptions = applicationOptions;
  //       let a = appOptions.filter((item: any) => {
  //         if (item['optionName'] === 'a2v3.setup.Search.Runsheets.grid.layout')
  //           this.columnState = JSON.parse(item['optionValue']);
  //         if (this.columnState) {
  //           if (this.columnState.columns) {
  //             this.columnState.columns.forEach((column: any) => {
  //               if ('name' in column) {
  //                 column.colId = column.name;
  //                 delete column.name;
  //               }
  //             });
  //             this.columnState = this.columnState.columns;
  //             this.applyLayout();
  //           }
  //         }
  //       });
  //     }
  //   );
  // }

  // applyLayout() {
  //   console.log('new:', this.columnState);
  //   const applyColumnStateParams = {
  //     state: this.columnState,
  //     applyOrder: true,
  //   };
  //   this.columnApi.applyColumnState(applyColumnStateParams);
  //   this.columnState.forEach(({ colId, width }: { colId: any; width: any }) => {
  //     const column = this.columnApi.getColumn(colId);
  //     if (column) {
  //       this.columnApi.setColumnWidth(column, width);
  //     }
  //   });
  // }
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.setup.Search.Runsheets.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Runsheets.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Runsheets.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }
  columnDefss: ColDef[] = this.columnDefs;
  private gridApi!: GridApi<any>;
  ngOnInit(): void {
    this.selectedOptions = this.columnDefss.map((coulmn) => coulmn.field);
  }

  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefss = this.columnDefs.filter(
      (column) => event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefss);
  }
  /**
   * This is used to clear all filter
   */
  clearFilters() {
    this.columnDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.runsheetList(event);
  }

  runsheetList(event: any) {
    this.searchFormDetails = event;
    this.searchServices.getRunsheetList(event).subscribe((result: any) => {
      this.rowData = result.runsheets;
      this.pagination.pageNumber = result.pagination.currentPage;
      this.totalRecords = result.pagination.totalRecords;
    });
  }

  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data;
      console.log(this.editForm);
      if (this.editForm)
        this.searchServices
          .getRunsheetDetailsByID(this.editForm?.runsheetid)
          .subscribe((results: any) => {
            this.runsheetDetails = results.runsheet;
            this.rowNodeRunsheetLines = results.runsheet.runsheetLines;
            this.summary = this.getSummary(this.rowNodeRunsheetLines);
            this.rowNodeDriverBreak = results.runsheet.driverBreaks;
          });
    }

    this.selectedSRunsheets = event.api
      .getSelectedNodes()
      .map((rowNode: any) => {
        return rowNode.data;
      });
    this.canDelete =
      this.selectedSRunsheets.filter((services: any) => services.complete)
        .length > 0
        ? true
        : false;
  }
  onTabSelectToggle(event: any) {
    console.log(event);
  }

  downloadCSVServices() {
    let selectedFields;
   // if (this.tableGridChnages) {
      //selectedFields = this.columnDefs.map((column) => column.field);
    //}
    const filteredFields = this.columnDefs.filter(column => column.field !== '');
    selectedFields = filteredFields.map(column => column.field);

    let downloadCSVRequestBody = this.formSearchDetails;
    downloadCSVRequestBody.pagination = this.pagination;
    downloadCSVRequestBody.selectFields = selectedFields;
    this.searchServices
      .downLoadCSVRunsheet(downloadCSVRequestBody)
      .subscribe((result) => {
        if (result) {
          this.sharedDervice.downloadCSV(result, 'Search.Runsheets.csv');
        }
      });
  }

  getSummary(runsheetlines: any[]): { label: string; value: number }[] {
    const result: { label: string; value: number }[] = [
      { label: 'services', value: runsheetlines.length },
    ];
    const resultObj: { [key: string]: number } = {};

    runsheetlines.map((line) => {
      for (let index = 1; index <= 8; index++) {
        const unitKey = `unit${index}`;
        const qtyKey = `qty${index}`;

        const isUnitRegistered = resultObj[line[unitKey]];
        const qtyValue = parseFloat(line[qtyKey] || 0);
        const addedValue = (resultObj[line[unitKey]] || 0) + qtyValue;
        resultObj[unitKey] = isUnitRegistered ? addedValue : qtyValue;
      }
    });

    const roundDecimal = (input: number): number => {
      return input % 1 === 0 ? input : parseFloat(input.toFixed(3));
    };

    for (const prop in resultObj) {
      if (resultObj[prop]) {
        result.push({
          label: runsheetlines[0][prop],
          value: roundDecimal(resultObj[prop]),
        });
      }
    }
    return result;
  }
  runsheetId: RunsheetDetails
  deletRunsheet() {
    const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result == true) {
       let canDeleteRecords: any[] = [];
        this.selectedSRunsheets.filter((runsheet: any) => {
          if (runsheet.complete == false) {
            canDeleteRecords.push(runsheet.runsheetid);
          }
        });
        this.searchServices
          .deleteRunsheet(canDeleteRecords)
          .subscribe((result: any) => {
            if (result) this.runsheetList(this.searchFormDetails);
            this.editForm = null
          });
      }
    });
  }
}

import { Component, ViewChild } from '@angular/core';
import { SearchService } from '../services/search.service';

import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';

import { SearchInvoiceService } from '../services/search-invoice.service';
import {
  InvoiceLines,
  InvoiceLinesGetData,
} from '../model/searchInvoice.model';
import { CellrenderComponent } from '../../reconcile/list-incomplete-services/cellrender/cellrender.component';
import * as moment from 'moment';
import { DeleteFolderComponent } from '../../reports/delete-folder/delete-folder.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteInvoiceLinesComponent } from '../delete-invoice-lines/delete-invoice-lines.component';
import { AgGridAngular } from 'ag-grid-angular';
import { MatSelect } from '@angular/material/select';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { TimeRunsheetService } from '../../reconcile/services/time-runsheet.service';
import { PlanService } from '../../plan/services/plan.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
@Component({
  selector: 'app-invoice-lines',
  templateUrl: './invoice-lines.component.html',
  styleUrls: ['./invoice-lines.component.scss'],
})
export class InvoiceLinesComponent {
  InvoiceLinesGetData: any;
  constructor(
    public planService: PlanService,
    public dialog: MatDialog,
    private timeService: TimeRunsheetService,
    private service: SearchInvoiceService,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    public permission: PermissionsService

  ) {
    this.gridOptions = {
      context: { Component: this },
    };

    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          console.log('create:', data);
          this.dialogService.savaLayout(data);
        }
      }
    );
    this.getView();
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }

  public rowData: InvoiceLines[] = [];
  companies: any[] = [];
  serviceTypes: any[] = [];
  loadTypes: any[] = [];
  adjustmentTypes: any[] = [];
  customers: any[] = [];
  customerGroups: any[] = [];
  companyTypes: any[] = [];
  invoiceLines: InvoiceLinesGetData;
  InvoiceLines: InvoiceLinesGetData[];
  filteredLoadTypes: any[];
  filteredCompanyID: any[];
  filteredServiceType: any[];
  filteredAdjustmentType: any[];
  filteredCustomerID: any[];
  filteredCustomerGroup: any[];
  filteredCompanyType: any[];
  filteDriverData: any[] = [];
  drivers: any[] = [];
  isFormDirty = true;
  selectedOptions: any[];
  columnApi: any;
  columnState: any;
  userName: any;
  selectedSite: any;
  applicationOptions: any;
  applicationId: any;
  layoutSubscription: Subscription;
  gridOptions: any;
  gridApi: GridApi<InvoiceLinesGetData>;
  @ViewChild('mySelect') mySelect: MatSelect;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  ngOnInit() {
    this.selectedOptions = this.colDefs.map((coulmn) => coulmn.field);
    this.service.getDropDownData().subscribe((data: any) => {
      this.serviceTypes = data.ref.serviceTypes.map(
        (obj: { serviceTypeId: any }) => obj.serviceTypeId
      );
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.companies = data.ref.companys.map(
        (obj: { companyId: any }) => obj.companyId
      );
      this.drivers = data.ref.drivers;
      this.filteDriverData = this.drivers.map((item) => {
        let nameParts = [];
        if (item.surname && item.firstName) {
          nameParts.push(item.surname, item.firstName);
          if (item.employeeName) {
            nameParts.push(`- ${item.employeeName}`);
          }
        } else {
          if (item.surname) {
            nameParts.push(item.surname);
          }
          if (item.firstName) {
            nameParts.push(item.firstName);
          }
          if (item.employeeName) {
            nameParts.push(item.employeeName);
          }
        }
        if (item.companyId) {
          nameParts.push(`(${item.companyId})`);
        }
        const filteredName = nameParts
          .filter(
            (value) => value !== null && value !== undefined && value !== ''
          )
          .join(' ');

        return {
          id: item.id,
          name: filteredName,
        };
      });
      console.log(this.drivers);
      console.log(this.filteDriverData);
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.loadTypes = data.ref.loadTypes.map(
        (obj: { loadTypeId: any }) => obj.loadTypeId
      );
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.adjustmentTypes = data.ref.adjustmentTypes.map(
        (obj: { adjustmentTypeId: any }) => obj.adjustmentTypeId
      );
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.customers = data.ref.customers.map(
        (obj: { customerId: any }) => obj.customerId
      );
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.customerGroups = data.ref.customerGroups.map(
        (obj: { groupId: any }) => obj.groupId
      );
    });
    this.service.getDropDownData().subscribe((data: any) => {
      this.companyTypes = data.ref.companyTypes.map(
        (obj: { companyTypeId: any }) => obj.companyTypeId
      );
    });
  }
  formData: any = {
    description: null,
    company: null,
    driver: null,
    loadNo: null,
    serviceNo: null,
    serviceType: null,
    loadType: null,
    unAllocatedOnly: null,
    adjustmentLineType: null,
    adjustmentType: null,
    effectiveFrom: null,
    effectiveTo: null,
    customer: null,
    customerGroup: null,
    companyType: null,
    amoutFrom: null,
    amoutTo: null,
  };
  // table
  colDefs: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'id',
      headerName: 'Id',
      resizable: true,
      cellDataType: 'text',
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'serviceid',
      headerName: 'Service ID',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'serviceno',
      headerName: 'Service No',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'effectivedate',
      headerName: 'Effective Date',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      floatingFilter: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },


    },
    {
      field: 'parentid',
      headerName: 'Print id',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'adjustmenttypeid',
      headerName: ' Adjustment Type Id',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'linetext',
      headerName: 'Line Text',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'lineamt',
      headerName: 'Line amt',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'customerid',
      headerName: 'Customer Id',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'enteredby',
      headerName: 'Entered By',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'payrollcode',
      headerName: 'Payroll',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'driver',
      headerName: 'Driver',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
    {
      field: 'linetype',
      headerName: 'Line Type',
      resizable: true,
      floatingFilter: true,
      filter: true,
    },
  ];

  isunAllocatedOnly: boolean = true;
  public defaultColDef: ColDef = {
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    headerClass: function (params) {
      // logic to return the correct class
      return 'header-one';
    },
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  columnDefs: ColDef[] = this.colDefs;
  onSelectionChange(event: any) {
    this.clearFilters();
    console.log(event.value);
    this.columnDefs = this.colDefs.filter((column) =>
      event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }

  public popupParent: HTMLElement | null = document.body;
  submitFormInvoiceLines() {
    this.formData.unAllocatedOnly = this.isChecked ? 'true' : null;
    if (this.selectedlineTypes == 'Any') {
      this.formData.adjustmentLineType = 'ALL';
    } else if (this.selectedlineTypes == 'Invoice Adjustment') {
      this.formData.adjustmentLineType = 'ADJUST';
    } else if (this.selectedlineTypes == 'Periodic Charges') {
      this.formData.adjustmentLineType = 'PERIODIC';
    } else if (this.selectedlineTypes == 'Service Charges') {
      this.formData.adjustmentLineType = 'LINE';
    }
    console.log('hello');
    this.service
      .postInvoiceLineData(this.formData)
      .subscribe((response: any) => {
        console.log('left form');
        console.log(response);
        this.rowData = response.adjustments;
        console.log('hiii', this.rowData);
      });
  }
  isDivVisible: boolean = false;
  isChecked: boolean = true;
  isComponentVisible = true;
  matchedDriver: any;
  invoiceLine: any;
  GetInvoiceLinedata(event: any) {
    this.printRowValue = event.data;
    console.log('row click', event);
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code in row clicked', rowCount);
    if (rowCount > 1) {
      // Get a reference to the grid API
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
      // Select the clicked row
      event.node.setSelected(true);
    }
  }

  findDriverById(driverId: any) {
    console.log(driverId);
    return this.drivers.find((driver) => driver.id === driverId);
  }
  close() {
    this.isComponentVisible = false;
  }

  filterLoadType(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.loadTypes.length; i++) {
      let country = this.loadTypes[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredLoadTypes = filtered;
  }

  filterCompanyID(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.companies.length; i++) {
      let country = this.companies[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredCompanyID = filtered;
  }
  selectedDriver: any;
  filteredDrivers: any[];
  filteredDriver(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.filteredDrivers = this.filteDriverData.filter(option => option.name.toLowerCase().includes(query.toLowerCase()));


    // for (let i = 0; i < this.filteDriverData.length; i++) {
    //   let driver = this.filteDriverData[i];
    //   if (driver.name.toLowerCase().indexOf(query.toLowerCase()) === 0) {
    //     filtered.push(driver);
    //   }
    // }
    // this.filteredDrivers = filtered;
  }
  // Function to handle the selection
  handleCompanyTypeSelect(event: any) {
    // Find the selected option by value
    const selectedOption = this.filteDriverData.find(
      (option) => option.name === event.name
    );
    // If an option is found, update the formData with its id
    if (selectedOption) {
      this.formData.driver = selectedOption.id;
    }
  }
  filterServiceType(event: any) {
    let filtered: any[] = [];
    let query = event.query;



    for (let i = 0; i < this.serviceTypes.length; i++) {
      let country = this.serviceTypes[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredServiceType = filtered;
  }

  filterAdjustmentType(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.adjustmentTypes.length; i++) {
      let country = this.adjustmentTypes[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredAdjustmentType = filtered;
  }

  filterCustomerID(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.customers.length; i++) {
      let country = this.customers[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredCustomerID = filtered;
  }

  filterCustomerGroup(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.customerGroups.length; i++) {
      let country = this.customerGroups[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredCustomerGroup = filtered;
  }

  lineType: any[] = [
    'Any',
    'Invoice Adjustment',
    'Periodic Charges',
    'Service Charges',
  ];
  selectedlineTypes: any;
  filteredlineTypes: any[];
  filteredlineType(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.lineType.length; i++) {
      let country = this.lineType[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredlineTypes = filtered;
  }

  filterCompanyType(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    for (let i = 0; i < this.companyTypes.length; i++) {
      let country = this.companyTypes[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }

    this.filteredCompanyType = filtered;
  }

  downloadCsv() {
    this.service.InvoiceLineCsvDownload(this.formData).subscribe((res: any) => {
      // Assuming 'response' is the array buffer received from your HTTP request
      var arrayBuffer = res;
      var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
      var url = window.URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'report.csv'; // Set the desired file name
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.setup.Search.InvoiceLines.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.InvoiceLines.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.InvoiceLines.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }

  isAbleToDeleteInvoiceLines() {
    return (
      this.canWrite() &&
      this.rowData &&
      this.rowData.length > 0 &&
      this.rowData.every((item) => this.service.canDelete(item))
    );
  }
  selectedRowNode: null | InvoiceLines;
  deleteInvoiceLines() {
    const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
    dialogRef.afterClosed().subscribe((result) => {
      console.log('clicked the download button');
      if (result == true) {
        if (this.canWrite() && this.isAbleToDeleteInvoiceLines()) {
          this.service
            .deleteInvoiceLines(this.invoiceLines.id)
            .subscribe((result: any) => {
              this.service
                .postInvoiceLineData(this.formData)
                .subscribe((response: any) => {
                  console.log('left form');
                  console.log(response);
                  this.rowData = response.adjustments;
                  console.log('hiii', this.rowData);
                });
            });
        }
      }
    });
  }
  onInputChange() {
    this.isFormDirty = false;
  }
  canWrite2: boolean = true
  async permissionMethod() {
    try {
      const permission1 = await this.permission.canWrite('ApplyPeriodicCharges');
      const permission2 = await this.permission.canWrite('EnterAdjustments');
      const canWriteBoth = permission1 || permission2;
      console.log("Can write both permissions:", canWriteBoth);
      this.canWrite2 = canWriteBoth;
    } catch (error) {
      console.error("Error:", error);
    }
  }
  canWrite() {
    return this.canWrite2;
  }

  ok: boolean = false;
  sum: number = 0;
  selectedRow: any = null;
  closeDialog() {
    this.isDivVisible = false;
    // Get a reference to the grid API
    var gridApi = this.gridOptions.api;
    // Call deselectAll to unselect all selected rows
    gridApi.deselectAll();
  }
  dataForRightSideForm(id: any) {
    this.isDivVisible = true;
    this.service.getInvoiceLineById(id).subscribe((response) => {
      console.log('Resource:', response);
      this.invoiceLines = response;
      console.log(this.invoiceLines);
      this.matchedDriver = this.findDriverById(this.invoiceLine.driverId);
    });
  }
  printRowValue: any;
  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code', rowCount);
    if (rowCount == 1) {
      this.printRowValue = event.api.getSelectedNodes()[0].data;
      console.log('here', event.api.getSelectedNodes()[0].data);
      this.isDivVisible = true;
      this.ok = true;
      this.dataForRightSideForm(event.api.getSelectedNodes()[0].data.id);
    } else {
      this.isDivVisible = false;
      this.ok = false;
    }
  }
  onClearLineType() {
    // Handle the clear event here, you can reset the form control value
    this.selectedlineTypes = null;
  }
}

import { Component } from '@angular/core';
import { SearchService } from '../services/search.service';
import { Line, PayAdvice } from '../model/search.model';
import { ColDef, GridReadyEvent } from 'ag-grid-community';
import { DatePipe } from '@angular/common';
import { DateFormateComponent } from '../services/date-formate/date-formate.component';
import {
  PayAdvicePreview,
  PayAdvicePreviewRequest,
} from '../../reportview/model/report-view.model';

import { ViewChild } from '@angular/core';
import { GridApi } from 'ag-grid-community';
import { MatSelect } from '@angular/material/select';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import * as moment from 'moment';
import { TimeRunsheetService } from '../../reconcile/services/time-runsheet.service';
import { PlanService } from '../../plan/services/plan.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-pay-advice',
  templateUrl: './pay-advice.component.html',
  styleUrls: ['./pay-advice.component.scss'],
  // encapsulation:ViewEncapsulation.None,
})
export class PayAdviceComponent {
  ok: boolean = false;
  filteredDrivers: any;
  private gridApi!: GridApi<any>;

  constructor(
    public planService: PlanService,
    private service: SearchService,
    private datePipe: DatePipe,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    private timezone: TimeRunsheetService,
    public authenticationService: AuthenticationService
  ) {
    this.gridOptions = {
      context: { Component: this },
    };
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          console.log('create:', data);
          this.dialogService.savaLayout(data);
        }
      }
    );
    // this.getView();
  }
  /**for drop down data */
  companies: any[] = [];
  userName: any;
  selectedSite: any;
  columnApi: any;
  columnState: any;
  gridOptions: any;
  applicationOptions: any;
  applicationId: any;
  layoutSubscription: Subscription;
  /**
   * for ag grid drop down for Company ID
   */
  //autocomplete for dropdowns
  selectedCompanies: any;
  filteredCompanies: any[];
  filteredCompanie(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.companies.length; i++) {
      let country = this.companies[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredCompanies = filtered;
  }

  onClearComapnyID() {
    this.selectedCompanies = '';
  }

  /**
   * For Ag-Grid Dropdown for Status
   */
  status: any[] = ['HOLD', 'PRINTED', 'READY'];
  selectedStatus: any;
  filteredStatus: any[];
  filterStatus(event: any) {
    let filtered: any[] = [];
    let query = event.query;


    for (let i = 0; i < this.status.length; i++) {
      let country = this.status[i];
      if (country.toLowerCase().includes(query.toLowerCase())) {
        filtered.push(country);
      }
    }
    this.filteredStatus = filtered;
  }

  onCleaStatus() {
    this.selectedStatus = '';
  }

  payAdviceTable: PayAdvice[] = [];
  payAdvice!: PayAdvice;
  lines: Line[] = [];

  /**For Driver data */
  drivers: any[] = [];
  payAdviceReportFormats: any[] = [];
  companie1: any[] = [];
  ngOnInit() {
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.authenticationService.viewAPI.subscribe((data: any) => {
      // console.log('onInit',data.ref.drivers);
      this.companies = data.ref.companys.map(
        (obj: { companyId: any }) => obj.companyId
      );
      console.log(this.companies);
      this.companie1 = data.ref.companys.map(
        (obj: { companyId: any }) => obj
      );
      console.log(this.companie1);
      this.payAdviceReportFormats = data.ref.payAdviceReportFormats;
      console.log('payAdviceReportFormats', this.payAdviceReportFormats);

      this.drivers = data.ref.drivers;
      console.log(this.drivers);
    });
  }

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  appOptionPayload: any = { };
  
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.reconcile.create-pay-advice.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.create-pay-advice.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.reconcile.create-pay-advice.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }
  formData: any = {
    payAdviceNo: null,
    status: null,
    companyId: null,
    payAdviceDate: null,
    issuedDate: null,
  }; // Initialize the form data fields as null

  /**
   * Here on submitt form we can send data to backend as post
   * And receive data we can display in frontend
   */
  PayAdviceDate: Date;
  IssuedDate: any;

  submitForm() {
    this.formData.companyId = this.selectedCompanies;
    this.formData.status = this.selectedStatus;
    if (this.PayAdviceDate != null) {      
      this.formData.payAdviceDate = this.timezone.convertDatetoMilliseconds(this.PayAdviceDate);
    } else if (this.PayAdviceDate == null) {
      this.formData.payAdviceDate = null;
    }
    if (this.IssuedDate != null) {
      this.formData.issuedDate = this.timezone.convertDatetoMilliseconds(this.IssuedDate);
    } else {
      this.formData.issuedDate = null;
    }
    this.service.postData(this.formData).subscribe((response: any) => {
      // Handle the response here if needed
      console.log('Response:', response);
      this.payAdviceTable = response.payadvices;
      console.log(this.payAdviceTable);
      if(this.payAdviceTable){
        this.payAdviceTable.forEach((row) =>{
          if(row){
            const matchingSites = this.payAdviceReportFormats.find((ele: any) => ele.id === row.defaultPaFormat);
            if(matchingSites){
              row.defaultPaFormat = matchingSites.name;
            }
          }
        })
      }
    });
  }

  /**
   * For right side Form table
   */
  displayedColumns: string[] = [
    'demo-position',
    'demo-name',
    'demo-weight',
    'demo-symbol',
    'demo-amount',
  ];
  dataSource: any;

  isDivVisible: boolean = false;
  selectedRow: any = null;
  checkboxClicked: boolean = false;

  /**
   * ag -grid table
   *
   */
  CurrencyCellRendererUSD(params: any) {
    var inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    });
    return inrFormat.format(params.value);
  }
  colDefs: ColDef[] = [
    // { cellRenderer: CellRendarComponent,width:50,headerName: '✔', cellRendererParams: {
    //   selectedRow: null, // Initially, no row is selected
    // }, },
    {
      headerName: 'Check Box',
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      headerName: 'Pay Advice',
      field: 'id',
      resizable: true,
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'From',
      field: 'fromDate',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      headerName: 'To',
      field: 'toDate',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      resizable: true,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      headerName: 'Company Code',
      field: 'companyId',
      width: 190,
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'Company Type',
      field: 'companyType',
      width: 190,
      filter: true,
      floatingFilter: true,
      valueGetter: params => {
        if (params.node && params.node.data) {
          const row = params.node.data;
          const matchingCompany = this.companie1.find((ele: any) => ele.companyId === row.companyId);
          if (matchingCompany) {
            return matchingCompany.companyType;
          }
        }
        return null; // Or any default value you want to return if no match is found
      }
    },
    {
      headerName: 'Status',
      field: 'statusId',
      width: 190,
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'Description',
      field: 'payAdviceText',
      width: 190,
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'Issue Date',
      field: 'issueDate',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      width: 190,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
    {
      headerName: 'Pa Formate',
      field: 'paFormat',
      width: 190,
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'Default Pa Formate',
      field: 'defaultPaFormat',
      width: 190,
      filter: true,
      floatingFilter: true,
    },
    {
      headerName: 'Base Ex GST',
      field: 'baseExGst',
      width: 190,
      filter: true,
      floatingFilter: true,
      cellRenderer: this.CurrencyCellRendererUSD 
    },
    {
      headerName: 'Total Ex GST',
      field: 'totalExGst',
      width: 190,
      filter: true,
      floatingFilter: true,
      cellRenderer: this.CurrencyCellRendererUSD 
    },
    {
      headerName: 'Created On',
      field: 'created',
      cellRenderer: (params: any) => {
        const timestamp = params.value;
        const date = new Date(timestamp);
        return moment(date).tz('Australia/Melbourne').format('DD/MM/YYYY');
      },
      width: 190,
      filter: 'agTextColumnFilter',
      filterParams: {
        filterOptions: ['contains'], // Use 'contains' filter option
        textMatcher: function (filter: any, value: any) {
          const formattedValue = moment
            .unix(filter.value / 1000)
            .tz('Australia/Melbourne')
            .format('DD/MM/YYYY')
            .toLowerCase();
          const formattedFilter = filter.filterText;

          console.log('Formatted Value:', formattedValue);
          console.log('Formatted Filter:', formattedFilter);

          return formattedValue.includes(formattedFilter);
        },
      },
      floatingFilter: true,
    },
  ];

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: true,
    sortable: true,
    resizable: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    // editable: true,
  };

  /**
   * ag-grid top right side corner
   */
  @ViewChild('mySelect') mySelect: MatSelect;
  columnDefs: ColDef[] = this.colDefs;
  selectedOptions: any[];
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.colDefs.filter(
      (column) => event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  /**
   * This is used to clear all filter
   */
  clearFilters() {
    this.colDefs.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
  /**
   * Here getting inpot as Array Buffer
   * then handeling it and printing csv file as requried
   */
  downloadCsv() {
    this.service.postCsvDownload(this.formData).subscribe((res: any) => {
      // Assuming 'response' is the array buffer received from your HTTP request
      var arrayBuffer = res;
      var blob = new Blob([arrayBuffer], { type: 'text/csv' }); // Set the type to 'text/csv' for CSV files
      var url = window.URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'report.csv'; // Set the desired file name
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }
  /**
   * To fetch data on click onclick on check box or row
   */
  dataForRightSideForm(id: any) {
    this.service.getPayAdviceById(id).subscribe((response) => {
      this.payAdvice = response.payAdvice;
      this.lines = response.lines;
      // Map the lines array to include the associated driver object
      const linesWithDrivers = this.lines.map((line) => {
        const driverId = line.driverId;
        const driver = this.drivers.find((d) => d.id === driverId);
        return { ...line, driver }; // Spread operator to include the driver object
      });
      this.dataSource = linesWithDrivers;
    });
  }
  /**Storing row value as event for print function */
  printRowValue: any;
  /**
   * This method for row clicked and also over lap check box one
   */
  rightSideForm(event: any) {
    this.printRowValue = event.data;
    console.log('row click', event);
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code in row clicked', rowCount);
    if (rowCount > 1) {
      // Get a reference to the grid API
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
      // Select the clicked row
      event.node.setSelected(true);
    }
  }
  /**
   * This method for checkbox event
   * @param event
   * Here we are checking tht overall row count,
   * if rowcount == 1
   * then we will go to call right side api and display
   * else
   * make false (to display right side)
   */
  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    if (rowCount == 1) {
      this.printRowValue = event.api.getSelectedNodes()[0].data;
      this.isDivVisible = true;
      this.ok = true;
      this.dataForRightSideForm(event.api.getSelectedNodes()[0].data.id);
    } else {
      this.isDivVisible = false;
      this.ok = false;
    }
  }
  /**
   * To close right side and unselect the selected one
   */
  closeDialog() {
    this.ok = false;
    this.isDivVisible = false;
    // Get a reference to the grid API
    var gridApi = this.gridOptions.api;
    // Call deselectAll to unselect all selected rows
    gridApi.deselectAll();
  }
  /**
   *
   */
  showZero: boolean = false;
  /**
   * Print function
   */
  onPrintWithCompanyFormatClick() {
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    let payAdviceParam: PayAdvicePreview[] = [
      {
        id: this.printRowValue.id, // 215587,
        siteId: this.printRowValue.siteId, // 296,
        paFormat: this.printRowValue.paFormat, // null,
        defaultPaFormat: this.printRowValue.defaultPaFormat, // 7
      },
    ];

    // create request params
    let payAdvicePreviewParam: PayAdvicePreviewRequest = {
      defaultCustFormat: true,
      paFormat: null,
      payrollCodeRequired: false,
      payAdvice: payAdviceParam,
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(payAdvicePreviewParam));

    // open report view window
    window.open('/reportview?payAdvicePreview=' + requestParam, '_blank');
  }

  onPrintPayAdviceFormatClick(id: any) {
    // TODO: this is just mock parameters. replace with data from selected rows in grid.
    let payAdviceParam: PayAdvicePreview[] = [
      {
        id: this.printRowValue.id, // 215587,
        siteId: this.printRowValue.siteId, // 296,
        paFormat: this.printRowValue.paFormat, // null,
        defaultPaFormat: this.printRowValue.defaultPaFormat, // 7
      },
    ];

    // create request params
    let payAdvicePreviewParam: PayAdvicePreviewRequest = {
      defaultCustFormat: false,
      paFormat: id, //4, // TODO: change this to what was chosen in the pay advice format list.
      payrollCodeRequired: false,
      payAdvice: payAdviceParam,
    };

    // encode params
    let requestParam = window.btoa(JSON.stringify(payAdvicePreviewParam));

    // open report view window
    window.open('/reportview?payAdvicePreview=' + requestParam, '_blank');
  }
}

import { Component, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import {
  ColDef,
  GridApi,
  GridOptions,
  GridReadyEvent,
  RowNode,
} from 'ag-grid-community';

import { SearchService } from '../services/search.service';
import { pagination } from 'src/app/shared/model/shared.model';
import { Services } from '../model/search.model';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Permissions } from 'src/app/shared/model/context-vew.model';
import { DeleteInvoiceLinesComponent } from '../delete-invoice-lines/delete-invoice-lines.component';
import { MatDialog } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { Subscription } from 'rxjs';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { ServiceDateCycle } from '../../plan/models/plan.model';
import { PlanService } from '../../plan/services/plan.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
import * as moment from 'moment';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-services-list',
  templateUrl: './services-list.component.html',
  styleUrls: ['./services-list.component.scss'],
})
export class ServicesListComponent {
  gridApi!: GridApi<any>;
  columnFields: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'docket',
      headerName: 'Docket',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'serviceid',
      headerName: 'Service ID',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'serviceno',
      headerName: 'Service No.',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'servicetypeid',
      headerName: 'Service type',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'servicedate',
      headerName: 'Service Date',
      type: 'DATE',
      cellRenderer: (milliseconds: any) => {
        return moment(milliseconds.value)
          .tz('Australia/Melbourne')
          .format('DD/MM/YYYY');
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'customerid',
      headerName: 'Customer ID',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'customergroupid',
      headerName: 'Customer Group',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'truckid',
      headerName: 'Truck',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'trailerid',
      headerName: 'Trailer',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'containerid',
      headerName: 'Container',
      type: 'container',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'containertypeid',
      headerName: 'Container type',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'locationid_pickup',
      headerName: 'Location Pickup',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'locationid_drop',
      headerName: 'Location Drop',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'enteredby',
      headerName: 'Entered by',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'loadid',
      headerName: 'Load',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtydesc',
      headerName: 'Qty Desc',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'locations',
      headerName: 'Locations',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'holdcode',
      headerName: 'Hold Code',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'complete',
      headerName: 'Complete',
      type: 'boolean',
      cellRenderer: 'agCheckboxCellRenderer',
      cellRendererParams: {
        disabled: true,
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'originsite',
      headerName: 'Origin Site',
      type: 'site',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'destinationsite',
      headerName: 'Destination Site',
      type: 'site',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'originloc',
      headerName: 'Origin Loc',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'destinationloc',
      headerName: 'Destination Loc',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'invoiceid',
      headerName: 'Invoice',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'companyid',
      headerName: 'Company ID',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'employeename',
      headerName: 'Employee Name',
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'firstname',
      headerName: 'Firstname',
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'lastname',
      headerName: 'Lastname',
      cellDataType: 'text',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'runsheetid',
      headerName: 'Runsheet ID',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'customerid_load',
      headerName: 'Customer ID Load',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'loadno',
      headerName: 'Load No.',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'loadtypeid',
      headerName: 'Load type',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'scheduleddate',
      headerName: 'Scheduled Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'holdcode_load',
      headerName: 'Holdcode Load',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'complete_load',
      headerName: 'Complete Load',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'batchno',
      headerName: 'ConNote',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'locationid',
      headerName: 'Location',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'custreference',
      headerName: 'Cust Ref.',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'customergroupid_load',
      headerName: 'Customer Group Load',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty1',
      headerName: 'Qty 1',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit1',
      headerName: 'Unit 1',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty2',
      headerName: 'Qty 2',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit2',
      headerName: 'Unit 2',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty3',
      headerName: 'Qty 3',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit3',
      headerName: 'Unit 3',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty4',
      headerName: 'Qty 4',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit4',
      headerName: 'Unit 4',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty5',
      headerName: 'Qty 5',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit5',
      headerName: 'Unit 5',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty6',
      headerName: 'Qty 6',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit6',
      headerName: 'Unit 6',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty7',
      headerName: 'Qty 7',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit7',
      headerName: 'Unit 7',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qty8',
      headerName: 'Qty 8',
      type: 'DECIMAL',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'unit8',
      headerName: 'Unit 8',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtya',
      headerName: 'Qty A',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtyb',
      headerName: 'Qty B',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtyc',
      headerName: 'Qty C',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtyd',
      headerName: 'Qty D',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtye',
      headerName: 'Qty E',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtyf',
      headerName: 'Qty F',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtyg',
      headerName: 'Qty G',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'qtyh',
      headerName: 'Qty H',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'sloadtype',
      headerName: 'S Load type',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'trailerid_tag',
      headerName: 'Trailer Tag',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'chargeamt',
      headerName: 'Charge Amount',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'rateid',
      headerName: 'Rate',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'driverrate',
      headerName: 'Driver Rate',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'driverpay',
      headerName: 'Driver Pay',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'tripid_cust',
      headerName: 'Trip Cust',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'datasourceid',
      headerName: 'Datasource',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'tripid',
      headerName: 'Trip',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'tripdate',
      headerName: 'Trip Date',
      type: 'DATE',
      cellRenderer: (data: any) => {
        return data.value ? new Date(data.value).toLocaleDateString() : '';
      },
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'driver',
      headerName: 'Driver',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'used',
      headerName: 'Used',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
    {
      field: 'servicedesc',
      headerName: 'Service Desc',
      type: 'TEXT',
      filter: true,
      floatingFilter: true,
    },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public rowData: Services[] = [];
  selectedNodes: RowNode[];
  defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    filter: 'agTextColumnFilter',
    floatingFilter: false,
    sortable: true,
    resizable: true,
    suppressMenu: true,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
  };
  serviceDetailsForm: FormGroup;
  tableGridChnages: boolean = false;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  @ViewChild('mySelect') mySelect: MatSelect;
  editForm: Services | null;
  formSearchDetails: any;
  pagination: pagination = {
    pageNumber: 1,
    recordsPerPage: 10000,
    orderType: 'DESC',
    orderByField: 'serviceid',
  };
  selectedServices: any;

  totalRecords: number = 0;
  canDelete: boolean = false;
  searchForm: any;
  setupPermission: Permissions;
  gridOptions: GridOptions;
  selectedOptions: any[];
  userName: any;
  selectedSite: any;
  columnApi: any;
  columnState: any;
  applicationOptions: any;
  applicationId: any;
  layoutSubscription: Subscription;
  constructor(
    private searchServices: SearchService,
    private authenticationService:AuthenticationService,
    private sharedDervice: SharedService,
    private planService: PlanService,
    private dialog: MatDialog,
    public dialogService: DialogService,
    public navbarService: NavbarService,
    public permission: PermissionsService
  ) {
    (this.gridOptions = <GridOptions>{
      onRowSelected: function (event) {
        if (event.node.isSelected()) {
          event.node.setSelected(true);
        }
      },
    }),
      (this.gridOptions = {
        context: { Component: this },
      });
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          this.dialogService.savaLayout(data);
        }
      }
    );
    this.getView();
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
  }
  canWrite2: boolean = true;
  async permissionMethod() {
    try {
      const permission1 = await this.permission.canWrite('AllocationByRoute');
      this.canWrite2 = permission1;
    } catch (error) {
      console.error('Error:', error);
    }
  }
  

  onGridReady(params: GridReadyEvent) {
    this.columnApi = params.columnApi;
    this.gridApi = params.api;
    this.getLayout();
  }
  appOptionPayload: any = {};
  
  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter
        }
        columns.push(customColumn)

      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = this.navbarService.selectedSiteId;
      console.log("site:", this.selectedSite);
      return {
        "applicationOptionId": this.applicationId,
        "optionName": "a2v3.setup.Search.Services.grid.layout",
        "optionValue": columnValueObj,
        "siteId": this.selectedSite,
        "userId": this.userName
      }
    }
  }

  getView() {
    this.planService.getView().subscribe((result: any) => {
      if (result) {
        this.applicationOptions = result.applicationOptions;
        console.log("applicationn optionsss:", this.applicationOptions);
        this.applicationOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Services.grid.layout")
            this.applicationId = JSON.parse(item["applicationOptionId"]);
          console.log("id:", this.applicationId)
        })
      }
    })
  }


  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item["optionName"] === "a2v3.setup.Search.Services.grid.layout")
            this.columnState = JSON.parse(item["optionValue"]);
          if (this.columnState) {

            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ("name" in column) {
                  column.colId = column.name;
                  delete column.name
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        })
      });
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true
    }
    this.columnApi.getColumnState().map((obj: any) => {
      const matchingObj = this.columnState.find((obj2: any) => obj2.colId === obj.colId);
      if (!matchingObj) {
        this.columnState.push({ colId: obj.colId, visible: false, width: obj.width, sort: null })
      }
    })

    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width, visible }: { colId: any, width: any, visible: boolean }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
        this.columnApi.setColumnVisible(column, visible)
      }
    })

  }
  ngOnInit(): void {
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.searchViewDetails();
    this.planService.ServiceSearchupdate.subscribe((res) => {
      console.log('INSIDE SEARCH UPDATED SERVICE: ', res);
      let matchRow=this.rowData.find((r)=>r.serviceno==res[0].serviceNo)
      const matchingrowindex = this.rowData.findIndex(
        (n) => n.serviceno == res[0].serviceNo
      );
      if (matchingrowindex !== -1) {
        var rowNode = this.gridApi.getRowNode(String(matchingrowindex));
        let temp = {
          batchno: matchRow?.batchno,
          chargeamt: res[0].chargeAmt,
          companyid: matchRow?.companyid,
          complete: res[0].complete,
          complete_load: matchRow?.customergroupid_load,
          containerid: res[0].containerId,
          containertypeid: res[0].containerTypeId,
          customergroupid: matchRow?.customergroupid,
          customergroupid_load:matchRow?.customergroupid_load,
          customerid: res[0].customerId,
          customerid_load: matchRow?.customerid_load,
          custreference: matchRow?.custreference,
          datasourceid:res[0].dataSourceId,
          destinationloc: res[0].destinationLoc,
          destinationsite: res[0].destinationSite,
          docket: res[0].docket,
          driver: matchRow?.driver,
          driverid: res[0].driverId,
          driverpay: matchRow?.driverpay,
          driverrate: matchRow?.driverrate,
          droparrivetemp: matchRow?.droparrivetemp,
          dropdeparttemp: matchRow?.dropdeparttemp,
          dropdoctemp: matchRow?.dropdoctemp,
          dropreadytemp: matchRow?.dropreadytemp ,
          employeename: matchRow?.employeename,
          enteredby: res[0].enteredBy,
          firstname: matchRow?.firstname,
          holdcode: res[0].holdcode,
          holdcode_load: matchRow?.holdcode_load,
          invoiceid: matchRow?.invoiceid,
          lastname: matchRow?.lastname,
          loadid: res[0].loadId,
          loadno: res[0].loadNo,
          loadtypeid: res[0].loadTypeId,
          locationid: matchRow?.locationid,
          locationid_drop: res[0].locationIdDrop,
          locationid_pickup: res[0].locationIdPickup,
          locations: matchRow?.locations,
          originloc: res[0].originLoc,
          originsite: res[0].originSite,
          pickuparrivetemp: matchRow?.pickuparrivetemp,
          pickupdeparttemp: matchRow?.pickupdeparttemp,
          pickupdoctemp: matchRow?.pickupdoctemp,
          pickupreadytemp: matchRow?.pickupreadytemp,
          qty1: res[0].qty1,
          qty2: res[0].qty2,
          qty3: res[0].qty3,
          qty4: res[0].qty4,
          qty5: res[0].qty5,
          qty6: res[0].qty6,
          qty7: res[0].qty7,
          qty8: res[0].qty8,
          qtya:matchRow?.qtya,
          qtyb:matchRow?.qtyb,
          qtyc: matchRow?.qtyc,
          qtyd:matchRow?.qtyd,
          qtydesc: matchRow?.qtydesc,
          qtye: matchRow?.qtye,
          qtyf: matchRow?.qtyf,
          qtyg: matchRow?.qtyg,
          qtyh: matchRow?.qtyh,
          rateid: res[0].rateId,
          runsheetid: matchRow?.runsheetid,
          scheduleddate: matchRow?.scheduleddate,
          servicedate: res[0].serviceDate,
          servicedesc: res[0].serviceDesc,
          serviceid: res[0].id,
          serviceno: res[0].serviceNo,
          servicetypeid: res[0].serviceTypeId,
          siteid: res[0].siteId,
          sloadtype: matchRow?.sloadtype,
          trailerid: res[0].trailerId,
          trailerid_tag: res[0].trailerIdTag,
          tripdate: matchRow?.tripdate,
          tripid: res[0].tripId,
          tripid_cust: res[0].tripIdCust,
          truckid: res[0].truckId,
          unit1: res[0].unit1,
          unit2: res[0].unit2,
          unit3: res[0].unit3,
          unit4: res[0].unit4,
          unit5: res[0].unit5,
          unit6: res[0].unit6,
          unit7: res[0].unit7,
          unit8: res[0].unit8,
          used: res[0].used,
        };
        rowNode?.setData(temp);
      }
    });
    this.authenticationService.viewAPI.subscribe((res: any) => {
      this.getsites(res['ref'].sites);
    });
  }
  sites: any[] = [];
  getsites(sites: any[]) {    
    sites.forEach((element) => {
        this.sites.push(element);
      });  
  }
  searchViewDetails() {
    this.searchServices.getSearchView().subscribe((result: any) => {
      this.setupPermission = result.permissions.sitePermissions[0].permissions;

      // this.rowData = result;
    });
  }
  canRead() {}

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }
  fromSearch: any;
  toSearch: any;
  getFormDetails(event: any) {
    event.pagination = this.pagination;
    this.formSearchDetails = event;
    this.fromSearch = event.svcDateFrom;
    this.toSearch = event.svcDateTo;
    setTimeout(() => {
      this.ServiceList(event);
    }, 500);
  }

  ServiceList(event: any) {
    this.searchForm = event;
    this.searchServices.getSearchList(event).subscribe((result: any) => {
      console.log('All Services:', result.services);
      this.rowData = result.services;
      console.log('-------------------------', this.rowData);
      this.pagination.pageNumber = result.pagination.currentPage;
      this.totalRecords = result.pagination.totalRecords;
      if(this.rowData){
        this.rowData.forEach((row) =>{
          console.log("------row------",row);
          if(row){
            const matchingSites = this.sites.find((ele: any) => ele.id === row.originsite);
            if (matchingSites) {
              row.originsite = matchingSites.description; // Assigning the value to result.originsite
            }
          }
          if(row){
            const matchingSites = this.sites.find((ele: any) => ele.id === row.destinationsite);
            if (matchingSites) {
              row.destinationsite = matchingSites.description; // Assigning the value to result.originsite
            }
          }
        });
      }
    });
  }
  onselectionrow: any;
  servicedata: ServiceDateCycle = {
    address: undefined,
    bookedTimeDrop: undefined,
    bookedTimePickup: undefined,
    chargeAmt: undefined,
    chargeDesc: undefined,
    chargeZoneDrop: undefined,
    chargeZonePickup: undefined,
    complete: false,
    containerId: undefined,
    containerTypeId: undefined,
    created: 0,
    curfewWindow: undefined,
    customerId: '',
    customerSite: undefined,
    dataSourceId: '',
    dehireDeadline: undefined,
    dehirePark: undefined,
    delivered: false,
    deliveryClose: undefined,
    deliveryOpen: undefined,
    depot: undefined,
    despatchBy: undefined,
    destinationLoc: undefined,
    destinationSite: 0,
    docket: undefined,
    driverId: undefined,
    dropDesc: undefined,
    dropSuburb: undefined,
    enteredBy: '',
    etaUpdatedTime: undefined,
    exported: false,
    holdcode: undefined,
    id: 0,
    loadBatchNo: undefined,
    loadCustReference: undefined,
    loadDesc: undefined,
    loadDestination: '',
    loadId: 0,
    loadNo: '',
    loadScheduledDate: 0,
    loadSuburb: undefined,
    loadTypeId: '',
    locationIdDrop: '',
    locationIdPickup: '',
    locationIdPickupActual: undefined,
    offsiderUsed: false,
    operationType: undefined,
    originLoc: undefined,
    originSite: 0,
    podCreated: false,
    priority: undefined,
    qty1: undefined,
    qty2: undefined,
    qty3: undefined,
    qty4: undefined,
    qty5: undefined,
    qty6: undefined,
    qty7: undefined,
    qty8: undefined,
    rateId: undefined,
    reasonId: undefined,
    remarks: undefined,
    replicated: undefined,
    runsheetId: undefined,
    serviceDate: 0,
    serviceDesc: undefined,
    serviceGroup: undefined,
    serviceIdRecharge: undefined,
    serviceNo: '',
    serviceTypeId: '',
    siteId: 0,
    stopSeqDrop: undefined,
    stopSeqPickup: undefined,
    storeETA: undefined,
    todFlags: undefined,
    trailerId: undefined,
    trailerIdTag: undefined,
    tripId: undefined,
    tripIdCust: undefined,
    tripNo: undefined,
    tripSeq: undefined,
    truckId: undefined,
    unit1: '',
    unit2: '',
    unit3: '',
    unit4: undefined,
    unit5: undefined,
    unit6: undefined,
    unit7: undefined,
    unit8: undefined,
    used: false,
    usedSet: undefined,
    vesselEta: undefined,
    vesselId: undefined,
    wharf: undefined,
    window1: undefined,
    window1From: undefined,
    window1To: undefined,
    window2: undefined,
    window2From: undefined,
    window2To: undefined,
    window3: undefined,
    window3From: undefined,
    window3To: undefined,
  };
  onSelectionChanged(event: any) {
    var rowCount = event.api.getSelectedNodes().length;
    this.editForm = null;
    if (rowCount == 1) {
      this.editForm = event.api.getSelectedNodes()[0].data;
    } else if (rowCount == 0) {
      this.searchServices.setMessage(false);
    }
    this.onselectionrow = event.api.getSelectedNodes().map((rowNode: any) => {
      return rowNode.data;
    });
    this.servicedata.chargeAmt = this.onselectionrow[0].chargeAmt;
    this.servicedata.complete = this.onselectionrow[0].complete;
    this.servicedata.containerId = this.onselectionrow[0].containerid;
    this.servicedata.containerTypeId = this.onselectionrow[0].containertypeid;
    this.servicedata.customerId = this.onselectionrow[0].customerid;
    this.servicedata.dataSourceId = this.onselectionrow[0].datasourceid;
    this.servicedata.destinationLoc = this.onselectionrow[0].destinationloc;
    this.servicedata.destinationSite = this.onselectionrow[0].destinationsite;
    this.servicedata.docket = this.onselectionrow[0].docket;
    this.servicedata.driverId = this.onselectionrow[0].driverid;
    this.servicedata.enteredBy = this.onselectionrow[0].enteredby;
    this.servicedata.holdcode = this.onselectionrow[0].holdcode;
    this.servicedata.loadId = this.onselectionrow[0].loadid;
    this.servicedata.loadTypeId = this.onselectionrow[0].loadtypeid;
    this.servicedata.locationIdDrop = this.onselectionrow[0].locationid_drop;
    this.servicedata.locationIdPickup =
      this.onselectionrow[0].locationid_pickup;
    this.servicedata.originLoc = this.onselectionrow[0].originloc;
    this.servicedata.originSite = this.onselectionrow[0].originsite;
    this.servicedata.qty1 = this.onselectionrow[0].qty1;
    this.servicedata.qty2 = this.onselectionrow[0].qty2;
    this.servicedata.qty3 = this.onselectionrow[0].qty3;
    this.servicedata.qty4 = this.onselectionrow[0].qty4;
    this.servicedata.qty5 = this.onselectionrow[0].qty5;
    this.servicedata.qty6 = this.onselectionrow[0].qty6;
    this.servicedata.qty7 = this.onselectionrow[0].qty7;
    this.servicedata.qty8 = this.onselectionrow[0].qty8;
    this.servicedata.rateId = this.onselectionrow[0].rateid;
    this.servicedata.runsheetId= this.onselectionrow[0].runsheetid
    this.servicedata.serviceDate = this.onselectionrow[0].servicedate;
    this.servicedata.serviceDesc = this.onselectionrow[0].servicedesc;
    this.servicedata.id = this.onselectionrow[0].serviceid;
    this.servicedata.serviceNo = this.onselectionrow[0].serviceno;
    this.servicedata.serviceTypeId = this.onselectionrow[0].servicetypeid;
    this.servicedata.siteId = this.onselectionrow[0].siteid;
    this.servicedata.trailerId = this.onselectionrow[0].trailerid;
    this.servicedata.trailerIdTag = this.onselectionrow[0].trailerid_tag;
    this.servicedata.tripId = this.onselectionrow[0].tripid;
    this.servicedata.tripIdCust = this.onselectionrow[0].tripid_cust;
    this.servicedata.truckId = this.onselectionrow[0].truckid;
    this.servicedata.unit1 = this.onselectionrow[0].unit1;
    this.servicedata.unit2 = this.onselectionrow[0].unit2;
    this.servicedata.unit3 = this.onselectionrow[0].unit3;
    this.servicedata.unit4 = this.onselectionrow[0].unit4;
    this.servicedata.unit5 = this.onselectionrow[0].unit5;
    this.servicedata.unit6 = this.onselectionrow[0].unit6;
    this.servicedata.unit7 = this.onselectionrow[0].unit7;
    this.servicedata.unit8 = this.onselectionrow[0].unit8;
    this.servicedata.used = this.onselectionrow[0].used;
    this.servicedata.loadNo = this.onselectionrow[0].loadno;

    this.selectedServices = this.servicedata;
    console.log(this.selectedServices);
    this.searchServices.setMessage(true);

      this.canDelete = !this.selectedServices.used
        // this.selectedServices.filter((services: any) => services.used).length >
        // 0
        //   ? true
        //   : false;
      // this.canDelete =
      //     this.selectedServices.filter((services: any) => services.complete)
      //       .length > 0
      //       ? true
      //       : false;
            console.log("-----------------------", this.canDelete)
  }

  onTabSelectToggle(event: any) {}

  downloadCSVServices() {
    let selectedFields;
    if (this.tableGridChnages) {
      selectedFields = this.columnDefs.map((column) => column.field);
    }
    let downloadCSVRequestBody = this.formSearchDetails;
    downloadCSVRequestBody.pagination = this.pagination;
    downloadCSVRequestBody.selectFields = selectedFields;
    this.searchServices
      .downLoadCSVService(downloadCSVRequestBody)
      .subscribe((result) => {
        if (result) {
          this.sharedDervice.downloadCSV(result, 'Search.Service.csv');
        }
      });
  }
  serviceid: Services;
  deleteServices() {
    const dialogRef = this.dialog.open(DeleteInvoiceLinesComponent);
    dialogRef.afterClosed().subscribe((result: any) => {
      if (result == true) {
        let data: any[] = [];
        // console.log("--------------------")
        let deletableServices = !this.selectedServices.used;
        // console.log("--------------------", deletableServices )
    //  if (deletableServices) {
          // this.selectedServices.forEach((element: any) => {
          //   data.push(element.id);
          // });
          if(deletableServices){
            data.push(this.selectedServices.id);
          }
          this.searchServices.deleteServices(data).subscribe((result: any) => {
            this.ServiceList(this.searchForm);
            this.editForm = null;
          });
        }
      //}
    });
  }
  canWrite() {
    return this.canWrite2;
  }
  isAbleToDeleteInvoiceLines() {
    return (
      this.canWrite() &&
      this.rowData &&
      this.rowData.length > 0 &&
      this.rowData.every((item) => this.searchServices.canDelete(item))
    );
  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.columnFields.filter(
      (column) => event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }

  /**
   * This is used to clear all filter
   */
  clearFilters() {
    this.columnFields.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
}

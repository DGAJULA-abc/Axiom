import { Injectable } from '@angular/core';
import { InvoicePreviewRequest, PayAdvicePreviewRequest } from '../model/report-view.model';
import { HttpClient } from '@angular/common/http';
import { apiEndpoint } from '../../../config/config.model';

@Injectable({
  providedIn: 'root'
})
export class ReportViewService {
  
  constructor(
    private http: HttpClient
  ) { }

  printInvoices (printParameter: InvoicePreviewRequest) {
    let options: InvoicePreviewRequest = printParameter;    
    return this.http.post<any>(apiEndpoint.printInvoices, options);   
  };

  printPayAdvices (printParameter: PayAdvicePreviewRequest) {
    let options: PayAdvicePreviewRequest = printParameter;    
    return this.http.post<any>(apiEndpoint.printPayAdvices, options);   
  };

  generateTripSheet (printParameter: number[]) {    
    return this.http.post(apiEndpoint.generateTripSheet, printParameter);
  };

  callQlrReport(qlrReportPreview: number) {
    let options :any = [];
    return this.http.get<any>(`${apiEndpoint.report.qlr}/${qlrReportPreview}/get-url`, options);    
  };

}

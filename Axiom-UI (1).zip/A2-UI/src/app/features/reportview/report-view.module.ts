import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { ReportViewComponent } from './report-view.component';
import { ReportViewRoutingModule } from './report-view-routing.module';
//import { PowerBIEmbedModule } from 'powerbi-client-angular';
// import { CommonModule, DatePipe } from '@angular/common';
// import { SearchRoutingModule } from './search-routing.module';
// import { SearchComponent } from './search.component';
// import { SharedModule } from 'src/app/shared/shared.module';
// import { ServicesListComponent } from './services-list/services-list.component';
// import { PayAdviceComponent } from './pay-advice/pay-advice.component';
// import { ServiceSearchFormComponent } from './services-list/service-search-form/service-search-form.component';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { InvoiceComponent } from './invoice/invoice.component';
// import { ViewInvoiceListComponent } from './view-invoice-list/view-invoice-list.component';
// import { CellRendarComponent } from './services/cell-rendar/cell-rendar.component';
// import { InvoiceLinesComponent } from './invoice-lines/invoice-lines.component';
// import { DateFormateComponent } from './services/date-formate/date-formate.component';
// import { PayAdviceLineComponent } from './pay-advice-line/pay-advice-line.component';

@NgModule({
  declarations: [
    ReportViewComponent,
    
  //   SearchComponent,
  //   ServicesListComponent,
  //   PayAdviceComponent,
  //   ServiceSearchFormComponent,
  //   InvoiceComponent,
  //   ViewInvoiceListComponent,
  //   CellRendarComponent,
  //   InvoiceLinesComponent,
  //   DateFormateComponent,
  //   PayAdviceLineComponent
  ],
  imports: [
    CommonModule,
    ReportViewRoutingModule,
    //PowerBIEmbedModule,
  //   FormsModule,
  //   SearchRoutingModule,
    SharedModule,
  //   ReactiveFormsModule,
  //   FormsModule,
    
  ],
  // providers:[DatePipe],
  exports: [
    ReportViewComponent
  ]
})
export class ReportViewModule { }

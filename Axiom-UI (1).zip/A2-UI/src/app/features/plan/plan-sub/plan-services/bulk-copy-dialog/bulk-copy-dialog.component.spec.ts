import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkCopyDialogComponent } from './bulk-copy-dialog.component';

describe('BulkCopyDialogComponent', () => {
  let component: BulkCopyDialogComponent;
  let fixture: ComponentFixture<BulkCopyDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkCopyDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BulkCopyDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

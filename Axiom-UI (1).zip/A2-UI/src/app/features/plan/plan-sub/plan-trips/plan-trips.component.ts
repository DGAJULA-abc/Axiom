import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewEncapsulation,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { catchError, Subscription, throwError } from 'rxjs';
import {
  ColDef,
  GridApi,
  GridReadyEvent,
  RowClassRules,
} from 'ag-grid-community';
import {
  DeleteTripPayload,
  Dock,
  Driver,
  Driver2,
  EventTypes,
  Reasons,
  ResourceAllocation,
  ResourceAllocationTable,
  ServiceDateCycle,
  Trailer,
  TripDateCycle,
  TripTable,
} from '../../models/plan.model';
import {
  ConfirmationService,
  ConfirmEventType,
  MessageService,
} from 'primeng/api';
import { PlanService } from '../../services/plan.service';
import { AllocatedDialogComponent } from './allocated-dialog/allocated-dialog.component';
import { DuplicateSelectedTripsDialogComponent } from './duplicate-selected-trips-dialog/duplicate-selected-trips-dialog.component';
import { ReasonDateChangeDialogComponent } from './reason-date-change-dialog/reason-date-change-dialog.component';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { DateformatTripsComponent } from '../../services/dateformat-trips/dateformat-trips.component';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import { MenuDialogComponent } from './menu-dialog/menu-dialog.component';
import * as moment from 'moment';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
@Component({
  selector: 'app-plan-trips',
  templateUrl: './plan-trips.component.html',
  styleUrls: ['./plan-trips.component.scss'],
  providers: [ConfirmationService, MessageService],
  encapsulation: ViewEncapsulation.None,
})
export class PlanTripsComponent implements OnInit, OnChanges {
  @Output() getselectedtrip: EventEmitter<TripDateCycle[]> = new EventEmitter<
    TripDateCycle[]
  >();
  @Output() getselectedtripservice: EventEmitter<ServiceDateCycle[]> =
    new EventEmitter<ServiceDateCycle[]>();
  @Input() dateCycleResult: any;
  @Input() selectedTrip: TripDateCycle[];
  @Input() CreatedTrip: TripDateCycle[];
  @Input() selecteddate_hm: any;
  selectedOptions: any[];
  checking: boolean = false;

  /**check for atmosphere */
  AtmosphereData: any;
  canWrite:boolean;
  private dataSubscription: Subscription;
  columnApi: any;
  columnState: any;
  userName: any;
  selectedSite: any;
  gridOptions: any;
  layoutSubscription: Subscription;
  totalrecords: number = 0;
  datefromDateCycle: any;

  calculateProgressbar() {
    this.totalcompleted = 0;
    this.totaldespatched = 0;
    this.totalplanned = 0;
    this.totalready = 0;
    this.totalrecords = 0;
    this.totaltransit = 0;
    this.totalrecords = this.rowData.length;

    this.rowData.forEach((element) => {
      if (element.status == 'planned') {
        this.totalplanned += 1;
      }
      if (element.status == 'despatched') {
        this.totaldespatched += 1;
      }
      if (element.status == 'transit') {
        this.totaltransit += 1;
      }
      if (element.status == 'ready') {
        this.totalready += 1;
      }
      if (element.status == 'complete') {
        this.totalcompleted += 1;
      }

    });
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.totalcompleted = 0;
    this.totaldespatched = 0;
    this.totalplanned = 0;
    this.totalready = 0;
    this.totalrecords = 0;
    this.totaltransit = 0;
    this.completewidth = 'width:';
    this.despatchwidth = 'width:';
    this.plannedwidth = 'width:';
    this.transitwidth = 'width:';
    this.readywidth = 'width:';
    this.isLoading = false;
    if (this.selectedTrip == null) {
      if (this.dateCycleResult) {
        this.datefromDateCycle = this.selecteddate_hm;
        if (
          this.dateCycleResult.trips.length != 0 ||
          this.dateCycleResult.services.length != 0 ||
          this.dateCycleResult.driverResources.length != 0
        ) {
          this.trips_date_cycle = this.dateCycleResult.trips;
          this.trip_service_data = this.dateCycleResult.services;
          if (this.dateCycleResult.driverResources.length != 0) {
            this.trip_driver_resources = this.dateCycleResult.driverResources;
            this.TableData(
              this.trips_date_cycle,
              this.trip_driver_resources[0].id
            );
          } else {
            this.TableData(this.trips_date_cycle, undefined);
          }
        } else {
          this.rowData = [];
        }
      }
    } 
    else {
      if (this.dateCycleResult && this.selectedTrip.length == 0) {
        if(this.dateflag){

        }
        else{
          this.datefromDateCycle = this.selecteddate_hm;
          if (
            this.dateCycleResult.trips.length != 0 ||
            this.dateCycleResult.services.length != 0 ||
            this.dateCycleResult.driverResources.length != 0
          ) {
            this.trips_date_cycle = this.dateCycleResult.trips;
            this.trip_service_data = this.dateCycleResult.services;
            if (this.dateCycleResult.driverResources.length != 0) {
              this.trip_driver_resources = this.dateCycleResult.driverResources;
              this.TableData(
                this.trips_date_cycle,
                this.trip_driver_resources[0].id
              );
            } else {
              this.TableData(this.trips_date_cycle, undefined);
            }
          } else {
            this.rowData = [];
          }
        }
      }
      
    }

    if (this.CreatedTrip) {
      if (this.CreatedTrip.length != 0) {
        this.rowData.forEach((element) => {
          if (element.trip == this.CreatedTrip[0].tripIdCust) {
            this.checking = true;
          } else {
            this.checking = false;
          }
        });
        if (!this.checking) {
          this.UpdateTableNewTrip(this.CreatedTrip);
        }
      }
    }
    if (this.selectedTrip.length != 0) {
      const matchingrowindex = this.rowData.findIndex(
        (n) => n.id == this.selectedTrip[0].id
      );
      if (matchingrowindex !== -1) {
        this.Updatetable(this.selectedTrip, matchingrowindex);
        this.dateCycleResult.trips.forEach((row:any,index:any) => {
          if(row.id==this.selectedTrip[0].id){
            this.dateCycleResult.trips.splice(index, 1);
            this.selectedTrip.forEach(element => {
              this.dateCycleResult.trips.push(element)
              
            });
          
        }}
        );
      }
    }
    this.gridApi.refreshCells();
    this.dateflag=false;
  }

  constructor(
    public permission: PermissionsService,
    public planService: PlanService,
    public dialog: MatDialog,
    private authenticationService:AuthenticationService,
    public timeService: TimeRunsheetService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    public dialogService: DialogService,
    public navbarService: NavbarService
  ) {
    this.gridOptions = {
      context: { Component: this },
      rowDragManaged: true,
      rowDragEntireRow: true,
      rowClassRules: {
        'row-planned': (params: any) =>
          params.api.getValue('status', params.node) == 'planned',
        'row-despatched': (params: any) =>
          params.api.getValue('status', params.node) == 'despatched',
        'row-complete': (params: any) =>
          params.api.getValue('status', params.node) == 'complete',
        'row-transit': (params: any) =>
          params.api.getValue('status', params.node) == 'transit',
        'row-ready': (params: any) =>
          params.api.getValue('status', params.node) == 'ready',
         
      },
      onRowDragEnd: () => {
        console.log('in Trips'); // Trigger your method here
      },
    };
    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe(
      (shouldSubscribe) => {
        if (shouldSubscribe) {
          let data = this.saveLayout();
          this.dialogService.savaLayout(data);
        }
      }
    );
  }

  saveLayout(): any {
    if (this.columnApi) {
      this.columnState = this.columnApi.getColumnState();
      let columns = [];
      for (let column of this.columnState) {
        const customColumn = {
          name: column.colId,
          visible: !column.hide,
          width: column.width,
          sort: column.sort,
          filter: column.filter,
        };
        columns.push(customColumn);
      }
      let columnValueObj: any = { columns };
      columnValueObj = JSON.stringify(columnValueObj);
      this.navbarService.usernameSubject.subscribe((username) => {
        this.userName = username;
      });
      this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!);
      return {
        applicationOptionId: 9776,
        optionName: 'a2v3.plan.trip-list.grid.layout',
        optionValue: columnValueObj,
        siteId: this.selectedSite,
        userId: this.userName,
      };
    }
  }

  getLayout() {
    this.navbarService.applicationOptions.subscribe(
      (applicationOptions: any) => {
        let appOptions = applicationOptions;
        let a = appOptions.filter((item: any) => {
          if (item['optionName'] === 'a2v3.plan.trip-list.grid.layout')
            this.columnState = JSON.parse(item['optionValue']);
          if (this.columnState) {
            if (this.columnState.columns) {
              this.columnState.columns.forEach((column: any) => {
                if ('name' in column) {
                  column.colId = column.name;
                  delete column.name;
                }
              });
              this.columnState = this.columnState.columns;
              this.applyLayout();
            }
          }
        });
      }
    );
  }

  applyLayout() {
    const applyColumnStateParams = {
      state: this.columnState,
      applyOrder: true,
    };
    this.columnApi.applyColumnState(applyColumnStateParams);
    this.columnState.forEach(({ colId, width }: { colId: any; width: any }) => {
      const column = this.columnApi.getColumn(colId);
      if (column) {
        this.columnApi.setColumnWidth(column, width);
      }
    });
  }

  //AG Grid configuration
  private gridApi!: GridApi<TripTable>;
  public rowSelection: 'single' | 'multiple' = 'single';
  public rowStyle = { color: '#007774' };
  rowData: TripTable[] = [];
  columnFields: ColDef[] = [
    {
      field: '',
      minWidth: 40,
      width: 40,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      filter: false,
      sortable: false,
      pinned: 'left',
    },
    {
      field: 'trip',
      headerName: 'Trip',
    },
    {
      field: 'startdatetime',
      headerName: 'Start date/time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'startdate',
      headerName: 'Start - Date',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'starttime',
      headerName: 'Start - Time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'enddatetime',
      headerName: 'End date/time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'enddate',
      headerName: 'End - Date',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'endtime',
      headerName: 'End - Time',
      cellRenderer: DateformatTripsComponent,
    },
    { field: 'totaltriptime', headerName: 'Total trip time' },
    { field: 'status', headerName: 'Status' },
    { field: 'despatched', headerName: 'Despatched' },
    {
      field: 'despatchdatetime',
      headerName: 'Despatch date/time',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'despatchdate',
      headerName: 'Despatch Date',
      cellRenderer: DateformatTripsComponent,
    },
    {
      field: 'despatchtime',
      headerName: 'Despatch Time',
      cellRenderer: DateformatTripsComponent,
    },
    { field: 'driver', headerName: 'Driver' },
    { field: 'truck', headerName: 'Truck' },
    { field: 'trailer', headerName: 'Trailer' },
    { field: 'firstpickup', headerName: 'First pickup' },
    { field: 'returnto', headerName: 'Return To' },
    { field: 'comments', headerName: 'Comments' },
    { field: 'remarks', headerName: 'Remarks' },
    { field: 'custref', headerName: 'CustRef' },
    { field: 'connote', headerName: 'ConNote' },
    { field: 'multidrop', headerName: 'Multi Drop' },
    { field: 'services', headerName: 'Services' },
    { field: 'dock', headerName: 'Dock' },
    { field: 'enteredby', headerName: 'Entered By' },
    { field: 'tonnes', headerName: 'TONNES' },
    { field: 'utilisation', headerName: 'Utilisation' },
    { field: 'curfewbreach', headerName: 'Curfew Breach' },
    { field: 'region', headerName: 'Region' },
    { field: 'firstdrop', headerName: 'First drop' },
    { field: 'lastdrop', headerName: 'Last drop' },
    { field: 'lastpickup', headerName: 'Last pickup' },
    { field: 'firstloadtype', headerName: 'First Load Type' },
    { field: 'dropsuburb', headerName: 'Drop Suburb' },
    { field: 'loadsuburb', headerName: 'Load Suburb' },
    { field: 'despatchbydatetime', headerName: 'Despatch By date/time' },
    { field: 'despatchbydate', headerName: 'Despatch By - Date' },
    { field: 'despatchbytime', headerName: 'Despatch By - Time' },
    { field: 'deliverywindow', headerName: 'Delivery Window' },
    { field: 'customerid', headerName: 'Customer ID' },
    { field: 'paperworkreadydate', headerName: 'Paper Work Ready - Date' },
    { field: 'paperworkreadytime', headerName: 'Paper Work Ready - Time' },
    { field: 'containerno', headerName: 'Container No.' },
    { field: 'companyid', headerName: 'Company ID' },
    { field: 'loadno', headerName: 'Load No.' },
    { field: 'vesselno', headerName: 'Vessel No.' },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    minWidth: 80,
    filter: 'agTextColumnFilter',
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };

  //disable/enable buttons on rowselection
  eventstab: boolean = true;
  moreactions: boolean = true;
  deletebtn: boolean = true;

  SiteId: number = 0;
  ngOnInit() {
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }

    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    this.planService.selectedRowGridS.subscribe((flagS)=>{
      if(flagS){
        this.gridApi.deselectAll();
      }
    })
    // Manually subscribe to data changes
    // this.dataSubscription = this.navbarService.data$.subscribe((data) => {
    //   this.AtmosphereData = data;
    //   if (this.AtmosphereData) {
    //     if (this.AtmosphereData.trips.length != 0) {
    //       const matchingrowindex = this.rowData.findIndex(
    //         (n) => n.id == this.AtmosphereData.trips[0].id
    //       );
    //       if (matchingrowindex !== -1) {
    //         this.Updatetable(this.AtmosphereData.trips, matchingrowindex);
    //         // if (this.AtmosphereData.trips[0].cachedStatus == 'P ') {
    //         //   this.totalplanned += 1;
    //         // }
    //         // if (this.AtmosphereData.trips[0].cachedStatus == 'D ') {
    //         //   this.totaldespatched += 1;
    //         //   this.totalplanned-=1;
    //         // }
    //         // if (this.AtmosphereData.trips[0].cachedStatus == 'U ') {
    //         //   this.totaldespatched += 1;
    //         // }
    //         // if(this.AtmosphereData.trips[0].cachedStatus == "L "){
    //         //   this.totaltransit += 1;
    //         // }
    //         // if(this.AtmosphereData.trips[0].cachedStatus == "T "){
    //         //   this.totaltransit += 1;
    //         // }
    //         this.calculateProgressbar();
    //         this.ProgressUpdates();

    //         this.messageService.add({
    //           severity: 'success',
    //           summary: '',
    //           detail: 'Table updated after atmosphere!',
    //         });
    //       }
    //     }
    //   }
    // });
    this.isLoading = false;
    this.authenticationService.viewAPI.subscribe((result) => {

      if (result) {
        this.ViewDataDrivers = result['ref'].drivers;
        this.ViewDataTrucks = result['ref'].trucks;
        this.ViewReasons = result['ref'].reasons;
        this.ViewEventTypes = result['ref'].eventTypes;
        this.ViewTrailers = result['ref'].trailers;
        this.ViewDocks = result['ref'].docks;
        this.getDrivers(this.ViewDataDrivers);
        this.getTrucks(this.ViewDataTrucks);
        this.getLoadTypes(result['ref'].loadTypes);
        this.getServiceTypes(result['ref'].serviceTypes);
      }
    });
    // TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
    this.SiteId = parseInt(sessionStorage.getItem('selectedSiteId')!)
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('AllocationByRoute');
      if(result1){
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }
      //console.log("Result:", this.canWrite,result1,; // Use the result here
      
    } catch (error) {
      console.error("Error:", error);
    }
  }

  /**Update table */
  Updatetable(thetrip: TripDateCycle[], matchingrowindex: any) {
    let temptrip: TripTable = {
      trip: '',
      id: '',
      startdatetime: '',
      startdate: '',
      starttime: '',
      enddatetime: '',
      enddate: '',
      endtime: '',
      totaltriptime: '',
      status: '',
      despatched: '',
      despatchdatetime: '',
      despatchdate: '',
      despatchtime: '',
      driver: '',
      truck: '',
      trailer: '',
      firstpickup: '',
      returnto: '',
      comments: '',
      remarks: '',
      custref: '',
      connote: '',
      multidrop: '',
      services: '',
      dock: '',
      enteredby: '',
      tonnes: '',
      utilisation: '',
      curfewbreach: '',
      region: '',
      firstdrop: '',
      lastdrop: '',
      lastpickup: '',
      firstloadtype: '',
      dropsuburb: '',
      loadsuburb: '',
      despatchbydatetime: '',
      despatchbydate: '',
      despatchbytime: '',
      deliverywindow: '',
      customerid: '',
      paperworkreadydate: '',
      paperworkreadytime: '',
      containerno: '',
      companyid: '',
      loadno: '',
      vesselno: '',
    };
    temptrip.trip = thetrip[0].tripIdCust;
    temptrip.startdate = thetrip[0].tripDate;
    temptrip.despatched = thetrip[0].despatched;
    temptrip.status = thetrip[0].cachedStatus;
    if (thetrip[0].cachedStatus == 'P ' ||thetrip[0].cachedStatus == 'AL' ||thetrip[0].cachedStatus == 'CN' ) {
      temptrip.status = 'planned';
      // this.totalplanned += 1;
    }
    if (thetrip[0].cachedStatus == 'R ' || thetrip[0].cachedStatus == 'U ' || thetrip[0].cachedStatus == 'D ' || thetrip[0].cachedStatus == 'DE' || thetrip[0].cachedStatus == 'RC' || thetrip[0].cachedStatus == 'LG' || thetrip[0].cachedStatus == 'LD' || thetrip[0].cachedStatus == 'TR' || thetrip[0].cachedStatus == 'UG' || thetrip[0].cachedStatus == 'UD' || thetrip[0].cachedStatus == 'RT' || thetrip[0].cachedStatus == 'E ') {
      temptrip.status = 'despatched';
      // this.totaldespatched += 1;
    }
    if (thetrip[0].cachedStatus == 'L '  || thetrip[0].cachedStatus == 'T ') {
      temptrip.status = 'transit';
      // this.totaltransit += 1;
    }
    if (thetrip[0].cachedStatus == 'CP'|| thetrip[0].cachedStatus == 'CR'|| thetrip[0].cachedStatus == 'F '|| thetrip[0].cachedStatus == 'FN'){
      temptrip.status = 'complete';
    }
    if (thetrip[0].cachedStatus == 'C ' || thetrip[0].cachedStatus == 'Y ' || thetrip[0].cachedStatus == 'A ' || thetrip[0].cachedStatus == 'PL' || thetrip[0].cachedStatus == 'RD') {
      temptrip.status = 'ready';
    }
    temptrip.startdate = thetrip[0].plannedStartTime;
    temptrip.starttime = thetrip[0].plannedStartTime;
    temptrip.startdatetime = thetrip[0].plannedStartTime;
    temptrip.enddatetime = thetrip[0].plannedFinishTime;
    temptrip.enddate = thetrip[0].plannedFinishTime;
    temptrip.endtime = thetrip[0].plannedFinishTime;
    temptrip.despatchbydatetime = thetrip[0].plannedDespatchTime;
    temptrip.despatchbydate=thetrip[0].plannedDespatchTime;
    temptrip.despatchbytime=thetrip[0].plannedDespatchTime;
    if (thetrip[0].actualDespatchTime) {
      temptrip.despatchdatetime = thetrip[0].actualDespatchTime;
      temptrip.despatchdate = thetrip[0].actualDespatchTime;
      temptrip.despatchtime = thetrip[0].actualDespatchTime;
    } else {
      temptrip.despatchdatetime = 0;
      temptrip.despatchdate = 0;
      temptrip.despatchtime = 0;
    }
    temptrip.totaltriptime = this.getActivityTime(
      thetrip[0].plannedFinishTime - thetrip[0].plannedStartTime
    );
    temptrip.truck = thetrip[0].truckId;
    temptrip.id = thetrip[0].id;
    if (thetrip[0].driverId == null) {
      temptrip.driver = '';
    } else {
      temptrip.driver = this.getDriverforTable(thetrip[0].driverId);
    }
    temptrip.trailer = thetrip[0].trailerId;
    temptrip.connote = thetrip[0].batchNo;
    temptrip.dock = this.getDockName(thetrip[0].dockId);
    temptrip.firstpickup = thetrip[0].firstPickup;
    temptrip.returnto = thetrip[0].returnLocationId;
    temptrip.comments = thetrip[0].comments;
    temptrip.remarks = thetrip[0].remarks;
    temptrip.custref = thetrip[0].custRef;
    temptrip.multidrop = thetrip[0].multiDrop;
    temptrip.services = thetrip[0].serviceIds.length;
    temptrip.enteredby = thetrip[0].enteredBy;
    temptrip.utilisation =
      Math.round(Number(thetrip[0].utilization) * 100) / 100;
    temptrip.firstdrop = thetrip[0].firstDrop;
    temptrip.lastdrop = thetrip[0].lastDrop;
    temptrip.lastpickup = thetrip[0].lastPickup;
    temptrip.firstloadtype = thetrip[0].firstLoadType;
    temptrip.dropsuburb = thetrip[0].dropSuburb;
    temptrip.loadsuburb = thetrip[0].loadSuburb;
    temptrip.companyid = thetrip[0].companyId;
    temptrip.loadno = thetrip[0].loadNo;
    var rowNode = this.gridApi.getRowNode(String(matchingrowindex));

    rowNode?.setData(temptrip);
    // Find the index of the updated row in your rowData array
    const rowIndex = this.rowData.findIndex(
      (row) => row.trip === temptrip.trip
    );

    // Update the rowData array with the new data
    if (rowIndex !== -1) {
      this.rowData[rowIndex] = temptrip;

      // Notify ag-Grid about the change
      // thisgridApi.applyTransaction({ update: [updatedRow] });
    }
    this.gridApi.refreshCells();
    this.calculateProgressbar();
    this.ProgressUpdates();
  }
  /*Update table with New Row*/
  AllTripsfromCreation: TripDateCycle[] = [];
  UpdateTableNewTrip(Trips: TripDateCycle[]) {
    this.AllTripsfromCreation = Trips;
    Trips.forEach((thetrip) => {
      let temptrip: TripTable = {
        trip: '',
        id: '',
        startdatetime: '',
        startdate: '',
        starttime: '',
        enddatetime: '',
        enddate: '',
        endtime: '',
        totaltriptime: '',
        status: '',
        despatched: '',
        despatchdatetime: '',
        despatchdate: '',
        despatchtime: '',
        driver: '',
        truck: '',
        trailer: '',
        firstpickup: '',
        returnto: '',
        comments: '',
        remarks: '',
        custref: '',
        connote: '',
        multidrop: '',
        services: '',
        dock: '',
        enteredby: '',
        tonnes: '',
        utilisation: '',
        curfewbreach: '',
        region: '',
        firstdrop: '',
        lastdrop: '',
        lastpickup: '',
        firstloadtype: '',
        dropsuburb: '',
        loadsuburb: '',
        despatchbydatetime: '',
        despatchbydate: '',
        despatchbytime: '',
        deliverywindow: '',
        customerid: '',
        paperworkreadydate: '',
        paperworkreadytime: '',
        containerno: '',
        companyid: '',
        loadno: '',
        vesselno: '',
      };
      temptrip.trip = thetrip.tripIdCust;
      temptrip.startdate = thetrip.tripDate;
      temptrip.despatched = thetrip.despatched;
      // temptrip.status = thetrip[0].cachedStatus;
    if (thetrip.cachedStatus == 'P ' ||thetrip.cachedStatus == 'AL' ||thetrip.cachedStatus == 'CN' ) {
        temptrip.status = 'planned';
        // this.totalplanned += 1;
      }
    if (thetrip.cachedStatus == 'R ' || thetrip.cachedStatus == 'U ' || thetrip.cachedStatus == 'D ' || thetrip.cachedStatus == 'DE' || thetrip.cachedStatus == 'RC' || thetrip.cachedStatus == 'LG' || thetrip.cachedStatus == 'LD' || thetrip.cachedStatus == 'TR' || thetrip.cachedStatus == 'UG' || thetrip.cachedStatus == 'UD' || thetrip.cachedStatus == 'RT' || thetrip.cachedStatus == 'E ') {
        temptrip.status = 'despatched';
        // this.totaldespatched += 1;
      }
    
      if (thetrip.cachedStatus == 'L '  || thetrip.cachedStatus == 'T ') {
        temptrip.status = 'transit';
        // this.totaltransit += 1;
      }
     
      if (thetrip.cachedStatus == 'CP'|| thetrip.cachedStatus == 'CR'|| thetrip.cachedStatus == 'F '|| thetrip.cachedStatus == 'FN'){
        temptrip.status = 'complete';
      }
      if (thetrip.cachedStatus == 'C ' || thetrip.cachedStatus == 'Y ' || thetrip.cachedStatus == 'A ' || thetrip.cachedStatus == 'PL' || thetrip.cachedStatus == 'RD') {
        temptrip.status = 'ready';
      }
      temptrip.startdate = thetrip.plannedStartTime;
      temptrip.starttime = thetrip.plannedStartTime;
      temptrip.startdatetime = thetrip.plannedStartTime;
      temptrip.enddatetime = thetrip.plannedFinishTime;
      temptrip.enddate = thetrip.plannedFinishTime;
      temptrip.endtime = thetrip.plannedFinishTime;
      if (thetrip.actualDespatchTime) {
        temptrip.despatchdatetime = thetrip.actualDespatchTime;
        temptrip.despatchdate = thetrip.actualDespatchTime;
        temptrip.despatchtime = thetrip.actualDespatchTime;
      } else {
        temptrip.despatchdatetime = 0;
        temptrip.despatchdate = 0;
        temptrip.despatchtime = 0;
      }
      temptrip.totaltriptime = this.getActivityTime(
        thetrip.plannedFinishTime - thetrip.plannedStartTime
      );
      temptrip.truck = thetrip.truckId;
      temptrip.id = thetrip.id;
      if (thetrip.driverId == null) {
        temptrip.driver = '';
      } else {
        temptrip.driver = this.getDriverforTable(thetrip.driverId);
      }
      temptrip.trailer = thetrip.trailerId;
      temptrip.connote = thetrip.batchNo;
      temptrip.dock = this.getDockName(thetrip.dockId);
      temptrip.firstpickup = thetrip.firstPickup;
      temptrip.returnto = thetrip.returnLocationId;
      temptrip.comments = thetrip.comments;
      temptrip.remarks = thetrip.remarks;
      temptrip.custref = thetrip.custRef;
      temptrip.multidrop = thetrip.multiDrop;
      temptrip.services = thetrip.serviceIds.length;
      temptrip.enteredby = thetrip.enteredBy;
      temptrip.utilisation =
        Math.round(Number(thetrip.utilization) * 100) / 100;
      temptrip.firstdrop = thetrip.firstDrop;
      temptrip.lastdrop = thetrip.lastDrop;
      temptrip.lastpickup = thetrip.lastPickup;
      temptrip.firstloadtype = thetrip.firstLoadType;
      temptrip.dropsuburb = thetrip.dropSuburb;
      temptrip.loadsuburb = thetrip.loadSuburb;
      temptrip.companyid = thetrip.companyId;
      temptrip.loadno = thetrip.loadNo;
      this.rowData.push(temptrip);
    });
    this.calculateProgressbar();
    this.ProgressUpdates();
  }

  trips_date_cycle: TripDateCycle[] = [];
  trip_service_data: ServiceDateCycle[] = [];
  trip_driver_resources: any = 0;

  ViewDataDrivers: Driver2[] = [];
  drivers: any[] = [];
  driver: any;
  dt: any;

  ViewDataTrucks: ResourceAllocation[] = [];
  ViewReasons: Reasons[] = [];
  ViewEventTypes: EventTypes[] = [];
  ViewTrailers: Trailer[] = [];
  ViewDocks: Dock[] = [];
  isLoading: boolean = true;
  onGridReady(params: GridReadyEvent<TripTable>) {
    this.gridApi = params.api;
    this.isGridAPIReady = true;
    //  this.isLoading = true;
    this.getLayout();
  }

  loadTypes: any[] = [];
  getLoadTypes(loadtypes: any[]) {
    loadtypes.forEach((element) => {
      this.loadTypes.push(element.loadTypeId);
    });
  }
  servicetypes: any[] = [];
  getServiceTypes(serviceTypes: any[]) {
    serviceTypes.forEach((element) => {
      this.servicetypes.push(element.serviceTypeId);
    });
  }

  trucks: any[] = [];
  value: any;
  //Get trucks info from View API
  getTrucks(viewtrucks: ResourceAllocation[]) {
    viewtrucks.forEach((element) => {
      if (element.active == true) {
        this.value =
          element.truckId +
          ' (' +
          element.routeCapacity +
          ', ' +
          element.truckTypeId +
          ')';
        this.trucks.push(this.value);
      }
    });
  }
  //Get Driver info from View API
  getDrivers(viewdrivers: Driver2[]) {
    viewdrivers.forEach((element: any) => {
      this.driver = { name: '', company: '', id: '' };
      if (element.active == true) {
        if (element.surname != null && element.firstName != null) {
          this.driver.name =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        } else if (element.employeeName != null) {
          this.driver.name = element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        }
        this.drivers.push(this.driver);
      }
    });
  }
  SelectedTrips: TripTable[] = [];
  selectedtrip: TripDateCycle[] = [];
  selectedtrip2:TripDateCycle[]=[];
  selectedservice: ServiceDateCycle[] = [];
  isdespatched: boolean = true;

  onSelectionChanged(event: any) {
    this.selectedservice = [];
    const selectedRows = this.gridApi.getSelectedRows();
    this.SelectedTrips = [];
    this.selectedtrip = [];
    this.selectedtrip2 = [];
    // this.restoreSelectedRowData();
    if (selectedRows.length != 0) {
      this.eventstab = false;
      this.moreactions = false;
      this.deletebtn = false;
      this.planService.selectedRowGridT.next(true);

      selectedRows.forEach((element) => {
        this.SelectedTrips.push(element);
        if (element.status == 'despatched' || element.status =='complete' || element.status=='ready') {
          this.isdespatched = false;
        } else {
          this.isdespatched = true;
        }
      });
      if (this.trips_date_cycle.length != 0) {
        selectedRows.forEach((selectedrow) => {
          this.trips_date_cycle.forEach((trip) => {
            if (selectedrow.id == trip.id) {
              let a: TripDateCycle = {
                activities: trip.activities,
                actualDespatchTime: selectedRows[0].despatchbydate,
                actualFinishTime: trip.actualFinishTime,
                actualReturnTime: trip.actualReturnTime,
                actualStartTime: trip.actualStartTime,
                batchNo: selectedRows[0].connote,
                cachedPhase: trip.cachedPhase,
                cachedRoutingQty: trip.cachedRoutingQty,
                cachedStatus: '',
                cachedTrailerCapacity: trip.cachedTrailerCapacity,
                cachedTruckCapacity: trip.cachedTruckCapacity,
                chainCommands: trip.chainCommands,
                comments: selectedRows[0].comments,
                companyId: selectedRows[0].companyid,
                containerNo: trip.containerNo,
                created: trip.created,
                custRef: selectedRows[0].custref,
                customerClaimAmt: trip.customerClaimAmt,
                dataSourceId: trip.dataSourceId,
                deliveredServicesCount: trip.deliveredServicesCount,
                deliveryWindow: trip.deliveryWindow,
                despatchByTime: trip.despatchByTime,
                despatchLocationId: trip.despatchLocationId,
                despatched: selectedRows[0].despatched,
                dockId: trip.dockId,
                docket: trip.docket,
                driverBreakIds: trip.driverBreakIds,
                driverId: trip.driverId,
                dropSuburb: selectedRows[0].dropsuburb,
                enteredBy: selectedRows[0].enteredby,
                etaUpdatedTime: trip.etaUpdatedTime,
                eventIds: trip.eventIds,
                firstDrop: selectedRows[0].firstdrop,
                firstLoadType: selectedRows[0].firstloadtype,
                firstPickup: selectedRows[0].firstpickup,
                holdCode: trip.holdCode,
                id: selectedRows[0].id,
                lastDrop: selectedRows[0].lastdrop,
                lastPickup: selectedRows[0].lastpickup,
                loadNo: selectedRows[0].loadno,
                loadSuburb: selectedRows[0].loadsuburb,
                locations: trip.locations,
                multiDrop: selectedRows[0].multidrop,
                paperWorkReady: trip.paperWorkReady,
                pickWaveRef: trip.pickWaveRef,
                pickupLocationIds: trip.pickupLocationIds,
                plannedDespatchTime: trip.plannedDespatchTime,
                plannedFinishTime: selectedRows[0].enddate,
                plannedReturnTime: trip.plannedReturnTime,
                plannedStartTime: selectedRows[0].startdate,
                regionId: trip.regionId,
                remarks: selectedRows[0].remarks,
                returnLocationId: selectedRows[0].returnto,
                revenue: trip.revenue,
                routeId: trip.routeId,
                routingUnit: trip.routingUnit,
                sdpLineIds: trip.sdpLineIds,
                serviceIds: trip.serviceIds,
                settledDate: trip.settledDate,
                siteId: trip.siteId,
                trailerId: selectedRows[0].trailer,
                trailerIdTag: trip.trailerIdTag,
                tripComplete: trip.tripComplete,
                tripDate: trip.tripDate,
                tripIdCust: selectedRows[0].trip,
                tripNo: trip.tripNo,
                truckId: selectedRows[0].truck,
                utilization: trip.utilization,
                vesselNo: trip.vesselNo,
              };
              if (selectedRows[0].status == 'planned') {
                a.cachedStatus = 'P ';
              }
              if (selectedRows[0].status == 'despatched') {
                a.cachedStatus = 'D ';
              }

              if (selectedRows[0].status == 'transit') {
                a.cachedStatus = 'T ';
              }
              if (selectedRows[0].status == 'ready') {
                a.cachedStatus = 'RD';
              }
              if (selectedRows[0].status == 'complete') {
                a.cachedStatus = 'CP';
              }
              
              this.selectedtrip2.push(a);
            } 
          })
        })

        selectedRows.forEach((selectedrow) => {
          this.trips_date_cycle.forEach((trip) => {
            if (selectedrow.id == trip.id) {
              let a: TripDateCycle = {
                activities: trip.activities,
                actualDespatchTime: selectedRows[0].despatchbydate,
                actualFinishTime: trip.actualFinishTime,
                actualReturnTime: trip.actualReturnTime,
                actualStartTime: trip.actualStartTime,
                batchNo: selectedRows[0].connote,
                cachedPhase: trip.cachedPhase,
                cachedRoutingQty: trip.cachedRoutingQty,
                cachedStatus: '',
                cachedTrailerCapacity: trip.cachedTrailerCapacity,
                cachedTruckCapacity: trip.cachedTruckCapacity,
                chainCommands: trip.chainCommands,
                comments: selectedRows[0].comments,
                companyId: selectedRows[0].companyid,
                containerNo: trip.containerNo,
                created: trip.created,
                custRef: selectedRows[0].custref,
                customerClaimAmt: trip.customerClaimAmt,
                dataSourceId: trip.dataSourceId,
                deliveredServicesCount: trip.deliveredServicesCount,
                deliveryWindow: trip.deliveryWindow,
                despatchByTime: trip.despatchByTime,
                despatchLocationId: trip.despatchLocationId,
                despatched: selectedRows[0].despatched,
                dockId: trip.dockId,
                docket: trip.docket,
                driverBreakIds: trip.driverBreakIds,
                driverId: trip.driverId,
                dropSuburb: selectedRows[0].dropsuburb,
                enteredBy: selectedRows[0].enteredby,
                etaUpdatedTime: trip.etaUpdatedTime,
                eventIds: trip.eventIds,
                firstDrop: selectedRows[0].firstdrop,
                firstLoadType: selectedRows[0].firstloadtype,
                firstPickup: selectedRows[0].firstpickup,
                holdCode: trip.holdCode,
                id: selectedRows[0].id,
                lastDrop: selectedRows[0].lastdrop,
                lastPickup: selectedRows[0].lastpickup,
                loadNo: selectedRows[0].loadno,
                loadSuburb: selectedRows[0].loadsuburb,
                locations: trip.locations,
                multiDrop: selectedRows[0].multidrop,
                paperWorkReady: trip.paperWorkReady,
                pickWaveRef: trip.pickWaveRef,
                pickupLocationIds: trip.pickupLocationIds,
                plannedDespatchTime: trip.plannedDespatchTime,
                plannedFinishTime: selectedRows[0].enddate,
                plannedReturnTime: trip.plannedReturnTime,
                plannedStartTime: selectedRows[0].startdate,
                regionId: trip.regionId,
                remarks: selectedRows[0].remarks,
                returnLocationId: selectedRows[0].returnto,
                revenue: trip.revenue,
                routeId: trip.routeId,
                routingUnit: trip.routingUnit,
                sdpLineIds: trip.sdpLineIds,
                serviceIds: trip.serviceIds,
                settledDate: trip.settledDate,
                siteId: trip.siteId,
                trailerId: selectedRows[0].trailer,
                trailerIdTag: trip.trailerIdTag,
                tripComplete: trip.tripComplete,
                tripDate: trip.tripDate,
                tripIdCust: selectedRows[0].trip,
                tripNo: trip.tripNo,
                truckId: selectedRows[0].truck,
                utilization: trip.utilization,
                vesselNo: trip.vesselNo,
              };
              if (selectedRows[0].status == 'planned') {
                a.cachedStatus = 'P ';
              }
              if (selectedRows[0].status == 'despatched') {
                a.cachedStatus = 'D ';
              }

              if (selectedRows[0].status == 'transit') {
                a.cachedStatus = 'T ';
              }
              if (selectedRows[0].status == 'ready') {
                a.cachedStatus = 'RD';
              }
              if (selectedRows[0].status == 'complete') {
                a.cachedStatus = 'CP';
              }
              
              this.selectedtrip.push(a);
            } else {
              let a: TripDateCycle = {
                activities: trip.activities,
                actualDespatchTime: selectedRows[0].despatchbydate,
                actualFinishTime: trip.actualFinishTime,
                actualReturnTime: trip.actualReturnTime,
                actualStartTime: trip.actualStartTime,
                batchNo: selectedRows[0].connote,
                cachedPhase: trip.cachedPhase,
                cachedRoutingQty: trip.cachedRoutingQty,
                cachedStatus: '',
                cachedTrailerCapacity: trip.cachedTrailerCapacity,
                cachedTruckCapacity: trip.cachedTruckCapacity,
                chainCommands: trip.chainCommands,
                comments: selectedRows[0].comments,
                companyId: selectedRows[0].companyid,
                containerNo: trip.containerNo,
                created: trip.created,
                custRef: selectedRows[0].custref,
                customerClaimAmt: trip.customerClaimAmt,
                dataSourceId: trip.dataSourceId,
                deliveredServicesCount: trip.deliveredServicesCount,
                deliveryWindow: trip.deliveryWindow,
                despatchByTime: trip.despatchByTime,
                despatchLocationId: trip.despatchLocationId,
                despatched: selectedRows[0].despatched,
                dockId: trip.dockId,
                docket: trip.docket,
                driverBreakIds: trip.driverBreakIds,
                driverId: trip.driverId,
                dropSuburb: selectedRows[0].dropsuburb,
                enteredBy: selectedRows[0].enteredby,
                etaUpdatedTime: trip.etaUpdatedTime,
                eventIds: trip.eventIds,
                firstDrop: selectedRows[0].firstdrop,
                firstLoadType: selectedRows[0].firstloadtype,
                firstPickup: selectedRows[0].firstpickup,
                holdCode: trip.holdCode,
                id: selectedRows[0].id,
                lastDrop: selectedRows[0].lastdrop,
                lastPickup: selectedRows[0].lastpickup,
                loadNo: selectedRows[0].loadno,
                loadSuburb: selectedRows[0].loadsuburb,
                locations: trip.locations,
                multiDrop: selectedRows[0].multidrop,
                paperWorkReady: trip.paperWorkReady,
                pickWaveRef: trip.pickWaveRef,
                pickupLocationIds: trip.pickupLocationIds,
                plannedDespatchTime: trip.plannedDespatchTime,
                plannedFinishTime: selectedRows[0].enddate,
                plannedReturnTime: trip.plannedReturnTime,
                plannedStartTime: selectedRows[0].startdate,
                regionId: trip.regionId,
                remarks: selectedRows[0].remarks,
                returnLocationId: selectedRows[0].returnto,
                revenue: trip.revenue,
                routeId: trip.routeId,
                routingUnit: trip.routingUnit,
                sdpLineIds: trip.sdpLineIds,
                serviceIds: trip.serviceIds,
                settledDate: trip.settledDate,
                siteId: trip.siteId,
                trailerId: selectedRows[0].trailer,
                trailerIdTag: trip.trailerIdTag,
                tripComplete: trip.tripComplete,
                tripDate: trip.tripDate,
                tripIdCust: selectedRows[0].trip,
                tripNo: trip.tripNo,
                truckId: selectedRows[0].truck,
                utilization: trip.utilization,
                vesselNo: trip.vesselNo,
              };
              if (selectedRows[0].status == 'planned') {
                a.cachedStatus = 'P ';
              }
              if (selectedRows[0].status == 'despatched') {
                a.cachedStatus = 'D ';
              }

              if (selectedRows[0].status == 'transit') {
                a.cachedStatus = 'T ';
              }
              if (selectedRows[0].status == 'ready') {
                a.cachedStatus = 'RD';
              }
              if (selectedRows[0].status == 'complete') {
                a.cachedStatus = 'CP';
              }
              
              this.selectedtrip.push(a);
            }
          });
          this.trip_service_data.forEach((service) => {
            if (selectedrow.trip == service.tripIdCust) {
              this.selectedservice.push(service);
            }
          });
        });
      } else {
        selectedRows.forEach((selectedrow) => {
          this.AllTripsfromCreation.forEach((trip) => {
            if (selectedrow.id == trip.id) {
              let a: TripDateCycle = {
                activities: trip.activities,
                actualDespatchTime: selectedrow.despatchbydate,
                actualFinishTime: trip.actualFinishTime,
                actualReturnTime: trip.actualReturnTime,
                actualStartTime: trip.actualStartTime,
                batchNo: selectedrow.connote,
                cachedPhase: trip.cachedPhase,
                cachedRoutingQty: trip.cachedRoutingQty,
                cachedStatus: '',
                cachedTrailerCapacity: trip.cachedTrailerCapacity,
                cachedTruckCapacity: trip.cachedTruckCapacity,
                chainCommands: trip.chainCommands,
                comments: selectedrow.comments,
                companyId: selectedrow.companyid,
                containerNo: trip.containerNo,
                created: trip.created,
                custRef: selectedrow.custref,
                customerClaimAmt: trip.customerClaimAmt,
                dataSourceId: trip.dataSourceId,
                deliveredServicesCount: trip.deliveredServicesCount,
                deliveryWindow: trip.deliveryWindow,
                despatchByTime: trip.despatchByTime,
                despatchLocationId: trip.despatchLocationId,
                despatched: selectedrow.despatched,
                dockId: trip.dockId,
                docket: trip.docket,
                driverBreakIds: trip.driverBreakIds,
                driverId: trip.driverId,
                dropSuburb: selectedrow.dropsuburb,
                enteredBy: selectedrow.enteredby,
                etaUpdatedTime: trip.etaUpdatedTime,
                eventIds: trip.eventIds,
                firstDrop: selectedrow.firstdrop,
                firstLoadType: selectedrow.firstloadtype,
                firstPickup: selectedrow.firstpickup,
                holdCode: trip.holdCode,
                id: selectedrow.id,
                lastDrop: selectedrow.lastdrop,
                lastPickup: selectedrow.lastpickup,
                loadNo: selectedrow.loadno,
                loadSuburb: selectedrow.loadsuburb,
                locations: trip.locations,
                multiDrop: selectedrow.multidrop,
                paperWorkReady: trip.paperWorkReady,
                pickWaveRef: trip.pickWaveRef,
                pickupLocationIds: trip.pickupLocationIds,
                plannedDespatchTime: trip.plannedDespatchTime,
                plannedFinishTime: selectedrow.enddate,
                plannedReturnTime: trip.plannedReturnTime,
                plannedStartTime: selectedrow.startdate,
                regionId: trip.regionId,
                remarks: selectedrow.remarks,
                returnLocationId: selectedrow.returnto,
                revenue: trip.revenue,
                routeId: trip.routeId,
                routingUnit: trip.routingUnit,
                sdpLineIds: trip.sdpLineIds,
                serviceIds: trip.serviceIds,
                settledDate: trip.settledDate,
                siteId: trip.siteId,
                trailerId: selectedrow.trailer,
                trailerIdTag: trip.trailerIdTag,
                tripComplete: trip.tripComplete,
                tripDate: trip.tripDate,
                tripIdCust: selectedrow.trip,
                tripNo: trip.tripNo,
                truckId: selectedrow.truck,
                utilization: trip.utilization,
                vesselNo: trip.vesselNo,
              };
              if (selectedRows[0].status == 'planned') {
                a.cachedStatus = 'P ';
              }
              if (selectedRows[0].status == 'despatched') {
                a.cachedStatus = 'D ';
              }

              if (selectedRows[0].status == 'transit') {
                a.cachedStatus = 'T ';
              }
              if (selectedRows[0].status == 'ready') {
                a.cachedStatus = 'RD';
              }
              if (selectedRows[0].status == 'complete') {
                a.cachedStatus = 'CP';
              }
              

              this.selectedtrip.push(a);
            }
          });
          this.trip_service_data.forEach((service) => {
            if (selectedrow.trip == service.tripIdCust) {
              this.selectedservice.push(service);
            }
          });
        });
      }
      if(this.selectedtrip2.length==1){
        this.getselectedtrip.emit(this.selectedtrip2);

      }
      else{
        this.getselectedtrip.emit(this.selectedtrip);

      }
      this.getselectedtripservice.emit(this.selectedservice);
    } else if (selectedRows.length == 0) {
      this.planService.selectedRowGridT.next(false);
      this.selectedtrip = [];
      this.eventstab = true;
      this.moreactions = true;
      this.deletebtn = true;
      this.getselectedtrip.emit(this.selectedtrip);
    }
  }

  //fill table with data and record them for progress bar
  totalcompleted: number = 0;
  totaldespatched: number = 0;
  totalplanned: number = 0;
  totaltransit: number = 0;
  totalready: number = 0;

  completewidth = 'width:';
  despatchwidth = 'width:';
  plannedwidth = 'width:';
  transitwidth = 'width:';
  readywidth = 'width:';

  getActivityTime(time: number): string {
    let hours = Math.floor(time / 3600000);
    var minutes = (time % 3600000) / 60000;
    // var minutes = Math.round((32.7666666 - hours) * 60);
    return String(hours) + 'h ' + String(minutes) + 'm';
  }
  drivername: string;
  getDriverforTable(dat: any): string {
    this.drivername = '';
    this.drivers.forEach((element) => {
      if (element.id == dat) {
        this.drivername = element.name + ' (' + element.company + ')';
      }
    });
    return this.drivername;
  }
  dockname: string;
  getDockName(did: number): string {
    this.dockname = '';
    this.ViewDocks.forEach((element) => {
      if (element.id == did) {
        this.dockname = element.dockName;
      }
    });
    return this.dockname;
  }
  rows: TripTable[] = [];
  date_temp: any;

  TableData(trips: TripDateCycle[], dat?: any) {
    this.rows = [];
    this.totalplanned = 0;
    this.totaldespatched = 0;
    this.totalcompleted = 0;
    this.totalready = 0;
    this.totalrecords = 0;
    this.totaltransit = 0;

    trips.forEach((trip) => {
      let temp: TripTable = {
        trip: '',
        id: '',
        startdatetime: '',
        startdate: '',
        starttime: '',
        enddatetime: '',
        enddate: '',
        endtime: '',
        totaltriptime: '',
        status: '',
        despatched: '',
        despatchdatetime: '',
        despatchdate: '',
        despatchtime: '',
        driver: '',
        truck: '',
        trailer: '',
        firstpickup: '',
        returnto: '',
        comments: '',
        remarks: '',
        custref: '',
        connote: '',
        multidrop: '',
        services: '',
        dock: '',
        enteredby: '',
        tonnes: '',
        utilisation: '',
        curfewbreach: '',
        region: '',
        firstdrop: '',
        lastdrop: '',
        lastpickup: '',
        firstloadtype: '',
        dropsuburb: '',
        loadsuburb: '',
        despatchbydatetime: '',
        despatchbydate: '',
        despatchbytime: '',
        deliverywindow: '',
        customerid: '',
        paperworkreadydate: '',
        paperworkreadytime: '',
        containerno: '',
        companyid: '',
        loadno: '',
        vesselno: '',
      };
      temp.trip = trip.tripIdCust;
      temp.startdate = this.timeService.convertMillisecondsToDateTimeSF(
        trip.tripDate
      );
      temp.despatched = trip.despatched;
      if (trip.cachedStatus == 'P ' ||trip.cachedStatus == 'AL' ||trip.cachedStatus == 'CN' ) {
        temp.status = 'planned';
        // this.totalplanned += 1;
      }
      if (trip.cachedStatus == 'R ' || trip.cachedStatus == 'U ' || trip.cachedStatus == 'D ' || trip.cachedStatus == 'DE' || trip.cachedStatus == 'RC' || trip.cachedStatus == 'LG' || trip.cachedStatus == 'LD' || trip.cachedStatus == 'TR' || trip.cachedStatus == 'UG' || trip.cachedStatus == 'UD' || trip.cachedStatus == 'RT' || trip.cachedStatus == 'E ') {
        temp.status = 'despatched';
        // this.totaldespatched += 1;
      }
     
      if (trip.cachedStatus == 'L '  || trip.cachedStatus == 'T ') {
        temp.status = 'transit';
        // this.totaltransit += 1;
      }
     
    if (trip.cachedStatus == 'C ' || trip.cachedStatus == 'Y ' || trip.cachedStatus == 'A ' || trip.cachedStatus == 'PL' || trip.cachedStatus == 'RD') {
        temp.status = 'ready';
        // this.totaltransit += 1;
      }
      if (trip.cachedStatus == 'CP'|| trip.cachedStatus == 'CR'|| trip.cachedStatus == 'F '|| trip.cachedStatus == 'FN'){
        temp.status= 'complete';
      }
      
      temp.startdate = trip.plannedStartTime;
      temp.starttime = trip.plannedStartTime;
      temp.startdatetime = trip.plannedStartTime;
      temp.enddatetime = trip.plannedFinishTime;
      temp.enddate = trip.plannedFinishTime;
      temp.endtime = trip.plannedFinishTime;
      temp.despatchbydatetime=trip.plannedDespatchTime;
      temp.despatchbydate=trip.plannedDespatchTime;
      temp.despatchbytime=trip.plannedDespatchTime;
      if (trip.actualDespatchTime) {
        temp.despatchdatetime = trip.actualDespatchTime;
        temp.despatchdate = trip.actualDespatchTime;
        temp.despatchtime = trip.actualDespatchTime;
      } else {
        temp.despatchdatetime = 0;
        temp.despatchdate = 0;
        temp.despatchtime = 0;
      }
      temp.totaltriptime = this.getActivityTime(
        trip.plannedFinishTime - trip.plannedStartTime
      );
      temp.truck = trip.truckId;
      temp.id = trip.id;
      if (trip.driverId == null) {
        temp.driver = '';
      } else {
        temp.driver = this.getDriverforTable(dat);
      }
      temp.trailer = trip.trailerId;
      temp.connote = trip.batchNo;
      temp.dock = this.getDockName(trip.dockId);
      temp.firstpickup = trip.firstPickup;
      temp.returnto = trip.returnLocationId;
      temp.comments = trip.comments;
      temp.remarks = trip.remarks;
      temp.custref = trip.custRef;
      temp.multidrop = trip.multiDrop;
      if(trip.serviceIds){
        temp.services = trip.serviceIds.length;
      }
      else{
        temp.services = 0
      }
      temp.enteredby = trip.enteredBy;
      temp.utilisation = Math.round(Number(trip.utilization) * 100) / 100;
      temp.firstdrop = trip.firstDrop;
      temp.lastdrop = trip.lastDrop;
      temp.lastpickup = trip.lastPickup;
      temp.firstloadtype = trip.firstLoadType;
      temp.dropsuburb = trip.dropSuburb;
      temp.loadsuburb = trip.loadSuburb;
      temp.companyid = trip.companyId;
      temp.loadno = trip.loadNo;
      this.rows.push(temp);
    });
    this.rowData = this.rows;
    this.SaveRowData = this.rowData;
    //progressbar updates
    this.calculateProgressbar();
    this.ProgressUpdates();
    if (this.isGridAPIReady) {
      this.gridApi.setRowData(this.rowData);
    }
  }
  isGridAPIReady: boolean = false;
  ProgressUpdates() {
    this.completewidth = 'width:';
    this.despatchwidth = 'width:';
    this.plannedwidth = 'width:';
    this.transitwidth = 'width:';
    this.readywidth = 'width:';
    if (this.totaldespatched != 0) {
      this.despatchwidth =
        this.despatchwidth +
        String((this.totaldespatched / this.totalrecords) * 100) +
        '%';
    } else {
      this.despatchwidth = this.despatchwidth + '0%';
    }
    if (this.totalplanned != 0) {
      this.plannedwidth =
        this.plannedwidth +
        String((this.totalplanned / this.totalrecords) * 100) +
        '%';
    } else {
      this.plannedwidth = this.plannedwidth + '0%';
    }
    if (this.totalcompleted != 0) {
      this.completewidth =
        this.completewidth +
        String((this.totalcompleted / this.totalrecords) * 100) +
        '%';
    } else {
      this.completewidth = this.completewidth + '0%';
    }
    if (this.totaltransit) {
      this.transitwidth =
        this.transitwidth +
        String((this.totaltransit / this.totalrecords) * 100) +
        '%';
    } else {
      this.transitwidth = this.transitwidth + '0%';
    }
    if (this.totalready != 0) {
      this.readywidth =
        this.readywidth +
        String((this.totalready / this.totalrecords) * 100) +
        '%';
    } else {
      this.readywidth = this.readywidth + '0%';
    }
  }

  menuHumbergurDialog() {
    const dialogRef = this.dialog.open(MenuDialogComponent, {
      data: {
        complete: this.totalcompleted,
        despatch: this.totaldespatched,
        planned: this.totalplanned,
        transit: this.totaltransit,
        ready: this.totaltransit,
        total: this.totalrecords,
        completewidth: this.completewidth,
        despatchwidth: this.despatchwidth,
        plannedwidth: this.plannedwidth,
        transitwidth: this.transitwidth,
        readywidth: this.readywidth,
        date: this.datefromDateCycle,
      },
    });
  }

  //duplication
  servicetypeofTrip: any;
  openDuplicateDialog() {
    this.trip_service_data.forEach((element) => {
      if (element.id == this.selectedtrip[0].serviceIds[0]) {
        this.servicetypeofTrip = element.serviceTypeId;
      }
    });
    const dialogRef = this.dialog.open(DuplicateSelectedTripsDialogComponent, {
      data: {
        drivers: this.drivers,
        trucks: this.trucks,
        loadTypes: this.loadTypes,
        servicetypes: this.servicetypes,
        selectedTrips: this.SelectedTrips,
        servicetype: this.servicetypeofTrip,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      if (res) {
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Trip duplicated',
        });
        res.data.trips.forEach((trip: any) => {
          this.trips_date_cycle.push(trip);
        });
        this.TableData(this.trips_date_cycle, this.trip_driver_resources[0].id);
      }
    });
  }
  dateflag:boolean=false;
  //change date
  openDateChangeDialog() {
    const dialogRef = this.dialog.open(ReasonDateChangeDialogComponent, {
      data: {
        reasons: this.ViewReasons,
        selectedtrips: this.SelectedTrips,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      if (res.data.flag == true) {
        this.dateflag=true;
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Date Changed',
        });
        this.gridApi.deselectAll
        let arr:any[]=[];
        this.rowData.forEach((ele)=>{
          if (ele.trip == res.data.res.trips[0].tripIdCust) {
            arr.push(ele);
            const a = this.gridApi.applyTransaction({
              remove: arr,
            })!;
          }

        })
      
        // this.rowData.forEach((element) => {
        //   if (element.trip == res.data.res.trips[0].tripIdCust) {

        //     element.startdate = res.data.res.trips[0].tripDate;
        //     element.starttime=res.data.res.trips[0].plannedStartTime;
        //     element.enddate = res.data.res.trips[0].tripDate;
        //     element.endtime = res.data.res.trips[0].plannedFinishTime;
        //     if (res.data.res.trips[0].cachedStatus == 'P ' ||res.data.res.trips[0].cachedStatus == 'AL' ||res.data.res.trips[0].cachedStatus == 'CN' ) {
        //       element.status = 'planned';
        //     }
        //     if (res.data.res.trips[0].cachedStatus == 'R ' || res.data.res.trips[0].cachedStatus == 'U ' || res.data.res.trips[0].cachedStatus == 'D ' || res.data.res.trips[0].cachedStatus == 'DE' || res.data.res.trips[0].cachedStatus == 'RC' || res.data.res.trips[0].cachedStatus == 'LG' || res.data.res.trips[0].cachedStatus == 'LD' || res.data.res.trips[0].cachedStatus == 'TR' || res.data.res.trips[0].cachedStatus == 'UG' || res.data.res.trips[0].cachedStatus == 'UD' || res.data.res.trips[0].cachedStatus == 'RT' || res.data.res.trips[0].cachedStatus == 'E ') {
        //       element.status = 'despatched';
        //     }
        //     if (res.data.res.trips[0].cachedStatus == 'L '  || res.data.res.trips[0].cachedStatus == 'T ') {
        //       element.status = 'transit';
        //     }
           
        //     if (res.data.res.trips[0].cachedStatus == 'C ' || res.data.res.trips[0].cachedStatus == 'Y ' || res.data.res.trips[0].cachedStatus == 'A ' || res.data.res.trips[0].cachedStatus == 'PL' || res.data.res.trips[0].cachedStatus == 'RD') {
        //       element.status = 'ready';
        //     }
        //     if (res.data.res.trips[0].cachedStatus == 'CP'|| res.data.res.trips[0].cachedStatus == 'CR'|| res.data.res.trips[0].cachedStatus == 'F '|| res.data.res.trips[0].cachedStatus == 'FN'){
        //       element.status= 'complete';
        //     }
        //     let date = this.timeService.convertMillisecondsToDateTimeSF(
        //       res.data.res.trips[0].tripDate
        //     );
        //     let start_date;
        //     start_date = moment(date);
        //     start_date = start_date
        //       .set({
        //         hour: 0,
        //         minute: 0,
        //         second: 0,
        //       })
        //       .format('YYYY-MM-DD HH:mm:ss');
        //     var s_australia_time = moment.tz(start_date, 'Australia/Melbourne');
        //     var s_india = s_australia_time.clone().tz('Asia/Kolkata');
        //     let milliseconds = moment(s_india).valueOf();
        //     element.startdatetime = res.data.res.trips[0].plannedStartTime;
        //     element.enddatetime =  res.data.res.trips[0].plannedFinishTime;
        //     element.totaltriptime = this.getActivityTime(
        //       res.data.res.trips[0].plannedFinishTime - res.data.res.trips[0].plannedStartTime
        //     );
        //   }
        // });
      
        this.gridApi.refreshCells();
        this.planService
          .getTripEvent(this.SelectedTrips[0].id)
          .subscribe((res) => {
            //events called
          });
      }
      else{
        this.dateflag=false;
      }
    });
  }
  //event variables
  datasourceId: string;
  allocatetype: EventTypes;
  lunchbreakstarttype: EventTypes;
  lunchbreakendtype: EventTypes;
  shiftendtype: EventTypes;
  departdepoteventtype: EventTypes;
  //disabled events
  returningtobasetype: EventTypes;
  returnedtobasetype: EventTypes;
  departdepottype: EventTypes;
  returnedtobaseeventtype: EventTypes;
  returningtobaseeventtype: EventTypes;
  getdatasource() {
    this.trip_service_data.forEach((element) => {
      this.datasourceId = element.dataSourceId;
    });
  }
  openAllocatedDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Allocated') {
        this.allocatetype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.allocatetype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      if (res) {
        this.rowData.forEach((row) => {
          this.planService.getTripEvent(row.id).subscribe((res) => {
            //events called
          });
        });
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
    });
  }
  openLunchBreakStartDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Lunch Break - Start') {
        this.lunchbreakstarttype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.lunchbreakstarttype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        // received data from dialog-component
        this.rowData.forEach((row) => {
          this.planService.getTripEvent(row.id).subscribe((res) => {
            //events called
          });
        });
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
    });
  }

  openLunchBreakEndDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Lunch Break - End') {
        this.lunchbreakendtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.lunchbreakendtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        // received data from dialog-component
        this.rowData.forEach((row) => {
          this.planService.getTripEvent(row.id).subscribe((res) => {
            //events called
          });
        });
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
    });
  }
  openShiftEndDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Shift End') {
        this.shiftendtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.shiftendtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        // received data from dialog-component
        this.rowData.forEach((row) => {
          this.planService.getTripEvent(row.id).subscribe((res) => {
            //events called
          });
        });
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
    });
  }
  openDepartDepotDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Depart Depot') {
        this.departdepoteventtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.departdepoteventtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        // received data from dialog-component
        this.rowData.forEach((row) => {
          this.planService.getTripEvent(row.id).subscribe((res) => {
            //events called
          });
        });
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
    });
  }
  openReturningBaseDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Returning To Base') {
        this.returningtobaseeventtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.returningtobaseeventtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        // received data from dialog-component
        this.rowData.forEach((row) => {
          this.planService.getTripEvent(row.id).subscribe((res) => {
            //events called
          });
        });
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
    });
  }
  openReturnedBaseDialog() {
    this.getdatasource();
    this.ViewEventTypes.forEach((element) => {
      if (element.eventDesc == 'Returned To Base') {
        this.returnedtobaseeventtype = element;
      }
    });
    const dialogRef = this.dialog.open(AllocatedDialogComponent, {
      data: {
        trips: this.selectedtrip,
        datasource: this.datasourceId,
        eventType: this.returnedtobaseeventtype,
      },
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res) {
        // received data from dialog-component
        this.rowData.forEach((row) => {
          this.planService.getTripEvent(row.id).subscribe((res) => {
            //events called
          });
        });
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'Event created',
        });
      }
    });
  }
  onRemove(payload: DeleteTripPayload) {
    this.planService
      .DeleteTrip(payload)
      .pipe(
        catchError((error) => {
          // Handle the error here
          let errormessage = error;
          this.messageService.add({
            severity: 'error',
            summary: error.status,
            detail: errormessage,
            life: 20000,
          });
          // You can also re-throw the error if needed
          return throwError(error);
        })
      )
      .subscribe((result) => {
        if (result) {
          // this.messageService.add({
          //   severity: 'error',
          //   summary: '',
          //   detail: result.errorList.ErrorMessage,
          // });

          const selectedData = this.SelectedTrips;
          const res = this.gridApi.applyTransaction({ remove: selectedData })!;
          const matchingrowindex = this.rowData.findIndex(
            (n) => n.id == this.SelectedTrips[0].id
          );
          if (matchingrowindex !== -1) {
            var rowNode = this.gridApi.getRowNode(String(matchingrowindex));
            if (rowNode) {
              const myTransaction = {
                remove: [rowNode.data!],
              };
              this.gridApi.applyTransaction(myTransaction);
            }
          }
          let toastrNO: string = '';
          this.SelectedTrips.forEach((element) => {
            toastrNO += element.trip + ' ';
          });
          let mess = 'Trip(s): ' + toastrNO + 'deleted.';
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: mess,
          });

          this.gridApi.refreshCells();
          this.calculateProgressbar();
          this.ProgressUpdates();
        }
      });
  }
  deletepayload: DeleteTripPayload = {
    ids: [],
    siteId: 0,
  };
  idList: number[] = [];
  onDelete() {
    this.SelectedTrips.forEach((element) => {
      this.deletepayload.ids.push(element.id);
    });
    this.deletepayload.siteId = parseInt(sessionStorage.getItem('selectedSiteId')!)

    this.confirmationService.confirm({
      message: 'Click OK to Continue',
      header: 'Are you sure you want to delete?',

      accept: () => {
        this.onRemove(this.deletepayload);
      },
      // reject: (type: ConfirmEventType) => {
      //   switch (type) {
      //     case ConfirmEventType.REJECT:
      //       this.messageService.add({
      //         severity: 'error',
      //         summary: 'Rejected',
      //         detail: 'You have rejected',
      //       });
      //       break;
      //     case ConfirmEventType.CANCEL:
      //       this.messageService.add({
      //         severity: 'warn',
      //         summary: 'Cancelled',
      //         detail: 'You have cancelled',
      //       });
      //       break;
      //   }
      // },
    });
  }
  clearFilters() {
    this.columnFields.forEach((element) => {
      this.gridApi.destroyFilter(element.field!);
    });
  }
  onSelectionChange(event: any) {
    this.clearFilters();
    this.columnDefs = this.columnFields.filter(
      (column) => event.value.includes(column.field) || column.field === ''
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }

  plannedtripflag: boolean = false;
  SaveRowData: TripTable[] = [];
  text1: string = 'Show only planned trips';
  PlannedTrip() {
    this.text1 = !this.plannedtripflag
      ? 'Show all trips'
      : 'Show only planned trips';
    this.plannedtripflag = !this.plannedtripflag;
    if (this.plannedtripflag) {
      this.rowData = this.rowData.filter(
        (x) => x.status == 'ready' || x.status == 'planned'
      );
    } else {
      this.rowData = this.SaveRowData;
    }
  }
  resourcetripflag: boolean = false;
  text2: string = 'Show only unresourced trips';
  ResourcedTrip() {
    this.text2 = !this.resourcetripflag
      ? 'Show resourced and unresourced trips'
      : 'Show only unresourced trips';
    this.resourcetripflag = !this.resourcetripflag;
    if (this.resourcetripflag) {
      //resource check
      this.rowData = this.rowData.filter(
        (x) => x.truck == null || x.truck == ''
      );
    } else {
      this.rowData = this.SaveRowData;
    }
  }
  rightSideForm(event: any) {
    console.log('row click', event);
    var rowCount = event.api.getSelectedNodes().length;
    console.log('checcking code in row clicked', rowCount);
    if (rowCount > 1) {
      // Get a reference to the grid API
      var gridApi = this.gridOptions.api;
      // Call deselectAll to unselect all selected rows
      gridApi.deselectAll();
      // Select the clicked row
      event.node.setSelected(true);
    }
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocatedDialogComponent } from './allocated-dialog.component';

describe('AllocatedDialogComponent', () => {
  let component: AllocatedDialogComponent;
  let fixture: ComponentFixture<AllocatedDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllocatedDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllocatedDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

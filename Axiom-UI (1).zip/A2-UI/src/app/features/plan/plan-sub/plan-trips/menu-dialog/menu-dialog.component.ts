import { Component, Inject } from '@angular/core';
import {MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';

@Component({
  selector: 'app-menu-dialog',
  templateUrl: './menu-dialog.component.html',
  styleUrls: ['./menu-dialog.component.scss'],
})
export class MenuDialogComponent {

  dialogdata:any;
  totalcompleted:any;
  totaldespatched:any;
  totalplanned:any;
  totaltransit:any;
  totalready:any;
  totalrecords:any;
  completewidth:any;
  despatchwidth:any;
  plannedwidth:any;
  transitwidth:any;
  readywidth:any;
  datecheckhere:any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public timeService:TimeRunsheetService
  ) {}

  ngOnInit(){
    this.dialogdata=this.data;
    this.totalcompleted=this.dialogdata.complete;
    this.totaldespatched=this.dialogdata.despatch;
    this.totalplanned=this.dialogdata.planned;
    this.totaltransit=this.dialogdata.transit;
    this.totalready=this.dialogdata.ready;
    this.totalrecords=this.dialogdata.total;
    this.completewidth=this.dialogdata.completewidth;
    this.despatchwidth=this.dialogdata.despatchwidth;
    this.plannedwidth=this.dialogdata.plannedwidth;
    this.transitwidth=this.dialogdata.transitwidth;
    this.readywidth=this.dialogdata.readywidth;
    this.datecheckhere = this.timeService.convertMillisecondsToDate(this.data.date)
   // 
  }

}

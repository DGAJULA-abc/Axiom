import { Component, Input } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { AgChartOptions } from 'ag-charts-community';
import { ICellRendererParams } from 'ag-grid-community';
@Component({
  selector: 'app-gantt-cell-renderer',
  templateUrl: './gantt-cell-renderer.component.html',
  styleUrls: ['./gantt-cell-renderer.component.scss'],
})
export class GanttCellRendererComponent implements ICellRendererAngularComp {
  public params: any;

  data: any;
  display: any = '';

  plannedwidth = 'width:';
  despatchwidth = 'width:';

  agInit(params: any) {
    this.TestingTime='';
    if (params.data.Gantttest?.driver) {
      this.data = params.data.Gantttest;
      this.display = this.data.driver;
      this.plannedwidth = 'width:';
      this.despatchwidth = 'width:';
      params.data.Gantttest.activity.forEach((activity:any) => {
        this.TestingTime+=activity.time+" ";
        
      });
      if (this.data.status == 'D ') {
        // alert("Reached!")
        this.despatchwidth = this.despatchwidth + '10%';
      }
      // if (this.data.status == 'P ') {
        // alert("Reached!")
        this.plannedwidth = this.plannedwidth + '50%';
      // }
    }
  }
  TestingTime:any='';
  refresh(params: any): boolean {
    this.TestingTime='';

    if (params.data.Gantttest?.driver) {
      this.data = params.data.Gantttest;
      params.data.Gantttest.activity.forEach((activity:any) => {
        this.TestingTime+=activity.time+" ";
      });
      this.plannedwidth = 'width:';
      this.despatchwidth = 'width:';
      if (this.data.status == 'D ') {
      
        this.despatchwidth = this.despatchwidth + '10%';
      }
      if (this.data.status == 'P ') {
        
        this.plannedwidth = this.plannedwidth + '20%';
      }
    }
    return false;
  }
  tooltipText: string = '';
  getTooltipContent(barname:string): string {
    if(barname=='planned'){
  return "Planned "    }
    else if(barname=='despatch'){

    }
    return 'This Value cannot be Empty';
  }
}

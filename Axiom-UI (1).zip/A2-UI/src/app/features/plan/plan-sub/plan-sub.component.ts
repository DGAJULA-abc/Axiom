import { LiveAnnouncer } from '@angular/cdk/a11y';
import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { MatSort, Sort, MatSortModule } from '@angular/material/sort';
import {
  Driver,
  ResourceAllocation,
  ServiceDateCycle,
  TripDateCycle,
  TripDespatchResponse,
  TripSaveResponse,
  TripUndespatchResponse,
  TruckUnavailability,
  ViewCustomer,
} from '../models/plan.model';
import {
  CdkDragDrop,
  CdkDragEnter,
  CdkDragExit,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { PlanService } from '../services/plan.service';
import { BehaviorSubject } from 'rxjs';
import { MatTabGroup } from '@angular/material/tabs';

@Component({
  selector: 'app-plan-sub',
  templateUrl: './plan-sub.component.html',
  styleUrls: ['./plan-sub.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class PlanSubComponent implements OnChanges, OnInit, AfterViewInit {
  previousIndex: number;

  roster: boolean = false;
  showform: boolean = false;
  resource: boolean = false;
  tripdetails: boolean = false;

  trips: boolean = true;
  primemovers: boolean = false;
  drivers: boolean = true;
  services: boolean = true;
  resourceallocation: boolean = true;
  datecycle: any;
  @Input() createnewservice: boolean;
  @Input() details: number;
  @Input() filters: string;
  @Input() filterflag_pm: boolean;
  @Input() filterflag_dr: boolean;
  @Input() filterflag_tr: boolean;
  @Input() filterflag_sr: boolean;
  @Input() filterflag_ra: boolean;
  @Input() servicecycle: ServiceDateCycle[];
  @Input() selectedService: ServiceDateCycle;
  @Input() selectedTrip2: TripDateCycle[];
  @Input() servicetripcycle: TripDateCycle[];
  @Input() datecycleresult: any;
  @Input() selectedcustomer: ViewCustomer;
  @Input() Location: string;
  @Input() customerValue: any;
  @Input() selecteddate_hm: any;

  @Output() ondriverselect: EventEmitter<any[]> = new EventEmitter<any[]>();
  @Output() ontripselect: EventEmitter<TripDateCycle[]> = new EventEmitter<
    TripDateCycle[]
  >();
  @Output() onserviceselect: EventEmitter<ServiceDateCycle> =
    new EventEmitter<ServiceDateCycle>();
  @Output() onresourceSelect: EventEmitter<ResourceAllocation> =
    new EventEmitter<ResourceAllocation>();
  @Output() isservicecreate: EventEmitter<boolean> =
    new EventEmitter<boolean>();
  headers = [
    { field: 'A', index: 0 },
    { field: 'B', index: 1 },
    { field: 'C', index: 2 },
  ];

  /* Tabs */
  @ViewChild('tabGroup', { static: false }) childTabGroup!: MatTabGroup;
  @ViewChild('tabGroup2', { static: false }) childTabGroup2!: MatTabGroup;
  @ViewChild('tabGroup3', { static: false }) childTabGroup3!: MatTabGroup;
  @ViewChild('group1', { static: false }) Group1!: ElementRef;

  createservice: boolean = false;
  textondetails: string = '';
  //check on max/min screen
  isMaximized: boolean = false;
  toggleSize() {
    this.isMaximized = !this.isMaximized;
  }

  CHILD_ID_ONE = 'menu-one';
  CHILD_ID_TWO = 'menu-two';
  CHILD_ID_THREE = 'menu-three';

  childMenuIds$ = new BehaviorSubject<string[]>([]);
  childMenuIds2$ = new BehaviorSubject<string[]>([]);
  childMenuIds3$ = new BehaviorSubject<string[]>([]);

  menus = ['Services', 'Trips', 'Prime Movers', 'Drivers'];
  showmenus = this.menus;
  menus2 = ['Details'];
  showmenus2 = this.menus2;
  menus3 = ['Resource Allocation'];
  showmenus3 = this.menus3;

  fromSearch: boolean = false;
  constructor(
    private _liveAnnouncer: LiveAnnouncer,
    private planService: PlanService
  ) {}

  servicetrips: TripDateCycle[];
  @ViewChild(MatSort) sort: MatSort;

  divWidth: any;
  divHeight: any;
  maxmin: boolean = false;
  maxminbutton: boolean = false;
  showResource: boolean = true;
  showDetail: boolean = true;
  showLeft: boolean = true;

  MaxMinClick() {
    this.maxmin = !this.maxmin;
    this.maxminbutton = !this.maxminbutton;
    this.showResource = !this.showResource;
    this.showDetail = !this.showDetail;
  }
  MaxMinClick2() {
    this.maxmin = !this.maxmin;
    this.maxminbutton = !this.maxminbutton;
    this.showDetail = !this.showDetail;
    this.showLeft = !this.showLeft;
  }
  MaxMinClick3() {
    this.maxmin = !this.maxmin;
    this.maxminbutton = !this.maxminbutton;
    this.showResource = !this.showResource;
    this.showLeft = !this.showLeft;
  }
  ngOnInit(): void {
    this.recalculateUniqIdsForDragDrop();
  }
  ngAfterViewInit() {
    this.divWidth = this.Group1.nativeElement.offsetWidth;
    this.divHeight = this.Group1.nativeElement.offsetHeight;
  }

  // onDropTab(event: CdkDragDrop<any[]>): void {
  //   const previousIndex = parseInt(
  //     event.previousContainer.id.replace(this.CHILD_ID_ONE, ''),
  //     10
  //   );
  //   const newIndex = parseInt(
  //     event.container.id.replace(this.CHILD_ID_ONE, ''),
  //     10
  //   );
  //   moveItemInArray(this.menus, previousIndex, newIndex);
  //   this.showDragWrapper(event);
  // }

  onDropTab2(event: CdkDragDrop<any[]>): void {
    const previousIndex = parseInt(
      event.previousContainer.id.replace(this.CHILD_ID_TWO, ''),
      10
    );
    const newIndex = parseInt(
      event.container.id.replace(this.CHILD_ID_TWO, ''),
      10
    );
    moveItemInArray(this.menus2, previousIndex, newIndex);
    this.showDragWrapper(event);
  }

  onDropTab3(event: CdkDragDrop<any[]>): void {
    const previousIndex = parseInt(
      event.previousContainer.id.replace(this.CHILD_ID_THREE, ''),
      10
    );
    const newIndex = parseInt(
      event.container.id.replace(this.CHILD_ID_THREE, ''),
      10
    );
    moveItemInArray(this.menus3, previousIndex, newIndex);
    this.showDragWrapper(event);
  }

  check1flag: boolean;
  check2flag: boolean;
  check3flag: boolean;
  onDropTab(event: CdkDragDrop<any[]>): void {
    if (event.distance.x > this.divWidth || event.distance.y > this.divHeight) {
      if (event.distance.x > this.divWidth) {
        transferArrayItem(
          this.menus,
          this.menus2,
          parseInt(event.previousContainer.id.match(/\d+/)![0]),
          1
        );
      }
      if (event.distance.y > this.divHeight) {
        transferArrayItem(
          this.menus,
          this.menus3,
          parseInt(event.previousContainer.id.match(/\d+/)![0]),
          1
        );
      }
    } else {
      const menu1_prev = event.previousContainer['_unsortedItems']
        .values()
        .next()
        .value.dropContainer.id.includes('menu-one');
      const menu1_cur = event.container['_unsortedItems']
        .values()
        .next()
        .value.dropContainer.id.includes('menu-one');

      const menu2_prev = event.previousContainer['_unsortedItems']
        .values()
        .next()
        .value.dropContainer.id.includes('menu-two');
      const menu2_cur = event.container['_unsortedItems']
        .values()
        .next()
        .value.dropContainer.id.includes('menu-two');

      const menu3_prev = event.previousContainer['_unsortedItems']
        .values()
        .next()
        .value.dropContainer.id.includes('menu-three');
      const menu3_cur = event.container['_unsortedItems']
        .values()
        .next()
        .value.dropContainer.id.includes('menu-three');
      this.check1flag = menu1_prev && menu1_cur ? true : false;
      this.check2flag = menu2_prev && menu2_cur ? true : false;
      this.check3flag = menu3_prev && menu3_cur ? true : false;

      if (this.check1flag || this.check2flag || this.check3flag) {
        let from = parseInt(
          event.previousContainer['_unsortedItems']
            .values()
            .next()
            .value.dropContainer.id.match(/\d+/)![0]
        );
        let to = parseInt(
          event.container['_unsortedItems']
            .values()
            .next()
            .value.dropContainer.id.match(/\d+/)![0]
        );
        let chosenmenu: string[] = [];
        if (this.check1flag) {
          chosenmenu = this.menus;
        } else if (this.check2flag) {
          chosenmenu = this.menus2;
        } else if (this.check3flag) {
          chosenmenu = this.menus3;
        }
        moveItemInArray(chosenmenu, from, to);
      }
    }
    this.showDragWrapper(event);
  }

  onDragEntered(event: CdkDragEnter): void {
    this.hideDragWrapper(event);
  }

  onDragExited(event: CdkDragExit): void {
    this.showDragWrapper(event);
  }

  private showDragWrapper(event: CdkDragExit | CdkDragDrop<string[]>): void {
    const element = this.getDragWrappedElement(event);
    if (element) {
      element.classList.remove('d-none');
    }
  }

  private hideDragWrapper(event: CdkDragEnter): void {
    const element = this.getDragWrappedElement(event);
    if (element) {
      element.classList.add('d-none');
    }
  }

  private getDragWrappedElement(
    event: CdkDragEnter | CdkDragExit
  ): HTMLElement | null {
    return event.container.element.nativeElement.querySelector(`.drag-wrapper`);
  }

  private recalculateUniqIdsForDragDrop(): void {
    const uniqIds: string[] = [];
    const uniqIdss: string[] = [];
    this.menus.reduce((accumulator: string[], _, index) => {
      accumulator.push(`${this.CHILD_ID_ONE}${index}`);
      return accumulator;
    }, uniqIdss);
    this.childMenuIds$.next(uniqIdss);

    this.menus2.reduce((accumulator: string[], _, index) => {
      accumulator.push(`${this.CHILD_ID_TWO}${index}`);
      return accumulator;
    }, uniqIds);
    this.childMenuIds2$.next(uniqIds);
  }

  trackByIndex(index: number): number {
    return index;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.selectedService != null) {
      this.SelectedService = this.selectedService;
      this.details = 5;
    }
    if (this.selectedTrip2 != null) {
      this.SelectedTrip = this.selectedTrip2;
      this.details = 4;
    }
    if (this.details == 1) {
      this.showform = true;
      this.createservice = this.createnewservice;
      this.roster = false;
      this.textondetails = '';
      this.resource = false;
      this.tripdetails = false;
    } else if (this.details == 2) {
      this.roster = true;
      this.showform = false;
      this.textondetails = '';
      this.resource = false;
      this.tripdetails = false;
    } else if (this.details == 0) {
      this.textondetails = ' ';
      this.showform = false;
      this.roster = false;
      this.resource = false;
      this.tripdetails = false;
    } else if (this.details == 3) {
      this.resource = true;
      this.showform = false;
      this.textondetails = '';
      this.roster = false;
      this.tripdetails = false;
    } else if (this.details == 4) {
      this.resource = false;
      this.showform = false;
      this.tripdetails = true;
      this.textondetails = '';
      this.roster = false;
    } else if (this.details == 5) {
      this.resource = false;
      this.showform = true;
      this.createservice = this.createnewservice;
      this.servicetrips = this.servicetripcycle;
      this.tripdetails = false;
      this.textondetails = '';
      this.roster = false;
    }
    let selectedmenu: any[] = [];
    switch (this.filters) {
      case 'trips':
      case 'drivers':
      case 'services':
      case 'primemovers':
        selectedmenu = this.menus;
        this.showmenus = this.menus;
        break;

      case 'resourceallocation':
        selectedmenu = this.menus3;
        this.showmenus3 = this.menus3;

        break;

      default:
        break;
    }
    if (!this.filterflag_tr) {
      this.showmenus = this.showmenus.filter((x) => x != 'Trips');
    }
    if (!this.filterflag_pm) {
      this.showmenus = this.showmenus.filter((x) => x != 'Prime Movers');
    }
    if (!this.filterflag_dr) {
      this.showmenus = this.showmenus.filter((x) => x != 'Drivers');
    }
    if (!this.filterflag_sr) {
      this.showmenus = this.showmenus.filter((x) => x != 'Services');
    }
    if (!this.filterflag_ra) {
      this.showmenus3 = this.showmenus3.filter(
        (x) => x != 'Resource Allocation'
      );
    }

    if (this.datecycleresult) {
      this.datecycle = this.datecycleresult;
    }
    if (this.Location != '') {
      this.Locationselected = this.Location;
    } else {
      this.Locationselected = 'na';
    }
  }
  Locationselected: string = '';
  deleteService: ServiceDateCycle;
  onDeleteNotify(message: ServiceDateCycle) {
    this.deleteService = message;
  }
  driveroster: any;
  onDriverSelection(SelectedDriver: any[]) {
    if (SelectedDriver != null) {
      if (SelectedDriver.length != 0) {
        this.driveroster = SelectedDriver;
        this.ondriverselect.emit(SelectedDriver);
        this.roster = true;
        this.showform = false;
      } else {
        this.roster = false;
      }
    } else {
      this.roster = false;
    }
  }

  resourceAllo: ResourceAllocation;
  onResourceAllocationSelection(
    SelectedResourceAllocation: ResourceAllocation
  ) {
    //new form showld show here
    this.onresourceSelect.emit(SelectedResourceAllocation);
    this.resourceAllo = SelectedResourceAllocation;
    this.resource = true;
    this.roster = false;
    this.showform = false;
  }

  Trips: TripDateCycle[] = [];
  onTripCreateNotify(trips: any[]) {
    this.Trips = trips;
  }
  onTripCreatedServiceNotify(servicesoftrips: any[]) {
    this.SelectedTripService = servicesoftrips;
  }

  truckUnavail: TruckUnavailability;
  onTruckUnavailability(selectedtruckunavailability: TruckUnavailability) {
    this.truckUnavail = selectedtruckunavailability;
  }
  SelectedTrip: TripDateCycle[] = [];
  onTripSelectionNotify(message: TripDateCycle[]) {
    if (message.length != 0) {
      this.SelectedTrip = message;
      this.ontripselect.emit(message);
      this.roster = false;
      this.showform = false;
      this.tripdetails = true;
    } else {
      this.tripdetails = false;
      this.SelectedTrip=[]
    }
  }
  HideRoster(check:any){
    if(check){
      this.details=0
      this.textondetails = ' ';
      this.showform = false;
      this.roster = false;
      this.resource = false;
      this.tripdetails = false;
    

    }
  }

  onGoToServiceNotify(message: any) {
    this.SelectedService = message;
    this.onserviceselect.emit(message);
    this.roster = false;
    this.showform = true;
    this.tripdetails = false;
  }
  SelectedService: ServiceDateCycle = {
    address: undefined,
    bookedTimeDrop: undefined,
    bookedTimePickup: undefined,
    chargeAmt: undefined,
    chargeDesc: undefined,
    chargeZoneDrop: undefined,
    chargeZonePickup: undefined,
    complete: false,
    containerId: undefined,
    containerTypeId: undefined,
    created: 0,
    curfewWindow: undefined,
    customerId: '',
    customerSite: undefined,
    dataSourceId: '',
    dehireDeadline: undefined,
    dehirePark: undefined,
    delivered: false,
    deliveryClose: undefined,
    deliveryOpen: undefined,
    depot: undefined,
    despatchBy: undefined,
    destinationLoc: undefined,
    destinationSite: 0,
    docket: undefined,
    driverId: undefined,
    dropDesc: undefined,
    dropSuburb: undefined,
    enteredBy: '',
    etaUpdatedTime: undefined,
    exported: false,
    holdcode: undefined,
    id: 0,
    loadBatchNo: undefined,
    loadCustReference: undefined,
    loadDesc: undefined,
    loadDestination: '',
    loadId: 0,
    loadNo: '',
    loadScheduledDate: 0,
    loadSuburb: undefined,
    loadTypeId: '',
    locationIdDrop: '',
    locationIdPickup: '',
    locationIdPickupActual: undefined,
    offsiderUsed: false,
    operationType: undefined,
    originLoc: undefined,
    originSite: 0,
    podCreated: false,
    priority: undefined,
    qty1: undefined,
    qty2: undefined,
    qty3: undefined,
    qty4: undefined,
    qty5: undefined,
    qty6: undefined,
    qty7: undefined,
    qty8: undefined,
    rateId: undefined,
    reasonId: undefined,
    remarks: undefined,
    replicated: undefined,
    runsheetId: undefined,
    serviceDate: 0,
    serviceDesc: undefined,
    serviceGroup: undefined,
    serviceIdRecharge: undefined,
    serviceNo: '',
    serviceTypeId: '',
    siteId: 0,
    stopSeqDrop: undefined,
    stopSeqPickup: undefined,
    storeETA: undefined,
    todFlags: undefined,
    trailerId: undefined,
    trailerIdTag: undefined,
    tripId: undefined,
    tripIdCust: undefined,
    tripNo: undefined,
    tripSeq: undefined,
    truckId: undefined,
    unit1: '',
    unit2: '',
    unit3: '',
    unit4: undefined,
    unit5: undefined,
    unit6: undefined,
    unit7: undefined,
    unit8: undefined,
    used: false,
    usedSet: undefined,
    vesselEta: undefined,
    vesselId: undefined,
    wharf: undefined,
    window1: undefined,
    window1From: undefined,
    window1To: undefined,
    window2: undefined,
    window2From: undefined,
    window2To: undefined,
    window3: undefined,
    window3From: undefined,
    window3To: undefined,
  };
  onServiceSelectionNotify(message: ServiceDateCycle[]) {
    if (message.length > 0) {
      this.SelectedService = message[0];
      this.onserviceselect.emit(message[0]);
      this.roster = false;
      this.showform = true;
      this.tripdetails = false;
    } else {
      this.showform = false;
    }
  }
  onbulkedit: boolean;
  onbulkeditnotify(message: boolean) {
    this.onbulkedit = message;
  }

  ServiceCreated: boolean = false;
  onServiceCreatedNotify(message: any) {
    if (message == true) {
      this.ServiceCreated = true;
      this.isservicecreate.emit(this.ServiceCreated);
    }
  }
  ServiceUpdated: ServiceDateCycle[] = [];
  onServiceUpdatedNotify(service: any[]) {
    this.ServiceUpdated = service;
    this.planService.ServiceSearchupdate.next(service)
  }

  SelectedTripService: ServiceDateCycle[] = [];
  OnTripServiceSelecetionNotify(message: ServiceDateCycle[]) {
    if (message.length != 0) {
      this.SelectedTripService = message;
    }
  }
  onSaveNotify(result: TripSaveResponse) {
    this.SelectedTripService = result.services;
    this.SelectedTrip = result.trips;
  }
  onDespatchNotify(result: TripDespatchResponse) {
    this.SelectedTrip = result.trips;
    this.SelectedTripService = result.services;
  }
  onUndespatchNotify(result: TripUndespatchResponse) {
    this.SelectedTrip = result.trips;
  }

  /** Announce the change in sort state for assistive technology. */
  announceSortChange(sortState: Sort) {
    // This example uses English messages. If your application supports
    // multiple language, you would internationalize these strings.
    // Furthermore, you can customize the message to add additional
    // details about the values being sorted.
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }
}

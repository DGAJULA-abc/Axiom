import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import {
  MatDialog,
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogModule,
} from '@angular/material/dialog';
import { AddContainerDialogComponent } from './add-container-dialog/add-container-dialog.component';
import { PlanService } from '../../services/plan.service';
import {
  EventTable,
  GetEvent,
  MultiLegSiteLocation,
  Reasons,
  ResourceAllocation,
  ServiceDateCycle,
  ServiceTripUI,
  ServiceTypes,
  Trailer,
  TripDateCycle,
  Vessel,
  ViewContainers,
  ViewCustomer,
  ViewDriver,
} from '../../models/plan.model';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import {
  FormBuilder,
  FormControl,
  Validators,
  FormGroup,
} from '@angular/forms';
import {
  MessageService,
  ConfirmationService,
  ConfirmEventType,
} from 'primeng/api';
import * as moment from 'moment';
import { EventdateCellRendererComponent } from '../../services/eventdate-cell-renderer/eventdate-cell-renderer.component';
import { AddReturnServiceDialogComponent } from './add-return-service-dialog/add-return-service-dialog.component';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import { SearchService } from 'src/app/features/search/services/search.service';
import { ActivatedRoute, Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-plan-details',
  templateUrl: './plan-details.component.html',
  styleUrls: ['./plan-details.component.scss'],
  providers: [ConfirmationService, MessageService],
})
export class PlanDetailsComponent implements OnInit, OnChanges {
  //get the selected service in this component
  @Input() selectedService: ServiceDateCycle;
  @Input() onbulkedit: boolean;
  @Input() create: boolean;
  @Input() selectedcustomer: ViewCustomer;
  @Input() serviceTrips: TripDateCycle[];
  @Input() customerValue: any;
  @Input() fromDtSearch: any;
  @Input() toDtSearch: any;
  @Output() deletenotify: EventEmitter<ServiceDateCycle> =
    new EventEmitter<ServiceDateCycle>();

  //Output variables
  @Output() servicecreatednotify: EventEmitter<boolean> =
    new EventEmitter<boolean>();
  @Output() serviceupdatesnotify: EventEmitter<ServiceDateCycle[]> =
    new EventEmitter<ServiceDateCycle[]>();

  //flag variables
  pickupflag: boolean = false;
  addbutton: boolean = true;
  // variables for a selected service;
  ServiceHeader: string = 'New Service';
  tripno: any;
  runsheetno: any;
  used: boolean = false;
  completed: boolean = false;

  ChosenTrip: TripDateCycle;
  trip: ServiceTripUI = {
    status: undefined,
    driver: undefined,
    truck: undefined,
    trailerlead: undefined,
    trailertag: undefined,
    plannedstart: undefined,
    plannedend: undefined,
  };

  servicecalcmethod: any;
  servicecharge: any;
  servicerate: any;

  showReason: Reasons = {
    active: false,
    driver: false,
    reasonDescription: '',
    reasonId: '',
    siteId: 0,
  };
  isLoading: boolean = true;
  descmerge: any;
  // reasonmerge: any;
  savepayload: any;
  remarksmerge: any;
  containermerge: any;
  vesselmerge: any;
  dehiredeadlinemerge: any;
  deliveryopenmerge: any;
  deliveryclosemerge: any;
  vesseleta: any;
  wharfmerge: any;
  depotmerge: any;
  custsitemerge: any;
  originLoacmerge: any;
  destLocmerge: any;
  dehireparkmerge: any;
  dropmerge: any;
  servicetypemerge:any;
  loadschedmerge: any;
  schedatemerge: any;
  docketmerge: any;
  pickupmerge: any;
  loadtypemerge: any;
  custrefmerge: any;
  connotemerge: any;
  uni1merge: any;
  uni2merge: any;
  uni3merge: any;
  uni4merge: any;
  uni5merge: any;
  uni6merge: any;
  uni7merge: any;
  uni8merge: any;

  deliverydate: any;
  scheduleddate:any;
  deliveryclose: any;
  dehiredeadline: any;
  @Input() fromSearch: boolean;
  @Input() fromSearchRunsheet: any;

  fromSearchRunshet1Type: any = '';
  runsheetUsed: boolean = false;

  fromSearch1: boolean = false;
  selectedTrip:any[];
  ngOnChanges() {
    this.checkRunseetServiceBtnState = this.planService.runsheetServiceBtnState;
    // console.log("checkRunseetServiceBtnState plan>>",  this.checkRunseetServiceBtnState);
    this.searchService.getMessage.subscribe((msg: any) => (this.message = msg));
    if(this.checkRunseetServiceBtnState){
      this.fromSearch1 = true;

    }
    if (this.message == true && this.fromSearch == undefined) {
      this.fromSearch1 = true;
    } else if (this.fromSearch == false) {
      this.fromSearch1 = false;
    }
    
     this.fromSearchRunshet1Type = this.fromSearchRunsheet?.type;
     this.runsheetUsed = this.fromSearchRunsheet?.used;

    if (this.customerValue == null || typeof this.customerValue !== 'string') {
      // Set the value for customerValue as an empty string
      this.customerValue = '';
    }
    this.isLoading = true;
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        this.isLoading = false;
        this.getServiceTypes(result['ref'].serviceTypes);
        this.getLoadTypes(result['ref'].loadTypes);
        this.selectedsite = result['selectedSite'];
        this.ViewServiceTypes = result['ref'].serviceTypes;
        this.ViewDrivers = result['ref'].drivers;
        this.ViewTrucks = result['ref'].trucks;
        this.ViewContainers = result['ref'].containers;
        this.ViewCustomers = result['ref'].customers;
        this.ViewTrailers = result['ref'].trailers;
        this.ViewVessels = result['ref'].vessels;
        this.ViewLocations = result['ref'].locations;
        this.ViewSites = result['ref'].sites;
        this.getReason(result['ref'].reasons);
  
        if (this.selectedService.id != 0) {
          if (
            this.selectedService.originSite == this.selectedsiteid &&
            this.selectedService.destinationSite == this.selectedsiteid
          ) {
            this.selectedsitedescription = this.selectedsite.description;
            this.sites.push(this.selectedsite.description);
          }
        } else {
          this.sites.push(
            this.ViewSites.filter(
              (x: { id: number }) => x.id == parseInt(sessionStorage.getItem('selectedSiteId')!)
            )[0].description
          );
        }
      }

    });
    //TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
    this.selectedsiteid = parseInt(sessionStorage.getItem('selectedSiteId')!);
    this.AllCustomerId(this.selectedsiteid);
    this.serviceform = this.formBuilder.group({
      loadno: [],
      serviceno: [],
      delivered: [],
      deliverydate: [],
      scheduleddate: [],
      customer: ['', Validators.required],
      servicetype: ['', Validators.required],
      loadtype: [],
      pickup: [],
      drop: [],
      docket: [],
      custref: [],
      connote: [],
      tonnes: [],
      pallets: [],
      dollars: [],
      hours: [],
      containers: [],
      kilograms: [],
      kilometers: [],
      reels: [],
      description: [],
      deliverywindow1: [],
      deliverywindow2: [],
      deliverywindow3: [],
      deliverywindow4: [],
      deliverywindow5: [],
      deliverywindow6: [],
      pickuptime: [],
      droptime: [],
      enteredby: [],
      servicecreated: [],
      reason: [],
      remarks: [],
      container: [],
      vessel: [],
      vesseleta: [],
      deliveryopen: [],
      deliveryclose: [],
      dehiredeadline: [],
      wharf: [],
      depot: [],
      customersite: [],
      dehirepark: [],
      primaryoriginsite: [],
      primaryoriginlocation: [],
      finaldestinationsite: [],
      finaldestinationlocation: [],
    });
    this.detailsform = this.formBuilder.group({
      CONNOTE: [],
      CUSTREF: [],
      DOCKET: [],
    });
    if (this.selectedService.id != 0) {
      this.create = false;
    }
    if (this.create == true) {
      //it's a new service
      this.fromSearch = false;
      this.ServiceHeader = 'New Service';
      this.serviceform.get('pickup')?.enable();
      this.serviceform.get('drop')?.enable();
      this.deliverydate = moment(new Date()).format('DD/MM/YY');
      this.serviceform.controls['customer'].setValue(
        this.selectedcustomer.customerId
      );
      this.serviceform.reset;
      this.detailsform.reset;
    } else {
      //it's an existing one
      if (this.selectedService.id != null) {
        this.ServiceHeader = 'Service ' + this.selectedService.serviceNo;
        this.tripno = this.selectedService.tripIdCust;
        if(this.selectedService.tripId){
          this.planService.getTrip(this.selectedService.tripId).subscribe((res) => {
            if (res) {
              this.selectedTrip = res.trips;
            }
          });

        }
        this.runsheetno = this.selectedService.runsheetId;
        if (this.tripno) {
          this.showtripno = true;
        }
        if (this.runsheetno) {
          this.showrunsheetno = true;
        }
        if (this.selectedService.used == true) {
          this.used = true;
        }
        if (this.selectedService.complete == true) {
          this.completed = true;
        }
        this.addbutton = true;
        // this.serviceform.get('pickup')?.disable();
        // this.serviceform.get('drop')?.disable();
        // this.serviceform.get('container')?.disable();
        // this.serviceform.get('vessel')?.disable();
        // this.serviceform.get('vesseleta')?.disable();
        // this.serviceform.get('deliveryopen')?.disable();
        // this.serviceform.get('deliveryclose')?.disable();
        // this.serviceform.get('dehiredeadline')?.disable();
        // this.serviceform.get('wharf')?.disable();
        // this.serviceform.get('depot')?.disable();
        // this.serviceform.get('customersite')?.disable();
        // this.serviceform.get('dehirepark')?.disable();
        // this.serviceform.get('primaryoriginsite')?.disable();
        // this.serviceform.get('primaryoriginlocation')?.disable();
        // this.serviceform.get('finaldestinationsite')?.disable();
        // this.serviceform.get('finaldestinationlocation')?.disable();

        this.pickupflag = true;

        //get trip info if it exists
        if (this.selectedService.tripId != null) {
          this.tripexists = true;
          this.serviceTrips.forEach((t) => {
            if (t.id == this.selectedService.tripId) this.ChosenTrip = t;
          });
          if(this.ChosenTrip!=undefined){
            this.getTripDetails(this.ChosenTrip);
          }
        } else {
          this.showtripno = false;
          this.tripexists = false;
          this.showrunsheetno = false;
          this.ChosenTrip = {
            activities: [],
            actualDespatchTime: undefined,
            actualFinishTime: undefined,
            actualReturnTime: undefined,
            actualStartTime: undefined,
            batchNo: undefined,
            cachedPhase: 0,
            cachedRoutingQty: 0,
            cachedStatus: '',
            cachedTrailerCapacity: 0,
            cachedTruckCapacity: 0,
            chainCommands: [],
            comments: undefined,
            companyId: '',
            containerNo: undefined,
            created: 0,
            custRef: undefined,
            customerClaimAmt: undefined,
            dataSourceId: undefined,
            deliveredServicesCount: '',
            deliveryWindow: undefined,
            despatchByTime: undefined,
            despatchLocationId: undefined,
            despatched: false,
            dockId: undefined,
            docket: undefined,
            driverBreakIds: undefined,
            driverId: 0,
            dropSuburb: '',
            enteredBy: '',
            etaUpdatedTime: undefined,
            eventIds: undefined,
            firstDrop: '',
            firstLoadType: undefined,
            firstPickup: '',
            holdCode: undefined,
            id: 0,
            lastDrop: '',
            lastPickup: '',
            loadNo: '',
            loadSuburb: '',
            locations: [],
            multiDrop: undefined,
            paperWorkReady: undefined,
            pickWaveRef: undefined,
            pickupLocationIds: [],
            plannedDespatchTime: undefined,
            plannedFinishTime: 0,
            plannedReturnTime: undefined,
            plannedStartTime: 0,
            regionId: undefined,
            remarks: undefined,
            returnLocationId: '',
            revenue: undefined,
            routeId: undefined,
            routingUnit: '',
            sdpLineIds: undefined,
            serviceIds: [],
            settledDate: undefined,
            siteId: 0,
            trailerId: undefined,
            trailerIdTag: undefined,
            tripComplete: false,
            tripDate: 0,
            tripIdCust: '',
            tripNo: undefined,
            truckId: '',
            utilization: '',
            vesselNo: undefined,
          };
        }

        this.showReason = this.getSelectedReason(this.selectedService.reasonId);
        let r =
          this.showReason.reasonId + '_' + this.showReason.reasonDescription;
        //form values
        if (this.selectedService.loadScheduledDate != 0) {
          this.deliverydate = this.timeService.convertMillisecondsToDate(
            this.selectedService.loadScheduledDate
          );
          this.scheduleddate =this.deliverydate
        
          // this.serviceform.controls['scheduleddate'].setValue(v)
        } else {
          this.deliverydate = this.timeService.convertMillisecondsToDate(
            this.selectedService.serviceDate
          );
         this.scheduleddate=this.deliverydate;

        }

        this.deliveryclose = this.timeService.convertMillisecondsToDate(
          this.selectedService.deliveryClose
        );
        this.dehiredeadline = this.timeService.convertMillisecondsToDate(
          this.selectedService.dehireDeadline
        );
        this.selectedServiceType = this.selectedService.serviceTypeId;
        this.selectedLoadType = this.selectedService.loadTypeId;
        this.serviceform.patchValue({
          loadno: this.selectedService.loadNo,
          serviceno: this.selectedService.serviceNo,
          customer: this.selectedService.customerId,
          // servicetype: this.selectedService.serviceTypeId,
          loadtype: this.selectedService.loadTypeId,
          deliverydate: this.timeService.convertMillisecondsToDate(
            this.selectedService.serviceDate
          ),
          scheduleddate: this.timeService.convertMillisecondsToDate(
            this.selectedService.serviceDate
          ),
          pickup: this.selectedService.locationIdPickup,
          dehiredeadline: this.timeService.convertMillisecondsToDate(
            this.selectedService.dehireDeadline
          ),
          deliveryopen: this.timeService.convertMillisecondsToDate(
            this.selectedService.deliveryOpen
          ),
          deliveryclose: this.timeService.convertMillisecondsToDate(
            this.selectedService.deliveryClose
          ),
          vesseleta: this.timeService.convertMillisecondsToDate(
            this.selectedService.vesselEta
          ),
          drop: this.selectedService.locationIdDrop,
          docket: this.selectedService.docket,
          custref: this.selectedService.loadCustReference,
          connote: this.selectedService.loadBatchNo,
          tonnes: this.selectedService.qty1,
          pallets: this.selectedService.qty2,
          dollars: this.selectedService.qty3,
          hours: this.selectedService.qty4,
          containers: this.selectedService.qty5,
          kilograms: this.selectedService.qty6,
          kilometers: this.selectedService.qty7,
          reels: this.selectedService.qty8,
          enteredby: this.selectedService.enteredBy,
          servicecreated: this.timeService.convertMillisecondsToDateTimeM(
            this.selectedService.created
          ),
          reason: this.showReason,
          description: this.selectedService.serviceDesc,
          remarks: this.selectedService.remarks,
          container:
            this.selectedService.containerId +
            '(' +
            this.selectedService.containerTypeId +
            ')',
          wharf: this.selectedService.wharf,
          depot: this.selectedService.depot,
          customersite: this.selectedService.customerSite,
          dehirepark: this.selectedService.dehirePark,
          primaryoriginlocation: this.selectedService.originLoc,
          finaldestinationsite: this.selectedsitedescription,
          finaldestinationlocation: this.selectedService.destinationLoc,
          primaryoriginsite: this.selectedsitedescription,
          vessel: this.selectedService.vesselId,
        });
        this.selectedContainer=this.selectedService.containerId
        this.selectedLocation = this.selectedService.locationIdPickup;
        this.customerValue = this.selectedService.customerId;
        this.servicerate = this.selectedService.rateId;
        this.servicecalcmethod = this.selectedService.chargeDesc;
        this.servicecharge = this.selectedService.chargeAmt;
        //event tables
        this.getEventTableData(this.selectedService.id);

        //search api
        this.planService
          .searchContainer(this.selectedService.containerId)
          .subscribe((res: any) => {
            //handle it here
          });
      }
    }
  }
  tripdata(tripno: any) {
    console.log(this.trip);
    const baseURL = this.router.serializeUrl(
      this.router.createUrlTree(['plan'],{
        queryParams:{ startdate:this.selectedTrip[0].plannedStartTime  ,enddate:this.selectedTrip[0].plannedFinishTime,tripid:this.selectedTrip[0].id},
        queryParamsHandling: 'merge',
      })
    );
    window.open(baseURL, '_blank');
  }
  runsheetdata(runsheetId: any) {
    const baseUrl = this.router.serializeUrl(
      this.router.createUrlTree(['reconcile/ViewRunsheet'], {
        queryParams: { runsheetId: runsheetId },
        queryParamsHandling: 'merge',
      })
    );
    window.open(baseUrl, '_blank');
  }

  getTooltipContent(controlName: string): string {
    let servicetype = this.detailsform.controls['servicetype'].value;
    if (servicetype === 'local' && controlName == 'TONNES') {
      return 'This Value cannot be higher than 50';
    } else if (servicetype === 'local' && controlName == 'PALLETS') {
      return 'This Value cannot be higher than 30';
    }
    {
      // Handle other cases
      return 'This Value cannot be Empty';
    }
  }

  getBorderColor(controlName: string): string {
    let value = this.detailsform.controls[controlName].value;
    if (controlName === 'TONNES' && value >= 50) {
      return '#ff5054'; // Red border color
    } else if (controlName === 'PALLETS' && value >= 30) {
      return '#ff5054'; // Red border color
    } else {
      return ''; // Default border color
    }
  }

  getBackgroundColor(controlName: string): string {
    let value = this.detailsform.controls[controlName].value;
    if (controlName === 'TONNES' && value >= 50) {
      return '#ffe9e9'; // Light red background color
    } else if (controlName === 'PALLETS' && value >= 30) {
      return '#ffe9e9'; // Light red background color
    } else {
      return ''; // Default background color
    }
  }

  tableeventrow: EventTable = {
    eventdatetime: undefined,
    eventdate: undefined,
    eventtime: 0,
    eventtype: '',
    relation: '',
    mdserverdatetime: undefined,
    mdserverdate: undefined,
    mdservertime: undefined,
    eventcreateddatetime: 0,
    eventcreateddate: undefined,
    eventcreatedtime: undefined,
    driver: '',
    trip: '',
    truck: '',
    trailer1: '',
    trailer2: '',
    dock: '',
    user: '',
    location: undefined,
    datasource: '',
    eventadjusted: false,
    todexportable: false,
    exported: false,
    comments: '',
    latitude: undefined,
    longitude: undefined,
    logonlogoffcompliance: false,
    serviceno: undefined,
    loadno: undefined,
  };
  getEventTableData(serviceid: any) {
    this.planService.getServiceEvent(serviceid).subscribe((result) => {
      this.eventsfromapi = result.events.events;
      this.Eventrows = [];
      this.eventsfromapi.forEach((event) => {
        this.tableeventrow = {
          eventdatetime: '',
          eventdate: '',
          eventtime: 0,
          eventtype: '',
          relation: '',
          mdserverdatetime: '',
          mdserverdate: '',
          mdservertime: '',
          eventcreateddatetime: 0,
          eventcreateddate: '',
          eventcreatedtime: '',
          driver: '',
          trip: '',
          truck: '',
          trailer1: '',
          trailer2: '',
          dock: '',
          user: '',
          location: '',
          datasource: '',
          eventadjusted: false,
          todexportable: false,
          exported: false,
          comments: '',
          latitude: '',
          longitude: '',
          logonlogoffcompliance: false,
          serviceno: '',
          loadno: '',
        };
        this.tableeventrow.eventtype = event.eventDescription;
        this.tableeventrow.relation = event.eventLevel.toLowerCase();
        this.tableeventrow.driver = this.getSelectedDriver(event.driverId);
        this.tableeventrow.trip = event.tripIdCust;
        this.tableeventrow.truck = this.getSelectedTruck(event.truckId);
        this.tableeventrow.trailer1 = event.trailerId;
        this.tableeventrow.trailer2 = event.trailerTagId;
        this.tableeventrow.user = event.userId;
        this.tableeventrow.datasource = event.datasourceId;
        this.tableeventrow.loadno = event.loadNo;
        this.tableeventrow.serviceno = event.serviceNo;
        this.tableeventrow.comments = event.comments;
        this.tableeventrow.eventcreateddatetime = event.created;
        this.tableeventrow.eventcreateddate = event.created;
        this.tableeventrow.eventcreatedtime = event.created;
        this.tableeventrow.eventdatetime = event.eventTime;
        this.tableeventrow.eventdate = event.eventTime;
        this.tableeventrow.eventtime = event.eventTime;

        this.Eventrows.push(this.tableeventrow);
      });
      this.rowData = this.Eventrows;
    });
  }
  Eventrows: EventTable[] = [];
  eventsfromapi: GetEvent[] = [];
  //get data for trip
  getTripDetails(chosentrip: TripDateCycle) {
    if (chosentrip.despatched == true) {
      this.trip.status = 'despatched';
    }
    this.trip.driver = this.getSelectedDriver(chosentrip.driverId);
    this.trip.truck = this.getSelectedTruck(chosentrip.truckId);
    this.trip.trailerlead = chosentrip.trailerId;
    this.trip.trailertag = chosentrip.trailerIdTag;
    this.trip.plannedstart = this.timeService.convertMillisecondsToDateTimeM(
      chosentrip.plannedStartTime
    );
    this.trip.plannedend = this.timeService.convertMillisecondsToDateTimeM(
      chosentrip.plannedFinishTime
    );
  }
  getSelectedDriver(driverId: any): any {
    let a = '';
    this.ViewDrivers.forEach((element) => {
      if (element.id == driverId) {
        a = element.employeeName + ' (' + element.companyId + ')';
      }
    });
    return a;
  }
  getSelectedTruck(truckId: any) {
    let a = '';
    this.ViewTrucks.forEach((element) => {
      if (element.truckId == truckId) {
        a =
          element.truckId +
          ' (' +
          element.routeCapacity +
          ', ' +
          element.truckTypeId +
          ', ' +
          element.companyId +
          ')';
      }
    });
    return a;
  }

  //getthe selected reason in an existing service
  reason: Reasons;
  getSelectedReason(Id: any): Reasons {
    let a = '';
    this.reasons.forEach((reason) => {
      if (reason.reasonId == Id) {
        this.reason = reason;
      }
    });
    if (this.reason != undefined || this.reason != null) {
      return this.reason;
    }
    return {
      active: false,
      driver: false,
      reasonDescription: '',
      reasonId: '',
      siteId: 0,
    };
  }
  date: Date;
  //selected service toggle hidden items
  showtripno: boolean = false;
  tripexists: boolean = false;
  showrunsheetno: boolean = false;

  //autocomplete for dropdowns
  customers: string[] = [];
  // selectedCustomer: any ;
  filteredCustomers: any[];
  getCustomers() {
   this.customers=[];
    this.ViewCustomers.forEach((element) => {
      this.customers.push(element.customerId);
    });
  }
  filterCustomer(event: any) {
    this.getCustomers();
    this.filteredCustomers=[]
    
    let filtered: any[] = [];
    let query = event.query;
    this.filteredCustomers = this.customers.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  //autocomplete for reasons
  filteredReasons: any[] = [];
  filterReason(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.filteredReasons = this.reasons.filter(option => option.reasonDescription.toLowerCase().includes(query.toLowerCase()));

  }
  getReason(viewreasons: Reasons[]) {
    this.reasons=[];
    viewreasons.forEach((element) => {
      // let temp = '';
      // temp = element.reasonId + '_' + element.reasonDescription;
      this.reasons.push(element);
    });
    this.planService.reasons.next(this.reasons);
    // this.childComponent.reasons = this.reasons
  }

  //autocomplete for servicetypes
  servicetypes: any[] = [];
  selectedServiceType: any = null;
  filteredServiceType: any[];
  //service type api integration
  getServiceTypes(serviceTypes: any[]) {
    serviceTypes.forEach((element) => {
      this.servicetypes.push(element.serviceTypeId);
    });
  }
  filterServiceType(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.filteredServiceType = this.servicetypes.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  unitdata: any;
  isservicetypeSelected: boolean = false;
  unit1: boolean = false;
  unit2: boolean = false;
  unit3: boolean = false;
  unit4: boolean = false;
  unit5: boolean = false;
  unit6: boolean = false;
  unit7: boolean = false;
  unit8: boolean = false;

  reqPickupLocation: boolean;
  reqDropLocation: boolean;
  dropcheck: boolean;
  pickupcheck: boolean;

  details_showred: boolean = false;
  summary_showred: boolean = false;

  HidefaultDetail: boolean = true;
  onServiceSelection(event: any) {
    this.unit1 = false;
    this.unit2 = false;
    this.unit3 = false;
    this.unit4 = false;
    this.unit5 = false;
    this.unit6 = false;
    this.unit7 = false;
    this.unit8 = false;
    this.reqDropLocation = false;
    this.reqPickupLocation = false;
    if (this.create == true) {
      const matchedServiceType = this.ViewServiceTypes.find(
        (element) => element.serviceTypeId == event
      );
      if (matchedServiceType) {
        this.isservicetypeSelected = true;
        this.unitdata = matchedServiceType;
        this.reqDropLocation = this.unitdata.reqDropLocation;
        this.reqPickupLocation = this.unitdata.reqPickupLocation;

        if (
          this.unitdata.reqUnit1 ||
          this.unitdata.reqUnit2 ||
          this.unitdata.reqUnit3 ||
          this.unitdata.reqUnit4 ||
          this.unitdata.reqUnit5 ||
          this.unitdata.reqUnit6 ||
          this.unitdata.reqUnit7 ||
          this.unitdata.reqUnit8
        ) {
          //show detail as red and toggle off
          this.details_showred = true;
        } else {
          this.details_showred = false;
        }
        if (this.reqDropLocation) {
          this.dropcheck = true;
          this.serviceform.controls['drop'].setValidators([
            Validators.required,
          ]);
          this.serviceform.get('drop')!.updateValueAndValidity();
        } else {
          this.dropcheck = false;
          this.serviceform.controls['drop'].setValidators([]);
          this.serviceform.get('drop')!.updateValueAndValidity();
        }
        if (this.reqPickupLocation) {
          this.pickupcheck = true;
          this.serviceform.controls['pickup'].setValidators([
            Validators.required,
          ]);
          this.serviceform.get('pickup')!.updateValueAndValidity();
        } else {
          this.pickupcheck = false;
          this.serviceform.controls['pickup'].setValidators([]);
          this.serviceform.get('pickup')!.updateValueAndValidity();
        }
        if (this.pickupcheck || this.dropcheck) {
          this.summary_showred = true;
        } else {
          this.summary_showred = false;
        }

        if (this.unitdata.unit1) {
          this.unit1 = true;
          this.detailsform.addControl(this.unitdata.unit1, new FormControl(''));
        }
        if (this.unitdata.unit2) {
          this.unit2 = true;
          this.detailsform.addControl(this.unitdata.unit2, new FormControl(''));
        }
        if (this.unitdata.unit3) {
          this.unit3 = true;
          this.detailsform.addControl(this.unitdata.unit3, new FormControl(''));
        }
        if (this.unitdata.unit4) {
          this.unit4 = true;
          this.detailsform.addControl(this.unitdata.unit4, new FormControl(''));
        }
        if (this.unitdata.unit5) {
          this.unit5 = true;
          this.detailsform.addControl(this.unitdata.unit5, new FormControl(''));
        }
        if (this.unitdata.unit6) {
          this.unit6 = true;
          this.detailsform.addControl(this.unitdata.unit6, new FormControl(''));
        }
        if (this.unitdata.unit7) {
          this.unit7 = true;
          this.detailsform.addControl(this.unitdata.unit7, new FormControl(''));
        }
        if (this.unitdata.unit8) {
          this.unit8 = true;
          this.detailsform.addControl(this.unitdata.unit8, new FormControl(''));
        }
      }
    } else {
      const matchedServiceType = this.ViewServiceTypes.find(
        (element) => element.serviceTypeId == event
      );
      this.HidefaultDetail = !this.HidefaultDetail;
      if (matchedServiceType) {
        this.isservicetypeSelected = true;
        this.unitdata = matchedServiceType;
        this.reqDropLocation = this.unitdata.reqDropLocation;
        this.reqPickupLocation = this.unitdata.reqPickupLocation;

        if (this.unitdata.unit1) {
          this.unit1 = true;
          this.serviceform.addControl(this.unitdata.unit1, new FormControl(''));
        }
        if (this.unitdata.unit2) {
          this.unit2 = true;
          this.serviceform.addControl(this.unitdata.unit2, new FormControl(''));
        }
        if (this.unitdata.unit3) {
          this.unit3 = true;
          this.serviceform.addControl(this.unitdata.unit3, new FormControl(''));
        }
        if (this.unitdata.unit4) {
          this.unit4 = true;
          this.serviceform.addControl(this.unitdata.unit4, new FormControl(''));
        }
        if (this.unitdata.unit5) {
          this.unit5 = true;
          this.serviceform.addControl(this.unitdata.unit5, new FormControl(''));
        }
        if (this.unitdata.unit6) {
          this.unit6 = true;
          this.serviceform.addControl(this.unitdata.unit6, new FormControl(''));
        }
        if (this.unitdata.unit7) {
          this.unit7 = true;
          this.serviceform.addControl(this.unitdata.unit7, new FormControl(''));
        }
        if (this.unitdata.unit8) {
          this.unit8 = true;
          this.serviceform.addControl(this.unitdata.unit8, new FormControl(''));
        }
      }
    }
  }
  //autocomplete for loadtypes
  loadTypes: any[] = [];
  selectedLoadType: any = null;
  filteredLoadTypes: any[];
  //load type api integration
  getLoadTypes(loadtypes: any[]) {
    loadtypes.forEach((element) => {
      this.loadTypes.push(element.loadTypeId);
    });
  }
  filterLoadType(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    this.filteredLoadTypes = this.loadTypes.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  //autocomplete for locationIds
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  location_arr: any[] = [];
  getLocationIds() {
    this.locationIds = [];
    this.ViewLocations.forEach((element) => {
      this.locationIds.push(element.locationId);
    });
  }
  filterLocation(event: any) {
    this.getLocationIds();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredLocations = this.locationIds.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }

  //autocomplete for containers
  containers: any[] = [];
  selectedContainer: any;
  filteredContainers: any[];
  container_arr: any[] = [];
  getContainers() {
    this.containers=[]
    this.ViewContainers.forEach((element) => {
      this.containers.push(element.containerId);
    });
  }
  filterContainer(event: any) {
    this.getContainers();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredContainers = this.containers.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }

  //autocomplete for drop location
  filtereddropLocations: any[] = [];
  selecteddropLocation: any;
  filterdropLocation(event: any) {
    this.getLocationIds();
    let filtered: any[] = [];
    let query = event.query;
    this.filtereddropLocations = this.locationIds.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }

  //autocomplete for Wharf
  wharf_arr: string[] = [];
  wharfs: any[] = [];
  getAllWharf() {
    this.wharfs=[];
    this.wharf_arr=[];
    this.AllData.forEach((element: any) => {
      if (element.locationTypeId == 'WHARF') {
        this.wharf_arr.push(element.locationId);
      }
    });
    this.wharfs = this.wharf_arr.filter(
      (item, index) => this.wharf_arr.indexOf(item) === index
    );
  }
  selectedWharf: any;
  filteredWharfs: any[] = [];
  filterWharf(event: any) {
    this.getAllWharf();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredWharfs = this.wharfs.filter(option => option.toLowerCase().includes(query.toLowerCase()));
  }
  //autocomplete for depot
  depot_arr: string[] = [];
  depots: any[] = [];
  getAllDepots() {
    this.depot_arr=[];
    this.depots=[];
    this.AllData.forEach((element: any) => {
      if (element.locationTypeId == 'DEPOT') {
        this.depot_arr.push(element.locationId);
      }
    });
    this.depots = this.depot_arr.filter(
      (item, index) => this.depot_arr.indexOf(item) === index
    );
  }
  selectedDepot: any;
  filteredDepots: any[] = [];
  filterDepot(event: any) {
    this.getAllDepots();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredDepots = this.depots.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  //autocomplete for Customer Site
  custsite_arr: string[] = [];
  custSites: any[] = [];
  getAllCustomerSites() {
    this.custsite_arr = [];
    this.custSites= [];
    this.AllData.forEach((element: any) => {
      if (element.locationTypeId == 'CUSTOMER') {
        this.custsite_arr.push(element.locationId);
      }
    });
    this.custSites = this.custsite_arr.filter(
      (item, index) => this.custsite_arr.indexOf(item) === index
    );
  }
  selectedCustomerSite: any;
  filteredCustomerSites: any[] = [];
  filterCustomerSite(event: any) {
    this.getAllCustomerSites();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredCustomerSites = this.custSites.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  //autocomplete for Dehire Park
  dehirepark_arr: string[] = [];
  dehireParks: any[] = [];
  getAllDehireParks() {
    this.AllData.forEach((element: any) => {
      if (element.locationTypeId == 'PARK') {
        this.dehirepark_arr.push(element.locationId);
      }
    });
    this.dehireParks = this.dehirepark_arr.filter(
      (item, index) => this.dehirepark_arr.indexOf(item) === index
    );
  }
  selectedDehire: any;
  filteredDehires: any[] = [];
  filterDehire(event: any) {
    this.getAllDehireParks();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredDehires = this.dehireParks.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  //autocomplete for origin location
  filteredOriginLocations: any[] = [];
  selectedOriginLocation: any;
  filterOriginLocation(event: any) {
    this.getLocationIds();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredOriginLocations = this.locationIds.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }

  //autocomplete for final destination location
  filteredDestLocations: any[] = [];
  selectedDestLocation: any;
  filterDestLocation(event: any) {
    this.getLocationIds();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredDestLocations = this.locationIds.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }

  //autocomplete for Vessel
  vessel_arr: string[] = [];
  vessels: any[] = [];

  getVessels(viewvessels: Vessel[]) {
    this.vessel_arr= [];
  this.vessels= [];

    viewvessels.forEach((element) => {
      this.vessel_arr.push(element.vessel);
    });
    this.vessels = this.vessel_arr.filter(
      (item, index) => this.vessel_arr.indexOf(item) === index
    );
  }

  selectedVessel: any;
  filteredVessels: any[] = [];
  filterVessel(event: any) {
    this.getVessels(this.ViewVessels);
    let filtered: any[] = [];
    let query = event.query;
    this.filteredVessels = this.vessels.filter(option => option.toLowerCase().includes(query.toLowerCase()));
  }

  //autocomplete finish

  //create another button
  blankeventtable: EventTable[] = [];
  blankreason: Reasons = {
    active: false,
    driver: false,
    reasonDescription: '',
    reasonId: '',
    siteId: 0,
  };
  CreateAnother() {
    this.addbutton = true;
    this.trip.status = '';
    this.trip.driver = '';
    this.trip.truck = '';
    this.trip.trailerlead = '';
    this.trip.trailertag = '';
    this.trip.plannedstart = '';
    this.trip.plannedend = '';
    this.tripno = '';
    this.tripexists = false;
    this.showtripno = false;
    this.serviceform.controls['pickup'].enable();
    this.serviceform.controls['drop'].enable();
    this.serviceform.controls['container'].enable();
    this.serviceform.controls['vessel']?.enable();
    this.serviceform.controls['vesseleta']?.enable();
    this.serviceform.controls['deliveryopen']?.enable();
    this.serviceform.controls['deliveryclose']?.enable();
    this.serviceform.controls['dehiredeadline']?.enable();
    this.serviceform.controls['wharf']?.enable();
    this.serviceform.controls['depot']?.enable();
    this.serviceform.controls['customersite']?.enable();
    this.serviceform.controls['dehirepark']?.enable();
    this.serviceform.controls['primaryoriginsite']?.enable();
    this.serviceform.controls['primaryoriginlocation']?.enable();
    this.serviceform.controls['finaldestinationsite']?.enable();
    this.serviceform.controls['finaldestinationlocation']?.enable();
    this.create = !this.create;
    this.rowData = this.blankeventtable;
    this.showReason = this.blankreason;
    this.serviceform.patchValue({
      drop: null,
      docket: '',
      custref: '',
      connote: '',
      tonnes: '',
      pallets: ' ',
      loadno: ' ',
      serviceno: ' ',
      dollars: ' ',
      hours: ' ',
      containers: ' ',
      kilograms: ' ',
      kilometers: ' ',
      reels: ' ',
      description: ' ',
      reason: null,
      enteredby: ' ',
      servicecreated: ' ',
      remarks: ' ',
      container: ' ',
      wharf: null,
      depot: null,
      customersite: null,
      dehirepark: null,
      primaryoriginlocation: null,
      finaldestinationlocation: null,
      vessel: '',
    });
    this.detailsform.reset;
  }

  // getDepotformdetails(){
  //   this.savepayload.address=this.selectedService.address;
  //   this.savepayload.chargeZoneDrop=this.selectedService.chargeZoneDrop;
  //   this.savepayload.destinationLoc=this.selectedService.destinationLoc;
  //   this.savepayload.driverId=this.selectedService.driverId;
  //   this.savepayload.dropDesc=this.selectedService.dropDesc;
  //   this.savepayload.dropSuburb=this.selectedService.dropSuburb;
  //   this.savepayload.loadDesc=this.selectedService.loadDesc;
  //   this.savepayload.loadDestination=this.selectedService.loadDestination;
  //   this.savepayload.loadSuburb=this.selectedService.loadSuburb;
  // }
  getConatinerformdetails() {
    const containerinfomerge = {
      chargeZonePickup: this.selectedService.chargeZonePickup,
      complete: this.selectedService.complete,
      created: this.selectedService.created,
      dataSourceId: this.selectedService.dataSourceId,
      delivered: this.selectedService.delivered,
      enteredBy: this.selectedService.enteredBy,
      exported: this.selectedService.exported,
      id: this.selectedService.id,
      loadId: this.selectedService.loadId,
      loadNo: this.selectedService.loadNo,
      loadScheduledDate: this.selectedService.loadScheduledDate,
      offsiderUsed: this.selectedService.offsiderUsed,
      podCreated: this.selectedService.podCreated,
      todFlags: this.selectedService.todFlags,
      used: this.selectedService.used,
    };
  }
  //get vessel id
  getVesselId(vesseldesc: string): number {
    let a: number = 0;
    this.ViewVessels.forEach((element) => {
      if (element.vessel == vesseldesc) {
        a = element.id;
      }
    });
    return a;
  }

  //get formcontrolname based on detail form for create
  getformcontrolname(key: any): string {
    var a = '';
    for (const field in this.detailsform.controls) {
      if (field == key) {
        a = field;
      }
    }
    return this.detailsform.controls[a].value;
  }
  onChangeDeliverydate() {
    this.serviceform.controls['scheduleddate'].setValue(
      this.serviceform.controls['deliverydate'].value
    );
  }
  //save button

  savepayload_arr: any[] = [];
  savenewpayload_arr: any[] = [];
  savenewpayload: ServiceDateCycle = {
    address: undefined,
    bookedTimeDrop: undefined,
    bookedTimePickup: undefined,
    chargeAmt: undefined,
    chargeDesc: undefined,
    chargeZoneDrop: undefined,
    chargeZonePickup: undefined,
    complete: false,
    containerId: undefined,
    containerTypeId: undefined,
    created: 0,
    curfewWindow: undefined,
    customerId: '',
    customerSite: undefined,
    dataSourceId: '',
    dehireDeadline: undefined,
    dehirePark: undefined,
    delivered: false,
    deliveryClose: undefined,
    deliveryOpen: undefined,
    depot: undefined,
    despatchBy: undefined,
    destinationLoc: undefined,
    destinationSite: 0,
    docket: undefined,
    driverId: undefined,
    dropDesc: undefined,
    dropSuburb: undefined,
    enteredBy: '',
    etaUpdatedTime: undefined,
    exported: false,
    holdcode: undefined,
    id: 0,
    loadBatchNo: undefined,
    loadCustReference: undefined,
    loadDesc: undefined,
    loadDestination: '',
    loadId: 0,
    loadNo: '',
    loadScheduledDate: 0,
    loadSuburb: undefined,
    loadTypeId: '',
    locationIdDrop: '',
    locationIdPickup: '',
    locationIdPickupActual: undefined,
    offsiderUsed: false,
    operationType: undefined,
    originLoc: undefined,
    originSite: 0,
    podCreated: false,
    priority: undefined,
    qty1: undefined,
    qty2: undefined,
    qty3: undefined,
    qty4: undefined,
    qty5: undefined,
    qty6: undefined,
    qty7: undefined,
    qty8: undefined,
    rateId: undefined,
    reasonId: undefined,
    remarks: undefined,
    replicated: undefined,
    runsheetId: undefined,
    serviceDate: 0,
    serviceDesc: undefined,
    serviceGroup: undefined,
    serviceIdRecharge: undefined,
    serviceNo: '',
    serviceTypeId: '',
    siteId: 0,
    stopSeqDrop: undefined,
    stopSeqPickup: undefined,
    storeETA: undefined,
    todFlags: undefined,
    trailerId: undefined,
    trailerIdTag: undefined,
    tripId: undefined,
    tripIdCust: undefined,
    tripNo: undefined,
    tripSeq: undefined,
    truckId: undefined,
    unit1: '',
    unit2: '',
    unit3: '',
    unit4: undefined,
    unit5: undefined,
    unit6: undefined,
    unit7: undefined,
    unit8: undefined,
    used: false,
    usedSet: undefined,
    vesselEta: undefined,
    vesselId: undefined,
    wharf: undefined,
    window1: undefined,
    window1From: undefined,
    window1To: undefined,
    window2: undefined,
    window2From: undefined,
    window2To: undefined,
    window3: undefined,
    window3From: undefined,
    window3To: undefined,
  };
  reasonIds: any[] = [];

  onSave() {
    this.descmerge = '';
    // this.reasonmerge = '';
    this.savepayload = '';
    this.remarksmerge = '';
    this.containermerge = '';
    this.vesselmerge = '';
    this.schedatemerge = '';
    this.dehiredeadlinemerge = '';
    this.deliveryclosemerge = '';
    this.deliveryopenmerge = '';
    this.vesseleta = '';
    this.wharfmerge = '';
    this.depotmerge = '';
    this.custsitemerge = '';
    this.originLoacmerge = '';
    this.destLocmerge = '';
    this.dehireparkmerge = '';
    this.dropmerge = '';
    this.servicetypemerge='';
    this.docketmerge = '';
    this.pickupmerge = '';
    this.loadtypemerge = '';
    this.custrefmerge = '';
    this.connotemerge = '';
    if (this.create == true) {
      if (this.serviceform.dirty) {
        this.savenewpayload_arr = [];
        /*Common parameters */
        const savenewpayloadCommons = {
          customerId: this.serviceform.controls['customer'].value,
          // loadTypeId: null,
          destinationSite: this.selectedsiteid,
          originSite: this.selectedsiteid,
          qty1: null,
          qty2: null,
          qty3: null,
          qty4: null,
          qty5: null,
          qty6: null,
          qty7: null,
          qty8: null,
          serviceTypeId: this.serviceform.controls['servicetype'].value,
          siteId: this.selectedsiteid,
          unit1: null,
          unit2: null,
          unit3: null,
          unit4: null,
          unit5: null,
          unit6: null,
          unit7: null,
          unit8: null,
        };
        if (this.unitdata.unit1) {
          const Obj = {
            unit1: this.unitdata.unit1,
            qty1: this.getformcontrolname(this.unitdata.unit1),
          };
          this.uni1merge = { ...savenewpayloadCommons, ...Obj };
        }
        if (this.unitdata.unit2) {
          const Obj = {
            unit2: this.unitdata.unit2,
            qty2: this.getformcontrolname(this.unitdata.unit2),
          };
          this.uni2merge = { ...this.uni1merge, ...Obj };
        }

        if (this.unitdata.unit3) {
          const Obj = {
            unit3: this.unitdata.unit3,
            qty3: this.getformcontrolname(this.unitdata.unit3),
          };
          this.uni3merge = { ...this.uni2merge, ...Obj };
        }
        if (this.unitdata.unit4) {
          const Obj = {
            unit4: this.unitdata.unit4,
            qty4: this.getformcontrolname(this.unitdata.unit4),
          };
          this.uni4merge = { ...this.uni3merge, ...Obj };
        }
        if (this.unitdata.unit5) {
          const Obj = {
            unit5: this.unitdata.unit5,
            qty5: this.getformcontrolname(this.unitdata.unit5),
          };
          this.uni5merge = { ...this.uni4merge, ...Obj };
        }
        if (this.unitdata.unit6) {
          const Obj = {
            unit6: this.unitdata.unit6,
            qty6: this.getformcontrolname(this.unitdata.unit6),
          };
          this.uni6merge = { ...this.uni5merge, ...Obj };
        }
        if (this.unitdata.unit7) {
          const Obj = {
            unit7: this.unitdata.unit7,
            qty7: this.getformcontrolname(this.unitdata.unit7),
          };
          this.uni7merge = { ...this.uni6merge, ...Obj };
        }
        if (this.unitdata.unit8) {
          const Obj = {
            unit8: this.unitdata.unit8,
            qty8: this.getformcontrolname(this.unitdata.unit8),
          };
          this.uni8merge = { ...this.uni7merge, ...Obj };
        }

        /* If 'drop' from summary is touched */
        if (this.serviceform.controls['drop'].touched) {
          const dropObj = {
            locationIdDrop: this.serviceform.controls['drop'].value,
          };
          this.dropmerge = { ...savenewpayloadCommons, ...dropObj };
        }
        if (this.serviceform.controls['deliverydate'].touched) {
          const Obj = {
            loadScheduledDate: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['deliverydate'].value
            ),
          };
          this.loadschedmerge = { ...savenewpayloadCommons, ...Obj };
          const Obj2 = {
            serviceDate: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['deliverydate'].value
            ),
          };
          this.schedatemerge = { ...savenewpayloadCommons, ...Obj2 };
        }
        else{
          const Obj = {
            loadScheduledDate: this.timeService.convertDatetoMilliseconds(
              moment(new Date())
            ),
          };
          this.loadschedmerge = { ...savenewpayloadCommons, ...Obj };
          const Obj2 = {
            serviceDate: this.timeService.convertDatetoMilliseconds(
              moment(new Date())
            ),
          };
          this.schedatemerge = { ...savenewpayloadCommons, ...Obj2 };
        }
          // const Obj = {
          //   serviceDate: this.timeService.convertDatetoMilliseconds(
          //     this.serviceform.controls['deliverydate'].value
          //   ),
          // };
          // this.schedatemerge = { ...savenewpayloadCommons, ...Obj };
        
        /* If 'pickup' from summary is touched */
        if (this.serviceform.controls['pickup'].touched) {
          const Obj = {
            locationIdPickup: this.serviceform.controls['pickup'].value,
          };
          this.pickupmerge = { ...savenewpayloadCommons, ...Obj };
        }
        /* If 'loadType' from summary is touched */
        if (this.serviceform.controls['loadtype'].touched) {
          const Obj = {
            loadTypeId: this.serviceform.controls['loadtype'].value,
          };
          this.loadtypemerge = { ...savenewpayloadCommons, ...Obj };
        }
        /* If 'docket' from summary is touched */
        if (this.detailsform.controls['DOCKET'].touched) {
          const Obj = {
            docket: this.detailsform.controls['DOCKET'].value,
          };
          this.docketmerge = { ...savenewpayloadCommons, ...Obj };
        }
        /* If 'custref' from summary is touched */
        if (this.detailsform.controls['CUSTREF'].touched) {
          const Obj = {
            loadCustReference: this.detailsform.controls['CUSTREF'].value,
          };
          this.custrefmerge = { ...savenewpayloadCommons, ...Obj };
        }
        /* If 'connote' from summary is touched */
        if (this.detailsform.controls['CONNOTE'].touched) {
          const Obj = {
            loadBatchNo: this.detailsform.controls['CONNOTE'].value,
          };
          this.connotemerge = { ...savenewpayloadCommons, ...Obj };
        }

        /* If 'servicedesc' from summary is touched */
        if (this.serviceform.controls['description'].touched) {
          const Obj = {
            serviceDesc: this.serviceform.controls['description'].value,
          };
          this.descmerge = { ...savenewpayloadCommons, ...Obj };
        }
        /* if reason field is touched in Event*/
        //  this.rowDataReason.forEach(row=>{
        //   this.reasons.forEach(element => {
        //     if(row.reason!="" && row.reason==element.reasonDescription){
        //       this.reasonIds.push(element.reasonId)
        //     }
        //   });
        //  })

        // if (this.serviceform.controls['reason'].touched) {
        //   const reasonObj = {
        //     reasonId: this.serviceform.controls['reason'].value.reasonId,
        //   };
        //   this.reasonmerge = { ...savenewpayloadCommons, ...reasonObj };
        // }

        /*if remarks field is touched in Rating*/
        if (this.serviceform.controls['remarks'].touched) {
          const remarkObj = {
            remarks: this.serviceform.controls['remarks'].value,
          };
          this.remarksmerge = { ...savenewpayloadCommons, ...remarkObj };
        }
        /*If any field in Container is touched */
        if (this.serviceform.controls['container'].touched) {
          const containerObj = {
            containerId: this.serviceform.controls['container'].value,
          };
          this.containermerge = { ...savenewpayloadCommons, ...containerObj };
        }
        if (this.serviceform.controls['deliveryopen'].touched) {
          const Obj = {
            deliveryOpen: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['deliveryopen'].value
            ),
          };
          this.deliveryopenmerge = { ...savenewpayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['deliveryclose'].touched) {
          const Obj = {
            deliveryClose: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['deliveryclose'].value
            ),
          };
          this.deliveryclosemerge = { ...savenewpayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['dehiredeadline'].touched) {
          const Obj = {
            dehireDeadline: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['dehiredeadline'].value
            ),
          };
          this.dehiredeadlinemerge = { ...savenewpayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['vessel'].touched) {
          const vesselObj = {
            vesselId: this.getVesselId(
              this.serviceform.controls['vessel'].value
            ),
          };
          this.vesselmerge = { ...savenewpayloadCommons, ...vesselObj };
        }
        if (this.serviceform.controls['vesseleta'].touched) {
          const Obj = {
            vesselEta: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['vesseleta'].value
            ),
          };
          this.vesseleta = { ...savenewpayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['wharf'].touched) {
          const wharfObj = {
            wharf: this.serviceform.controls['wharf'].value,
          };
          this.wharfmerge = { ...savenewpayloadCommons, ...wharfObj };
        }
        if (this.serviceform.controls['depot'].touched) {
          // this.getDepotformdetails();
          const depotObj = {
            depot: this.serviceform.controls['depot'].value,
          };
          this.depotmerge = { ...savenewpayloadCommons, ...depotObj };
        }
        if (this.serviceform.controls['customersite'].touched) {
          const custsiteObj = {
            customerSite: this.serviceform.controls['customersite'].value,
          };
          this.custsitemerge = { ...savenewpayloadCommons, ...custsiteObj };
        }
        if (this.serviceform.controls['dehirepark'].touched) {
          const Obj = {
            dehirePark: this.serviceform.controls['dehirepark'].value,
          };
          this.dehireparkmerge = { ...savenewpayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['primaryoriginlocation'].touched) {
          const Obj = {
            originLoc: this.serviceform.controls['primaryoriginlocation'].value,
          };
          this.originLoacmerge = { ...savenewpayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['finaldestinationlocation'].touched) {
          const Obj = {
            destinationLoc:
              this.serviceform.controls['finaldestinationlocation'].value,
          };
          this.destLocmerge = { ...savenewpayloadCommons, ...Obj };
        }
        const finalmerge = {
          ...this.dropmerge,
          ...this.pickupmerge,
          ...this.loadschedmerge,
          ...this.schedatemerge,
          ...this.loadtypemerge,
          ...this.docketmerge,
          ...this.custrefmerge,
          ...this.connotemerge,
          ...this.descmerge,
          // ...this.reasonmerge,
          ...this.remarksmerge,
          ...this.containermerge,
          ...this.vesselmerge,
          ...this.vesseleta,
          ...this.dehiredeadlinemerge,
          ...this.deliveryclosemerge,
          ...this.deliveryopenmerge,
          ...this.wharfmerge,
          ...this.depotmerge,
          ...this.custsitemerge,
          ...this.dehireparkmerge,
          ...this.originLoacmerge,
          ...this.destLocmerge,
          ...this.uni1merge,
          ...this.uni2merge,
          ...this.uni3merge,
          ...this.uni4merge,
          ...this.uni5merge,
          ...this.uni6merge,
          ...this.uni7merge,
          ...this.uni8merge,
        };
        this.savenewpayload_arr.push(finalmerge);
        this.planService
          .saveExistingService(this.savenewpayload_arr)
          .pipe(
            catchError((error) => {
              // Handle the error here
              let errormessage = error.error.errorList.ErrorMessage;
              let errorurl = error.url;
              let errortime = error.error.errorList.ExceptionTime;
              let multiLineString = `${errormessage}.
URL: ${errorurl}.
Time: ${errortime}.`;

              this.messageService.add({
                severity: 'error',
                summary: error.status,
                detail: multiLineString,
                life: 20000,
              });
              // You can also re-throw the error if needed
              return throwError(error);
            })
          )
          .subscribe((result:any) => {
            this.messageService.add({
              severity: 'warn',
              summary: '',
              detail: 'creating service',
            });
            if (result) {
              this.ServiceHeader = 'Service ' + result[0].serviceNo;
              this.serviceform.controls['enteredby'].setValue(result[0].enteredBy)
              this.serviceform.controls['servicecreated'].setValue(this.timeService.convertMillisecondsToDateTimeM(result[0].created))
              this.planService
                .getServiceEvent(result[0].id)
                .subscribe((res) => {
                  this.messageService.add({
                    severity: 'success',
                    summary: '',
                    detail: 'Service created',
                    life:50000000
                  });
                });
              this.servicecreatednotify.emit(true);
            }
          });
      }
    } else {
      this.savepayload_arr = [];
      //payload for save
      /*Common parameters  */
      const savepayloadCommons = {
        customerId: this.serviceform.controls['customer'].value,
        destinationSite: this.selectedsiteid,
        // loadTypeId: this.selectedService.loadTypeId,
        loadId:this.selectedService.loadId,
        loadNo:this.selectedService.loadNo,
        loadScheduledDate:this.selectedService.serviceDate,
        locationIdPickup: this.serviceform.controls['pickup'].value,
        locationIdDrop:this.selectedService.locationIdDrop,
        originSite: this.selectedsiteid,
        created:this.timeService.convertDatetoMilliseconds3(new Date()),
        qty1: this.serviceform.controls['tonnes'].value,
        qty2: this.serviceform.controls['pallets'].value,
        qty3: this.serviceform.controls['dollars'].value,
        qty4: this.serviceform.controls['hours'].value,
        qty5: this.serviceform.controls['containers'].value,
        qty6: this.serviceform.controls['kilograms'].value,
        qty7: this.serviceform.controls['kilometers'].value,
        qty8: this.serviceform.controls['reels'].value,
        serviceDate: this.selectedService.serviceDate,
        serviceNo:this.selectedService.serviceNo,
        serviceTypeId: this.selectedService.serviceTypeId,
        siteId: this.selectedService.siteId,
        id:this.selectedService.id,
        unit1: 'TONNES',
        unit2: 'PALLETS',
        unit3: 'DOLLARS',
        unit4: 'HOURS',
        unit5: 'CONTAINERS',
        unit6: 'KILOGRAMS',
        unit7: 'KILOMETERS',
        unit8: 'REELS',
      };
      if (this.serviceform.dirty) {
        if(this.serviceform.controls['servicetype'].touched){
          const servicetypeObj = {
            serviceTypeId: this.serviceform.controls['servicetype'].value,
          };
          this.servicetypemerge = { ...savepayloadCommons, ...servicetypeObj };
        }
        /* If 'drop' from summary is touched */
        if (this.serviceform.controls['drop'].touched) {
          const dropObj = {
            locationIdDrop: this.serviceform.controls['drop'].value,
          };
          this.dropmerge = { ...savepayloadCommons, ...dropObj };
        }
        if (this.serviceform.controls['deliverydate'].touched) {
          const Obj = {
            loadScheduledDate: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['deliverydate'].value
            ),
          };
          this.loadschedmerge = { ...savepayloadCommons, ...Obj };
        }

        if (this.serviceform.controls['loadtype'].touched) {
          const Obj = {
            loadTypeId: this.serviceform.controls['loadtype'].value,
          };
          this.loadtypemerge = { ...savepayloadCommons, ...Obj };
        }

        /*      If any field is touched in Detail   */
        if (this.serviceform.controls['docket'].touched) {
          const docketObj = {
            docket: this.serviceform.controls['docket'].value,
          };
          this.docketmerge = { ...savepayloadCommons, ...docketObj };
        }
        if (this.serviceform.controls['custref'].touched) {
          const custrefObj = {
            loadCustReference: this.serviceform.controls['custref'].value,
          };
          this.custrefmerge = { ...savepayloadCommons, ...custrefObj };
        }
        if (this.serviceform.controls['connote'].touched) {
          const connoteObj = {
            loadBatchNo: this.serviceform.controls['connote'].value,
          };
          this.connotemerge = { ...savepayloadCommons, ...connoteObj };
        }
        if (this.serviceform.controls['description'].touched) {
          const descObj = {
            serviceDesc: this.serviceform.controls['description'].value,
          };
          this.descmerge = { ...savepayloadCommons, ...descObj };
        }
        /* if reason field is touched in Event*/
        // if (this.serviceform.controls['reason'].touched) {
        //   const reasonObj = {
        //     reasonId: this.serviceform.controls['reason'].value.reasonId,
        //   };
        //   this.reasonmerge = { ...savepayloadCommons, ...reasonObj };
        // }
        /*if remarks field is touched in Rating*/
        if (this.serviceform.controls['remarks'].touched) {
          const remarkObj = {
            remarks: this.serviceform.controls['remarks'].value,
          };
          this.remarksmerge = { ...savepayloadCommons, ...remarkObj };
        }
        /*If any field in Container is touched */
        if (this.serviceform.controls['container'].touched) {
          this.getConatinerformdetails();
          const containerObj = {
            containerId: this.serviceform.controls['container'].value,
          };
          this.containermerge = { ...savepayloadCommons, ...containerObj };
        }
        // if (this.serviceform.controls['vessel'].touched) {
        //   const vesselObj = {
        //     vesselId: this.serviceform.controls['container'].value,
        //   };
        //   this.vesselmerge = { ...savepayloadCommons, ...vesselObj };
        // }

        if (this.serviceform.controls['deliveryopen'].touched) {
          const Obj = {
            deliveryOpen: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['deliveryopen'].value
            ),
          };
          this.deliveryopenmerge = { ...savepayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['deliveryclose'].touched) {
          const Obj = {
            deliveryClose: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['deliveryclose'].value
            ),
          };
          this.deliveryclosemerge = { ...savepayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['dehiredeadline'].touched) {
          const Obj = {
            dehireDeadline: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['dehiredeadline'].value
            ),
          };
          this.dehiredeadlinemerge = { ...savepayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['vessel'].touched) {
          const vesselObj = {
            vesselId: this.getVesselId(
              this.serviceform.controls['vessel'].value
            ),
          };
          this.vesselmerge = { ...savepayloadCommons, ...vesselObj };
        }
        if (this.serviceform.controls['vesseleta'].touched) {
          const Obj = {
            vesselEta: this.timeService.convertDatetoMilliseconds(
              this.serviceform.controls['vesseleta'].value
            ),
          };
          this.vesseleta = { ...savepayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['wharf'].touched) {
          const wharfObj = {
            wharf: this.serviceform.controls['wharf'].value,
          };
          this.wharfmerge = { ...savepayloadCommons, ...wharfObj };
        }
        if (this.serviceform.controls['depot'].touched) {
          // this.getDepotformdetails();
          const depotObj = {
            depot: this.serviceform.controls['depot'].value,
          };
          this.depotmerge = { ...savepayloadCommons, ...depotObj };
        }
        if (this.serviceform.controls['customersite'].touched) {
          const custsiteObj = {
            customerSite: this.serviceform.controls['customersite'].value,
          };
          this.custsitemerge = { ...savepayloadCommons, ...custsiteObj };
        }
        if (this.serviceform.controls['dehirepark'].touched) {
          const Obj = {
            dehirePark: this.serviceform.controls['dehirepark'].value,
          };
          this.dehireparkmerge = { ...savepayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['primaryoriginlocation'].touched) {
          const Obj = {
            originLoc: this.serviceform.controls['primaryoriginlocation'].value,
          };
          this.originLoacmerge = { ...savepayloadCommons, ...Obj };
        }
        if (this.serviceform.controls['finaldestinationlocation'].touched) {
          const Obj = {
            destinationLoc:
              this.serviceform.controls['finaldestinationlocation'].value,
          };
          this.destLocmerge = { ...savepayloadCommons, ...Obj };
        }
      }
      const finalmerge = {
        ...savepayloadCommons,
        ...this.servicetypemerge,
        ...this.dropmerge,
        ...this.docketmerge,
        ...this.custrefmerge,
        ...this.connotemerge,
        ...this.descmerge,
        ...this.loadtypemerge,
        // ...this.reasonmerge,
        ...this.savepayload,
        ...this.loadschedmerge,
        ...this.remarksmerge,
        ...this.containermerge,
        ...this.vesselmerge,
        ...this.wharfmerge,
        ...this.depotmerge,
        ...this.custsitemerge,
        ...this.originLoacmerge,
        ...this.destLocmerge,
        ...this.dehireparkmerge,
      };

      this.savepayload_arr.push(finalmerge);
      this.planService.duplicatecheck(this.savepayload_arr).subscribe((result)=>{
if(result){
        this.planService
          .saveExistingService2(this.savepayload_arr)
          .subscribe((result) => {
            this.messageService.add({
              severity: 'warn',
              summary: '',
              detail: 'updating service',
            });
            if (result) {
              this.messageService.add({
                severity: 'success',
                summary: '',
                detail: 'Service updated',
                life: 10000,
              });
  
              this.servicecreatednotify.emit(true);
              this.serviceupdatesnotify.emit(result);
              this.planService.ServiceSearchupdate.next(result.services)
            }
          });
        }

      })
    }
  }

  saveCreateAnother() {
    this.onSave();
    this.CreateAnother();
  }

  //get reasons and vessel dropdowns
  ViewVessels: Vessel[] = [];
  ViewDrivers: ViewDriver[] = [];
  ViewCustomers: ViewCustomer[] = [];
  ViewTrucks: ResourceAllocation[] = [];
  ViewLocations: MultiLegSiteLocation[] = [];
  ViewTrailers: Trailer[] = [];
  ViewContainers: ViewContainers[] = [];
  ViewServiceTypes: ServiceTypes[] = [];
  ViewSites: any[] = [];

  selectedsiteid: number = 0;
  selectedsitedescription: any = '';
  sites: any[] = [];
  selectedsite: any;
  reasons: any[] = [];
  buttondisable: boolean;

  message: any = true;
  constructor(
    public dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    public searchService: SearchService,
    public planService: PlanService,
    public timeService: TimeRunsheetService,
    public navbarService: NavbarService,
    private messageService: MessageService,
    private formBuilder: FormBuilder,
    private authenticationService:AuthenticationService,
    private confirmationService: ConfirmationService
  ) {}
  //get all dropdown data from API
  serviceform: FormGroup;
  detailsform: FormGroup;
  checkRunseetServiceBtnState: any;
  ngOnInit(): void {
    // Check if customerValue is not null
    // Check if customerValue is null, undefined, or not a string
    if (this.customerValue == null || typeof this.customerValue !== 'string') {
      // Set the value for customerValue as an empty string
      this.customerValue = '';
    }
    this.selectedOptions = this.columnDefs.map((coulmn) => coulmn.field);
    if (this.serviceform.touched == false) {
      if (this.create == true) {
        this.buttondisable = true;
      }
    }
    this.selectedsiteid = parseInt(sessionStorage.getItem('selectedSiteId')!);
    this.AllCustomerId(this.selectedsiteid);
  }
  onReasonSelection() {
    this.showReason = this.serviceform.controls['reason'].value;
  }

  toggleDetail: boolean = true;
  toggleSummary: boolean = true;
  toggleTrip: boolean = true;
  toggleEvent: boolean = true;
  toggleRating: boolean = true;
  toggleContainer: boolean = true;

  // Get all unique Customer IDs
  AllData: any[] = [];
  arr: string[] = [];
  public AllCustomerId(selectedId: number) {
    let unique: any[];
    this.planService.getAllData(selectedId).subscribe((result: any) => {
      this.AllData = result;
    });
  }
  selectedOptions: any[];
  onSelectionChange(event: any) {
    this.columnDefs = this.columnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  //AG Grid configuration for Event table
  public rowSelection: 'single' | 'multiple' = 'single';
  private gridApi!: GridApi<EventTable>;
  rowData: EventTable[] = [];
  columnFields: ColDef[] = [
    {
      field: 'eventdatetime',
      headerName: 'Event date/time',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventdate',
      headerName: 'Event-Date',
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventtime',
      headerName: 'Event-Time',
      cellRenderer: EventdateCellRendererComponent,
    },
    { field: 'eventtype', headerName: 'Event Type' },
    { field: 'relation', headerName: 'Relation' },
    { field: 'mdserverdatetime', headerName: 'MD Server date/time' },
    { field: 'mdserverdate', headerName: 'MD Server-Date' },
    { field: 'mdservertime', headerName: 'MD Server-Time' },
    {
      field: 'eventcreateddatetime',
      headerName: ' Event Created date/time',
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventcreateddate',
      headerName: 'Event Created-Date',
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventcreatedtime',
      headerName: 'Event Created-Time',
      cellRenderer: EventdateCellRendererComponent,
    },
    { field: 'driver', headerName: 'Driver' },
    { field: 'trip', headerName: 'Trip' },
    { field: 'truck', headerName: 'Truck' },
    { field: 'trailer1', headerName: 'Trailer 1' },
    { field: 'trailer2', headerName: 'Trailer 2' },
    { field: 'dock', headerName: 'Dock' },
    { field: 'user', headerName: 'User' },
    { field: 'location', headerName: 'Location' },
    { field: 'datasource', headerName: 'Data Source' },
    { field: 'eventadjusted', headerName: 'Event Adjusted' },
    { field: 'todexportable', headerName: 'TOD Exportable' },
    { field: 'exported', headerName: 'Exported' },
    { field: 'comments', headerName: 'Comments' },
    { field: 'latitude', headerName: 'Latitude' },
    { field: 'longitude', headerName: 'Longitude' },
    { field: 'logonlogoffcompliance', headerName: 'Logon/Logoff Compliance' },
    { field: 'serviceno', headerName: 'Service No.' },
    { field: 'loadno', headerName: 'Load No.' },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    // minWidth: 180,
    filter: 'agTextColumnFilter',
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    floatingFilter: true,
    sortable: true,
    resizable: true,
    // editable: true,
  };
  onGridReady(params: GridReadyEvent<EventTable>) {
    this.gridApi = params.api;
  }

  //on row selection in AG Grid

  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
  }

  //Toggle event for tabs inside form
  Togglesummary() {
    this.toggleSummary = !this.toggleSummary;
  }
  Toggledetail() {
    this.toggleDetail = !this.toggleDetail;
  }
  Toggleevent() {
    this.toggleEvent = !this.toggleEvent;
  }
  Toggletrip() {
    this.toggleTrip = !this.toggleTrip;
  }
  Togglerating() {
    this.toggleRating = !this.toggleRating;
  }
  Togglecontainer() {
    this.toggleContainer = !this.toggleContainer;
  }
  //popup for Add return service
  AddReturnDialog() {
    const dialogRef = this.dialog.open(AddReturnServiceDialogComponent);
    dialogRef.afterClosed().subscribe((res) => {
      if (res.data) {
        this.messageService.add({
          severity: 'info',
          summary: '',
          detail: 'adding return service for this service',
        });
      }
    });
  }
  //Popup for Adding Container
  openDialog() {
    const dialogRef = this.dialog.open(AddContainerDialogComponent);
    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      if (res.data[0] != null) {
        this.serviceform.controls['container'].setValue(res.data[0].label);
      }
    });
  }
  //on delete
  serviceno: any[] = [];
  onDelete() {
    let toastrNO: string = '';
    this.confirmationService.confirm({
      message: 'Click OK to Continue',
      header: 'Are you sure you want to delete?',

      accept: () => {
        this.serviceno.push(this.selectedService.id);
        this.planService
          .DeleteService(this.serviceno)
          .subscribe((result: any) => {
            this.deletenotify.emit(this.selectedService);
          });

        toastrNO = this.selectedService.serviceNo;

        let mess = 'Service: ' + toastrNO + ' deleted.';
        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: mess,
        });
      },
      reject: (type: ConfirmEventType) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            this.messageService.add({
              severity: 'error',
              summary: 'Rejected',
              detail: 'You have rejected',
            });
            break;
          case ConfirmEventType.CANCEL:
            this.messageService.add({
              severity: 'warn',
              summary: 'Cancelled',
              detail: 'You have cancelled',
            });
            break;
        }
      },
    });
  }
  onClear() {
    this.serviceform.controls['deliverywindow1'].setValue('');
    this.serviceform.controls['deliverywindow2'].setValue('');
  }
  showClearIcon(): boolean {
    // Check if either of the p-calendar inputs has data
    return (
      this.serviceform.controls['deliverywindow1'].value ||
      this.serviceform.controls['deliverywindow2'].value
    );
  }
  onClear2() {
    this.serviceform.controls['deliverywindow3'].setValue('');
    this.serviceform.controls['deliverywindow4'].setValue('');
  }
  showClearIcon2(): boolean {
    // Check if either of the p-calendar inputs has data
    return (
      this.serviceform.controls['deliverywindow3'].value ||
      this.serviceform.controls['deliverywindow4'].value
    );
  }
  onClear3() {
    this.serviceform.controls['deliverywindow5'].setValue('');
    this.serviceform.controls['deliverywindow6'].setValue('');
  }
  showClearIcon3(): boolean {
    // Check if either of the p-calendar inputs has data
    return (
      this.serviceform.controls['deliverywindow5'].value ||
      this.serviceform.controls['deliverywindow6'].value
    );
  }
  BulkEditMode() {}
  ViewinPlanning() {
     const baseUrl = this.router.serializeUrl(
      this.router.createUrlTree(['plan'], {
        queryParams: {  startdate: this.fromDtSearch,
          enddate: this.toDtSearch,
          serviceid: this.selectedService.id, },
        queryParamsHandling: 'merge',
      })
    );
    window.open(baseUrl, '_blank');
    // this.router.navigate(['plan'], {
    //   queryParams: {
    //     startdate: this.fromDtSearch,
    //     enddate: this.toDtSearch,
    //     serviceid: this.selectedService.id,
    //   },
    //   queryParamsHandling: 'merge',
    // });

    // window.open('/plan')
  }
  // // //ag grid configuration for Reason table
  // columnDefsReason:ColDef[] = [
  //   { headerName: 'Reason', field: 'reason', editable: true,cellRenderer: DropdownCellRendererComponent,cellEditor:DropdownCelleditorComponent },
  //   { headerName: 'Comments', field: 'comments', editable: true,cellRenderer: TextboxCellRendererComponent }
  // ];
  // rowDataReason:any[] = [
  //   { reason: '', comments: '' }
  // ];
  // onCellValueChangedCustom(event:any) {
  //   if(event.colDef.field!=="comments" && event.oldValue==""){
  //     const newRow = { reason: '', comments: '' };
  //     this.rowDataReason.push(newRow);
  //     console.log(this.gridApiReason);
  //     this.gridApiReason.setRowData(this.rowDataReason)
  //   }

  // }
  // onGridReasonReady(params: GridReadyEvent<any>) {
  //   this.gridApiReason = params.api;
  // }
  // private gridApiReason!: GridApi<any>;
}

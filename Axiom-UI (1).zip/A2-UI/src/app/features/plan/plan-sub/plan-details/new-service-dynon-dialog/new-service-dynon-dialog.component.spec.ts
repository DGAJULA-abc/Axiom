import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewServiceDynonDialogComponent } from './new-service-dynon-dialog.component';

describe('NewServiceDynonDialogComponent', () => {
  let component: NewServiceDynonDialogComponent;
  let fixture: ComponentFixture<NewServiceDynonDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewServiceDynonDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewServiceDynonDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanResourceDetailsComponent } from './plan-resource-details.component';

describe('PlanResourceDetailsComponent', () => {
  let component: PlanResourceDetailsComponent;
  let fixture: ComponentFixture<PlanResourceDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanResourceDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanResourceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GridApi, ColDef, GridReadyEvent } from 'ag-grid-community';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import {
  ExecEventTable,
  ExecEventAPIResponse,
} from '../../../models/plan.model';
import { PlanService } from '../../../services/plan.service';
import { DateCellEditorComponent } from '../date-cell-editor/date-cell-editor.component';
import { DateCellRendererComponent } from '../date-cell-renderer/date-cell-renderer.component';

@Component({
  selector: 'app-execution-events-dialog',
  templateUrl: './execution-events-dialog.component.html',
  styleUrls: ['./execution-events-dialog.component.scss'],
  providers: [MessageService],
})
export class ExecutionEventsDialogComponent implements OnInit {
  tripno: string = '';
  showAlert:boolean=false;
  ngOnInit() {
    this.tripno = this.data.tripno;
  //   this.planService.getDateSelected().subscribe((selected: boolean) => {
  //     this.isDataChanged = selected;
  //     console.log(this.isDataChanged)
  // });
  this.planService.dateSelectedSubject.subscribe((result:any) => {
    console.log(result);
      this.isDataChanged = result;
      if(result==false){
        this.showAlert=false
      }
  });
  // this.reconcileService._multiLangData.subscribe((runsheet: any) => {})
}
  
  constructor(
    public planService: PlanService,
    public timeService:TimeRunsheetService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private messageService: MessageService,
    public dialogRef: MatDialogRef<ExecutionEventsDialogComponent>
  ) {}
  //AG Grid configuration for Execution Events dialog
  private gridApiExecEvent!: GridApi<ExecEventTable>;
  rowDataExecEvent: ExecEventTable[] = [];
  columnDefsExecEvent: ColDef[] = [
    { field: 'sno', headerName: '#' },
    { field: 'location', headerName: 'Location' },
    {
      field: 'arrive',
      headerName: 'Arrive',
      editable: true,
      cellRenderer: DateCellRendererComponent,
      cellEditor:DateCellEditorComponent 
    },
    { field: 'source_a', headerName: 'Source' },
    {
      field: 'completed',
      headerName: 'Completed',
      cellRenderer: DateCellRendererComponent,
      cellEditor:DateCellEditorComponent,
      editable: true,
    },
    { field: 'source_c', headerName: 'Source' },
    {
      field: 'depart',
      headerName: 'Depart',
      cellRenderer: DateCellRendererComponent,
      cellEditor:DateCellEditorComponent,
      editable: true,
    },
    { field: 'source_d', headerName: 'Source' },
    { field: 'type', headerName: 'Type' },
  ];

  public defaultColDef: ColDef = {
    filter: 'agTextColumnFilter',
    cellStyle: {'border-right': '1px solid #d4d4d4'},
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };
  onCellValueChangedCustom(event:any) {

   
  }

  //On Event grid ready
  onExecEventGridReady(params: GridReadyEvent<ExecEventTable>) {
    this.gridApiExecEvent = params.api;
    this.getExecutionEvents();
  }

  //on row selection in AG Grid for Event
  onExecEventSelectionChanged(event: any) {
    const selectedRows = this.gridApiExecEvent.getSelectedRows();
  }

  onCellValueChanged(event: any) {
  }

  exectablerows: ExecEventTable[] = [];
  StoreResult: ExecEventAPIResponse;
  //get executionevent api data
  getExecutionEvents() {
    this.planService
      .getExecutionEvents(this.data.tripId)
      .subscribe((result: ExecEventAPIResponse) => {
        if (result) {
          this.StoreResult = result;
          result.executionEvents.forEach((element) => {
            this.exectablerows.push({
              sno: element.sequenceNo,
              location: element.location,
              arrive: element.arrivalEvent.time
                ? this.timeService.convertMillisecondsToDateTimeMS(element.arrivalEvent.time)
                : '',
              source_a: element.arrivalEvent.source,
              completed: element.completionEvent.time
                ? this.timeService.convertMillisecondsToDateTimeMS(element.completionEvent.time)
                : '',
              source_c: element.completionEvent.source,
              depart: element.departureEvent.time
                ? this.timeService.convertMillisecondsToDateTimeMS(element.departureEvent.time)
                : '',
              source_d: element.departureEvent.source,
              type: element.activityType,
            });
          });
          this.rowDataExecEvent = this.exectablerows;
        }
      });
  }

  //close dialog
  onCancel() {
    this.dialogRef.close();
  }

  // onDateSelected(date: Date) {
  // }
  // TODO: on save executionevent post
  saveexecevent_arr: ExecEventAPIResponse[] = [];
  saveexecevent: ExecEventAPIResponse;
  index:number=0;
  check_ALERT:boolean
  onSave() {
    this.index=0
    this.check_ALERT=false;
    //updated values in table
    this.saveexecevent = this.StoreResult;
    this.rowDataExecEvent.forEach((row) => {
      if(row.arrive!=""){
        let a_compare;
        if(row.arrive.split(' ')[0].includes("/")){
          this.saveexecevent.executionEvents[this.index].arrivalEvent.modified=false;
        }
        else{
          a_compare=Number(row.arrive)
        if(a_compare != this.saveexecevent.executionEvents[this.index].arrivalEvent.time){
          this.saveexecevent.executionEvents[this.index].arrivalEvent.modified=true;
          this.saveexecevent.executionEvents[this.index].arrivalEvent.time=a_compare
          this.saveexecevent.executionEvents[this.index].arrivalEvent.source="A2"
          this.showAlert=false
        }
        else{
          this.saveexecevent.executionEvents[this.index].arrivalEvent.modified=false;
        }
      }
             }
      if(row.completed!=""){
        let c_compare;
        if(row.completed.split(' ')[0].includes("/")){
          this.saveexecevent.executionEvents[this.index].completionEvent.modified=false;
        }
        else{
          c_compare=Number(row.completed)
          if(c_compare< this.saveexecevent.executionEvents[this.index].arrivalEvent.time){
            this.showAlert=true;
            this.check_ALERT=true;
          }
          else if(c_compare != this.saveexecevent.executionEvents[this.index].completionEvent.time){
            this.saveexecevent.executionEvents[this.index].completionEvent.modified=true;
            this.saveexecevent.executionEvents[this.index].completionEvent.time=c_compare
            this.saveexecevent.executionEvents[this.index].completionEvent.source="A2"
            this.showAlert=false
          }
          else{
            this.saveexecevent.executionEvents[this.index].completionEvent.modified=false;
          }
        }
      }
      if(row.depart!=""){

        let d_compare;
        if(row.depart.split(' ')[0].includes("/")){
          this.saveexecevent.executionEvents[this.index].departureEvent.modified=false;
        }
        else{
          if(!this.showAlert){
            d_compare=Number(row.depart);
            if(d_compare< this.saveexecevent.executionEvents[this.index].completionEvent.time){
              this.showAlert=true;
              this.check_ALERT=true;
            }
            else
            if(d_compare != this.saveexecevent.executionEvents[this.index].departureEvent.time){
              this.saveexecevent.executionEvents[this.index].departureEvent.modified=true;
              this.saveexecevent.executionEvents[this.index].departureEvent.time=d_compare
              this.saveexecevent.executionEvents[this.index].departureEvent.source="A2"
              this.showAlert=false
            }
            else{
              this.saveexecevent.executionEvents[this.index].departureEvent.modified=false;
            }

          }

        }
      }

      this.index+=1;

    });
this.flag=false;
if(!this.check_ALERT){
  this.planService.postExecutionEvents(this.data.tripId,this.saveexecevent.executionEvents).subscribe((result:ExecEventAPIResponse)=>{
 if(result){
  //all good
  this.flag=true
 
  this.dialogRef.close({data:this.flag})
 }
  })
}
  }
  flag:boolean=false;
  datecheck(check:any):number{
   let a =moment(
      moment.tz(moment(check).format("DD/MM/YYYY HH:mm:ss"), 'Australia/Melbourne').clone().tz('Asia/Kolkata')
    ).valueOf();
    return a
  }

  /**
   * Save and Cancle button should be Blur before Changing data in ag-Gride
   */
  isDataChanged: boolean = false;
  // onDateSelected(date: string) {
  //   this.isDataChanged = !!date; // Set isDateSelected to true if a date is selected
  // }
  // ngOnInit() {
  //   this.dateSelectionService.getDateSelected().subscribe((selected: boolean) => {
  //     this.isDataChanged = selected;
  //   });
  // }
}

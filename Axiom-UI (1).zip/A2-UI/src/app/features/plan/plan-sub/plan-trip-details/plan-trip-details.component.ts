import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewEncapsulation,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GridApi, ColDef, GridReadyEvent } from 'ag-grid-community';
import { catchError, elementAt, throwError } from 'rxjs';
import {
  Dock,
  Driver2,
  ResourceAllocation,
  Trailer,
  Location,
  ServiceDateCycle,
  TripDateCycle,
  activities,
  ActivityTypes,
  ActivityDisplay,
  ViewDriver,
  Driver,
  ChainCommand,
  GetEvent,
  EventTable,
  TripSaveResponse,
  TripDespatchResponse,
  TripUndespatchResponse,
  ExecEventTable,
  ExecEventAPIResponse,
} from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';
import {
  ConfirmationService,
  ConfirmEventType,
  MessageService,
} from 'primeng/api';
import { ExecutionEventsDialogComponent } from './execution-events-dialog/execution-events-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { EventdateCellRendererComponent } from '../../services/eventdate-cell-renderer/eventdate-cell-renderer.component';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import { SearchService } from 'src/app/features/search/services/search.service';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
@Component({
  selector: 'app-plan-trip-details',
  templateUrl: './plan-trip-details.component.html',
  styleUrls: ['./plan-trip-details.component.scss'],
  providers: [ConfirmationService, MessageService],
  encapsulation: ViewEncapsulation.None
})
export class PlanTripDetailsComponent implements OnInit, OnChanges {
  @Input() selectedTrip: TripDateCycle[];
  @Input() selectedTripService: ServiceDateCycle[];
  @Output() savenotify: EventEmitter<TripSaveResponse> =
    new EventEmitter<TripSaveResponse>();
  @Output() despatchnotify: EventEmitter<TripDespatchResponse> =
    new EventEmitter<TripDespatchResponse>();
  @Output() undespatchnotify: EventEmitter<TripUndespatchResponse> =
    new EventEmitter<TripUndespatchResponse>();
  @Output() gotoservicenotify: EventEmitter<ServiceDateCycle> = new EventEmitter<ServiceDateCycle>();

  selectedOptionsservice: any[];
  selectedOptionsevent: any[];
  noshow: boolean = false;
  noshowdetail: string = "";
  TripDespatched: boolean = false;

  //getting data from View have View keyword
  ViewDocks: Dock[] = [];
  ViewDrivers: ViewDriver[] = [];
  ViewTrucks: ResourceAllocation[] = [];
  ViewTrailers: Trailer[] = [];
  ViewLocations: Location[] = [];
  ViewActivityTypes: ActivityTypes[] = [];

  //extra variables for form data display
  driver: Driver2;
  tripno: string = '';
  activities: activities[] = [];
  Activity_display: ActivityDisplay[] = [];
  totaltriptime: string = '';
  totaltime: number = 0;
  showReturnto: string = '';
  fulladdress: string = '';
  connote: number = 0;
  utilisation: string = '';
  status: string = '';
  endtime: string;

  //ngif to show activity label
  Activityavailable: boolean = false;

  //despatch/undespatch buttons
  despatchtoggle: boolean = false;
  transittoggle: boolean = false;

  //selected trip in TripDateCycle format
  TripDetails: TripDateCycle;

  constructor(
    public permission: PermissionsService,
    public planService: PlanService,
    private formBuilder: FormBuilder,
    private router: Router,
private authenticationService:AuthenticationService,
    public searchService:SearchService,
    public dialog: MatDialog,
    public timeService: TimeRunsheetService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService
  ) { }
  showStartTime: any;
  showDespathByTime:any;
  message: any = true;
  @Input() fromSearch: boolean;
  fromSearch1: boolean = false;
  //geting all new data in the form based on trip selection in Plan Trips component
  ngOnChanges(changes: SimpleChanges): void {
    this.noshow = false;
    this.noshowdetail = ""
    this.searchService.getMessage.subscribe((msg) => this.message = msg)
    if (this.message == true && this.fromSearch == undefined) {
      this.fromSearch1 = true;
    }
    else if (this.fromSearch == false) {
      this.fromSearch1 = false;
    }
    this.Activity_display = [];
    this.tripdetailsform = this.formBuilder.group({
      tripno: [this.tripno],
      loadready: [false],
      paperworkavailable: [false],
      starttime: [],
      despatchby: [''],
      dock: [this.selectedDock],
      comments: [''],
      connote: [],
      driver: ['', Validators.required],
      truck: ['', Validators.required],
      trailer1: [''],
      trailer2: [''],
      returnto: [this.selectedTrip[0].returnLocationId],
      route: [''],
    });
    if (this.selectedTrip.length != 0) {

        if (this.selectedTrip[0].cachedStatus != 'R ' && this.selectedTrip[0].cachedStatus != 'U ' && this.selectedTrip[0].cachedStatus != 'D ' && this.selectedTrip[0].cachedStatus != 'DE' && this.selectedTrip[0].cachedStatus != 'RC' && this.selectedTrip[0].cachedStatus != 'LG' && this.selectedTrip[0].cachedStatus != 'LD' && this.selectedTrip[0].cachedStatus != 'TR' && this.selectedTrip[0].cachedStatus != 'UG' && this.selectedTrip[0].cachedStatus != 'UD' && this.selectedTrip[0].cachedStatus != 'RT' && this.selectedTrip[0].cachedStatus != 'E ') {

        this.disableAll = false;
        this.tripdetailsform.get('starttime')?.enable();
        this.tripdetailsform.get('despatchby')?.enable();
        this.tripdetailsform.get('dock')?.enable();
        this.tripdetailsform.get('driver')?.enable();
        this.tripdetailsform.get('truck')?.enable();
        this.tripdetailsform.get('trailer1')?.enable();
        this.tripdetailsform.get('trailer2')?.enable();
        this.tripdetailsform.get('returnto')?.enable();
        this.tripdetailsform.get('tripno')?.enable();
        this.TripDespatched = false;
        this.getEvents(this.selectedTrip[0].id);
        this.TripDetails = this.selectedTrip[0];
        //update form details
        this.tripno = this.selectedTrip[0].tripIdCust;
        this.tripdetailsform.controls['tripno'].setValue(
          this.selectedTrip[0].tripIdCust
        );
        this.showStartTime = this.timeService.convertMillisecondsToDateTimeMS(this.selectedTrip[0].plannedStartTime),
          this.tripdetailsform.controls['starttime'].setValue(
            this.timeService.convertMillisecondsToDateTimeMS(this.selectedTrip[0].plannedStartTime)
          );
          this.showDespathByTime=  this.timeService.convertMillisecondsToDateTimeMS(this.selectedTrip[0].actualDespatchTime)
          this.tripdetailsform.controls['despatchby'].setValue(
            this.timeService.convertMillisecondsToDateTimeMS(this.selectedTrip[0].plannedDespatchTime)
          );
        this.endtime = this.timeService.convertMillisecondsToDateTimeM(this.selectedTrip[0].plannedFinishTime)
        if (this.selectedTripService != undefined) {
          this.selectedTripService.forEach(element => {
            if (element.locationIdPickup == null || element.locationIdDrop == null) {
              this.noshow = true;
              this.noshowdetail = "Some services do not have a pickup or drop location."
            }
          });
          this.rowData = this.selectedTripService;
        }
        else {

        }
        this.activities = this.selectedTrip[0].activities;
        this.connote = this.selectedTrip[0].batchNo;
        let stat = this.selectedTrip[0].cachedStatus;
        if (stat == 'P ' ||stat == 'AL' ||stat == 'CN' ) {
          this.status = 'planned';
          this.despatchtoggle = false;
          this.transittoggle = false;
          this.tripdetailsform.get('starttime')?.enable();
        } 
        else if (stat == 'R ' || stat == 'U ' || stat == 'D ' || stat == 'DE' || stat == 'RC' || stat == 'LG' || stat == 'LD' || stat == 'TR' || stat == 'UG' || stat == 'UD' || stat == 'RT' || stat == 'E ') {
          this.status = 'despatched';
          this.despatchtoggle = true;
          this.transittoggle = false;
          this.tripdetailsform.get('starttime')?.disable();
        } 
        else if (stat == 'L '  || stat == 'T ') {
          this.status = 'transit';
          this.transittoggle = true;
          this.despatchtoggle = true;
          this.tripdetailsform.get('starttime')?.disable();
        }
        else if (stat == 'CP'|| stat == 'CR'|| stat == 'F '|| stat == 'FN'){
          this.status='complete';
          this.despatchtoggle = false;
          this.transittoggle = false;
          this.tripdetailsform.get('starttime')?.disable();
        }
        else if (stat == 'C ' || stat == 'Y ' || stat == 'A ' || stat == 'PL' || stat == 'RD') {
          this.status='ready';
          this.despatchtoggle = true;
          this.transittoggle = false;
          this.tripdetailsform.get('starttime')?.disable();
        }


  
        let num =
          (this.selectedTrip[0].cachedRoutingQty /
            this.selectedTrip[0].cachedTruckCapacity) *
          100;
        this.utilisation =
          num +
          ' % (' +
          String(this.selectedTrip[0].cachedRoutingQty) +
          ' of ' +
          String(this.selectedTrip[0].cachedTruckCapacity) +
          ' TONNES)';
        if (this.selectedTrip[0].comments != null) {
          this.tripdetailsform.controls['comments'].setValue(
            this.selectedTrip[0].comments
          );
        }
        if (this.activities.length != 0) {
          this.totaltriptime = '';
          this.totaltime = 0;
          this.Activityavailable = true;
          this.activities.forEach((activity) => {
            if (activity.activityTypeId == 1) {
              this.totaltime = this.totaltime + activity.activityTime;
              this.Activity_display.push({
                header: 'Travel',
                label:
                  activity.pickupLocationId + ' to ' + activity.dropLocationId,
                time: this.getActivityTime(activity.activityTime),
                colorbar: true,
              });
            } else if (activity.activityTypeId == 2) {
              this.totaltime = this.totaltime + activity.activityTime;
              this.Activity_display.push({
                header: 'Pickup',
                label: 'at ' + activity.pickupLocationId,
                time: this.getActivityTime(activity.activityTime),
                colorbar: false,
              });
            } else if (activity.activityTypeId == 3) {
              this.totaltime = this.totaltime + activity.activityTime;
              this.Activity_display.push({
                header: 'Dropoff',
                label: 'at ' + activity.dropLocationId,
                time: this.getActivityTime(activity.activityTime),
                colorbar: false,
              });
            }
          });
          this.totaltriptime = this.getActivityTime(this.totaltime);
        } else if (this.activities.length == 0) {
          this.Activityavailable = false;
        }
      }
      else {
        this.disableAll = true;
        this.tripdetailsform.get('starttime')?.disable();
        this.tripdetailsform.get('despatchby')?.disable();
        this.tripdetailsform.get('dock')?.disable();
        this.tripdetailsform.get('driver')?.disable();
        this.tripdetailsform.get('truck')?.disable();
        this.tripdetailsform.get('trailer1')?.disable();
        this.tripdetailsform.get('trailer2')?.disable();
        this.tripdetailsform.get('returnto')?.disable();
        this.tripdetailsform.get('tripno')?.disable();
        this.TripDespatched = true
        this.getEvents(this.selectedTrip[0].id);
        this.TripDetails = this.selectedTrip[0];
        //update form details
        this.tripno = this.selectedTrip[0].tripIdCust;
        this.tripdetailsform.controls['tripno'].setValue(
          this.selectedTrip[0].tripIdCust
        );
        this.showStartTime = this.timeService.convertMillisecondsToDateTimeMS(this.selectedTrip[0].plannedStartTime),
          this.tripdetailsform.controls['starttime'].setValue(
            this.timeService.convertMillisecondsToDateTimeMS(this.selectedTrip[0].plannedStartTime)
          );
        this.endtime = this.timeService.convertMillisecondsToDateTimeM(this.selectedTrip[0].plannedFinishTime)
        if (this.selectedTripService != undefined) {
          this.selectedTripService.forEach(element => {
            if (element.locationIdPickup == null || element.locationIdDrop == null) {
              this.noshow = true;
              this.noshowdetail = "Some services do not have a pickup or drop location."
            }
          });
          this.rowData = this.selectedTripService;
        }
        else {

        }
        this.activities = this.selectedTrip[0].activities;
        this.connote = this.selectedTrip[0].batchNo;
        let stat = this.selectedTrip[0].cachedStatus;
        if (stat == 'P ' ||stat == 'AL' ||stat == 'CN' ) {
          this.status = 'planned';
          this.despatchtoggle = false;
          this.transittoggle = false;
          this.tripdetailsform.get('starttime')?.enable();
        } 
        else if (stat == 'R ' || stat == 'U ' || stat == 'D ' || stat == 'DE' || stat == 'RC' || stat == 'LG' || stat == 'LD' || stat == 'TR' || stat == 'UG' || stat == 'UD' || stat == 'RT' || stat == 'E ') {
          this.status = 'despatched';
          this.despatchtoggle = true;
          this.transittoggle = false;
          this.tripdetailsform.get('starttime')?.disable();
        } 
        else if (stat == 'L '  || stat == 'T ') {
          this.status = 'transit';
          this.transittoggle = true;
          this.despatchtoggle = true;
          this.tripdetailsform.get('starttime')?.disable();
        }
        else if (stat == 'CP'|| stat == 'CR'|| stat == 'F '|| stat == 'FN'){
          this.status = 'complete';
          this.despatchtoggle = false;
          this.transittoggle = false;
          this.tripdetailsform.get('starttime')?.disable();
        }
  
        let num =
          (this.selectedTrip[0].cachedRoutingQty /
            this.selectedTrip[0].cachedTruckCapacity) *
          100;
        this.utilisation =
          num +
          ' % (' +
          String(this.selectedTrip[0].cachedRoutingQty) +
          ' of ' +
          String(this.selectedTrip[0].cachedTruckCapacity) +
          ' TONNES)';
        if (this.selectedTrip[0].comments != null) {
          this.tripdetailsform.controls['comments'].setValue(
            this.selectedTrip[0].comments
          );
        }
        if (this.activities.length != 0) {
          this.totaltriptime = '';
          this.totaltime = 0;
          this.Activityavailable = true;
          this.activities.forEach((activity) => {
            if (activity.activityTypeId == 1) {
              this.totaltime = this.totaltime + activity.activityTime;
              this.Activity_display.push({
                header: 'Travel',
                label:
                  activity.pickupLocationId + ' to ' + activity.dropLocationId,
                time: this.getActivityTime(activity.activityTime),
                colorbar: true,
              });
            } else if (activity.activityTypeId == 2) {
              this.totaltime = this.totaltime + activity.activityTime;
              this.Activity_display.push({
                header: 'Pickup',
                label: 'at ' + activity.pickupLocationId,
                time: this.getActivityTime(activity.activityTime),
                colorbar: false,
              });
            } else if (activity.activityTypeId == 3) {
              this.totaltime = this.totaltime + activity.activityTime;
              this.Activity_display.push({
                header: 'Dropoff',
                label: 'at ' + activity.dropLocationId,
                time: this.getActivityTime(activity.activityTime),
                colorbar: false,
              });
            }
          });
          this.totaltriptime = this.getActivityTime(this.totaltime);
        } else if (this.activities.length == 0) {
          this.Activityavailable = false;
        }
      }

    }
  }
  disableAll: boolean = false;
  isLoading: boolean = true;
  //form data on Init
  tripdetailsform: FormGroup;
  canWrite: boolean;
  ngOnInit(): void {

    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }
    this.selectedOptionsservice = this.columnDefs.map((coulmn) => coulmn.field);
    this.selectedOptionsevent = this.columnDefsEvent.map(
      (coulmn) => coulmn.field
    );
    this.isLoading = true;
    this.authenticationService.viewAPI.subscribe((result) => {
      if (result) {
        this.isLoading = false;
        this.ViewDocks = result['ref'].docks;
        this.ViewDrivers = result['ref'].drivers;
        this.ViewTrucks = result['ref'].trucks;
        this.ViewTrailers = result['ref'].trailers;
        this.ViewLocations = result['ref'].locations;
        this.ViewActivityTypes = result['ref'].activityTypes;
        this.getRoutes(result['ref'].routes)
        this.getDockvalue(this.ViewDocks);
        this.getDrivers(this.ViewDrivers);
        this.getTrucks(this.ViewTrucks);
        this.getTrailers(this.ViewTrailers);
        this.getLocations(this.ViewLocations);
      }

    });
    // TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });

    this.getEvents(this.selectedTrip[0].id);
    this.Activity_display = [];
    this.activities = this.selectedTrip[0].activities;
    this.showReturnto = this.selectedTrip[0].returnLocationId;
    this.connote = this.selectedTrip[0].batchNo;
    let stat = this.selectedTrip[0].cachedStatus;
    this.endtime = this.timeService.convertMillisecondsToDateTimeM(this.selectedTrip[0].plannedFinishTime)
    if (stat == 'P ' ||stat == 'AL' ||stat == 'CN' ) {
      this.status = 'planned';
      this.despatchtoggle = false;
      this.tripdetailsform.get('starttime')?.enable();
    }
     if (stat == 'R ' || stat == 'U ' || stat == 'D ' || stat == 'DE' || stat == 'RC' || stat == 'LG' || stat == 'LD' || stat == 'TR' || stat == 'UG' || stat == 'UD' || stat == 'RT' || stat == 'E ') {
      this.status = 'despatched';
      this.despatchtoggle = true;
      this.tripdetailsform.get('starttime')?.disable();
    }
    if (stat == 'CP'|| stat == 'CR'|| stat == 'F '|| stat == 'FN'){
      this.status = 'complete';
      this.despatchtoggle = false;
      this.tripdetailsform.get('starttime')?.disable();
    }
    let num =
      (this.selectedTrip[0].cachedRoutingQty /
        this.selectedTrip[0].cachedTruckCapacity) *
      100;
    this.utilisation =
      num +
      ' % (' +
      String(this.selectedTrip[0].cachedRoutingQty) +
      ' of ' +
      String(this.selectedTrip[0].cachedTruckCapacity) +
      ' TONNES)';
    if (this.selectedTrip.length != 0) {
      this.tripno = this.selectedTrip[0].tripIdCust;
    }
    if (this.selectedTrip[0].comments != null) {
      this.tripdetailsform.controls['comments'].setValue(
        this.selectedTrip[0].comments
      );
    }
    if (this.activities.length != 0) {
      this.totaltriptime = '';
      this.totaltime = 0;
      this.Activityavailable = true;
      this.activities.forEach((activity) => {
        if (activity.activityTypeId == 1) {
          this.totaltime = this.totaltime + activity.activityTime;
          this.Activity_display.push({
            header: 'Travel',
            label: activity.pickupLocationId + ' to ' + activity.dropLocationId,
            time: this.getActivityTime(activity.activityTime),
            colorbar: true,
          });
        } else if (activity.activityTypeId == 2) {
          this.totaltime = this.totaltime + activity.activityTime;
          this.Activity_display.push({
            header: 'Pickup',
            label: 'at ' + activity.pickupLocationId,
            time: this.getActivityTime(activity.activityTime),
            colorbar: false,
          });
        } else if (activity.activityTypeId == 3) {
          this.totaltime = this.totaltime + activity.activityTime;
          this.Activity_display.push({
            header: 'Dropoff',
            label: 'at ' + activity.dropLocationId,
            time: this.getActivityTime(activity.activityTime),
            colorbar: false,
          });
        }
      });
      this.totaltriptime = this.getActivityTime(this.totaltime);
    }
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('AllocationByRoute');
      if(result1){
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }
      //console.log("Result:", this.canWrite,result1,; // Use the result here
      
    } catch (error) {
      console.error("Error:", error);
    }
  }

  //getting total activity time
  getActivityTime(time: number): string {
    let hours = Math.floor(time / 60);
    let minutes = time % 60;
    return String(hours) + 'h ' + String(minutes) + 'm';
  }
  //get drivers in correct format in dropdown from View
  showDriver: Driver2 = {
    id: 0,
    name: '',
    company: '',
  };
  getDrivers(viewdrivers: ViewDriver[]) {
    viewdrivers.forEach((element: any) => {
      this.driver = { name: '', company: '', id: 0 };
      if (element.active == true) {
        if (
          element.surname != null &&
          element.firstName != null &&
          element.employeeName != null
        ) {
          this.driver.name =
            element.surname +
            ' ' +
            element.firstName +
            ' - ' +
            element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        } else if (
          element.surname == null ||
          (element.firstName == null && element.employeeName != null)
        ) {
          this.driver.name = element.employeeName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        } else if (
          element.surname != null &&
          element.firstName != null &&
          element.employeeName == null
        ) {
          this.driver.name = element.surname + ' ' + element.firstName;
          this.driver.company = element.companyId;
          this.driver.id = element.id;
        }
        this.drivers.push(this.driver);
      }
    });
    viewdrivers.forEach((driver) => {
      if (driver.id != null && driver.id == this.selectedTrip[0].driverId) {
        if (
          driver.surname != null &&
          driver.firstName != null &&
          driver.employeeName != null
        ) {
          this.showDriver.name =
            driver.surname +
            ' ' +
            driver.firstName +
            ' - ' +
            driver.employeeName +
            ' (' +
            driver.companyId +
            ')';
          this.showDriver.company = driver.companyId;
          this.showDriver.id = driver.id;
        } else if (
          driver.surname == null ||
          (driver.firstName == null && driver.employeeName != null)
        ) {
          this.showDriver.name =
            driver.employeeName + ' (' + driver.companyId + ')';
          this.showDriver.company = driver.companyId;
          this.showDriver.id = driver.id;
        } else if (
          driver.surname != null &&
          driver.firstName != null &&
          driver.employeeName == null
        ) {
          this.showDriver.name =
            driver.surname +
            ' ' +
            driver.firstName +
            ' (' +
            driver.companyId +
            ')';
          this.showDriver.company = driver.companyId;
          this.showDriver.id = driver.id;
        }
      }
    });
    setTimeout(() => {
      this.selectedDriver = this.showDriver
      // this.selectedDriver = this.showDriver.name

    }, 100);
  }

  //get docks
  showDock: Dock = {
    active: false,
    dockName: '',
    homeLocationId: undefined,
    id: 0,
    locationId: '',
    siteId: 0,
  };
  getDockvalue(viewdocks: Dock[]) {
    viewdocks.forEach((dock) => {
      if (dock.id == this.selectedTrip[0].dockId) {
        this.showDock = dock;
      }
    });
  }
  routes:any[]=[]
  getRoutes(viewroutes:any[]){
    viewroutes.forEach((route) => {
        this.routes.push(route);
    });

  }
  //get trucks in correct format in dropdown from View
  value: any;
  showTruck = {
    id: '',
    name: '',
  };
  getTrucks(viewtrucks: ResourceAllocation[]) {
    viewtrucks.forEach((element) => {
      if (element.active == true) {
        this.value =
          element.truckId +
          ' (' +
          element.routeCapacity +
          ', ' +
          element.truckTypeId +
          ', ' +
          element.companyId +
          ')';
        this.trucks.push(this.value);
      }
    });
    viewtrucks.forEach((truck) => {
      if (truck.truckId == this.selectedTrip[0].truckId) {
        this.showTruck.id = truck.truckId;
        this.showTruck.name =
          truck.truckId +
          ' (' +
          truck.routeCapacity +
          ', ' +
          truck.truckTypeId +
          ', ' +
          truck.companyId +
          ')';
      }
    });
    this.selectedTruck = this.showTruck.name
  }

  //get trailers in correct format in dropdown from View
  t_val: any;
  trailers: any[] = [];
  getTrailers(viewtrailers: Trailer[]) {
    viewtrailers.forEach((trailer) => {
      if (trailer.active == true) {
        if (trailer.companyId != null) {
          if (trailer.routeCapacity != null) {
            this.t_val =
              trailer.trailerId +
              ' (' +
              trailer.routeCapacity +
              ', ' +
              trailer.trailerTypeId +
              ', ' +
              trailer.companyId +
              ')';
            this.trailers.push(this.t_val);
          } else {
            this.t_val =
              trailer.trailerId +
              ' (' +
              trailer.trailerTypeId +
              ', ' +
              trailer.companyId +
              ')';
            this.trailers.push(this.t_val);
          }
        } else {
          this.t_val =
            trailer.trailerId +
            ' (' +
            trailer.routeCapacity +
            ', ' +
            trailer.trailerTypeId +
            ')';
          this.trailers.push(this.t_val);
        }
      }
    });
  }

  //get locations in correct format in dropdown from View
  locations: any[] = [];
  getLocations(viewlocations: Location[]) {
    viewlocations.forEach((location) => {
      this.locations.push(location.locationId);
      if (location.locationId == this.selectedTrip[0].returnLocationId) {
        if (location.address2 != null) {
          this.fulladdress =
            location.address1 +
            ' ' +
            location.address2 +
            ', ' +
            location.suburb +
            ', ' +
            location.state +
            ', ' +
            location.postCode;
        } else {
          this.fulladdress =
            location.address1 +
            ', ' +
            location.suburb +
            ', ' +
            location.state +
            ', ' +
            location.postCode;
        }
        if (location.address1 == null) {
          this.fulladdress = '';
        }
      }
    });
  }

  //toggle events for tabs inside form
  toggleResource: boolean = true;
  toggleSummary: boolean = true;
  toggleService: boolean = true;
  toggleActivity: boolean = true;
  toggleEvent: boolean = true;

  Togglesummary() {
    this.toggleSummary = !this.toggleSummary
  }
  Toggleresource() {
    this.toggleResource = !this.toggleResource;
  }
  Toggleservice() {
    this.toggleService = !this.toggleService;
  }
  Toggleactivity() {
    this.toggleActivity = !this.toggleActivity;
  }
  Toggleevent() {
    this.toggleEvent = !this.toggleEvent;
  }

  //autocomplete for docks
  docks: Dock[] = [];

  getDocks(viewdocks: Dock[]) {
    this.docks=[];
    viewdocks.forEach((element) => {
      if (element.dockName != null) {
        this.docks.push(element);
      }
    });
    // this.docks = this.docks_arr.filter(
    //   (item, index) => this.docks_arr.indexOf(item) === index
    // );
  }

  selectedDock: any = '';
  filteredDocks: any[] = [];
  filterDock(event: any) {
    this.getDocks(this.ViewDocks);
    let filtered: any[] = [];
    let query = event.query;
    this.filteredDocks = this.docks.filter(option => option.dockName.toLowerCase().includes(query.toLowerCase()));

  }
  //autocomplete for drivers
  drive_arr: Driver2[] = [];
  drivers: Driver2[] = [];
  selectedDriver: any = '';
  filteredDrivers: any[] = [];
  getDriverValue(drivers: any[]) {
    this.drive_arr=[];
    drivers.forEach((driver) => {
      let val = '';
      val = driver.name + ' (' + driver.company + ')';
      this.drive_arr.push({
        id: driver.id,
        name: val,
        company: driver.companyId,
      });
    });
  }
  filterDriver(event: any) {
    this.getDriverValue(this.drivers);
    let filtered: any[] = [];
    let query = event.query;
    this.filteredDrivers= this.drive_arr.filter(option => option.name.toLowerCase().includes(query.toLowerCase()));


  }

  //autocomplete for trucks
  trucks: any[] = [];
  selectedTruck: any = '';
  filteredTrucks: any[] = [];

  filterTruck(event: any) {
    let filtered: any[] = [];
    let query = event.query;

    this.filteredTrucks = this.trucks.filter(option => option.toLowerCase().includes(query.toLowerCase()));
  }

  //autocomplete for trailer1
  selectedTrailerone: any = '';
  filteredTrailersone: any[] = [];

  filterTrailerone(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.filteredTrailersone = this.trailers.filter(option => option.toLowerCase().includes(query.toLowerCase()));


  }
  //autocomplete for trailer2
  selectedTrailertwo: any = '';
  filteredTrailerstwo: any[] = [];

  filterTrailertwo(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.filteredTrailerstwo= this.trailers.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  //autocomplete for trailer2
  selectedReturnto: any = '';
  filteredReturntos: any[] = [];

  filterReturnto(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.filteredReturntos = this.locations.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
 //autocomplete for routes
 selectedRoute: any = '';
 filteredRoutes: any[] = [];

 filterRoute(event: any) {
   let filtered: any[] = [];
   let query = event.query;
   this.filteredRoutes = this.routes.filter(option => option.routeId.toLowerCase().includes(query.toLowerCase()));

 }

  //AG Grid configuration for Service Table
  private gridApi!: GridApi<ServiceDateCycle>;
  public rowSelection: 'single' | 'multiple' = 'multiple';
  rowData: ServiceDateCycle[] = [];
  servicecolumnFields: ColDef[] = [
    {
      field: 'serviceGroup',
      headerName: 'Service Group',
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
    { field: 'serviceNo', headerName: 'Service No.' },
    { field: 'docket', headerName: 'Docket' },
    { field: 'customerId', headerName: 'Customer' },
    { field: 'deliverydate', headerName: 'Delivery Date' },
    { field: 'createddatetime', headerName: 'Created Date/Time' },
    { field: 'createddate', headerName: 'Create Date' },
    { field: 'createdtime', headerName: 'Create Time' },
    { field: 'locationIdDrop', headerName: 'Drop' },
    { field: 'locationIdPickup', headerName: 'Pickup' },
    { field: 'serviceDesc', headerName: 'Service Desc' },
    { field: 'bookedTimeDrop', headerName: 'Drop Time' },
    { field: 'bookedTimePickup', headerName: 'Pickup Time' },
    { field: 'serviceTypeId', headerName: 'Service Type' },
    { field: 'loadTypeId', headerName: 'Load Type' },
    { field: 'status', headerName: 'Status' },
    { field: 'seq', headerName: 'Seq' },
    { field: 'custref', headerName: 'Cust Ref' },
    { field: 'remarks', headerName: 'Remarks' },
    { field: 'loadNo', headerName: 'Load No.' },
    { field: 'tripNo', headerName: 'Trip No.' },
    { field: 'batchNo', headerName: 'ConNote' },
    { field: 'containerId', headerName: 'Container No' },
    { field: 'containerTypeId', headerName: 'Container Type' },
    { field: 'vesselId', headerName: 'Vessel No' },
    { field: 'enteredBy', headerName: 'Entered By' },
    { field: 'deliverywindow', headerName: 'Delivery Window' },
    { field: 'dropSuburb', headerName: 'Drop Suburb' },
    { field: 'tonnes', headerName: 'TONNES' },
    { field: 'unit1', headerName: 'Qty1.' },
    { field: 'unit2', headerName: 'Qty2.' },
    { field: 'unit3', headerName: 'Qty3.' },
    { field: 'unit4', headerName: 'Qty4.' },
    { field: 'unit5', headerName: 'Qty5.' },
    { field: 'unit6', headerName: 'Qty6.' },
    { field: 'unit7', headerName: 'Qty7.' },
    { field: 'unit8', headerName: 'Qty8.' },
  ];
  columnDefs: ColDef[] = this.servicecolumnFields;
  public defaultColDef: ColDef = {
    filter: 'agTextColumnFilter',
    cellStyle: { 'border-right': '1px solid #d4d4d4' },
    floatingFilter: true,
    sortable: true,
    resizable: true,
  };

  //On grid ready
  onGridReady(params: GridReadyEvent<ServiceDateCycle>) {
    this.gridApi = params.api;
    this.rowData = this.selectedTripService;
  }

  //on row selection in AG Grid
  selectedserviceno: number = 0;
  showGotoServicebutton: boolean = true;
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows.length != 0) {
      this.selectedserviceno = selectedRows.length;
      this.showGotoServicebutton = false;
    } else {
      this.showGotoServicebutton = true;
      this.selectedserviceno = selectedRows.length;
    }
  }
  showEventtable: boolean = false;

  tableeventrow: EventTable = {
    eventdatetime: undefined,
    eventdate: undefined,
    eventtime: 0,
    eventtype: '',
    relation: '',
    mdserverdatetime: undefined,
    mdserverdate: undefined,
    mdservertime: undefined,
    eventcreateddatetime: 0,
    eventcreateddate: undefined,
    eventcreatedtime: undefined,
    driver: '',
    trip: '',
    truck: '',
    trailer1: '',
    trailer2: '',
    dock: '',
    user: '',
    location: undefined,
    datasource: '',
    eventadjusted: false,
    todexportable: false,
    exported: false,
    comments: '',
    latitude: undefined,
    longitude: undefined,
    logonlogoffcompliance: false,
    serviceno: undefined,
    loadno: undefined,
  };
  tablevents: EventTable[] = [];
  eventfromapi: GetEvent[] = [];
  //call events of the trip
  getEvents(id: number) {
    this.planService.getTripEvent(id).subscribe((result) => {
      if (result['events'].length != 0) {
        this.showEventtable = true;
        this.eventfromapi = result['events'];
        this.tablevents = [];
        this.eventfromapi.forEach((event) => {
          this.tableeventrow = {
            eventdatetime: '',
            eventdate: '',
            eventtime: 0,
            eventtype: '',
            relation: '',
            mdserverdatetime: '',
            mdserverdate: '',
            mdservertime: '',
            eventcreateddatetime: 0,
            eventcreateddate: '',
            eventcreatedtime: '',
            driver: '',
            trip: '',
            truck: '',
            trailer1: '',
            trailer2: '',
            dock: '',
            user: '',
            location: '',
            datasource: '',
            eventadjusted: false,
            todexportable: false,
            exported: false,
            comments: '',
            latitude: '',
            longitude: '',
            logonlogoffcompliance: false,
            serviceno: '',
            loadno: '',
          };
          this.tableeventrow.eventtype = event.eventDescription;
          this.tableeventrow.relation = event.eventLevel.toLowerCase();
          this.tableeventrow.driver = String(event.driverId);
          this.tableeventrow.trip = event.tripIdCust;
          this.tableeventrow.truck = event.truckId;
          this.tableeventrow.trailer1 = event.trailerId;
          this.tableeventrow.trailer2 = event.trailerTagId;
          this.tableeventrow.user = event.userId;
          this.tableeventrow.datasource = event.datasourceId;
          this.tableeventrow.loadno = event.loadNo;
          this.tableeventrow.serviceno = event.serviceNo;
          this.tableeventrow.eventcreateddatetime = event.created;
          this.tableeventrow.eventcreateddate = event.created;
          this.tableeventrow.eventcreatedtime = event.created;
          this.tableeventrow.eventdatetime = event.eventTime;
          this.tableeventrow.eventdate = event.eventTime;
          this.tableeventrow.eventtime = event.eventTime;
          this.tablevents.push(this.tableeventrow);
        });
        this.rowDataEvent = this.tablevents;
      } else {
        this.showEventtable = false;
      }
    });
  }
  //on saving the form
  onSave() {
    this.getEvents(this.selectedTrip[0].id);
    if (this.tripdetailsform.dirty) {
      let chaincommand: ChainCommand[] = [
        { commandData: [], commandString: 'PROCESS_TRIP_DATE_CHANGE' },
      ];
      if (this.tripdetailsform.controls['tripno'].touched) {
        this.TripDetails.tripIdCust = this.tripdetailsform.controls['tripno'].value
      }
      if (this.tripdetailsform.controls['starttime'].touched) {
        this.TripDetails.plannedStartTime = this.timeService.convertDatetoMilliseconds(
          this.tripdetailsform.controls['starttime'].value);
      }
      if (this.tripdetailsform.controls['despatchby'].touched) {
        this.TripDetails.plannedDespatchTime =  this.timeService.convertDatetoMilliseconds(
          this.tripdetailsform.controls['despatchby'].value);
      }
      

      if (this.tripdetailsform.controls['dock'].touched) {
        this.TripDetails.dockId =
          this.tripdetailsform.controls['dock'].value.id;
      }
      if (this.tripdetailsform.controls['connote'].touched) {
        this.TripDetails.batchNo =
          this.tripdetailsform.controls['connote'].value;
      }
      if (this.tripdetailsform.controls['comments'].touched) {
        this.TripDetails.comments =
          this.tripdetailsform.controls['comments'].value;
      }
      if (this.tripdetailsform.controls['driver'].touched) {
        this.TripDetails.driverId =
          this.tripdetailsform.controls['driver'].value.id;
      }
      else {
        this.TripDetails.driverId =
          this.showDriver.id
      }
      if (this.tripdetailsform.controls['truck'].touched) {
        this.TripDetails.truckId = this.tripdetailsform.controls[
          'truck'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['trailer1'].touched) {
        this.TripDetails.trailerId = this.tripdetailsform.controls[
          'trailer1'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['trailer2'].touched) {
        this.TripDetails.trailerIdTag = this.tripdetailsform.controls[
          'trailer2'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['returnto'].touched) {
        this.TripDetails.returnLocationId =
          this.tripdetailsform.controls['returnto'].value;
      }
      if (
        this.tripdetailsform.controls['trailer1'].value == '' ||
        this.tripdetailsform.controls['trailer2'].value == ''
      ) {
        this.TripDetails.chainCommands = chaincommand;
        this.planService
          .TripDetailUpdate(this.TripDetails).pipe(
            catchError((error) => {
              // Handle the error here
              let errormessage = error.error.errorList.ErrorMessage;
              let errorurl = error.url;
              let errortime = error.error.errorList.ExceptionTime;
              let multiLineString = `${errormessage}.
URL: ${errorurl}.
Time: ${errortime}.`;

              this.messageService.add({
                severity: 'error',
                summary: error.status,
                detail: multiLineString,
                life: 20000

              });
              // You can also re-throw the error if needed
              return throwError(error);
            })
          )
          .subscribe((result) => {
            if (result) {
              this.savenotify.emit(result.trips);
              this.planService.nodatecycleupdate.next(true);
              console.log("UPDATE:", result);
              this.planService.tripUpdate.next(result.trips);
              this.messageService.add({
                severity: 'success',
                summary: '',
                detail: 'trip saved',
              });
              

            }
          });
      } else {
        this.TripDetails.chainCommands = chaincommand;
        this.planService
          .TripDetailUpdate(this.TripDetails)
          .subscribe((result) => {
            this.savenotify.emit(result.trips);
            this.planService.nodatecycleupdate.next(true);
            console.log("UPDATE:", result);

            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'trip saved',
            });
          });
      }
    }
  }

  //AG Grid configuration for Event Table
  private gridApiEvent!: GridApi<EventTable>;
  public rowSelectionEvent: 'single' | 'multiple' = 'multiple';
  rowDataEvent: EventTable[] = [];
  eventcolumnFields: ColDef[] = [
    {
      field: 'eventdatetime',
      headerName: 'Event date/time',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventdate',
      headerName: 'Event-Date',
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventtime',
      headerName: 'Event-Time',
      cellRenderer: EventdateCellRendererComponent,
    },
    { field: 'eventtype', headerName: 'Event Type' },
    { field: 'relation', headerName: 'Relation' },
    { field: 'mdserverdatetime', headerName: 'MD Server date/time' },
    { field: 'mdserverdate', headerName: 'MD Server-Date' },
    { field: 'mdservertime', headerName: 'MD Server-Time' },
    {
      field: 'eventcreateddatetime',
      headerName: ' Event Created date/time',
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventcreateddate',
      headerName: 'Event Created-Date',
      cellRenderer: EventdateCellRendererComponent,
    },
    {
      field: 'eventcreatedtime',
      headerName: 'Event Created-Time',
      cellRenderer: EventdateCellRendererComponent,
    },
    { field: 'driver', headerName: 'Driver' },
    { field: 'trip', headerName: 'Trip' },
    { field: 'truck', headerName: 'Truck' },
    { field: 'trailer1', headerName: 'Trailer 1' },
    { field: 'trailer2', headerName: 'Trailer 2' },
    { field: 'dock', headerName: 'Dock' },
    { field: 'user', headerName: 'User' },
    { field: 'location', headerName: 'Location' },
    { field: 'datasource', headerName: 'Data Source' },
    { field: 'eventadjusted', headerName: 'Event Adjusted' },
    { field: 'todexportable', headerName: 'TOD Exportable' },
    { field: 'exported', headerName: 'Exported' },
    { field: 'comments', headerName: 'Comments' },
    { field: 'latitude', headerName: 'Latitude' },
    { field: 'longitude', headerName: 'Longitude' },
    { field: 'logonlogoffcompliance', headerName: 'Logon/Logoff Compliance' },
    { field: 'serviceno', headerName: 'Service No.' },
    { field: 'loadno', headerName: 'Load No.' },
  ];
  columnDefsEvent: ColDef[] = this.eventcolumnFields;

  //On Event grid ready
  onEventGridReady(params: GridReadyEvent<EventTable>) {
    this.gridApiEvent = params.api;
  }

  //on row selection in AG Grid for Event

  onEventSelectionChanged(event: any) {
    const selectedRows = this.gridApiEvent.getSelectedRows();
  }
  isFormTouched(): boolean {
    const controls = this.tripdetailsform.controls;
    return Object.keys(controls).some(
      (controlName) => controls[controlName].touched
    );
  }

  //gotoservice button
  gotoService: ServiceDateCycle;
  gotoserviceCheck: boolean = false;
  GoToService() {

    const selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows.length != 0) {
      this.gotoService = selectedRows[0];
      this.gotoserviceCheck = true;
      this.gotoservicenotify.emit(this.gotoService);
    }
  }

  //despatch trip
  despatchTrip() {
    //first save trip if driver or truck or trailers added
    if (this.tripdetailsform.dirty) {
      let chaincommand: ChainCommand[] = [
        { commandData: [], commandString: 'PROCESS_TRIP_DATE_CHANGE' },
      ];
      //--tripno
      if (this.tripdetailsform.controls['starttime'].touched) {
        this.TripDetails.plannedStartTime =
          this.tripdetailsform.controls['starttime'].value;
      }

      if (this.tripdetailsform.controls['dock'].touched) {
        this.TripDetails.dockId =
          this.tripdetailsform.controls['dock'].value.id;
      }
      if (this.tripdetailsform.controls['connote'].touched) {
        this.TripDetails.batchNo =
          this.tripdetailsform.controls['connote'].value;
      }
      if (this.tripdetailsform.controls['comments'].touched) {
        this.TripDetails.comments =
          this.tripdetailsform.controls['comments'].value;
      }
      if (this.tripdetailsform.controls['driver'].touched) {
        this.TripDetails.driverId =
          this.tripdetailsform.controls['driver'].value.id;
      }
      if (this.tripdetailsform.controls['truck'].touched) {
        this.TripDetails.truckId = this.tripdetailsform.controls[
          'truck'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['trailer1'].touched) {
        this.TripDetails.trailerId = this.tripdetailsform.controls[
          'trailer1'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['trailer2'].touched) {
        this.TripDetails.trailerIdTag = this.tripdetailsform.controls[
          'trailer2'
        ].value.split(' ', 1)[0];
      }
      if (this.tripdetailsform.controls['returnto'].touched) {
        this.TripDetails.returnLocationId =
          this.tripdetailsform.controls['returnto'].value;
      }
      if (
        this.tripdetailsform.controls['trailer1'].value == '' ||
        this.tripdetailsform.controls['trailer2'].value == ''
      ) {
        this.TripDetails.chainCommands = chaincommand;
        this.planService
          .TripDetailUpdate(this.TripDetails)
          .pipe(
            catchError((error) => {
              // Handle the error here
              let errormessage = error.error.errorList.ErrorMessage;
              let errorurl = error.url;
              let errortime = error.error.errorList.ExceptionTime;
              let multiLineString = `${errormessage}.
    URL: ${errorurl}.
    Time: ${errortime}.`;
    
              this.messageService.add({
                severity: 'error',
                summary: error.status,
                detail: multiLineString,
                life: 20000,
              });
              // You can also re-throw the error if needed
              return throwError(error);
            })
          )
          .subscribe((result) => {
                       
            this.getEvents(this.TripDetails.id);
            // this.savenotify.emit(result);
            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'trip saved',
            });
            this.planService
              .DespatchTrip(this.selectedTrip[0].id)
              .subscribe((result) => {
                if (result) {
                  let r = "";
                  if (result.errors.length != 0) {
                    result.errors.forEach((err: any) => {
                      r = err.userErrorDescription;
                      this.messageService.add({
                        severity: 'error',
                        summary: '',
                        detail: r,
                      });
                    });
                  }

                  else {

                    //send info back to update table
                    this.despatchtoggle = true;
                    this.transittoggle = false;
                    this.despatchnotify.emit(result);
                    this.getEvents(this.selectedTrip[0].id);
                    let toastmessage =
                      'Trip:' + this.selectedTrip[0].tripIdCust + ' despatched';
                    this.messageService.add({
                      severity: 'success',
                      summary: '',
                      detail: toastmessage,
                    });
                  }


                }
              });
          });
      } else {
        this.TripDetails.chainCommands = chaincommand;
        this.planService
          .TripDetailUpdate(this.TripDetails)
          .subscribe((result) => {
            this.savenotify.emit(result);
            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'trip saved',
            });
            this.planService
              .DespatchTrip(this.selectedTrip[0].id)
              .subscribe((result) => {
                if (result) {
                  let r = "";
                  if (result.errors.length!=0) {
                    result.errors.forEach((err: any) => {
                      r = err.userErrorDescription;
                      this.messageService.add({
                        severity: 'error',
                        summary: '',
                        detail: r,
                      });
                    });
                  }

                  else {

                    //send info back to update table
                    this.despatchtoggle = true;
                    this.transittoggle = false;
                    this.despatchnotify.emit(result);
                    this.getEvents(this.selectedTrip[0].id);
                    let toastmessage =
                      'Trip:' + this.selectedTrip[0].tripIdCust + ' despatched';
                    this.messageService.add({
                      severity: 'success',
                      summary: '',
                      detail: toastmessage,
                    });
                  }


                }
              });
          });
      }
    }

    //
    // this.planService
    //   .DespatchTrip(this.selectedTrip[0].id)
    //   .subscribe((result) => {
    //     if(result){
    //       let r="";
    //       if(result.errors){
    //         result.errors.forEach((err:any) => {
    //            r=err.userErrorDescription;
    //            this.messageService.add({
    //             severity: 'error',
    //             summary: '',
    //             detail: r,
    //           });
    //         });
    //       }

    //       else{

    //         //send info back to update table
    //         this.despatchtoggle = true;
    //         this.transittoggle = false;
    //         this.despatchnotify.emit(result);
    //         this.getEvents(this.selectedTrip[0].id);
    //         let toastmessage =
    //           'Trip:' + this.selectedTrip[0].tripIdCust + ' despatched';
    //         this.messageService.add({
    //           severity: 'success',
    //           summary: '',
    //           detail: toastmessage,
    //         });
    //       }


    //     }
    //   });
  }
  //undespatch trip
  undespatchTrip() {
    this.planService
      .UndespatchTrip(this.selectedTrip[0].id)
      // .pipe(
      //   catchError((error: any) => {
      //     // Handle the error here
      //     let errormessage = error.error.errorList.ErrorMessage;
      //     let errorurl=  error.url;
      //     let errortime= error.error.errorList.ExceptionTime;
      //     let multiLineString = `${errormessage}.
      //     URL: ${errorurl}.
      //     Time: ${errortime}.`;

      //     this.messageService.add({
      //       severity: 'error',
      //       summary: error.status,
      //       detail:multiLineString,
      //       life: 20000

      //     });
      //     // You can also re-throw the error if needed
      //     return throwError(error);
      //   })
      // )
      .subscribe((result) => {
        if (result) {
          if (result.errorList) {
            this.messageService.add({
              severity: 'error',
              summary: '',
              detail: result.errorList.ErrorMessage,
              life: 20000

            });
          }
          this.undespatchnotify.emit(result);
          this.getEvents(this.selectedTrip[0].id);
          let toastmessage =
            'Trip:' + this.selectedTrip[0].tripIdCust + ' undespatched';
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: toastmessage,
          });

        }
      }, (err: any) => {
        console.log("Undespach error", err);
        let toastmessage = "Trip cannot be undespatched.";
        this.messageService.add({
          severity: 'error',
          summary: '',
          detail: toastmessage,
        });
      });
  }

  // //click on execution event button
  onExecEventClick() {

    this.confirmationService.confirm({
      accept: () => {

        this.messageService.add({
          severity: 'success',
          summary: '',
          detail: 'mess',
        });
      },
      reject: (type: ConfirmEventType) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            this.messageService.add({
              severity: 'error',
              summary: 'Rejected',
              detail: 'You have rejected',
            });
            break;
          case ConfirmEventType.CANCEL:
            this.messageService.add({
              severity: 'warn',
              summary: 'Cancelled',
              detail: 'You have cancelled',
            });
            break;
        }
      },
    });
  }
  openExecEventsDialog() {
    const dialogRef = this.dialog.open(ExecutionEventsDialogComponent, {
      data: {
        tripId: this.selectedTrip[0].id,
        tripno: this.selectedTrip[0].tripIdCust,
      },
      width: '60vw'
    });
    dialogRef.afterClosed().subscribe((res) => {
      if(res){
        if(res.data){
          this.getEvents(this.selectedTrip[0].id)
          this.messageService.add({
            severity: 'success',
            summary: '',
            detail: 'event updated',
          });
        }
      }
      // this.messageService.add({
      //   severity: 'info',
      //   summary: '',
      //   detail: 'event updated',
      // });

    });
  }

  OnTripSheetClick() {
    let tripId = this.selectedTrip[0].id;

    // open report view window
    window.open('/reportview?tripSheetPreview=' + tripId, '_blank');
  }
  onserviceSelectionChange(event: any) {
    this.columnDefs = this.servicecolumnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  oneventSelectionChange(event: any) {
    this.columnDefsEvent = this.eventcolumnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  ViewinPlanning() {
    this.router.navigate(['plan'], {
      queryParams: { startdate: this.selectedTrip[0].plannedStartTime, enddate: this.selectedTrip[0].plannedFinishTime, tripid: this.selectedTrip[0].id },
      queryParamsHandling: 'merge',
    });

    // window.open('/plan')

  }
}

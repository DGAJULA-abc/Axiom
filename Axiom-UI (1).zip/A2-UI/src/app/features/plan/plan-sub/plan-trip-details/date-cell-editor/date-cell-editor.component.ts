import { Component } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';
import { ICellEditorParams } from 'ag-grid-community';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';

@Component({
  selector: 'app-date-cell-editor',
  templateUrl: './date-cell-editor.component.html',
  styleUrls: ['./date-cell-editor.component.scss']
})
export class DateCellEditorComponent implements ICellEditorAngularComp  {
  params:any;
  value:any;
  date_today:any;
  constructor(public timeService:TimeRunsheetService){}
  agInit(params: ICellEditorParams<any, any, any>): void {
    this.params=params;
    this.date_today = new Date();
  
  }
  getValue() {
    return this.selectedDate.toString()
  }
  onSelect(event:any){
    this.selectedDate = this.timeService.convertDatetoMilliseconds3(event);
    this.params.api.stopEditing();
  }

  selectedDate:any
  

}

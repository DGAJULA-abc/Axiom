import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TripInformationSettingsDialogComponent } from './trip-information-settings-dialog.component';

describe('TripInformationSettingsDialogComponent', () => {
  let component: TripInformationSettingsDialogComponent;
  let fixture: ComponentFixture<TripInformationSettingsDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TripInformationSettingsDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TripInformationSettingsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

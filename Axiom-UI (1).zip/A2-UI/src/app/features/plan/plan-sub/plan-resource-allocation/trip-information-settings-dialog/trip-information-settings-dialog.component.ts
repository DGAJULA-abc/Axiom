import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { PlanService } from '../../../services/plan.service';

@Component({
  selector: 'app-trip-information-settings-dialog',
  templateUrl: './trip-information-settings-dialog.component.html',
  styleUrls: ['./trip-information-settings-dialog.component.scss'],
})
export class TripInformationSettingsDialogComponent {
  constructor(
    public planService: PlanService,
    public navbarService: NavbarService,
    public dialogRef: MatDialogRef<TripInformationSettingsDialogComponent>
  ) {}
  unassigned = [
    'Load numbers',
    'Service numbers',
    'Drop Locations',
    'Service types',
    'Load types',
    'Cust Refs',
  ];

  assigned = [
    'Trip No',
    'Driver',
    'Truck',
    'Trailer 1',
    'Trailer 2',
    'Batch numbers',
  ];

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  userName: any;
  temp:string;
  onSave() {
    this.temp="[";
    this.navbarService.usernameSubject.subscribe((username) => {
      this.userName = username;
    });
    this.assigned.forEach((item) => {
      switch (item) {
        case 'Trip No':
          this.temp+="\"tripIdCust\","
          // \"tripIdCust\",
          break;
        case 'Driver':
          this.temp+="\"driverObject\","
          // \"driverObject\",
          break;
        case 'Truck':
          this.temp+="\"truckObject\","
          // \"truckObject\",
          break;
        case 'Batch numbers':
          this.temp+="\"batchNos\","
          // \"batchNos\",
          break;

        case 'Load numbers':
          this.temp+="\"loadNumbers\","
          // \"loadNumbers\",
          break;
        case 'Service numbers':
          this.temp+="\"serviceNumbers\","
          // \"serviceNumbers\",
          break;
        case 'Drop Locations':
          this.temp+="\"dropLocations\","
          // \"dropLocations\",
          break;
        case 'Service types':
          this.temp+="\"serviceTypes\","
          // \"serviceTypes\",
          break;
        case 'Load types':
          this.temp+="\"loadTypes\","
          //  \"loadTypes\",
          break;
        case 'Cust Refs':
          this.temp+="\"custIds\","
          // \"custIds\",
          break;
        case 'Trailer 1':
          this.temp+="\"trailerObject\","
          // \"trailerObject\",
          break;

        default:
          break;
      }
    });
    this.temp+="]";
    const obj = {
      applicationOptionId: 9785,
      optionName: 'a2v3.trip.info',
      optionValue:this.temp,
      siteId: this.navbarService.selectedSiteId,
      userId: this.userName,
    };
    let arr = [];
    arr.push(obj);
    this.planService.saveTripInformationSettings(arr).subscribe((result) => {
      if (result) {
        this.dialogRef.close();
      }
    });
  }
}

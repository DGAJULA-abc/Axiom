import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { FilterTable } from 'src/app/features/plan/models/plan.model';
import { PlanService } from 'src/app/features/plan/services/plan.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-filter-dialog',
  templateUrl: './filter-dialog.component.html',
  styleUrls: ['./filter-dialog.component.scss'],
})
export class FilterDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<FilterDialogComponent>,
    public planService: PlanService,
    private authenticationService:AuthenticationService
  ) {}
  selectedOptions: any[];
  onSelectionChange(event: any) {
    this.columnDefs = this.columnFields.filter((column) =>
      event.value.includes(column.field)
    );
    this.gridApi.setColumnDefs(this.columnDefs);
  }
  //AG Grid configuration
  public rowSelection: 'single' | 'multiple' = 'multiple';
  private gridApi!: GridApi<FilterTable>;
  rowData: FilterTable[] = [];
  columnFields: ColDef[] = [
    {
      field: 'type',
      headerName: 'Type',
      headerCheckboxSelection: true,
      checkboxSelection: true,
    },
  ];
  columnDefs: ColDef[] = this.columnFields;
  public defaultColDef: ColDef = {
    // minWidth: 180,
    cellStyle: { 'border-right': '1px solid #d4d4d4' },

    sortable: true,
    resizable: true,
    // editable: true,
  };
  onGridReady(params: GridReadyEvent<FilterTable>) {
    this.gridApi = params.api;
    this.authenticationService.viewAPI.subscribe((result) => {

      this.ViewDataTrucks = result['ref'].trucks;
      this.ViewTruckTypes=result['ref'].truckTypes;
      this.getTruckTypeIds(this.ViewTruckTypes);
    });
    // TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
  }
SelectAll(){
  this.gridApi.selectAll();
}
DeselectAll(){
  this.gridApi.deselectAll();
}

  ViewDataTrucks: any[] = [];
  ViewTruckTypes:any[]=[];
  selectedRows:any[]=[]
  //on row selection in AG Grid
  onSelectionChanged(event: any) {
    const selectedRows = this.gridApi.getSelectedRows();
    this.selectedRows=selectedRows;
  }
  onNoClick() {
    this.dialogRef.close();
  }
  type_arr: FilterTable[] = [];
  //Get Resource Allocation Trucks
  getTruckTypeIds(viewtrucks: any[]) {
    viewtrucks.forEach((element) => {
      let typeobj = { type: '' };
        if (element.truckTypeId != null) {
          typeobj.type = element.truckTypeId;
          this.type_arr.push(typeobj);
        }
    });
    this.rowData = this.type_arr;
  }

onFilter(){
this.dialogRef.close({data:this.selectedRows});

}
}
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewEncapsulation,
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { catchError, throwError } from 'rxjs';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { TimeRunsheetService } from 'src/app/features/reconcile/services/time-runsheet.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import {
  BulkCreateFetch,
  DriverRoster,
  MultiLegSiteLocation,
} from '../../models/plan.model';
import { PlanService } from '../../services/plan.service';

@Component({
  selector: 'app-plan-driver-roster',
  templateUrl: './plan-driver-roster.component.html',
  styleUrls: ['./plan-driver-roster.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class PlanDriverRosterComponent implements OnInit, OnChanges {
  constructor(
    public navbarService: NavbarService,
    private messageService: MessageService,
    public planService: PlanService,
    private authenticationService:AuthenticationService,
    public timeService: TimeRunsheetService
  ) {}
  ngOnChanges(changes: SimpleChanges): void {
    if (this.DriverRoster) {
      this.selectedLocation = '';
      this.selected_time = '05:30';
      this.selected_time_end = '05:30';
      this.comments = '';
    }
  }
  @Output() hideroster: EventEmitter<boolean> = new EventEmitter<boolean>();

  @Input() DriverRoster: any;
  date_instance: Date = new Date();
  date_tomorrow = new Date(
    this.date_instance.setDate(this.date_instance.getDate() + 1)
  );
  selected_time: any = '00:00';
  times: any[] = [
    '00:00',
    '00:30',
    '01:00',
    '01:30',
    '02:00',
    '02:30',
    '03:00',
    '03:30',
    '04:00',
    '04:30',
    '05:00',
    '05:30',
  ];
  selected_time_end: any = '00:00';
  times_end: any[] = [
    '00:00',
    '00:30',
    '01:00',
    '01:30',
    '02:00',
    '02:30',
    '03:00',
    '03:30',
    '04:00',
    '04:30',
    '05:00',
    '05:30',
    '06:00',
    '06:30',
    '07:00',
    '07:30',
    '08:00',
    '08:30',
    '09:00',
    '09:30',
    '10:00',
    '10:30',
    '11:00',
    '11:30',
    '12:00',
    '12:30',
    '13:00',
    '13:30',
    '14:00',
    '14:30',
    '15:00',
    '15:30',
    '16:00',
    '16:30',
    '17:00',
    '17:30',
    '18:00',
    '18:30',
    '19:00',
    '19:30',
    '20:00',
    '20:30',
    '21:00',
    '21:30',
    '22:00',
    '23:00',
    '23:30',
    '23:59',
  ];

  ViewLocations: MultiLegSiteLocation[] = [];
  ViewDataDrivers: any[];
  DateCycleRosters: BulkCreateFetch[] = [];
  today_date: any;

  ngOnInit() {
    console.log(this.DriverRoster);
    if (this.DriverRoster) {
      this.selectedLocation = '';
      this.selected_time = '05:30';
      this.selected_time_end = '05:30';
      this.comments = '';
    }
    this.today_date = new Date();
    this.planService.dataCycleArray.subscribe((res) => {
      if (res) {
        this.DateCycleRosters = res.rosters;
       let start_date = moment(this.today_date);
       let start_dateb = start_date
          .set({
            hour: 0,
            minute: 0,
            second: 0,
          })
          .format('YYYY-MM-DD HH:mm:ss');
        var s_australia_time = moment.tz(start_dateb, 'Australia/Melbourne');
        var s_india = s_australia_time.clone().tz('Asia/Kolkata');
        let today_milliseconds= moment(s_india).valueOf();
       
        let datafromdatecycle = res.dateCycle.from;
        if (datafromdatecycle < today_milliseconds) {
          this.crossedout = false;
        } else {
          this.crossedout = true;
        }
      }
    });
    this.authenticationService.viewAPI.subscribe((result) => {

      this.ViewLocations = result['ref'].locations;
      this.ViewDataDrivers = result['ref'].drivers;
    });
    //TODO: remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
  }
  locationIds: any[] = [];
  selectedLocation: any;
  filteredLocations: any[];
  getLocationIds() {
    this.locationIds = [];
    this.ViewLocations.forEach((element) => {
      this.locationIds.push(element.locationId);
    });
  }
  filterLocation(event: any) {
    this.getLocationIds();
    let filtered: any[] = [];
    let query = event.query;
    this.filteredLocations = this.locationIds.filter(option => option.toLowerCase().includes(query.toLowerCase()));

  }
  // onChangeLocation(event: any) {
  //   if (this.selectedLocation != undefined) {
  //     this.crossedout = true;
  //   }
  // }
  crossedout: boolean = false;
  comments: string = '';
  payload: BulkCreateFetch[] = [];
  bulkfetchobj: BulkCreateFetch;
  onSave() {
    this.payload = [];
    this.bulkfetchobj = {
      id: 0,
      siteId: 0,
      driverId: 0,
      truckId: '',
      trailerId: undefined,
      trailerIdTag: undefined,
      startDate: 0,
      startTime: undefined,
      start: 0,
      endDate: 0,
      endTime: undefined,
      end: 0,
      rosterTypeId: undefined,
      startLocation: undefined,
      comments: undefined,
      warnings: [],
    };
    this.bulkfetchobj.comments = this.comments;
    this.bulkfetchobj.startLocation = this.selectedLocation;

    this.bulkfetchobj.driverId = this.DriverRoster.id;
    this.DateCycleRosters.forEach((row) => {
      if (row.driverId == this.DriverRoster.id) {
        this.bulkfetchobj.id = row.id;
        this.bulkfetchobj.trailerId = row.trailerId;
        this.bulkfetchobj.trailerIdTag = row.trailerIdTag;
        this.bulkfetchobj.truckId = row.truckId;
        this.bulkfetchobj.rosterTypeId = row.rosterTypeId;
        this.bulkfetchobj.warnings = row.warnings;
        this.bulkfetchobj.end = row.end;
        this.bulkfetchobj.endDate = row.endDate;

        const [ehour, eminute] = this.selected_time_end.split(':').map(Number);
        const updatedendDateTime = moment(row.endDate)
          .set({
            hour: ehour,
            minute: eminute,
            second: 0,
          })
          .format('YYYY-MM-DD HH:mm:ss');
        var s_australia_time = moment.tz(
          updatedendDateTime,
          'Australia/Melbourne'
        );
        var s_india = s_australia_time.clone().tz('Asia/Kolkata');
        this.bulkfetchobj.endTime = moment(s_india).valueOf();

        this.bulkfetchobj.startDate = row.startDate;
        this.bulkfetchobj.start = row.start;
        const [shour, sminute] = this.selected_time.split(':').map(Number);
        const updatedstartDateTime = moment(row.startDate)
          .set({
            hour: shour,
            minute: sminute,
            second: 0,
          })
          .format('YYYY-MM-DD HH:mm:ss');
        var s_australia_time = moment.tz(
          updatedstartDateTime,
          'Australia/Melbourne'
        );
        var s_india = s_australia_time.clone().tz('Asia/Kolkata');
        this.bulkfetchobj.startTime = moment(s_india).valueOf();
      }
    });

    this.bulkfetchobj.siteId = parseInt(sessionStorage.getItem('selectedSiteId')!);
    this.payload.push(this.bulkfetchobj);

    this.planService
      .rosters(this.payload)
      .pipe(
        catchError((error) => {
          // Handle the error here
          let errormessage = error.error.errorList.ErrorMessage;
          let errorurl = error.url;
          let errortime = error.error.errorList.ExceptionTime;
          let multiLineString = `${errormessage}.
URL: ${errorurl}.
Time: ${errortime}.`;

          this.messageService.add({
            severity: 'error',
            summary: error.status,
            detail: multiLineString,
            life: 20000,
          });
          // You can also re-throw the error if needed
          return throwError(error);
        })
      )
      .subscribe((result) => {
        if (result) {
          if (result.errorInfo.length != 0) {
            let mes = '';
            result.errorInfo[0].errors.forEach((err: any) => {
              mes = err;
              this.messageService.add({
                severity: 'error',
                summary: '',
                detail: mes,
                life: 20000,
              });
            });
          } else {
            this.messageService.add({
              severity: 'success',
              summary: '',
              detail: 'Roster Added',
            });
          }
          this.hideroster.emit(true);
        }
      });
  }
}

import {
  Component,
  OnInit,
  ElementRef,
  Renderer2,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { NgIf, JsonPipe, DatePipe } from '@angular/common';
import * as moment from 'moment';
import {
  Driver,
  HomeLocations,
  MultiLegSiteLocation,
  ResourceAllocation,
  ResourceAllocationTable,
  ServiceDateCycle,
  TripDateCycle,
  ViewCustomer,
} from './models/plan.model';
import { PlanService } from './services/plan.service';
import 'moment-timezone'; // Import moment-timezone
import { HomeLocation } from 'src/app/core/model/navbar.model';
import { MenuItem } from 'primeng/api';
import { ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { NewServiceDialogComponent } from './plan-sub/plan-details/new-service-dialog/new-service-dialog.component';
import { NewServiceDynonDialogComponent } from './plan-sub/plan-details/new-service-dynon-dialog/new-service-dynon-dialog.component';
import { DialogService } from 'src/app/shared/dialog/dialog.service';
import { Subscription } from 'rxjs';
import { NavbarService } from 'src/app/core/components/navbar/services/navbar.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import { PermissionsService } from 'src/app/shared/services/permissions.service';
@Component({
  selector: 'app-plan',
  templateUrl: './plan.component.html',
  styleUrls: ['./plan.component.scss'],
  providers: [DatePipe],
})
export class PlanComponent implements OnInit {
  //DetailsTab-> 0:Blank 1:New Service 2:Roster 3:Resource Allocation dialog 4:Trip Details 5:Existing Service
  DetailsTab: number = 0;
  showNewServiceForm: boolean = false;
  range = new FormGroup({
    start: new FormControl<Date | null>(null),
    end: new FormControl<Date | null>(null),
  });

  //display in details tab based on selection
  DriverSelect(message: any[]) {
    this.DetailsTab = 2;
  }
  ResourceAllocate(message: ResourceAllocation) {
    this.DetailsTab = 3;
  }
  TripSelect(message: TripDateCycle[]) {
  this.DetailsTab = 4;
  }
  ServiceSelect(mess: ServiceDateCycle) {
    this.DetailsTab = 5;
  }

  minDate = { day: 9, month: 4, year: 2022 };
  myDateValue!: Date;
  model!: any;
  date!: { year: number; month: number };
  private disabledWeekdays: number[] = [6, 7];

  selected_date = new Date();
  selected_time: any = '00:00';
  selected_duration: any ={name:'24h',value:24};
  end_date: any =
    this.datepipe.transform(this.selected_date, 'yyyy-MM-dd') + ' ' + '23:59';
  @ViewChild('toggleButton') toggleButton!: ElementRef;
  @ViewChild('dropdownmenu') dropdownmenu!: ElementRef;
  showDiv: boolean = false;
  times: any[] = [
    '00:00',
    '01:00',
    '02:00',
    '03:00',
    '04:00',
    '05:00',
    '06:00',
    '07:00',
    '08:00',
    '09:00',
    '10:00',
    '11:00',
    '12:00',
    '13:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
    '18:00',
    '19:00',
    '20:00',
    '21:00',
    '22:00',
    '23:00',
  ];
  durations: any[] = [
    { name: '4h', value: 4 },
    { name: '8h', value: 8 },
    { name: '12h', value: 12 },
    { name: '16h', value: 16 },
    { name: '20h', value: 20 },
    { name: '1d', value: 24 },
    { name: '1d4h', value: 28 },
    { name: '1d8h', value: 32 },
    { name: '1d12h', value: 36 },
    { name: '1d16h', value: 40 },
    { name: '1d20h', value: 44 },
    { name: '2d', value: 48 },
  ];

  items: MenuItem[] = [];
  layoutSubscription: Subscription;
  selectedSite: any;
  userName: any;

columnState: any;
displayLocTxt: any;
displayHomeTxt: any;
siteTimeZoneId: any;



  constructor(
    public permission: PermissionsService,
    public datepipe: DatePipe,
    private renderer: Renderer2,
    private route: ActivatedRoute,
    public planService: PlanService,
    public dialog: MatDialog,
    public authenticationService: AuthenticationService,
    public dialogService: DialogService,
    public navbarService: NavbarService,

    
  ) {
    this.renderer.listen('window', 'click', (e: Event) => {
      if (
        e.target !== this.toggleButton.nativeElement &&
        e.target !== this.dropdownmenu.nativeElement
      ) {
        this.showDiv = false;
      }
    });

    this.layoutSubscription = this.dialogService.shouldSubscribe$.subscribe((shouldSubscribe) => {
      if (shouldSubscribe) {
        let data = this.saveLayout();
        // this.dialogService.savaLayout(data);
        this.savaLayout(data);
      }
    })
  }
  filtermessage: string = '';
  homeLocations: any[] = [];
  gethomeLocations(ViewhomeLocations: HomeLocations[]) {
    this.ViewhomeLocations = ViewhomeLocations;
    ViewhomeLocations.forEach((element) => {
      if (element.active == true) {
        this.homeLocations.push({name:element.homeLocationId,selected:false});
      }
    });
  }

  customers: any[] = [];
  ViewCustomers: ViewCustomer[] = [];
  getCustomers(ViewCustomers: ViewCustomer[]) {
    this.ViewCustomers = ViewCustomers;
    ViewCustomers.forEach((element) => {
      this.customers.push(element.customerId);
    });
    this.customers.forEach((cust) => {
      this.items.push({
        label: cust,
        command: () => {
          this.selectCustomer(cust);
        },
      });
    });
  }
  query_serviceid: any;
  query_startdate: any;
  query_enddate: any;
  query_tripid: any;
  ViewhomeLocations: HomeLocations[] = [];
  viewData:any;
  ViewLocations: MultiLegSiteLocation[] = [];
  canWrite: boolean;
  ngOnInit(): void {
    try {
      this.permissionMethod();
    } catch (error) {
      console.error("Error in ngOnInit:", error);
    }

    this.route.queryParams.subscribe((params) => {
      if(Object.keys(params).length!=0){

        // Access and use the query parameters here
        this.query_serviceid = params['serviceid'];
        this.query_startdate = params['startdate'];
        this.query_enddate = params['enddate'];
        this.query_tripid = params['tripid'];
        this.callServicefromQuery(this.query_serviceid);
        this.callTripfromQuery(this.query_tripid);
      }
    });

    this.isLoading = true;
    this.planService.dataCycleArray.subscribe((result) => {

    });
    this.authenticationService.viewAPI.subscribe((result)=>{
      this.viewData=result;
      if (result) {
        this.isLoading = false;
        this.ViewhomeLocations = result['ref'].homeLocations;
        this.gethomeLocations(this.ViewhomeLocations);
        this.ViewLocations = result['ref'].locations;
        this.getLocationGroups(this.ViewLocations);
       
        this.getCustomers(result['ref'].customers);
        this.siteTimeZoneId = result?.siteTimeZoneId;
      }

    })
    //TODO:remove view
    // this.planService.getView().subscribe((result: any) => {
    // });
    this.getLayout();
  }

  async permissionMethod() {
    try {
      const result1 = await this.permission.canWrite('AllocationByRoute');
      if(result1){
        this.canWrite = true;
      } else {
        this.canWrite = false;
      }
      //console.log("Result:", this.canWrite,result1,; // Use the result here
      
    } catch (error) {
      console.error("Error:", error);
    }
  }

  groups:any[] = [];
  getLocationGroups(locs:MultiLegSiteLocation[]){
   this.groups=[];
    locs.forEach(element => {
      if(element.locationIdGroup!=null){
        this.groups.push({name:element.locationIdGroup,selected:false})
      }
    });

  }

  optionValueFiltered: any = {};
    appOptionPayload: any = { };
    locationIdGroup: any = [];
    homeLocationIdGroup: any = [];
  saveLayout(): any {
    const optionValue: any= {};
    this.selectedSite = parseInt(sessionStorage.getItem('selectedSiteId')!)
    this.navbarService.usernameSubject.subscribe((username) => {
      this.userName = username;
    });
    this.navbarService.applicationOptions.subscribe((applicationOptionsDataArray: any): any => {
      console.log("applicationOptionsData >>", applicationOptionsDataArray);
      applicationOptionsDataArray.map((applicationOptionsData: any): any => {
        if (
          applicationOptionsData?.applicationOptionId &&
          applicationOptionsData?.optionValue &&
          applicationOptionsData.optionName == 'a2v3.plan.filterObj'
        ) {
          this.optionValueFiltered = JSON.parse(
            applicationOptionsData?.optionValue
          );
          console.log(
            'api locations',
            JSON.stringify({
              homeLocation: { data: this.homeLocations, enabled: true },
              locationGroup: { data: this.groups, enabled: true },
            })
          );

          const updatedOptionValue = JSON.stringify({
            homeLocation: { data: this.homeLocations.filter((item:any) => item.selected), enabled: true },
            locationGroup: { data: this.groups.filter((item:any) => item.selected), enabled: true },
          })
          this.appOptionPayload = {
            applicationOptionId: applicationOptionsData?.applicationOptionId,
            optionName: applicationOptionsData?.optionName,
            // optionValue: "{\"homeLocation\":{\"data\":[{\"selected\":true,\"homeLocationId\":\"1250 - BRIAR HILL\"}],\"enabled\":false},\"locationGroup\":{\"data\":[{\"locationIdGroup\":\"Group1\",\"selected\":false},{\"locationIdGroup\":\"Group2\",\"selected\":false},{\"locationIdGroup\":\"qwert\",\"selected\":true}],\"enabled\":true}}",
            optionValue: updatedOptionValue,
            siteId: this.selectedSite,
            userId: this.userName,
          };
        } 
      })     
    })   
    return this.appOptionPayload;
 
}

savaLayout(data:any) {
  //  ;
      this.dialogService.layout(data).subscribe((response) =>{
        console.log(response);
      }) 
}

getLayout() {
  this.navbarService.applicationOptions.subscribe((applicationOptions: any) => {
    let appOptions = applicationOptions;
    let a = appOptions.filter((item: any) => {
      if (item['optionName'] === 'a2v3.plan.filterObj')
        this.columnState = JSON.parse(item['optionValue']);
      if (this.columnState) {
        const locationGroupData = this.columnState?.locationGroup?.data;
        const homeGroupData = this.columnState?.homeLocation?.data;

        // console.log('locationGroupData', locationGroupData);
        if(locationGroupData) {
          this.displayLocTxt = locationGroupData
          .filter((selectedItem: any) => selectedItem.selected)
          .map((selectedLocitem: any) => selectedLocitem.name)
          .join(',');
          // console.log('DisplayGrDisplay>>', this.displayLocTxt);
        }
        if(homeGroupData) {
          this.displayHomeTxt = homeGroupData
          .filter((selectedItem: any) => selectedItem.selected)
          .map((selectedLocitem: any) => selectedLocitem.name)
          .join(',');
          // console.log('homeGroupDataGrDisplay>>', this.displayHomeTxt);
        }
       
      }
    });
  });
}

applyLayout() {
  const applyColumnStateParams = {
    state: this.columnState,
    applyOrder: true
  }
  // this.columnApi.applyColumnState(applyColumnStateParams);
  // this.columnState.forEach(({ colId, width }: { colId: any, width: any }) => {
  //   // const column = this.columnApi.getColumn(colId);
  //   // if (column) {
  //     // this.columnApi.setColumnWidth(column, width);
  //   // }
  // })

}

  toggleMenu() {
    this.showDiv = !this.showDiv;
  }

  btnclick() {
    this.selected_date = new Date();
  }
  createserviceformflag: boolean = false;
  customerValue: any;

  showNewService(event: any): void {
    this.customerValue = event;
    this.showNewServiceForm = !this.showNewServiceForm;
    // ;
    if (this.showNewServiceForm == true) {
      this.DetailsTab = 1;
      this.createserviceformflag = true;
    } else {
      this.DetailsTab = -1;
      this.createserviceformflag = true;
    }
  }

  isLoading: boolean = true;

  from: number = 0;
  to: number = 0;
  services_date_cycle: ServiceDateCycle[] = [];
  serviceidfromquery: number;
  service_trips_date_cycle: TripDateCycle[];
  DateCycleResult: any;
  select_dateTime() {
    let start_date;
    start_date = moment(this.selected_date);
    start_date = start_date
      .set({
        hour: Number(this.selected_time.split(':', 1)[0]),
        minute: 0,
        second: 0,
      })
      .format('YYYY-MM-DD HH:mm:ss');
    var s_australia_time = moment.tz(start_date, 'Australia/Melbourne');
    var s_india = s_australia_time.clone().tz('Asia/Kolkata');
    this.from = moment(s_india).valueOf();

    let getendtime = s_australia_time
      .add(this.selected_duration.value, 'hours')
      .subtract(1, 'seconds');
    let endtime = getendtime.format('YYYY-MM-DD HH:mm:ss');
    this.end_date = getendtime.format('MM/DD/YY HH:mm');
    let e_australia_time = moment.tz(endtime, 'Australia/Melbourne');
    var e_india = e_australia_time.clone().tz('Asia/Kolkata');
    this.to = moment(e_india).valueOf();
    this.end_date = endtime;

    this.isLoading = true;
    this.selecteddate_hm=this.from;
    this.planService
      .getDataCycleData(this.from, this.to)
      .subscribe((result: any) => {
        if (result) {
          this.isLoading = false;
          this.DateCycleResult = result;
          if(result.services.length==0){
            this.services_date_cycle=[]
          }
          else{
            this.services_date_cycle = result.services;
          }
          if(result.trips.length==0){
            this.service_trips_date_cycle=[];   
          }
          else{
            this.service_trips_date_cycle = result.trips;
          }
          this.planService.dataCycleArray.next(this.DateCycleResult);
          this.DetailsTab=0;
        }
       
      });
  }
  selecteddate_hm:any;
  selectedService: ServiceDateCycle;
  callServicefromQuery(serviceid: number) {
    this.planService.getService(serviceid).subscribe((res) => {
      if (res) {
        this.selectedService = res;
      }
    });
  }
  selectedTrip2: TripDateCycle[];
  callTripfromQuery(tripid: number) {
    this.planService.getTrip(tripid).subscribe((res) => {
      if (res) {
        this.selectedTrip2 = res.trips;
      }
    });
  }
  //Filter dropdown for all tabs
  filtering: string = '';
  filteringflag_dr: boolean = true;
  filteringflag_tr: boolean = true;
  filteringflag_pm: boolean = true;
  filteringflag_sr: boolean = true;
  filteringflag_ra: boolean = true;

  showDrivers: boolean = true;
  showTrips: boolean = true;
  showPrimeMovers: boolean = true;
  showServices: boolean = true;
  showResourceAllocation: boolean = true;
  TabToggling(tog: string) {
    this.filtering = tog;
    if (tog == 'drivers') {
      this.filteringflag_dr = !this.filteringflag_dr;
      this.showDrivers = !this.showDrivers;
    }
    if (tog == 'trips') {
      this.filteringflag_tr = !this.filteringflag_tr;
      this.showTrips = !this.showTrips;
    }
    if (tog == 'primemovers') {
      this.filteringflag_pm = !this.filteringflag_pm;
      this.showPrimeMovers = !this.showPrimeMovers;
    }
    if (tog == 'services') {
      this.filteringflag_sr = !this.filteringflag_sr;
      this.showServices = !this.showServices;
    }
    if (tog == 'resourceallocation') {
      this.filteringflag_ra = !this.filteringflag_ra;
      this.showResourceAllocation = !this.showResourceAllocation;
    }
  }
  //CSV Upload application routing
  csvUpload() {
    window.open('https://axiom2-uat.tollgroup.com/csv/csv.html#/');
  }
  IsServiceCreated(mess: boolean) {
    if (mess == true) {
      this.isLoading = true;
      this.planService
        .getDataCycleData(this.from, this.to)
        .subscribe((result: any) => {
          if (result) {
            this.isLoading = false;
            this.services_date_cycle = result.services;
            this.service_trips_date_cycle = result.trips;
          }
        });
    }
  }
  SelectedCustomer: ViewCustomer;
  selectCustomer(event: any) {
    //const button = event.target as HTMLButtonElement;
    // const buttonText = button.textContent;
    const buttonText = event;
    this.ViewCustomers.forEach((cust) => {
      if (cust.customerId == buttonText?.trim()) {
        this.SelectedCustomer = cust;
        return;
      }
    });
    this.showNewService(event);
 if (
          this.SelectedCustomer.scheduleEntryForm == 'Container' ||
          this.SelectedCustomer.scheduleEntryForm == 'Dynon'
        ) {
          this.ShowThePerticularCustomer(this.SelectedCustomer);
        }
   
  }

  formType:any;
  ShowThePerticularCustomer(selectedcustomerdata: any) {
    const viewdata=this.viewData;
    this.formType=selectedcustomerdata.scheduleEntryForm;
    if (this.formType == 'Container') {
      // 
    const dialogRef=this.dialog.open(NewServiceDialogComponent , {
      width:'950px',
      height:'800px',
      data:{selectedcustomerdata,viewdata}
    });
    }else if(this.formType == 'Dynon') {
      const dialogRef=this.dialog.open(NewServiceDynonDialogComponent , {
        width:'900px',
        height:'800px',
        data:{selectedcustomerdata,viewdata}
      });
    }
  }

  homelocationToggle: boolean = true;
  HomeLocationToggle() {
    this.homelocationToggle = !this.homelocationToggle;
    if (!this.homelocationToggle) {
      this.filtermessage += 'All home locations ';
    } else {
      this.filtermessage = '';
    }
  }
  Location: string = '';
  homelocationoptionToggle: boolean = true;
  locgroupflag: boolean = false;

 
  onCheckboxClick(location: any) {
    this.homelocationoptionToggle = !this.homelocationoptionToggle;
    if (!this.homelocationoptionToggle) {
      this.Location = '';
      this.Location = location;
    } else {
      this.Location = 'na';
    }
  }
  locationGroups: any[] = [];
  locationgroupToggle: boolean = true;
  LocationGroupToggle() {
    this.locationgroupToggle = !this.locationgroupToggle;
    if (!this.locationgroupToggle) {
      this.filtermessage += '';
    } else {
      if (!this.homelocationToggle) {
        this.filtermessage = ' All home locations ';
      } else {
        this.filtermessage = '';
      }
    }
  }
 
  selectAllState = false;
  selectAllState2=false;

  toggleIndividualSelection(index: number): void {
    this.groups[index].selected = !this.groups[index].selected;
    this.updateSelectAllState();
  }
  toggleIndividualSelection2(index:number):void{
    this.homeLocations[index].selected = !this.homeLocations[index].selected;
    this.Location = '';
    if ( this.homeLocations[index].selected) {
      this.Location = this.homeLocations[index].name;
    } else {
      this.Location = 'na';
    }
    this.updateSelectAllState2();
  }

  toggleSelectAll(): void {
    this.selectAllState = !this.selectAllState;
    this.groups.forEach(group => group.selected = this.selectAllState);
  }
  toggleSelectAll2(): void {
    this.selectAllState2 = !this.selectAllState2;
    this.homeLocations.forEach(group => group.selected = this.selectAllState2);
  }
  updateSelectAllState(): void {
    this.selectAllState = this.groups.every(group => group.selected);
  }
  updateSelectAllState2():void{
    this.selectAllState2 = this.homeLocations.every(homeloc => homeloc.selected);

  }


  get displayText(): string {
    if (this.selectAllState) {
      return 'All location groups';
    } else {
      const selectedGroups = this.groups.filter(group => group.selected).map(group => group.name);
      return selectedGroups.join(', ');
    }
  }
  get displayText2(): string {
    if (this.selectAllState2) {
      return 'All home locations';
    } else {
      const selectedGroups = this.homeLocations.filter(group => group.selected).map(group => group.name);
      return selectedGroups.join(', ');
    }
  }
  

}

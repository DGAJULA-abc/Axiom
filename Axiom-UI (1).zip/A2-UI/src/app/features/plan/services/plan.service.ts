import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { apiEndpoint } from 'src/app/config/config.model';
import {
  AllocateEventPayload,
  BulkCreateFetch,
  CopyService,
  DateChangePayload,
  DeleteTripPayload,
  DuplicateTripOptions,
  ExecEventAPIResponse,
  MultiLegSiteLocation,
  ServiceDateCycle,
  TripDateCycle,
  TruckUnavailability,
} from '../models/plan.model';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PlanService {
  constructor(private http: HttpClient) {}

  public dataCycleArray = new BehaviorSubject<any>(null);
  dataCycleArray$ = this.dataCycleArray.asObservable();

  public tripUpdate = new BehaviorSubject<any[]>([]);
  public nodatecycleupdate = new BehaviorSubject<boolean>(false);
  public reasons = new BehaviorSubject<any[]>([]);
  truckUnavailability: TruckUnavailability;
  public FilterData = new BehaviorSubject<any[]>([]);
  public ServiceSearchupdate = new BehaviorSubject<any[]>([]);
  public ServiceReconcileUpdate = new BehaviorSubject<any[]>([]);

  public selectedRowGridS = new BehaviorSubject<boolean>(false);
  public selectedRowGridT = new BehaviorSubject<boolean>(false);

  public dateSelectedSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  setDateSelected(selected: boolean) {
    this.dateSelectedSubject.next(selected);
  }

  getDateSelected(): Observable<boolean> {
    return this.dateSelectedSubject.asObservable();
  }

  //viewreconcilre tab data;
  getTabsPlanData(): any {
    let options: any = [];
    return this.http.get<any>('assets/APIs/plan_tab.json', options);
  }
  //View API to get all info on trucks,companys,drivers,vendors,locations etc
  getView(): any {
    let options: any = {
      referenceDataActiveStates: {
        drivers: 'ANY',
      },
    };
    return this.http.post<any>(apiEndpoint.contextView, options);
  }
  //Get All Customer Data
  getAllData(selectedId: number) {
    let options: any = [];
    let url = apiEndpoint.multiLegSiteLocations + '/' + selectedId;
    return this.http.get<MultiLegSiteLocation>(url, options);
  }
  getAllData1(selectedId: number) {
    let options: any = [];
    let url = apiEndpoint.multiLegSiteLocations + '/' + selectedId;
    return this.http.get<MultiLegSiteLocation>(url, options);
  }

  validationContainer(data: any) {
    let option = data;
    return this.http.post<any>(
      apiEndpoint.schedule.validateAmcor.container,
      option
    );
  }
  //Dyon metadata
  getDyonmetadata() {
    return this.http.get<any>(apiEndpoint.schedule.getMetadata.dynon);
  }

  //Dyon Local Valadition
  PostDyonValidation(data:any){
    let option=data;
    return this.http.post<any>(apiEndpoint.schedule.validateAmcor.dynon.local,option);
  }

//Dynon ImportExport Validation
PostImportExportValidation(data:any){
let option=data;
return this.http.post<any>(apiEndpoint.schedule.validateAmcor.dynon.importExport,option);
}

//ImportexportDyonServices
PostImportExportDyonServices(data:any){
  let option:any[]=[data];
  return this.http.post<any>(apiEndpoint.schedule.dynon.importExport,option);
}

//Dyon Local servier
PostLocalDyonServices(data:any){
let option:any[]=[data];
return this.http.post<any>(apiEndpoint.schedule.dynon.local,option);
}

//associatedData
getAssociatedData(id:any){
  let url=apiEndpoint.service+'/'+id+'/associated-data';
   return this.http.get<any>(url);
}

  searchdata(data: any) {
    let option = { containerSearchString: data };
    return this.http.post<any>(apiEndpoint.searchContainer, option);
  }

  getMetadata() {
    return this.http.get<any>(apiEndpoint.schedule.getMetadata.container);
  }

  //Get All data for Resource Allocation Table
  getResourceAllocation(truckID: any) {
    let options: any = [];
    let url = apiEndpoint.getTruckUnavail + encodeURIComponent(truckID);
    return this.http.get<TruckUnavailability>(url, options);
  }
  //get bulkcreatefetch data from selected date
  bulkCreateFetch(selected_date: any) {
    //From palak for 25th
    // let options:any=1698085800000;
    //From UAT for 25th
    //let options :any=1698152400000;
    let options: any = selected_date;
    let url = apiEndpoint.roster.get;
    return this.http.post<any>(url, options);
  }
  rosters(obj: BulkCreateFetch[]) {
    let options: any = obj;
    let url = apiEndpoint.roster.update;
    return this.http.post<any>(url, options);
  }
  deleteRoster(deleteids: number[]) {
    let options: any = deleteids;
    let url = apiEndpoint.roster.delete;
    return this.http.post<any>(url, options);
  }
  //get data from date cycle selection
  getDataCycleData(From: number, To: number) {
    let options: any = {
      from: From,
      to: To,
    };
    let url = apiEndpoint.planContextDateCycle;
    return this.http.post<any>(url, options);
  }
  CopyService(serviceInfo: CopyService) {
    let options: CopyService = {
      newScheduledDate: serviceInfo.newScheduledDate,
      newServiceDate: serviceInfo.newServiceDate,
      noOfCopies: serviceInfo.noOfCopies,
      serviceId: serviceInfo.serviceId,
    };
    let url = apiEndpoint.copyService;
    return this.http.post<any>(url, options);
  }
  DeleteService(servicenos: any[]) {
    return this.http.delete<any>(`${apiEndpoint.service}`, {
      body: servicenos,
    });
  }
  BulkCopy(fromService: number, toService: number) {
    let options: any = {
      fromServiceDate: fromService,
      toServiceDate: toService,
    };
    let url = apiEndpoint.bulkCopy;
    return this.http.post<any>(url, options);
  }
  DuplicateTrip(tripinfo: DuplicateTripOptions, tripid: any, preloadDuplication:boolean) {
  let options ={};
    if(preloadDuplication){
       options = {
        driverId: tripinfo.driverId,
        loadType: tripinfo.loadType,
        numberOfDuplicates: tripinfo.numberOfDuplicates,
        serviceType: tripinfo.serviceType,
        tripDate: tripinfo.tripDate,
        truckId: tripinfo.truckId,
        reasonId: tripinfo.reasonId,
        preloadDropLocation: tripinfo.preloadDropLocation
      }
    }else{
    options = {
      driverId: tripinfo.driverId,
      loadType: tripinfo.loadType,
      numberOfDuplicates: tripinfo.numberOfDuplicates,
      serviceType: tripinfo.serviceType,
      tripDate: tripinfo.tripDate,
      truckId: tripinfo.truckId
    }
  }
    let url = apiEndpoint.trip + '/' + tripid + '/duplicate';
    return this.http.post<any>(url, options);
  }
  Trips(tripinfo: DateChangePayload) {
    let options = tripinfo;
    let url = apiEndpoint.trips;
    return this.http.post<any>(url, options);
  }
  putEvent(payload: AllocateEventPayload[]) {
    let options = payload;
    let url = apiEndpoint.events;
    return this.http.put<any>(url, options);
  }
  getTripEvent(tripId: number) {
    let options;
    let url = apiEndpoint.tripevent + '/' + tripId + '/events';
    return this.http.get<any>(url, options);
  }
  DeleteTrip(deletetrip: DeleteTripPayload) {
    return this.http.delete<any>(`${apiEndpoint.trips}`, {
      body: deletetrip,
    });
  }
  TripDetailUpdate(updatetrip: TripDateCycle) {
    let options: TripDateCycle = updatetrip;
    let url = apiEndpoint.trip + '/' + updatetrip.id + '/trip-svc-seq-update';
    return this.http.post<any>(url, options);
  }
  DespatchTrip(tripId: number) {
    let options: number[] = [tripId];
    let url = apiEndpoint.despatchtrip;
    return this.http.post<any>(url, options);
  }
  UndespatchTrip(tripdId: number) {
    let options: number[] = [tripdId];
    let url = apiEndpoint.undespatchtrip;
    return this.http.post<any>(url, options);
  }
  getExecutionEvents(tripId: number) {
    let options;
    let url = apiEndpoint.trip + '/' + tripId + '/execution-events';
    return this.http.get<any>(url, options);
  }
  postExecutionEvents(tripId: number, payload: any) {
    let options = payload;
    let url = apiEndpoint.trip + '/' + tripId + '/execution-events';
    return this.http.post<any>(url, options);
  }
  getServiceEvent(serviceId: any) {
    let options;
    let url = apiEndpoint.singleService + '/' + serviceId + '/associated-data';
    return this.http.get<any>(url, options);
  }
  getService(serviceId: any) {
    let options;
    let url = apiEndpoint.singleService + '/' + serviceId;
    return this.http.get<any>(url, options);
  }
  getTrip(tripid: number) {
    let options;
    let url = apiEndpoint.tripevent + '/' + tripid;
    return this.http.get<any>(url, options);
  }
  searchContainer(containerid: any) {
    let options = {
      containerId: containerid,
    };
    let url = apiEndpoint.searchContainer;
    return this.http.post<any>(url, options);
  }
  PostContainer(containerdata: any) {
    let options: any[] = [containerdata];
    let url = apiEndpoint.schedule.container;
    return this.http.post<any>(url, options);
  }
  PostDynon(containerid: any) {
    let options = {
      containerId: containerid,
    };
    let url = apiEndpoint.schedule.dynon.importExport;
    return this.http.post<any>(url, options);
  }

  saveExistingService(services: any[]) {
    let options = services;
    let url = apiEndpoint.service;
    return this.http.put<any>(url, options);
  }
  
  saveExistingService2(services: any[]) {
    let options = services;
    let url = apiEndpoint.service;
    return this.http.post<any>(url, options);
  }
  duplicatecheck(services:any[]){
    let options = services;
    let url = apiEndpoint.serviceCheckDuplication;
    return this.http.post<any>(url, options);
  }
  addContainer(container: any[]) {
    let options = container;
    let url = apiEndpoint.containers;
    return this.http.put<any>(url, options);
  }
  saveUnavailability(truckUnavail_arr: TruckUnavailability[]) {
    let options = truckUnavail_arr;
    let url = apiEndpoint.resourceUnavail;
    return this.http.post<any>(url, options);
  }
  putUnavailability(truckUnavail_arr: TruckUnavailability[]) {
    let options = truckUnavail_arr;
    let url = apiEndpoint.resourceUnavail;
    return this.http.put<any>(url, options);
  }

  fetchTripsandServices(payload:any){
    let options = payload;
    let url = apiEndpoint.fetchTripsAndServices;
    return this.http.post<any>(url, options);
  }
  saveTripInformationSettings(payload: any[]) {
    let options = payload;
    let url = apiEndpoint.applicationOptionsReturnAll;
    return this.http.post<any>(url, options);
  }

  DeleteRA(ids: number[]) {
    return this.http.delete<any>(`${apiEndpoint.resourceUnavail}`, {
      body: ids,
    });
  }
  DuplicateSelectedDriverRoster(obj: any) {
    let options: any = obj;
    let url = apiEndpoint.roster.copy;
    return this.http.post<any>(url, options);
  }
  TripCreate(obj:any){
    let options: any = obj;
    let url = apiEndpoint.trip;
    return this.http.put<any>(url, options);
  }

  runsheetServiceBtnState: any;
  get getRunsheetServicebtnState() {
    return this.runsheetServiceBtnState;
  }

  set getRunsheetServicebtnState(value: any) {
     this.runsheetServiceBtnState = value;
  }
}

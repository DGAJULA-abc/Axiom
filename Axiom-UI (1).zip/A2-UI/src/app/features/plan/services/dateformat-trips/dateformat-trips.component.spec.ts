import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DateformatTripsComponent } from './dateformat-trips.component';

describe('DateformatTripsComponent', () => {
  let component: DateformatTripsComponent;
  let fixture: ComponentFixture<DateformatTripsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DateformatTripsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DateformatTripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

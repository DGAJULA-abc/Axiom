import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-service-status',
  templateUrl: './service-status.component.html',
  styleUrls: ['./service-status.component.scss']
})
export class ServiceStatusComponent implements ICellRendererAngularComp {
  public params: any;
  status: any;
  agInit(params: any): void {
    this.params = params;
     if(params['data'].truckId!=null){
      this.status="allocated"
     }
     else{
      this.status="unallocated"
     }
  }
  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
}

export interface MultiLegSiteLocation {
  accShortCut: string;
  active: boolean;
  address1: string;
  address2: string;
  customerId: string;
  defaultTripSeq: any;
  disableWPUpdated: boolean;
  locationId: string;
  siteId: number;
  locationTypeId: string;
  locationDesc: string;
  zonePayId: string;
  zoneChargeId: string;
  suburb: any;
  loadTimeMins: number;
  state: string;
  postCode: number;
  window1From: number;
  window1To: number;
  window2From: number;
  window2To: number;
  window3From: number;
  window3To: number;
  personIdContact: number;
  personIdContactName: string;
  locationCode: string;
  latitude: number;
  longitude: number;
  geofence: number;
  mapSourceId: any;
  mapReference: any;
  remarks: any;
  truckSizeLimit: any;
  routeId: string;
  permanent: boolean;
  loadTimeMinsPerUnit: any;
  loadTimeUnit: any;
  waitTimeMins: any;
  waitTimeMinsPerUnit: any;
  waitTimeUnit: any;
  locationIdGroup: any;
  siteTravelTime: number;
  externalLookUp: any;
  internalLookUp: any;
  segManaged: boolean;
  segExported: boolean;
  routeCapacity: any;
}
export interface ViewDriver {
  active: boolean;
  companyId: string;
  employeeName: string;
  entityDriver: boolean;
  firstName: string;
  groupDriver: boolean;
  homeLocationId: any;
  id: number;
  invalidationDate: any;
  mdtCode: string;
  mobile: string;
  payBasisId: any;
  personId: number;
  siteId: number;
  surname: string;
  trailerId: any;
  truckId: any;
  vendorName: string;
}
export interface Driver {
  id: any;
  name: string;
  company: string;
  pdtloginId: string;
  pickupTime:any;
  travelTime:any;
  dropTime:any;
  colour: any;
  truckId: any;
}
export interface Driver2 {
  id: number;
  name: string;
  company: string;
}
export interface PrimeMover {
  Rego: string;
  Description: string;
  Fleet: string;
  id: any;
  name: string;
  company: string;
  pdtloginId: string;
  pickupTime:any;
  travelTime:any;
  dropTime:any;
  colour: any;
}
export interface ResourceAllocationTable {
  name: string;
  type: string;
  capacity: number;
  fleet: string;
}
export interface ResourceAllocation {
  active: boolean;
  companyId: string;
  costPerDay: number;
  costPerKm: number;
  equipmentGroupId: any;
  externalLookup: any;
  fleetNumber: string;
  hireRateHourly: any;
  homeLocationId: any;
  makeId: any;
  odometerKms: any;
  onHire: boolean;
  phoneNumber: any;
  regoExpiry: any;
  rigid: boolean;
  routeCapacity: number;
  siteId: number;
  tare: any;
  trackableObjectId: any;
  trailerId: string;
  trailerIdTag: any;
  transmittedTs: any;
  truckDesc: string;
  truckId: string;
  truckSize: any;
  truckSizeId: any;
  truckTypeDesc: any;
  truckTypeId: string;
  year: any;
}
export interface TruckUnavailability {
  id: any;
  lastModified: number;
  reasonId: string;
  siteId: number;
  trailerId: any;
  truckId: string;
  windowFrom: number;
  windowTo: number;
}
export interface DriverRosterTable {
  Driver: any;
  StartLocation: any;
  Start: any;
  Finish: any;
  Duration: any;
  Comments: any;
}
export interface DriverRoster {
  Id: number;
  Driver: any;
  TruckId: any;
  CompanyId: any;
}
export interface BulkCreateFetch {
  id: number;
  siteId: number;
  driverId: any;
  truckId: string;
  trailerId: any;
  trailerIdTag: any;
  startDate: number;
  startTime: any;
  start: number;
  endDate: number;
  endTime: any;
  end: number;
  rosterTypeId: any;
  startLocation: any;
  comments: any;
  warnings: [];
}
export interface ServiceDateCycle {
  address: any;
  bookedTimeDrop: any;
  bookedTimePickup: any;
  chargeAmt: any;
  chargeDesc: any;
  chargeZoneDrop: any;
  chargeZonePickup: any;
  complete: boolean;
  containerId: any;
  containerTypeId: any;
  created: number;
  curfewWindow: any;
  customerId: string;
  customerSite: any;
  dataSourceId: string;
  dehireDeadline: any;
  dehirePark: any;
  delivered: boolean;
  deliveryClose: any;
  deliveryOpen: any;
  depot: any;
  despatchBy: any;
  destinationLoc: any;
  destinationSite: number;
  docket: any;
  driverId: any;
  dropDesc: any;
  dropSuburb: any;
  enteredBy: string;
  etaUpdatedTime: any;
  exported: boolean;
  holdcode: any;
  id: number;
  loadBatchNo: any;
  loadCustReference: any;
  loadDesc: any;
  loadDestination: string;
  loadId: number;
  loadNo: string;
  loadScheduledDate: number;
  loadSuburb: any;
  loadTypeId: string;
  locationIdDrop: string;
  locationIdPickup: string;
  locationIdPickupActual: any;
  offsiderUsed: boolean;
  operationType: any;
  originLoc: any;
  originSite: number;
  podCreated: boolean;
  priority: any;
  qty1: any;
  qty2: any;
  qty3: any;
  qty4: any;
  qty5: any;
  qty6: any;
  qty7: any;
  qty8: any;
  rateId: any;
  reasonId: any;
  remarks: any;
  replicated: any;
  runsheetId: any;
  serviceDate: number;
  serviceDesc: any;
  serviceGroup: any;
  serviceIdRecharge: any;
  serviceNo: string;
  serviceTypeId: string;
  siteId: number;
  stopSeqDrop: any;
  stopSeqPickup: any;
  storeETA: any;
  todFlags: any;
  trailerId: any;
  trailerIdTag: any;
  tripId: any;
  tripIdCust: any;
  tripNo: any;
  tripSeq: any;
  truckId: any;
  unit1: string;
  unit2: string;
  unit3: string;
  unit4: any;
  unit5: any;
  unit6: any;
  unit7: any;
  unit8: any;
  used: boolean;
  usedSet: any;
  vesselEta: any;
  vesselId: any;
  wharf: any;
  window1: any;
  window1From: any;
  window1To: any;
  window2: any;
  window2From: any;
  window2To: any;
  window3: any;
  window3From: any;
  window3To: any;
}
export interface CopyService {
  newScheduledDate: any;
  newServiceDate: any;
  noOfCopies: number;
  serviceId: number;
}
export interface warnings {
  curfewWindowBreach: boolean;
}
export interface activities {
  activityIndex: number;
  activityTime: number;
  activityTypeId: number;
  comments: any;
  dropLocationId: any;
  id: any;
  pickupLocationId: string;
  siteId: number;
  tripId: number;
  warnings: warnings;
}
export interface ActivityDisplay {
  header: string;
  label: string;
  time: string;
  colorbar: boolean;
}
export interface ActivityTypes {
  code: string;
  id: number;
  name: string;
}
export interface ChainCommand {
  commandData: any[];
  commandString: string;
}
export interface TripDateCycle {
  activities: activities[];
  actualDespatchTime: any;
  actualFinishTime: any;
  actualReturnTime: any;
  actualStartTime: any;
  batchNo: any;
  cachedPhase: number;
  cachedRoutingQty: number;
  cachedStatus: string;
  cachedTrailerCapacity: number;
  cachedTruckCapacity: number;
  chainCommands: ChainCommand[];
  comments: any;
  companyId: string;
  containerNo: any;
  created: number;
  custRef: any;
  customerClaimAmt: any;
  dataSourceId: any;
  deliveredServicesCount: string;
  deliveryWindow: any;
  despatchByTime: any;
  despatchLocationId: any;
  despatched: boolean;
  dockId: any;
  docket: any;
  driverBreakIds: any;
  driverId: number;
  dropSuburb: string;
  enteredBy: string;
  etaUpdatedTime: any;
  eventIds: any;
  firstDrop: string;
  firstLoadType: any;
  firstPickup: string;
  holdCode: any;
  id: number;
  lastDrop: string;
  lastPickup: string;
  loadNo: string;
  loadSuburb: string;
  locations: string[];
  multiDrop: any;
  paperWorkReady: any;
  pickWaveRef: any;
  pickupLocationIds: string[];
  plannedDespatchTime: any;
  plannedFinishTime: number;
  plannedReturnTime: any;
  plannedStartTime: number;
  regionId: any;
  remarks: any;
  returnLocationId: string;
  revenue: any;
  routeId: any;
  routingUnit: string;
  sdpLineIds: any;
  serviceIds: number[];
  settledDate: any;
  siteId: number;
  trailerId: any;
  trailerIdTag: any;
  tripComplete: boolean;
  tripDate: number;
  tripIdCust: string;
  tripNo: any;
  truckId: string;
  utilization: string;
  vesselNo: any;
}
export interface TripTable {
  trip: string;
  id: any;
  startdatetime: any;
  startdate: any;
  starttime: any;
  enddatetime: any;
  enddate: any;
  endtime: any;
  totaltriptime: any;
  status: any;
  despatched: any;
  despatchdatetime: any;
  despatchdate: any;
  despatchtime: any;
  driver: any;
  truck: any;
  trailer: any;
  firstpickup: any;
  returnto: any;
  comments: any;
  remarks: any;
  custref: any;
  connote: any;
  multidrop: any;
  services: any;
  dock: any;
  enteredby: any;
  tonnes: any;
  utilisation: any;
  curfewbreach: any;
  region: any;
  firstdrop: any;
  lastdrop: any;
  lastpickup: any;
  firstloadtype: any;
  dropsuburb: any;
  loadsuburb: any;
  despatchbydatetime: any;
  despatchbydate: any;
  despatchbytime: any;
  deliverywindow: any;
  customerid: any;
  paperworkreadydate: any;
  paperworkreadytime: any;
  containerno: any;
  companyid: any;
  loadno: any;
  vesselno: any;
}
export interface DuplicateTripOptions {
  createServicesInSameLoad:boolean;
  driverId: any;
  loadType: any;
  reasonId:any;
  preloadDropLocation: any;
  numberOfDuplicates: number;
  serviceType: string;
  tripDate: any;
  truckId: string;
}
export interface Reasons {
  active: boolean;
  driver: boolean;
  reasonDescription: string;
  reasonId: string;
  siteId: number;
}
export interface EventTypes {
  eventDesc: string;
  id: number;
  siteId: number;
  todExportable: boolean;
}
// 1660140000000
// 5374244
export interface DateChangePayload {
  fields: { tripDate: number };
  ids: number[];
  //reason: string;
}

export interface AllocateEventPayload {
  datasourceId: string;
  driverId: number;
  eventTypeId: number;
  loggedDateTime: any;
  siteId: number;
  trailerId: any;
  trailerTagId: any;
  tripId: number;
  truckId: string;
}
export interface DeleteTripPayload {
  ids: number[];
  siteId: number;
}

export interface Vessel {
  id: number;
  siteId: number;
  vessel: string;
}
export interface Dock {
  active: boolean;
  dockName: string;
  homeLocationId: any;
  id: number;
  locationId: string;
  siteId: number;
}
export interface Trailer {
  active: boolean;
  companyId: string;
  costPerDay: any;
  costPerKm: any;
  customerId: string;
  dropDate: any;
  fleetNumber: string;
  hireRateDaily: any;
  homeLocationId: any;
  locationId: any;
  odometerKms: any;
  onHire: boolean;
  pickupDate: any;
  regoExpiry: any;
  routeCapacity: number;
  siteId: number;
  tare: any;
  trackableObjectId: number;
  trailerDesc: string;
  trailerId: string;
  trailerIdTag: any;
  trailerTypeDesc: any;
  trailerTypeId: string;
  transmittedTs: any;
}
export interface Location {
  accShortCut: any;
  active: boolean;
  address1: string;
  address2: any;
  customerId: any;
  defaultTripSeq: any;
  disableWPUpdated: boolean;
  externalLookUp: any;
  geofence: number;
  internalLookUp: any;
  latitude: number;
  loadTimeMins: number;
  loadTimeMinsPerUnit: any;
  loadTimeUnit: any;
  locationCode: string;
  locationDesc: string;
  locationId: string;
  locationIdGroup: any;
  locationTypeId: string;
  longitude: number;
  mapReference: any;
  mapSourceId: any;
  permanent: boolean;
  personIdContact: any;
  personIdContactName: any;
  postCode: string;
  remarks: any;
  routeCapacity: any;
  routeId: any;
  segExported: boolean;
  segManaged: boolean;
  siteId: number;
  siteTravelTime: any;
  state: string;
  suburb: string;
  truckSizeLimit: any;
  waitTimeMins: any;
  waitTimeMinsPerUnit: any;
  waitTimeUnit: any;
  window1From: any;
  window1To: any;
  window2From: any;
  window2To: any;
  window3From: any;
  window3To: any;
  zoneChargeId: string;
  zonePayId: string;
}
export interface GetEvent {
  certainty: any;
  comments: any;
  companyId: string;
  compliant: boolean;
  created: number;
  datasourceId: string;
  dockId: any;
  driverId: number;
  employeeName: string;
  eventAdjusted: boolean;
  eventDescription: string;
  eventLevel: string;
  eventTime: number;
  eventTypeId: number;
  exception: boolean;
  exceptiondesc: any;
  exported: boolean;
  firstName: any;
  fleetId: any;
  id: number;
  key: number;
  lastName: any;
  latitude: any;
  loadNo: any;
  locationId: any;
  loggedDateTime: number;
  longitude: any;
  mdrego: any;
  mdservertime: any;
  mdtcode: any;
  serviceId: any;
  serviceNo: any;
  siteId: number;
  textValue: any;
  textValue2: any;
  time1: any;
  time2: any;
  todexportable: boolean;
  trailerId: string;
  trailerTagId: string;
  tripId: number;
  tripIdCust: string;
  tripNo: any;
  truckId: string;
  unitId: any;
  userId: string;
  value1: any;
  value2: any;
  vehicleId: any;
}
export interface EventTable {
  eventdatetime: any;
  eventdate: any;
  eventtime: number;
  eventtype: string;
  relation: string;
  mdserverdatetime: any;
  mdserverdate: any;
  mdservertime: any;
  eventcreateddatetime: number;
  eventcreateddate: any;
  eventcreatedtime: any;
  driver: string;
  trip: string;
  truck: string;
  trailer1: string;
  trailer2: string;
  dock: string;
  user: string;
  location: any;
  datasource: string;
  eventadjusted: boolean;
  todexportable: boolean;
  exported: boolean;
  comments: string;
  latitude: any;
  longitude: any;
  logonlogoffcompliance: boolean;
  serviceno: any;
  loadno: any;
}
export interface ExecEventAPIResponse {
  executionEvents: {
    activityType: string;
    arrivalEvent: {
      time: any;
      source: any;
      modified: boolean;
      eventIds: any[];
    };
    completionEvent: {
      time: any;
      source: any;
      modified: boolean;
      eventIds: any[];
    };
    departureEvent: {
      time: any;
      source: any;
      modified: boolean;
      eventIds: any[];
    };
    location: string;
    sequenceNo: number;
    serviceIds: number[];
  }[];
}
export interface ExecEventTable {
  sno: number;
  location: string;
  arrive: any;
  source_a: any;
  completed: any;
  source_c: any;
  depart: any;
  source_d: any;
  type: string;
}
export interface TripSaveResponse {
  trips: TripDateCycle[];
  services: ServiceDateCycle[];
  operation: string;
}
export interface TripDespatchResponse {
  trips: TripDateCycle[];
  services: ServiceDateCycle[];
  errors: any[];
}
export interface TripUndespatchResponse {
  trips: TripDateCycle[];
  operation: string;
}
export interface ServiceTripUI {
  status: any;
  driver: any;
  truck: any;
  trailerlead: any;
  trailertag: any;
  plannedstart: any;
  plannedend: any;
}
export interface ViewCustomer {
  abn: any;
  active: boolean;
  allowContPickupDrop: boolean;
  applyGST: boolean;
  cnFormat: number;
  cnFormatName: string;
  customBillingName1: string;
  customBillingName2: string;
  customBillingName3: string;
  customBillingValue1: string;
  customBillingValue2: string;
  customBillingValue3: string;
  customerId: string;
  customerName: string;
  debtorCode: string;
  fuelLevyChargeRate: any;
  fuelLevyPayRate: any;
  glCodeBranch: string;
  groupId: string;
  groupName: any;
  internalCustomer: boolean;
  invFormat: number;
  invFormatName: string;
  invUnit1: any;
  invUnit2: any;
  invUnit3: any;
  invUnit4: any;
  invUnit5: any;
  invUnit6: any;
  invUnit7: any;
  invUnit8: any;
  invoiceRemarksMode: number;
  invoiceRemarksModeName: string;
  loadNoMaxLen: any;
  loadNoMinLen: any;
  numericLoadNo: boolean;
  personBillingName: string;
  personContactName: any;
  personIdBilling: number;
  personIdContact: any;
  scheduleEntryForm: string;
  scheduledImportFunction: string;
  siteId: number;
  uniqueLoadNo: boolean;
}
export interface ViewContainers {
  companyId: string;
  containerDesc: string;
  containerId: string;
  containerStatusId: string;
  containerType: string;
  dropDate: number;
  locationId: string;
  onHire: boolean;
  permanent: boolean;
  pickupDate: number;
  siteId: number;
  statusUdpdated: number;
  weightTonnes: number;
}
export interface ServiceTypes {
  active: boolean;
  allowBonusPay: boolean;
  allowNoRunsheet: boolean;
  allowZeroChargeAmt: boolean;
  applyDiscount: any;
  applyFuelLevy: boolean;
  applyRoute: boolean;
  categoryId: any;
  createInvoiceLine: boolean;
  customerId: any;
  defaultQty1: number;
  defaultQty2: any;
  defaultQty3: any;
  defaultQty4: any;
  defaultQty5: any;
  defaultQty6: any;
  defaultQty7: any;
  defaultQty8: any;
  disableTripRating: boolean;
  hireContainer: boolean;
  hireTrailer: boolean;
  hireTruck: boolean;
  labelContDrop: any;
  labelContPickup: any;
  labelDrop: any;
  labelDropArrTime: any;
  labelDropDocTime: any;
  labelDropDptTime: any;
  labelDropRdyTime: any;
  labelLoadLocation: any;
  labelPickup: any;
  labelPickupArrTime: any;
  labelPickupDocTime: any;
  labelPickupDptTime: any;
  labelPickupRdyTime: any;
  loadTypeIdPref: string;
  maxQty1: number;
  maxQty2: any;
  maxQty3: any;
  maxQty4: any;
  maxQty5: any;
  maxQty6: any;
  maxQty7: any;
  maxQty8: any;
  mdAllowCancel: boolean;
  mdAllowLoadNoEdit: boolean;
  mdAllowReject: boolean;
  mdAllowRequest: boolean;
  mdTimeMapArrDrop: any;
  mdTimeMapArrPickup: any;
  mdTimeMapDockDrop: any;
  mdTimeMapDockPickup: any;
  mdTimeMapDptDrop: any;
  mdTimeMapDptPickup: any;
  mdTimeMapRdyDrop: any;
  mdTimeMapRdyPickup: any;
  mdtException: boolean;
  onRunsheets: boolean;
  printOrder: any;
  reqContainer: boolean;
  reqDocket: boolean;
  reqDropArrTemp: boolean;
  reqDropArrTime: boolean;
  reqDropDocTemp: boolean;
  reqDropDocTime: boolean;
  reqDropDptTemp: boolean;
  reqDropDptTime: boolean;
  reqDropLocation: boolean;
  reqDropRdyTemp: boolean;
  reqDropRdyTime: boolean;
  reqPickupArrTemp: boolean;
  reqPickupArrTime: boolean;
  reqPickupDocTemp: boolean;
  reqPickupDocTime: boolean;
  reqPickupDptTemp: boolean;
  reqPickupDptTime: boolean;
  reqPickupLocation: boolean;
  reqPickupRdyTemp: boolean;
  reqPickupRdyTime: boolean;
  reqTrailer: boolean;
  reqTruck: boolean;
  reqUnit1: boolean;
  reqUnit2: boolean;
  reqUnit3: boolean;
  reqUnit4: boolean;
  reqUnit5: boolean;
  reqUnit6: boolean;
  reqUnit7: boolean;
  reqUnit8: boolean;
  runsheetCalcId1: any;
  runsheetCalcId2: any;
  runsheetCalcId3: any;
  runsheetCalcId4: any;
  runsheetCalcId5: any;
  runsheetCalcId6: any;
  runsheetCalcId7: any;
  runsheetCalcId8: any;
  serviceTypeDescription: string;
  serviceTypeId: string;
  showContainer: boolean;
  showContainerDrop: boolean;
  showContainerPickup: boolean;
  showDocket: boolean;
  showDropArrTemp: boolean;
  showDropArrTime: boolean;
  showDropDocTemp: boolean;
  showDropDocTime: boolean;
  showDropDptTemp: boolean;
  showDropDptTime: boolean;
  showDropLocation: boolean;
  showDropRdyTemp: boolean;
  showDropRdyTime: boolean;
  showLoad: boolean;
  showLoadLocation: boolean;
  showOffSiderUsed: boolean;
  showOwnTrailer: boolean;
  showPickupArrTemp: boolean;
  showPickupArrTime: boolean;
  showPickupDocTemp: boolean;
  showPickupDocTime: boolean;
  showPickupDptTemp: boolean;
  showPickupDptTime: boolean;
  showPickupLocation: boolean;
  showPickupRdyTemp: boolean;
  showPickupRdyTime: boolean;
  showTrailer: boolean;
  showTrailerTag: boolean;
  showTruck: boolean;
  singleTripRunsheets: boolean;
  siteId: number;
  sortOrder: any;
  tempDecimalPlaces: any;
  unit1: any;
  unit2: any;
  unit3: any;
  unit4: any;
  unit5: any;
  unit6: any;
  unit7: any;
  unit8: any;
}
export interface HomeLocations {
  active: boolean;
  homeLocationDesc: string;
  homeLocationId: string;
  siteId: number;
}
export interface FilterTable{
  type:string;
}

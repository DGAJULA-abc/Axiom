import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QlrMenuComponent } from './qlr-menu.component';

describe('QlrMenuComponent', () => {
  let component: QlrMenuComponent;
  let fixture: ComponentFixture<QlrMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QlrMenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QlrMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

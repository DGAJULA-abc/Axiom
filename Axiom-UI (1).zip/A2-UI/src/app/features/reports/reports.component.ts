import {
  AfterViewChecked,
  Component,
  OnInit,
  ChangeDetectorRef,
} from '@angular/core';
import { ReportService } from './services/report.service';
import { ViewReport } from './model/report.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
})
export class ReportsComponent implements OnInit {
  isClicked = false;
  public viewDetails: ViewReport;
  constructor(private reportService: ReportService, private router: Router ) {}

  ngOnInit(): void {

    this.getReportViewDetails();

    if (this.router.url.endsWith('Report.QLRMenu')) {
      this.isClicked = true;
    }
  }

  onQlrMenuClick() {
    this.isClicked = true;
  }

  getReportViewDetails() {    
    this.reportService.getReportViewDetails()
      .subscribe(
        (result: any) => {
          this.viewDetails = result;
          this.reportService.viewReport = result;
        }
      );       
  }
}

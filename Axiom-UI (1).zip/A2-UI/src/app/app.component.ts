import { Component } from '@angular/core';
// import { en_Global } from './transalation/en_Global.const'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'axioms';
  showHeader = true;

  constructor(){
    // disable header for some pages.
    if (window.location.pathname === '/reportview') {
      this.showHeader = false;
    }   
  }
}

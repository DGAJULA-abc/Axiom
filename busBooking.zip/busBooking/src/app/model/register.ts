export interface User {
    id: number;
    username: string;
    password: string;
    roles: string[];
    gender: string;
    contact: number;
    age: number;
    gmail: string;
    firstName: string;
    lastName: string;
  }
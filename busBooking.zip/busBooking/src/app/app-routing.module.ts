import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { BookingComponent } from './components/booking/booking.component';
import { BusesComponent } from './components/buses/buses.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { UserBookingsComponent } from './components/user-bookings/user-bookings.component';

const routes: Routes = [
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'booking', component: BookingComponent },
  { path: 'buses', component: BusesComponent },
  { path: 'nav', component: NavbarComponent },
  { path: '', redirectTo: '/register', pathMatch: 'full' },
  { path: 'user-bookings/:userId', component: UserBookingsComponent },
  { path: 'booking/:id', component: BookingComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

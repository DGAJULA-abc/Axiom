// buses.component.ts
import { Component, OnInit } from '@angular/core';
import { BusService } from '../../services/bus.service';

@Component({
  selector: 'app-buses',
  templateUrl: './buses.component.html',
  styleUrls: ['./buses.component.css']
})
export class BusesComponent implements OnInit {
  buses: any[] = [];

  constructor(private busService: BusService) {}

  ngOnInit() {
    this.getBusesData();
    const userId = localStorage.getItem('userId'); // Adjust this based on your actual logic
    console.log(userId);
  }

  getBusesData() {
    this.busService.getAllBuses().subscribe(data => {
      this.buses = data;
      console.log(this.buses);
    });
  }
}

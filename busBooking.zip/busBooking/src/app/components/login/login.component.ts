import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  zoneForm!: FormGroup;
  data: any[] = [];

  constructor(private fb: FormBuilder, private router: Router, private auth: AuthService) {}

  ngOnInit() {
    this.zoneForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.zoneForm.valid) {
      this.auth.loginApp(this.zoneForm.value).subscribe(response => {
        localStorage.setItem('token', response.token);
        alert('Login successful');
        this.router.navigate(['/buses']);
      }, error => {
        alert('Login failed');
      });
    }
  }

  onCancel() {
    this.router.navigate(['/register']);
  }
}

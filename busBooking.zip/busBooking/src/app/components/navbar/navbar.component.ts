import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  mobileQuery: any ;
  isLoggedIn: boolean = false; 
  constructor(private route: Router, private authService: AuthService){
    this.authService.isLoggedIn.subscribe(loggedIn => {
      this.isLoggedIn = loggedIn;
    });
  }
  onLogin(){
    this.authService.login();
    this.route.navigate(['/login'])
  }
  signUp(){
    this.route.navigate([''])
  }
  onLogout(){
    this.authService.logout();
    this.route.navigate([''])
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from '../../services/booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  booking: any = {
    user: { id: null },
    bus: { id: null },
    bookingDate: ''
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private bookingService: BookingService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.booking.bus.id = +params['id']; // Pre-fill bus ID from route parameters
    });
    const storedUserId = localStorage.getItem('userId'); // Adjust this based on your actual logic
    if (storedUserId) {
      this.booking.user.id = +storedUserId;
    }
  }

  bookTicket(): void {
    this.bookingService.bookTicket(this.booking).subscribe(response => {
      console.log('Booking successful:', response);
      this.router.navigate(['/user-bookings', this.booking.user.id]);
    }, error => {
      console.error('Error booking ticket:', error);
    });
  }
}

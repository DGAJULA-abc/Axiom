import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  zoneForm!: FormGroup;
  userExistsError: string | null = null;
  data: any[] = [];
  roles: string[] = ['Admin', 'User'];
  gender: string[] = ['Male', 'Female', 'Others'];

  constructor(private fb: FormBuilder, private auth: AuthService) { }

  ngOnInit() {
    this.zoneForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      roles: ['', Validators.required],
      gender: ['', Validators.required],
      contact: ['', Validators.required],
      age: ['', Validators.required],
      gmail: ['', [Validators.required, Validators.email]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      agreement: [false, Validators.requiredTrue]
    });
  }

  onSubmit() {
    if (this.zoneForm.valid) {
      this.auth.registerApp(this.zoneForm.value).subscribe((response: any) => {
        this.data = response;
        alert('User registered successfully');
      });
    }
  }

  onCancel() {
    this.zoneForm.reset();
    this.userExistsError = null;
  }
}

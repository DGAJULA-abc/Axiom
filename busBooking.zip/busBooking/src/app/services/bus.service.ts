// bus.service.ts
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BusService {
  private apiUrl = 'http://localhost:8080/bus';

  constructor(private http: HttpClient) {}

  getAllBuses(): Observable<any> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${localStorage.getItem('token')}`);
    return this.http.get(this.apiUrl, { headers });
  }

  getBusById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  addBuses(buses: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/list`, buses);
  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../model/register';
import { BehaviorSubject, Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);
  private baseUrl = 'http://localhost:8080/user';
  private urlRegister = `${this.baseUrl}/register`;
  private urlAuthenticate = `${this.baseUrl}/authenticate`;
  private urlCheckUserExists = `${this.baseUrl}/check-user-exists`;
  private authToken: string | null = null;
  constructor(private http: HttpClient) { }

  registerApp(data: any): Observable<User> {
    return this.http.post<User>(this.urlRegister, data);
  }

  loginApp(data: any): Observable<any> {
    return this.http.post<any>(this.urlAuthenticate, data).pipe(
      tap(response => {
        this.authToken = response.token; // Assuming the token is returned in the response
        this.login();
      })
    );
  }

  get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  login() {
    this.loggedIn.next(true);
  }

  logout() {
    this.loggedIn.next(false);
    this.authToken = null;
  }

  checkUserExists(username: string): Observable<boolean> {
    return this.http.get<boolean>(`${this.urlCheckUserExists}?username=${username}`);
  }

  getAuthToken(): string | null {
    return this.authToken; // Provide method to get the token
  }

}

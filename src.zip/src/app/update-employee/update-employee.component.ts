import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/modal/employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent {
  employee: Employee = new Employee();

  constructor(private employeeService: EmployeeService, private router: Router){

  }

  ngOnInit(): void {
  }

  saveEmployee(){
    this.employeeService.createEmployee(this.employee).subscribe( (data: any) => {
      console.log(data);
      this.goToEmployeeList();
    },
      (    error: any) => console.log(error));
  }

  goToEmployeeList(){
    this.router.navigate(['/employee']);
  }

  onSubmit(){
    console.log(this.employee);
    this.saveEmployee();
  }
}

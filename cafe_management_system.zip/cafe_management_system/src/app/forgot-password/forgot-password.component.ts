import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { SnackbarService } from '../services/snackbar.service';
import { GlobalConstants } from '../shared/global.constants';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent implements OnInit{
  forgotPasswordForm:any = FormGroup;
  responseMessage:any;
  
  registerSucess:boolean = false;
  isButtonVisible = true;

  constructor(private formBuilder:FormBuilder,
    private router:Router,
    private userService:UserService,
    public dialog: MatDialog,
    private snackbarService: SnackbarService ,
    public dialogRef:MatDialogRef<ForgotPasswordComponent>){
  
  }

  ngOnInit(): void {
    this.forgotPasswordForm= this.formBuilder.group({
      email:[null,[Validators.required , Validators.pattern(GlobalConstants.emailRegex)]]
    });
  }
  onSubmit(){
    var formData = this.forgotPasswordForm.value;
    var data = {
      email:formData.email
    }
    
    this.userService.forgotPassword(data).subscribe((response:any)=>{
      //this.ngxService.stop();
      this.dialogRef.close();
      this.responseMessage = response?.message;
      this.snackbarService.openSnackBar(this.responseMessage,"");
    },(error: { error: { message: any; }; })=>{
      //this.ngxService.stop();
      if(error.error?.message){
        this.responseMessage = error.error?.message;
      }else{
        this.responseMessage = GlobalConstants.genericError;
      }
      this.snackbarService.openSnackBar(this.responseMessage , GlobalConstants.error);
    })
    this.registerSucess=true; 
    this.isButtonVisible = false;   
  }

}

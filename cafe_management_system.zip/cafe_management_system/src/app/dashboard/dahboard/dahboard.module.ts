import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'; // Import RouterModule for 'forChild'
import { MaterialModule } from '../../material-component/material/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DashboardComponent } from '../dashboard.component';
import { DashboardRoutes } from '../dashboard.routing';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';


@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    MatCardModule,
    FlexLayoutModule,
    RouterModule.forChild(DashboardRoutes) ,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
  ],
  declarations: [DashboardComponent],
})
export class DashboardModule { }

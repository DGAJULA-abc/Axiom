import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { SnackbarService } from '../services/snackbar.service';
import { GlobalConstants } from '../shared/global.constants';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent implements OnInit{
  password = true;
  confirmPassword = true;
  signupForm:any = FormGroup;
  responseMessage:any;

constructor(private formBuilder:FormBuilder,
  private router:Router,
  private userService:UserService,
  public dialog: MatDialog,
  private snackbarService: SnackbarService ,
  public dialogRef:MatDialogRef<SignupComponent>){

}

  ngOnInit(): void {
   this.signupForm = this.formBuilder.group({
    name:[null , [Validators.required]],
    email:[null , Validators.required],
    contactNumber:[null , [Validators.required]],
    password:[null , Validators.required],
    confirmPassword:[null , [Validators.required]]
   })
  }
  onSubmit(){
    console.log("Hello", this.signupForm.value);
    var formDate = this.signupForm.value;
    var data = {
      name: formDate.name,
      email: formDate.email,
      contactNumber: formDate.contactNumber,
      password: formDate.password,
    }
    this.userService.signup(data).subscribe((ele: any) =>{
      this.dialogRef.close();
      this.responseMessage = ele?.message;
      this.snackbarService.openSnackBar(this.responseMessage,"");
      alert("Successfully Login");
      this.router.navigate(['/cafe/login']);
    }, (error) =>{
      if(error.error?.message){
        this.responseMessage = error.error?.message;
      }else{
        this.responseMessage = GlobalConstants.genericError;
      }
      this.snackbarService.openSnackBar(this.responseMessage , GlobalConstants.error);
    })
    }

  validateSubmit(){
    if(this.signupForm.controls['password'].value != this.signupForm.controls['confirmPassword'].value){
      return true;
    }else{
      return false;
    }
  }
}

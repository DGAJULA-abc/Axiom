import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
//  url = 'http://localhost:8081';
  url = environment.apiUrl;
  constructor(private httpClient:HttpClient) { }

  getDetails(){
    return this.httpClient.get(this.url + "/dashboard/details");
  }

}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { BestSellerComponent } from './best-seller/best-seller.component';
import { HomeComponent } from './home/home.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { SignupComponent } from './signup/signup.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { LoginComponent } from './login/login.component';
import { MatCardModule } from '@angular/material/card';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatFormFieldModule } from '@angular/material/form-field';
import { SharedModule } from './shared/shared.module';
import { DashboardModule } from './dashboard/dahboard/dahboard.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TokenInterceptorInterceptor } from './services/token-interceptor.interceptor';
import { HeaderComponent } from './layouts/full/header/header.component';
import { SidebarComponent } from './layouts/full/sidebar/sidebar.component';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { FullComponent } from './layouts/full/full.component';
import { ProductComponent } from './material-component/dialog/product/product.component';
import { ConfirmationComponent } from './material-component/dialog/confirmation/confirmation.component';
import { CategoryComponent } from './material-component/dialog/category/category.component';
import { ChangePasswordComponent } from './material-component/dialog/change-password/change-password.component';
import { ManageCategoryComponent } from './material-component/manage-category/manage-category.component';
import { ManageProductComponent } from './material-component/manage-product/manage-product.component';
import { MatTableModule } from '@angular/material/table';
import { ManageOrderComponent } from './material-component/manage-order/manage-order.component';
import { ManageUserComponent } from './material-component/manage-user/manage-user.component';
import { ViewBillComponent } from './material-component/view-bill/view-bill.component';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
@NgModule({
  declarations: [
    AppComponent,
    BestSellerComponent,
    HomeComponent,
    ForgotPasswordComponent,
    SignupComponent,
    LoginComponent,
    HeaderComponent,
    SidebarComponent,
    FullComponent,
    ProductComponent,
    ConfirmationComponent,
    CategoryComponent,
    ChangePasswordComponent,
    ManageCategoryComponent,
    ManageProductComponent,
    ManageOrderComponent,
    ManageUserComponent,
    ViewBillComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    MatButtonModule,
    MatMenuModule,
    MatIconModule, 
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    AppRoutingModule,
    MatDialogModule,
    MatInputModule,
    MatCardModule,
    MatSidenavModule,
    MatButtonModule,
    MatIconModule, 
    SharedModule,
    DashboardModule,
    MatListModule,
    MatTableModule,
    MatSelectModule,
    MatSlideToggleModule
  ],
  providers: [
    HttpClientModule, {provide:HTTP_INTERCEPTORS, useClass:TokenInterceptorInterceptor,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

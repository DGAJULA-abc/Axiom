import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-PQEU4F4K.js";
import "./chunk-OJOEFZDN.js";
import "./chunk-E4LXAG2G.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-WKYGNSYM.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
//# sourceMappingURL=@angular_cdk_bidi.js.map

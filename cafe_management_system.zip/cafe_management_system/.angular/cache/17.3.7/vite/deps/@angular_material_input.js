import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-5MJC5AWL.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-Y7TFU7L5.js";
import "./chunk-IBAI5NNK.js";
import "./chunk-RSCLFH3B.js";
import "./chunk-NAMPMKEM.js";
import "./chunk-ZFVW2RAU.js";
import "./chunk-237XUEJ5.js";
import "./chunk-EMZFKETF.js";
import "./chunk-OO2IHKJV.js";
import "./chunk-PQEU4F4K.js";
import "./chunk-RBYYBIZY.js";
import "./chunk-SMXFLPBF.js";
import "./chunk-OJOEFZDN.js";
import "./chunk-E4LXAG2G.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-WKYGNSYM.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map

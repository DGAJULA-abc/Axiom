import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-4JYPGXJY.js";
import "./chunk-3S2OUAB4.js";
import "./chunk-3SXWFKNJ.js";
import "./chunk-NAMPMKEM.js";
import "./chunk-ZFVW2RAU.js";
import "./chunk-237XUEJ5.js";
import "./chunk-EMZFKETF.js";
import "./chunk-OO2IHKJV.js";
import "./chunk-PQEU4F4K.js";
import "./chunk-RBYYBIZY.js";
import "./chunk-SMXFLPBF.js";
import "./chunk-OJOEFZDN.js";
import "./chunk-E4LXAG2G.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-WKYGNSYM.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
//# sourceMappingURL=@angular_material_icon.js.map

import {
  CdkObserveContent,
  ContentObserver,
  MutationObserverFactory,
  ObserversModule
} from "./chunk-EMZFKETF.js";
import "./chunk-RBYYBIZY.js";
import "./chunk-E4LXAG2G.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-WKYGNSYM.js";
export {
  CdkObserveContent,
  ContentObserver,
  MutationObserverFactory,
  ObserversModule
};
//# sourceMappingURL=@angular_cdk_observers.js.map

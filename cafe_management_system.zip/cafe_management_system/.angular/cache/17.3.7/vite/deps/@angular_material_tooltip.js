import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
} from "./chunk-S7PBLSSJ.js";
import "./chunk-RSCLFH3B.js";
import "./chunk-TAWK2DTX.js";
import "./chunk-NAMPMKEM.js";
import "./chunk-ZFVW2RAU.js";
import "./chunk-237XUEJ5.js";
import "./chunk-EMZFKETF.js";
import "./chunk-OO2IHKJV.js";
import "./chunk-MS53FBRT.js";
import "./chunk-R7NHJJEH.js";
import "./chunk-PQEU4F4K.js";
import "./chunk-RBYYBIZY.js";
import "./chunk-SMXFLPBF.js";
import "./chunk-H2HBIUW7.js";
import "./chunk-OJOEFZDN.js";
import "./chunk-E4LXAG2G.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-WKYGNSYM.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
};
//# sourceMappingURL=@angular_material_tooltip.js.map

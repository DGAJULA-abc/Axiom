import {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
} from "./chunk-5W27U7R2.js";
import "./chunk-R7NHJJEH.js";
import "./chunk-E4LXAG2G.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-WKYGNSYM.js";
export {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
};
//# sourceMappingURL=@angular_cdk_accordion.js.map

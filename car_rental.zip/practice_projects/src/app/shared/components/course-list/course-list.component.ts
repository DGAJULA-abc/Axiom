import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CourseService } from '../../../services/course.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']  // Correct path
})
export class CourseListComponent implements OnInit {  // Correctly declare the class name
  courseForm: FormGroup;
  selectedFile: File | null = null;
  fileError: boolean = false;
  courseId: any;  // Store courseId, null means "create" mode

  constructor(
    private fb: FormBuilder,
    private courseService: CourseService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    // Initialize form with validation rules
    this.courseForm = this.fb.group({
      description: ['', Validators.required],
      longDescription: ['', Validators.required],
      category: ['', Validators.required],
      lessonsCount: ['', [Validators.required, Validators.min(1)]],
    });
  }

  ngOnInit() {
    // Check if there is a courseId in the route to determine if we are in update mode
    this.courseId = this.route.snapshot.params['id'] ? +this.route.snapshot.params['id'] : null;
    if (this.courseId) {
      this.loadCourseDetails();  // Load course details if updating
    }
  }

  // Load course details for update
  loadCourseDetails() {
    this.courseService.getCourseById(this.courseId).subscribe(course => {
      this.courseForm.patchValue({
        description: course.description,
        longDescription: course.longDescription,
        category: course.category,
        lessonsCount: course.lessonsCount
      });
    });
  }

  // Handle form submission for both create and update
  onSubmit() {
    if (this.courseForm.valid) {
      const courseData = this.courseForm.value;
      const formData = new FormData();

      formData.append('description', courseData.description);
      formData.append('longDescription', courseData.longDescription);
      formData.append('category', courseData.category);
      formData.append('lessonsCount', courseData.lessonsCount.toString());

      // If a file is selected, append it
      if (this.selectedFile) {
        formData.append('iconFile', this.selectedFile);
      }

      // If courseId is present, update the course, otherwise create a new course
      if (this.courseId) {
        this.courseService.updateCourse(this.courseId, formData).subscribe(() => {
          console.log('Course updated successfully');
          this.router.navigate(['/dashboard']);
        });
      } else {
        this.courseService.createCourse(formData).subscribe(() => {
          console.log('Course created successfully');
          this.router.navigate(['/dashboard']);
        });
      }
    }
  }

  // Handle file selection and validation
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      if (!file.type.startsWith('image/')) {
        this.fileError = true;
      } else {
        this.fileError = false;
        this.selectedFile = file;
      }
    }
  }
}

// src/app/components/nav/nav.component.ts
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/auth.service';
import { UserService } from '../../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  isLoggedIn = false; // Track login status
  userId: number | null = null; // Holds the logged-in user's ID
  username: string | null = null; // Holds the logged-in user's username

  constructor(private authService: AuthService, private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.isLoggedIn = this.authService.isLoggedIn(); // Check login status

    // Subscribe to user changes in UserService
    this.userService.user$.subscribe(user => {
      if (user) {
        this.userId = user.userId; // Get the userId
        this.username = user.username; // Get the username
      } else {
        this.userId = null;
        this.username = null;
      }
    });
  }

  logout(): void {
    this.authService.logout(); // Log out the user
    this.isLoggedIn = false; // Update login status
    this.router.navigate(['/login']); // Redirect to login page
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { User } from '../../../model/User';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  userId!: number; // User ID to fetch from the route
  user!: User; // User object to hold the fetched user profile
  errorMessage!: string; // To display error messages

  constructor(
    private authService: AuthService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Get the user ID from route parameters
    this.route.params.subscribe(params => {
      this.userId = +params['id']; // Ensure it's a number
      this.getUserProfile();
    });
  }

  // Method to fetch user profile by userId
  getUserProfile(): void {
    this.authService.getUserById(this.userId).subscribe(
      (data: User) => {
        this.user = data; // Set the fetched user data
      },
      (error: any) => {
        this.errorMessage = 'Error fetching user profile: ' + error.message;
      }
    );
  }
}

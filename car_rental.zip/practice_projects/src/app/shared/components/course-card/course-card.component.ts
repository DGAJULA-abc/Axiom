import { Component, OnInit } from '@angular/core';
import { CourseCardService } from '../../../services/course-card.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-course-card',
  templateUrl: './course-card.component.html',
  styleUrls: ['./course-card.component.css']  // Corrected path to styleUrls
})
export class CourseCardComponent implements OnInit {
  courses: any[] = [];  // Initialize an empty array for courses

  constructor(private service: CourseCardService, private router: Router) {}

  ngOnInit() {
    this.getAllCourses();  // Load courses on initialization
  }

  // Fetch all courses from the service
  getAllCourses() {
    this.service.getAllCourses().subscribe((data: any) => {
      // Add a flipped property for toggling the flip effect
      this.courses = data.map((course: any) => ({ ...course, flipped: false }));
    });
  }

  // Toggle flip state for a specific course
  toggleFlip(courseId: number) {
    const course = this.courses.find(c => c.id === courseId);
    if (course) {
      course.flipped = !course.flipped;  // Toggle the flipped state
    }
  }

  // Use course ID for trackBy to improve rendering performance
  trackByCourseId(index: number, course: any): number {
    return course.id;
  }

  // Navigate to the create course page
  createCourse() {
    this.router.navigate(['/courseList']);  // Assumes /courseList is the route for creating a new course
  }

  // Navigate to the edit course page with the specific course ID
  editCourse(courseId: number) {
    this.router.navigate(['/edit-course', courseId]);
  }

  // Delete a course based on the ID
  deleteCourse(courseId: number) {
    if (confirm('Are you sure you want to delete this course?')) {
      this.service.deleteCourse(courseId).subscribe(() => {
        console.log(`Course with id ${courseId} deleted`);
        // Remove the course from the list after deletion
        this.courses = this.courses.filter(c => c.id !== courseId);
      });
    }
  }
}

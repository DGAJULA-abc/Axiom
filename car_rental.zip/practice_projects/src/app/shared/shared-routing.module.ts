import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedComponent } from './shared.component';
import { RegistrationComponent } from './login/registration/registration.component';
import { CourseCardComponent } from './components/course-card/course-card.component';
import { AuthGuard } from './auth.guard';
import { CourseListComponent } from './components/course-list/course-list.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './components/profile/profile.component';
const routes: Routes = [  { path: 'login', component: LoginComponent },
{ path: 'register', component: RegistrationComponent },
{ path: 'dashboard', component: CourseCardComponent, canActivate: [AuthGuard] },
{ path: 'edit-course/:id', component: CourseListComponent },
{ path: 'profile/:id', component: ProfileComponent },
{ path: 'courseList', component: CourseListComponent},
{ path: '', component: SharedComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedRoutingModule { }

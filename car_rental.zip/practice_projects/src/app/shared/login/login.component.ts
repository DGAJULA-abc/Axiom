import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']  // Corrected from styleUrl to styleUrls
})
export class LoginComponent implements OnInit {
  zoneForm!: FormGroup;
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router, private fb: FormBuilder) { }

  ngOnInit() {
    // Initialize the form with validators
    this.zoneForm = this.fb.group({
      username: ['', Validators.required], // Added Validators for required fields
      password: ['', Validators.required]
    });
  }

  login() {
    if (this.zoneForm.invalid) {
      this.errorMessage = 'Please fill in all fields.';
      return;
    }
  
    console.log(this.zoneForm.value);
    this.authService.login(this.zoneForm.value).subscribe(
      (response: string) => {  // Expecting a plain string (the token)
        localStorage.setItem('token', response); // Store token in localStorage
        console.log("Logged in successfully with token:", response);  // Log the token
        this.authService.setLoggedInStatus(true); // Update logged-in status
        this.router.navigate(['/dashboard']); // Redirect to dashboard after successful login
      },
      error => {
        this.errorMessage = 'Invalid username or password'; // Show error message on login failure
        console.error('Login error:', error); // Log the error for debugging
      }
    );
  }
  
}

import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  zoneForm!: FormGroup;
  updateProfileForm!: FormGroup;
  changePasswordForm!: FormGroup;
  userDetails: any; // Store user details for updating
  errorMessage: string = '';
  updateErrorMessage: string = '';
  passwordErrorMessage: string = '';
  updateSuccessMessage: string = '';
  passwordSuccessMessage: string = '';
  availableRoles: string[] = ['USER', 'ADMIN'];  // Define available roles

  constructor(private authService: AuthService, private router: Router, private fb: FormBuilder) {}

  ngOnInit() {
    // Initialize registration form
    this.zoneForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      education: ['', Validators.required],
      age: ['', [Validators.required, Validators.min(0)]],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      contact: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      roles: ['', Validators.required]  // Add validation for roles
    });

    // Initialize update profile form
    this.updateProfileForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      education: ['', Validators.required],
      age: ['',  Validators.required],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      contact: ['', Validators.required],
      username: ['', Validators.required]
    });

    // Initialize change password form
    this.changePasswordForm = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword: ['',  Validators.required],
      confirmPassword: ['', Validators.required]
    });

    // Load user details
    this.getUserDetails();
  }

  register() {
    console.log("Dtails", this.zoneForm.value)
    const { firstName, lastName, education, age, dateOfBirth, gender, contact, username, password, roles } = this.zoneForm.value;

      this.authService.register(username, password, [roles], firstName, lastName, education, age, dateOfBirth, gender, contact).subscribe(
        response => {
          this.router.navigate(['/dashboard']);
        },
      );
  }

  getUserDetails(): void {
    this.authService.getUserDetails().subscribe(
      (data: any) => {
        this.userDetails = data; // Assign the received user details
        // Populate update profile form with existing user data
        this.updateProfileForm.patchValue(this.userDetails);
      },
      (error: any) => {
        console.error('Error fetching user details:', error);
      }
    );
  }

  updateProfile() {
    if (this.updateProfileForm.valid) {
      const updatedData = this.updateProfileForm.value;
      
      this.authService.updateProfile(updatedData).subscribe(
        (response: any) => {
          this.updateSuccessMessage = 'Profile updated successfully.';
          this.getUserDetails(); // Reload user details
        },
        (error: any) => {
          this.updateErrorMessage = 'Profile update failed. Please try again.';
        }
      );
    } else {
      this.updateErrorMessage = 'Please fill in the update form correctly.';
    }
  }

  changePassword() {
    if (this.changePasswordForm.valid) {
      const { currentPassword, newPassword, confirmPassword } = this.changePasswordForm.value;

      if (newPassword !== confirmPassword) {
        this.passwordErrorMessage = 'Passwords do not match.';
        return;
      }

      this.authService.changePassword(currentPassword, newPassword).subscribe(
        (response: any) => {
          this.passwordSuccessMessage = 'Password changed successfully.';
          this.changePasswordForm.reset(); // Reset form after success
        },
        (error: any) => {
          this.passwordErrorMessage = 'Password change failed. Please try again.';
        }
      );
    } else {
      this.passwordErrorMessage = 'Please fill in the change password form correctly.';
    }
  }

  deleteAccount() {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      this.authService.deleteUser().subscribe(
        (response: any )=> {
          alert('Account deleted successfully.');
          this.router.navigate(['/login']); // Redirect to login page
        },
        (error: any) => {
          console.error('Error deleting account:', error);
          alert('Account deletion failed. Please try again.');
        }
      );
    }
  }
}

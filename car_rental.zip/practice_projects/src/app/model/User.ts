export interface User {
  id: number;
  firstName: string;
  lastName: string;
  education: string;
  age: number;
  gender: string;
  contact: string;
  username: string;
  // Add other fields as necessary
}

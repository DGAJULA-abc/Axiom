import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegistrationComponent } from './shared/login/registration/registration.component';
import { CourseCardComponent } from './shared/components/course-card/course-card.component';
import { AuthGuard } from './shared/auth.guard';

const routes: Routes = [
   // Only accessible after login
//  { path: '', redirectTo: '/register', pathMatch: 'full' },
  { path: '', loadChildren: () => import('./shared/shared.module').then(m => m.SharedModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

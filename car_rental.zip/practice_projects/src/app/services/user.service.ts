import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userSubject = new BehaviorSubject<any>(null);
  public user$ = this.userSubject.asObservable();

  // Method to set the user details when logging in
  setUser(user: { userId: number, username: string }): void {
    this.userSubject.next(user);
  }

  // Method to clear user details on logout
  clearUser(): void {
    this.userSubject.next(null);
  }
}

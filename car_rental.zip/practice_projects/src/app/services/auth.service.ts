import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { User } from '../model/User';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private authUrl = 'http://localhost:8080/api/auth';  // Replace with your actual API endpoint

  constructor(private http: HttpClient, private userService: UserService) { }
  private loggedInStatus = new BehaviorSubject<boolean>(this.isLoggedIn());
  // Login method
  login(data: { username: string, password: string }): Observable<any> {
    return this.http.post(`${this.authUrl}/login`, data, { responseType: 'text' }).pipe(
      tap((response) => {
        // Here, we assume the response is just the token as a string
        const token = response; // response is the token string
        localStorage.setItem('token', token); // Store token
        
        // Optionally, if your API returns userId, you may need to get it in a different way
        // For now, assuming you get userId via another API call or from the token payload.
        // const userId = this.decodeToken(token).userId; // Example of decoding if needed
        // localStorage.setItem('userId', userId); // Store userId
      })
    );
  }

  // Registration method
  register(username: string, password: string, roles: string[], firstName: string, lastName: string, education: string, age: number, dateOfBirth: string, gender: string, contact: string) {
    const registrationData = { username, password, roles, firstName, lastName, education, age, dateOfBirth, gender, contact };
    return this.http.post(`${this.authUrl}/register`, registrationData);
  }
  deleteUser(): Observable<any> {
    return this.http.delete(`${this.authUrl}/delete-user`); // Adjust endpoint as necessary
  }

  updateProfile(updatedData: any): Observable<any> {
    return this.http.put(`${this.authUrl}/update-profile`, updatedData);
  }

  changePassword(currentPassword: string, newPassword: string): Observable<any> {
    return this.http.post(`${this.authUrl}/change-password`, { currentPassword, newPassword });
  }
  setLoggedInStatus(status: boolean): void {
    this.loggedInStatus.next(status);
  }

  getLoggedInStatus(): Observable<boolean> {
    return this.loggedInStatus.asObservable();
  }

  // Check if the user is logged in
  isLoggedIn(): boolean {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return !!localStorage.getItem('token');
      }
    } catch (error) {
      console.error('Error accessing localStorage:', error);
    }
    return false;
  }

  // Logout method
  logout(): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.removeItem('token');
        this.setLoggedInStatus(false);
      }
    } catch (error) {
      console.error('Error accessing localStorage:', error);
    }
  }
  // Get user details after login
  getUserDetails(): Observable<User> {
    const userId = localStorage.getItem('userId');
    return this.http.get<User>(`${this.authUrl}/user/${userId}`);
  }
  getToken(): string | null {
    return localStorage.getItem('token'); // Assuming you store the token in localStorage
  }
  getUserById(userId: number): Observable<User> {
    return this.http.get<User>(`${this.authUrl}/user/${userId}`);
  }
}

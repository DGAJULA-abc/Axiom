import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Course } from '../model/Course';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseCardService {

  constructor(private http: HttpClient) { }
   
  private baseUrl = 'http://localhost:8080/api/courses';
 getAllCourses(): Observable<Course[]> {
  return this.http.get<Course[]>(this.baseUrl);
}
  // Delete a course by ID
  deleteCourse(courseId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${courseId}`);
  }

  // Fetch course by ID (for editing)
  getCourseById(courseId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${courseId}`);
  }

  // Update an existing course
  updateCourse(courseId: number, courseData: FormData): Observable<any> {
    return this.http.put(`${this.baseUrl}/${courseId}`, courseData);
  }
 
}

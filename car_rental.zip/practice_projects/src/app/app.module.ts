import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { CourseCardComponent } from './shared/components/course-card/course-card.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
// import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './shared/login/registration/registration.component';
import { JwtInterceptor } from './services/jwt.interceptor';
import { AuthGuard } from './shared/auth.guard';
import { NavComponent } from './shared/components/nav/nav.component';
import { CourseListComponent } from './shared/components/course-list/course-list.component';

@NgModule({
  declarations: [
    AppComponent,
    CourseCardComponent,
    // LoginComponent,
    RegistrationComponent,
    NavComponent,
    CourseListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    HttpClientModule,
    MatIconModule,
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync(),
    AuthGuard,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

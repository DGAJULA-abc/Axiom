import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  zoneForm!: FormGroup;
  password = true;
  confirmPassword = true;
  data: any[] = [];
  constructor(private fb: FormBuilder, private auth: AuthService) {}

  ngOnInit() {
    this.zoneForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      checkPassword: ['', Validators.required]
    }, { validator: this.passwordMatchValidator });
  }

  onSubmit() {
    if (this.zoneForm.valid) {
      console.log(this.zoneForm.value);
      this.auth.register(this.zoneForm.value).subscribe((response: any) =>{
        this.data = response;
        console.log("successfully Registered", response);
      })
    }
  }

  passwordMatchValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const password = control.get('password');
    const checkPassword = control.get('checkPassword');
    if (password && checkPassword && password.value !== checkPassword.value) {
      return { passwordMismatch: true };
    }
    return null;
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth/auth.service';
import { StorageService } from '../../services/storage/storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  zoneForm!: FormGroup;
  password = true;
  data: any[] = [];
  constructor(private fb: FormBuilder, private auth: AuthService, private route: Router){

  }
  ngOnInit(){
    this.zoneForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }
  onSubmit(){
    console.log(this.zoneForm.value);
    this.auth.login(this.zoneForm.value).subscribe((response: any) =>{
      this.data = response;
      console.log(response);
      if(response.userId != null){
        const user = {
          id: response.userId,
          role: response.userRole
        }
        StorageService.saveUser(user);
        StorageService.saveToken(response.jwt);
       if( StorageService.isAdminLoggedIn()){
        this.route.navigateByUrl("/admin/dashboard")
       }else if( StorageService.isCustomerLoggedIn()){
        this.route.navigateByUrl("/customer/dashboard")
       }else{
        console.log("bad credentilas")
       }

      }
    });
  }
}

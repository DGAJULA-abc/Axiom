import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }
  BASE_URL = `http://localhost:8080/api/auth`;

  register(signupRequest: any){
    return this.http.post(this.BASE_URL+"/signup", signupRequest);
  }

  login(loginRequest: any){
    return this.http.post(this.BASE_URL+"/login", loginRequest);
  }
}

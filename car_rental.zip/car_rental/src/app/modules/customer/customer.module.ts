import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerRoutingModule } from './customer-routing.module';
import { CustmerDashboardComponent } from './custmer-dashboard/custmer-dashboard.component';


@NgModule({
  declarations: [
    CustmerDashboardComponent
  ],
  imports: [
    CommonModule,
    CustomerRoutingModule
  ]
})
export class CustomerModule { }

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustmerDashboardComponent } from './custmer-dashboard/custmer-dashboard.component';

const routes: Routes = [
  {path: "dashboard", component: CustmerDashboardComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule { }

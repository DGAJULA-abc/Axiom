import { Component } from '@angular/core';

@Component({
  selector: 'app-custmer-dashboard',
  templateUrl: './custmer-dashboard.component.html',
  styleUrl: './custmer-dashboard.component.css'
})
export class CustmerDashboardComponent {

}

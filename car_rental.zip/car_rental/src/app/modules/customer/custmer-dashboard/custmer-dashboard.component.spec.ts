import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustmerDashboardComponent } from './custmer-dashboard.component';

describe('CustmerDashboardComponent', () => {
  let component: CustmerDashboardComponent;
  let fixture: ComponentFixture<CustmerDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustmerDashboardComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustmerDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-car',
  templateUrl: './post-car.component.html',
  styleUrls: ['./post-car.component.css']
})
export class PostCarComponent implements OnInit {
  postCarForm!: FormGroup;
  isSpinning: boolean = false;
  selectedFile: File | null = null;
  imagePreview: string | ArrayBuffer | null = null;
  listOfBrands = ["BMW", "AUDI", "FERRARI", "TESLA", "VOLVO", "TOYOTA", "HONDA", "FORD", "NISSAN", "HYUNDAI", "LEXUS", "KIA"];
  listOfType = ["Petrol", "Hybrid", "Diesel", "Electric", "CNG"];
  listOfColor = ["Red", "White", "Blue", "Black", "Orange", "Gray", "Silver"];
  listOfTransmission = ["Manual", "Automatic"];
  data: any[] = [];
  constructor(private fb: FormBuilder, private adminService: AdminService, private router: Router) { }

  ngOnInit() {
    this.postCarForm = this.fb.group({
      name: ['', Validators.required],
      brand: ['', Validators.required],
      type: ['', Validators.required],
      color: ['', Validators.required],
      transmission: ['', Validators.required],
      price: ['', Validators.required],
      description: ['', Validators.required],
      year: ['', Validators.required],
    });
  }

  onFileSelected(event: any): void {
    const file: File = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result;
      };
      reader.readAsDataURL(file);
    }
  }

  onSubmit() {
    if (this.postCarForm.valid) {
      this.isSpinning = true;
      const formData = new FormData();
      formData.append('name', this.postCarForm.get('name')!.value);
      formData.append('brand', this.postCarForm.get('brand')!.value);
      formData.append('type', this.postCarForm.get('type')!.value);
      formData.append('color', this.postCarForm.get('color')!.value);
      formData.append('transmission', this.postCarForm.get('transmission')!.value);
      formData.append('price', this.postCarForm.get('price')!.value);
      formData.append('description', this.postCarForm.get('description')!.value);
      formData.append('year', this.postCarForm.get('year')!.value);

      if (this.selectedFile) {
        formData.append('file', this.selectedFile);
      }

      this.adminService.postCar(formData).subscribe((res: any) => {
        this.isSpinning = false;
        this.data = res;
        console.log(res);
        this.router.navigateByUrl("/admin/dashboard");
      }, error => {
        console.error(error);
        this.isSpinning = false;
      });
    }
  }
}

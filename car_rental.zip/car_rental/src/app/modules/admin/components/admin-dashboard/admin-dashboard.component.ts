import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../service/admin.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit{
  data: any[] = [];
  constructor(private adminService: AdminService){

  }
  ngOnInit() {
    this.getAllCars();
  }

  getAllCars() {
    this.adminService.getAllCars().subscribe((res: any) => {
      this.data = res.map((element: any) => {
        return {
          ...element,
          processedimg: 'data:image/jpeg;base64,' + element.retunedImage  // Ensure the correct mime type
        };
      });
      console.log("-----------------------", this.data);
    });
  }

  deleteCar(id: number) {
    this.adminService.deleteCar(id).subscribe(() => {
      this.getAllCars();
    }, error => {
      console.error('Error deleting car', error);
    });
  }
}

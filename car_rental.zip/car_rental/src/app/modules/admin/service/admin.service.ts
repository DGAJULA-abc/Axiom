import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { StorageService } from '../../../auth/services/storage/storage.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  BASE_URL = `http://localhost:8080/api/admin`;

  constructor(private http: HttpClient) { }

  postCar(carDto: FormData): Observable<any>{
    return this.http.post(this.BASE_URL + "/car", carDto, {
      headers: this.createAuthorization()
    });
  }

  getAllCars(): Observable<any>{
    return this.http.get(this.BASE_URL+ "/cars", {
      headers: this.createAuthorization()
    });
  }

  deleteCar(id: number): Observable<any> {
    return this.http.delete(this.BASE_URL + "/car/" + id, {
      headers: this.createAuthorization()
    });
  }

  createAuthorization(): HttpHeaders {
    let authHeader: HttpHeaders = new HttpHeaders();
    return authHeader.set(
      "Authorization",
      "Bearer " + StorageService.getToken()
    );
  }
}
